var Exception = require('../models/exception.js');

module.exports = {

    addException: (req, res) => {

        if (!req.body.code || !req.body.message) return res.status(400).send('Invaild request');

        var newException = new Exception({
            code: req.body.code,
            created_at: new Date(),
            updated_at: new Date(),
            message: req.body.message,
        });

        newException.save((err) => {

            if (err) return res.status(400).send('Invaild request');

            res.status(200).send('Exception got saved successfully!');

        });
    },

    getExceptions: (req, res) => {

        Exception.find({}, (err, exceptions) => {

            if (err) return res.status(400).send('Connection Error');

            res.status(200).send(exceptions);

        });
    },

    getException: (req, res) => {

        if (!req.params.code) return res.status(400).send('Connection Error');

        Exception.findOne({ code: req.params.code }, (err, exceptions) => {

            if (err) return res.status(400).send('Connection Error');

            res.status(200).send(exceptions);

        });

    },

    updateException: (req, res) => {

        if (!req.params.code || !req.body.message) return res.status(400).send('Connection Error');

        Exception.update({ code: req.params.code }, { message: req.body.message }, (err) => {

            if (err) return res.status(400).send('Invaild request');

            res.status(200).send('updated successfully!');

        });

    },

    removeException: (req, res) => {

        if (!req.params.code) return res.status(400).send('Connection Error');

        Exception.remove({ code: req.params.code }, (err) => {

            if (err) return res.status(400).send('Connection Error');

            res.status(200).send('Deleted successfully!');

        });
    }
}
