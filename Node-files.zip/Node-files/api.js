const express = require('express');
const router = express.Router();

const exceptionHandler = require('../handlers/exceptionhandler');


/* GET api listing. */
router.get('/', (req, res) => {
    res.send('api works');
});

router.get('/exceptions', exceptionHandler.getExceptions);
router.get('/exception/:code', exceptionHandler.getException);
router.post('/exception', exceptionHandler.addException);
router.put('/exception/:code', exceptionHandler.updateException);
router.delete('/exception/:code', exceptionHandler.removeException);

module.exports = router;