const express = require('express');
const router = express.Router();
var exception = require('../handlers/exceptionhandler.js');
/* GET api listing. */
router.get('/', (req, res) => {
  res.send('api works');
});

// router.get('/addException', (req, res) => {
//    exception(req, res);
//   res.send('api ');
// });

router.post('/postapi', (req, res) => {
  let result = req.body.code + '' + req.body.message;
  res.send(result);
});

router.post('/addException', (req, res) => {
  exception(req, res);
  res.send('Exception works');
});

module.exports = router;