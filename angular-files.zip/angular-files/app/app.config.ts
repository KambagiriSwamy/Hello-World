
//api endpoints
const baseUrl = 'http://localhost:3000/api';
export const appConfig = {
    exceptionUrl: baseUrl + '/exception'
}