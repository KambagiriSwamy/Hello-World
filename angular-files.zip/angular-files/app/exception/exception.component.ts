import { Component, OnInit } from '@angular/core';

import { Exception } from './exception.model';
import { ExceptionService } from './exception.service';

@Component({
  selector: 'app-exception',
  templateUrl: './exception.component.html',
  styleUrls: ['./exception.component.css'],
  providers: [ExceptionService]
})
export class ExceptionComponent implements OnInit {

  isNewException = false;
  isGetException = false;
  isUpdateException = false;
  isDeleteException = false;
  
  constructor(public exceptionService: ExceptionService) { }

  ngOnInit() {
  }

  saveException(code, message) {
    if (!code || !message) return;
    let exception = new Exception(code, message);
    this.exceptionService.saveException(exception)
      .subscribe((res) => {
        //process response
        alert('success! see the console for result');
        console.log('res', res);
      }, (err) => {
        //handle error here
        alert('error! see the console for details');
        console.log(err);
      });
  }

  getException(code: number) {
    if (!code) return;
    this.exceptionService.getException(code)
      .subscribe((res) => {
        //process response
        alert('success! see the console for result');
        console.log('res', res);
      }, (err) => {
        //handle error here
        alert('error! see the console for details');
        console.log(err);
      });
  }

  // updateException(code: number) {
  //   if (!code) return;
  //   this.exceptionService.updateException(code)
  //     .subscribe((res) => {
  //       //process response
  //       alert('success! see the console for result');
  //       console.log('res', res);
  //     }, (err) => {
  //       //handle error here
  //       alert('error! see the console for details');
  //       console.log(err);
  //     });
  // }

  // deleteException(code: number) {
  //   if (!code) return;
  //   this.exceptionService.deleteException(code)
  //     .subscribe((res) => {
  //       //process response
  //       alert('success! see the console for result');
  //       console.log('res', res);
  //     }, (err) => {
  //       //handle error here
  //       alert('error! see the console for details');
  //       console.log(err);
  //     });
  // }

  // getExceptions() {
  //   this.exceptionService.getExceptions()
  //     .subscribe((res) => {
  //       //process response
  //       alert('success! see the console for list of exceptions');
  //       console.log('res', res);
  //     }, (err) => {
  //       //handle error here
  //       alert('error! see the console for details');
  //       console.log(err);
  //     });
  // }


}
