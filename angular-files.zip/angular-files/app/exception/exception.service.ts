import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

import { Exception } from './exception.model';
import { appConfig } from '../app.config';

@Injectable()
export class ExceptionService {


    constructor(public http: Http) { }

    saveException(exception: Exception) {
        return this.http.post(appConfig.exceptionUrl, { code: exception.code, message: exception.message });
    }

    getException(code: number) {
        return this.http.get(appConfig.exceptionUrl + '/' + code);
    }

    updateException(code: number) {
        return this.http.get(appConfig.exceptionUrl + '/' + code);

    }

    deleteException(code: number) {
        return this.http.get(appConfig.exceptionUrl + '/' + code);
    }

    getExceptions(){
        return this.http.get('htto://localhost:3000/api/exceptions');
    }


}