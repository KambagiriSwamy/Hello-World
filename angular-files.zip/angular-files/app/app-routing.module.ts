
import { Routes, RouterModule } from '@angular/router';

import { ExceptionComponent } from './exception/exception.component';

const appRoutes: Routes = [
    { path: '', redirectTo: 'exception', pathMatch: 'full' },
    { path: 'exception', component: ExceptionComponent }
    //   { path: '**', component: NotFound }, //always last
];

export const AppRouting = RouterModule.forRoot(appRoutes, {useHash:true});