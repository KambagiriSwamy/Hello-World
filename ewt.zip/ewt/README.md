# EWT management application

## What is done:


### FrontEnd
We have structured the frontend using a hybrid approach between MVC and feature driven architecture.

We are using the same `controller/view` to manage both creation and edit of campaigns as well to handle the 2 main roles
which are `manager` and `admin`, the code for cmapaign creation forms  logic live sin `campaign_management/new_campaign/` folder.
There the routes are configured, the controller is implemented as well as the `new_campaignSrv.js` which consolidates most of the controllers
data dependencies.


The Data dependencies declared in `new_campaignSrv.js`  are angular values for mock purposes, the most of this data should be retrieved from the server
and exposed using a service, by mocking then using angular.value allowed to make this transition smooth since you just need to replace the values with a service that
returns a similar data set.

Server Communication is handled by the `scripts/services/campaign.js` service. This services exposes a $resource class extended to support non standard behavior
like file uploads, default parameters and campaign state normalization. this will allow you to create your models for new or existing campaigns and use methods
like $save, $update to communicate with the server

#### What is left to do in the UI??

  * Authentication screens/services
    --Nothing is defined yet
  * Search screens/services
    -- the route/controller/view files are there, the ui needs to be designed and built. it should use
  the `Campaign.query(/*searchObject*/);` to get the results.
  * Desgin and implement the Dashboard
  * Review and Finish wiring the business logic on which fields/aactuators should be visible/enabled on each step and for which role
    -- in the `new_campaign.js` controller there are helper methods to handle report the state of the campaign
  * At the moment of this writing the upload functionallities are nor ready yet, so the UI is not wire for upload but there is
a sample function on `Camapign` service thatw ill serve as a guide.




#### Where is all my html??
In order for the views to mimic the app routing we kept them in the `views/routes/app` folder so they could kind a mimic the application flow.

#### Where is the userData comming from???
At this point the user is being mocked in `views/common/index.dust` as an angular eventually userData should be a service populated by the `authentication` service