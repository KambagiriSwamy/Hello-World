'use strict';
var data = {
  validCampaignObj: {
    "requestID": 17510,
    "createdOn": "2016-02-08T12:00:00Z",
    "endDate": "2016-03-16T12:00:00Z",
    "durationInWeeks": 2,
    "ma": {
      "maVersions": [],
      "instructionDocuments": [],
      "approvalDocuments": []
    },
    "espInstructions": "",
    "triggerRest": 12,
    "volumeCap": null,
    "conversionData": "Include detailed information about your campaign in this section. The Campaign Name must match your campaign approval documents. The Description must also be detailed and include information about the goal/objective of the campaign as well as an over",
    "description": "Include detailed information about your campaign in this section. The Campaign Name must match your campaign approval documents. The Description must also be detailed and include information about the goal/objective of the campaign as well as an overview of the targeting criteria. Please also include an initial draft or mock up of the creative.",
    "responsbilityCenter": "asdfasdfasdf",
    "budgetLine": "linea-12-2345",
    "isDynamicCampaign": false,
    "isMultiCMNeedCategory": false,
    "businessUnit": {
      "codeName": "BU_CCSG",
      "code": "U004",
      "name": "CCSG"
    },
    "emailType": {
      "codeName": "ET_ONEOFF",
      "name": "One Off",
      "code": "006"
    },
    "secondaryMarketingManager": {
      "markAsDeleted": false,
      "createdOn": "2016-01-25T10:00:14.695Z",
      "status": {
        "name": "Active",
        "codeName": "active",
        "code": "001"
      },
      "businessUnit": {
        "codeName": "BU_EGG",
        "code": "U023",
        "name": "Enterprise Growth Group (EGG)"
      },
      "role": {
        "code": "001",
        "codeName": "mm",
        "name": "manager"
      },
      "lastName": "arghese",
      "firstName": "Alfred T",
      "name": "Alfred T arghese",
      "email": "alfred.t.varghese@aexp.com",
      "phone": "212-624-9842",
      "value": "avargh3",
      "uid": "avargh3"
    },
    "primaryMarketingManager": {
      "markAsDeleted": false,
      "leader": {
        "email": "leader@aexp.com",
        "lastName": "leader",
        "firstName": "Dummy"
      },
      "lastLoggedOn": "2016-02-10T06:56:33.785Z",
      "createdOn": "2016-01-25T10:00:14.695Z",
      "status": {
        "name": "Active",
        "codeName": "active",
        "code": "001"
      },
      "businessUnit": {
        "codeName": "BU_EGG",
        "code": "U023",
        "name": "Enterprise Growth Group (EGG)"
      },
      "role": {
        "code": "001",
        "codeName": "mm",
        "name": "manager"
      },
      "lastName": "Guggino",
      "firstName": "Sarah E",
      "name": "Sarah E Guggino",
      "email": "Sarah.E.Guggino@aexp.com",
      "phone": "505-239-6368",
      "value": "sguggino",
      "uid": "sguggino"
    },
    "requestor": {
      "markAsDeleted": false,
      "leader": {
        "email": "leader@aexp.com",
        "lastName": "leader",
        "firstName": "Dummy"
      },
      "lastLoggedOn": "2016-02-08T06:38:53.876Z",
      "createdOn": "2016-01-25T10:00:14.695Z",
      "status": {
        "name": "Active",
        "codeName": "active",
        "code": "001"
      },
      "businessUnit": {
        "codeName": "BU_EGG",
        "code": "U023",
        "name": "Enterprise Growth Group (EGG)"
      },
      "role": {
        "code": "001",
        "codeName": "mm",
        "name": "manager"
      },
      "lastName": "Guggino",
      "firstName": "Sarah E",
      "name": "Sarah E Guggino",
      "email": "Sarah.E.Guggino@aexp.com",
      "phone": "505-239-6368",
      "value": "sguggino",
      "uid": "sguggino"
    },
    "name": "Oneoff date check",
    "state": {
      "code": "AID",
      "codeName": "submitted2admin",
      "name": "Pending Final Approval",
      "logDisplayName": "Pending Final Approval"
    },
    "sto": {
      "isSTO": true
    },
    "criticalDataUpdates": {
      "DEPLOYMENTDATES": false,
      "CELLS": false,
      "VERSIONS": false,
      "MHID": false
    },
    "isSubmittedToESP": true,
    "criticalDataSubmitted": [{
      "keys": {
        "REQR_CEY_DATE": "03/06/2026"
      }
    }, {
      "keys": {
        "REQR_CEY_DATE": "03/13/2026"
      }
    }, {
      "keys": {
        "REQR_CEY_DATE": "03/09/2026"
      }
    }, {
      "keys": {
        "REQR_CEY_DATE": "03/16/2026"
      }
    }, {
      "keys": {
        "REQR_CEY_DATE": "03/06/2026"
      }
    }, {
      "keys": {
        "REQR_CEY_DATE": "03/13/2026"
      }
    }, {
      "keys": {
        "REQR_CEY_DATE": "03/09/2026"
      }
    }, {
      "keys": {
        "REQR_CEY_DATE": "03/16/2026"
      }
    }],
    "espLoadDetails": [],
    "attachments": [{
      "gfsID": "56b86646cea85d302939af71",
      "fileName": "InstructionDoc.txt",
      "extension": ".txt",
      "size": "0",

      "type": {

        "code": "004",
        "codeName": "creative_governance",
        "name": "Creative Governance",
        "emailTypeCodes": ["008", "006"]
      },
      "creativeVersion": "0"
    }, {
      "gfsID": "56b86646cea85d302939af6f",
      "fileName": "ApprovalDoc.txt",
      "extension": ".txt",
      "size": "0",

      "creativeVersion": "1",
      "type": {

        "code": "003",
        "codeName": "html_version",
        "name": "HTML Version",
        "emailTypeCodes": ["012", "008", "006"]
      }
    }, {
      "gfsID": "56b86646cea85d302939af70",
      "fileName": "htmlVersion.txt",
      "extension": ".txt",
      "size": "0",

      "creativeVersion": "1",
      "type": {

        "code": "002",
        "codeName": "text_version",
        "name": "Text Version",
        "emailTypeCodes": ["012", "008", "006"]
      }
    }, {
      "gfsID": "56b86646cea85d302939af6e",
      "fileName": "testImage.bmp",
      "extension": ".bmp",
      "size": "0",

      "creativeVersion": "1",
      "type": {

        "code": "005",
        "codeName": "images",
        "name": "Images",
        "emailTypeCodes": ["012", "008", "006"]
      }
    }, {
      "gfsID": "56b86646cea85d302939af72",
      "fileName": "textVersion.txt",
      "extension": ".txt",
      "size": "0",

      "creativeVersion": "1",
      "type": {

        "code": "006",
        "codeName": "final_creative_preview",
        "name": "Final Creative Preview",
        "emailTypeCodes": ["012", "008", "006"]
      }
    }],
    "subjectLines": [],
    "versions": [{
      "complianceCode": "234234234324",
      "description": "Version1",
      "poid": "vers:0001",
      "number": 1,
      "subjects": [{
        "espInstructions": "subject",
        "subjectLine": "subject line 1"
      }],
      "cells": [{
        "type": {
          "name": "Mailable (Test)",
          "codeName": "test",
          "code": "T"
        },
        "description": "cell 1",
        "versionNo": 1,
        "srcCode": "CELL1"
      }, {
        "type": {
          "name": "Mailable (Test)",
          "codeName": "test",
          "code": "T"
        },
        "description": "cell 2",
        "versionNo": 1,
        "srcCode": "CELL2"
      }]
    }],
    "pznFields": [{

      "code": "CMFirstName",
      "codeName": "cmFirst",
      "name": "CM First Name",
      "description": "CM First Name",
      "reserved": true
    }, {

      "code": "CMMemberSinceDate",
      "codeName": "cmMember",
      "name": "CM Member Since Date",
      "description": "CM Member Since Date",
      "reserved": true
    }],
    "approversEmailList": ["test@aexp.com"],
    "deployEmailList": ["test@aexp.com"],
    "previewEmailList": ["test@aexp.com"],
    "mailHistory": [{
      "mhid": "MANNAR09"
    }],
    "comments": [],
    "deploymentDates": ["2017-03-06T12:00:00Z"],
    "log": [{
      "content": "Initiated",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T06:41:49.033Z"
    }, {
      "content": "Pending Initial Approval",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T09:49:58.025Z"
    }, {
      "content": "Request Approved",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T09:54:37.680Z"
    }, {
      "content": "Pending Final Approval",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T09:57:19.428Z"
    }, {
      "content": "Queued For ESP Submission",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T09:59:39.019Z"
    }, {
      "content": "Queued For ESP Submission",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T10:09:45.149Z"
    }, {
      "content": "Queued For ESP Submission",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T10:18:51.332Z"
    }, {
      "content": "Queued For ESP Submission",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T10:20:22.548Z"
    }, {
      "content": "Queued For ESP Submission",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T10:21:29.262Z"
    }, {
      "content": "Queued For ESP Submission",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T10:24:17.534Z"
    }, {
      "content": "Pending Final Approval",
      "userName": "ewt2.0",
      "timestamp": "2016-02-08T10:24:23.161Z"
    }, {
      "content": "Queued For ESP Submission",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-10T06:57:53.220Z"
    }, {
      "content": "Pending Final Approval",
      "userName": "ewt2.0",
      "timestamp": "2016-02-10T06:58:00.349Z"
    }, {
      "content": "Queued For ESP Submission",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-10T06:58:41.974Z"
    }, {
      "content": "Pending Final Approval",
      "userName": "ewt2.0",
      "timestamp": "2016-02-10T06:58:46.702Z"
    }],
    "cardProducts": [{
      "name": "Consumer Premium",
      "code": "x001"
    }],
    "dynamicCampaigns": [],
    "cmNeedCategories": [{
      "oneoffDeploymentDay": 0,
      "oneoffDeploymentWeek": 1,
      "name": "Benefits and Rewards - Shopping & Retail",
      "businessUnitCode": "U004",
      "granularOptOutCode": "MKSHOP",
      "code": "CMNC04"
    }],
    "lock": {
      "isLocked": false
    },
    "__v": 21,
    "creativeMockup": {
      "creativeVersion": 0,
      "type": {

        "code": "001",
        "codeName": "attachment_mock",
        "name": "Initial Draft",
        "emailTypeCodes": ["012", "008", "006"]
      },
      "gfsID": "56b838ada4922b3420c8615a",
      "fileName": "testImage.bmp",
      "extension": ".bmp",
      "size": "0"

    },
    "arbitration": {
      "name": "Arbitrated",
      "codeName": "arbitrated",
      "code": "Y"
    },
    "esp": {},
    "subType": {},
    "type": {},
    "buDeployment": "2016-03-06T12:00:00Z",
    "cancelledDrops": []
  },
  deployedCampaign: {
    "requestID": 17510,
    "createdOn": "2016-02-08T12:00:00Z",
    "endDate": "2016-03-16T12:00:00Z",
    "durationInWeeks": 2,
    "ma": {
      "maVersions": [],
      "instructionDocuments": [],
      "approvalDocuments": []
    },
    "espInstructions": "",
    "triggerRest": 12,
    "volumeCap": null,
    "conversionData": "Include detailed information about your campaign in this section. The Campaign Name must match your campaign approval documents. The Description must also be detailed and include information about the goal/objective of the campaign as well as an over",
    "description": "Include detailed information about your campaign in this section. The Campaign Name must match your campaign approval documents. The Description must also be detailed and include information about the goal/objective of the campaign as well as an overview of the targeting criteria. Please also include an initial draft or mock up of the creative.",
    "responsbilityCenter": "asdfasdfasdf",
    "budgetLine": "linea-12-2345",
    "isDynamicCampaign": false,
    "isMultiCMNeedCategory": false,
    "businessUnit": {
      "codeName": "BU_CCSG",
      "code": "U004",
      "name": "CCSG"
    },
    "emailType": {
      "codeName": "ET_ONEOFF",
      "name": "One Off",
      "code": "006"
    },
    "secondaryMarketingManager": {
      "markAsDeleted": false,
      "createdOn": "2016-01-25T10:00:14.695Z",
      "status": {
        "name": "Active",
        "codeName": "active",
        "code": "001"
      },
      "businessUnit": {
        "codeName": "BU_EGG",
        "code": "U023",
        "name": "Enterprise Growth Group (EGG)"
      },
      "role": {
        "code": "001",
        "codeName": "mm",
        "name": "manager"
      },
      "lastName": "arghese",
      "firstName": "Alfred T",
      "name": "Alfred T arghese",
      "email": "alfred.t.varghese@aexp.com",
      "phone": "212-624-9842",
      "value": "avargh3",
      "uid": "avargh3"
    },
    "primaryMarketingManager": {
      "markAsDeleted": false,
      "leader": {
        "email": "leader@aexp.com",
        "lastName": "leader",
        "firstName": "Dummy"
      },
      "lastLoggedOn": "2016-02-10T06:56:33.785Z",
      "createdOn": "2016-01-25T10:00:14.695Z",
      "status": {
        "name": "Active",
        "codeName": "active",
        "code": "001"
      },
      "businessUnit": {
        "codeName": "BU_EGG",
        "code": "U023",
        "name": "Enterprise Growth Group (EGG)"
      },
      "role": {
        "code": "001",
        "codeName": "mm",
        "name": "manager"
      },
      "lastName": "Guggino",
      "firstName": "Sarah E",
      "name": "Sarah E Guggino",
      "email": "Sarah.E.Guggino@aexp.com",
      "phone": "505-239-6368",
      "value": "sguggino",
      "uid": "sguggino"
    },
    "requestor": {
      "markAsDeleted": false,
      "leader": {
        "email": "leader@aexp.com",
        "lastName": "leader",
        "firstName": "Dummy"
      },
      "lastLoggedOn": "2016-02-08T06:38:53.876Z",
      "createdOn": "2016-01-25T10:00:14.695Z",
      "status": {
        "name": "Active",
        "codeName": "active",
        "code": "001"
      },
      "businessUnit": {
        "codeName": "BU_EGG",
        "code": "U023",
        "name": "Enterprise Growth Group (EGG)"
      },
      "role": {
        "code": "001",
        "codeName": "mm",
        "name": "manager"
      },
      "lastName": "Guggino",
      "firstName": "Sarah E",
      "name": "Sarah E Guggino",
      "email": "Sarah.E.Guggino@aexp.com",
      "phone": "505-239-6368",
      "value": "sguggino",
      "uid": "sguggino"
    },
    "name": "Oneoff date check",
    "state": {
      "code": "AID",
      "codeName": "submitted2admin",
      "name": "Pending Final Approval",
      "logDisplayName": "Pending Final Approval"
    },
    "sto": {
      "isSTO": true
    },
    "criticalDataUpdates": {
      "DEPLOYMENTDATES": false,
      "CELLS": false,
      "VERSIONS": false,
      "MHID": false
    },
    "isSubmittedToESP": true,
    "criticalDataSubmitted": [{
      "keys": {
        "REQR_CEY_DATE": "03/06/2026"
      }
    }, {
      "keys": {
        "REQR_CEY_DATE": "03/13/2026"
      }
    }, {
      "keys": {
        "REQR_CEY_DATE": "03/09/2026"
      }
    }, {
      "keys": {
        "REQR_CEY_DATE": "03/16/2026"
      }
    }, {
      "keys": {
        "REQR_CEY_DATE": "03/06/2026"
      }
    }, {
      "keys": {
        "REQR_CEY_DATE": "03/13/2026"
      }
    }, {
      "keys": {
        "REQR_CEY_DATE": "03/09/2026"
      }
    }, {
      "keys": {
        "REQR_CEY_DATE": "03/16/2026"
      }
    }],
    "espLoadDetails": [],
    "attachments": [{
      "gfsID": "56b86646cea85d302939af71",
      "fileName": "InstructionDoc.txt",
      "extension": ".txt",
      "size": "0",

      "type": {

        "code": "004",
        "codeName": "creative_governance",
        "name": "Creative Governance",
        "emailTypeCodes": ["008", "006"]
      },
      "creativeVersion": "0"
    }, {
      "gfsID": "56b86646cea85d302939af6f",
      "fileName": "ApprovalDoc.txt",
      "extension": ".txt",
      "size": "0",

      "creativeVersion": "1",
      "type": {

        "code": "003",
        "codeName": "html_version",
        "name": "HTML Version",
        "emailTypeCodes": ["012", "008", "006"]
      }
    }, {
      "gfsID": "56b86646cea85d302939af70",
      "fileName": "htmlVersion.txt",
      "extension": ".txt",
      "size": "0",

      "creativeVersion": "1",
      "type": {

        "code": "002",
        "codeName": "text_version",
        "name": "Text Version",
        "emailTypeCodes": ["012", "008", "006"]
      }
    }, {
      "gfsID": "56b86646cea85d302939af6e",
      "fileName": "testImage.bmp",
      "extension": ".bmp",
      "size": "0",

      "creativeVersion": "1",
      "type": {

        "code": "005",
        "codeName": "images",
        "name": "Images",
        "emailTypeCodes": ["012", "008", "006"]
      }
    }, {
      "gfsID": "56b86646cea85d302939af72",
      "fileName": "textVersion.txt",
      "extension": ".txt",
      "size": "0",

      "creativeVersion": "1",
      "type": {

        "code": "006",
        "codeName": "final_creative_preview",
        "name": "Final Creative Preview",
        "emailTypeCodes": ["012", "008", "006"]
      }
    }],
    "subjectLines": [],
    "versions": [{
      "complianceCode": "234234234324",
      "description": "Version1",
      "poid": "vers:0001",
      "number": 1,
      "subjects": [{
        "espInstructions": "subject",
        "subjectLine": "subject line 1"
      }],
      "cells": [{
        "type": {
          "name": "Mailable (Test)",
          "codeName": "test",
          "code": "T"
        },
        "description": "cell 1",
        "versionNo": 1,
        "srcCode": "CELL1"
      }, {
        "type": {
          "name": "Mailable (Test)",
          "codeName": "test",
          "code": "T"
        },
        "description": "cell 2",
        "versionNo": 1,
        "srcCode": "CELL2"
      }]
    }],
    "pznFields": [{

      "code": "CMFirstName",
      "codeName": "cmFirst",
      "name": "CM First Name",
      "description": "CM First Name",
      "reserved": true
    }, {

      "code": "CMMemberSinceDate",
      "codeName": "cmMember",
      "name": "CM Member Since Date",
      "description": "CM Member Since Date",
      "reserved": true
    }],
    "approversEmailList": ["test@aexp.com"],
    "deployEmailList": ["test@aexp.com"],
    "previewEmailList": ["test@aexp.com"],
    "mailHistory": [{
      "mhid": "MANNAR09"
    }],
    "comments": [],
    "deploymentDates": ["2016-03-06T12:00:00Z"],
    "log": [{
      "content": "Initiated",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T06:41:49.033Z"
    }, {
      "content": "Pending Initial Approval",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T09:49:58.025Z"
    }, {
      "content": "Request Approved",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T09:54:37.680Z"
    }, {
      "content": "Pending Final Approval",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T09:57:19.428Z"
    }, {
      "content": "Queued For ESP Submission",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T09:59:39.019Z"
    }, {
      "content": "Queued For ESP Submission",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T10:09:45.149Z"
    }, {
      "content": "Queued For ESP Submission",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T10:18:51.332Z"
    }, {
      "content": "Queued For ESP Submission",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T10:20:22.548Z"
    }, {
      "content": "Queued For ESP Submission",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T10:21:29.262Z"
    }, {
      "content": "Queued For ESP Submission",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T10:24:17.534Z"
    }, {
      "content": "Pending Final Approval",
      "userName": "ewt2.0",
      "timestamp": "2016-02-08T10:24:23.161Z"
    }, {
      "content": "Queued For ESP Submission",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-10T06:57:53.220Z"
    }, {
      "content": "Pending Final Approval",
      "userName": "ewt2.0",
      "timestamp": "2016-02-10T06:58:00.349Z"
    }, {
      "content": "Queued For ESP Submission",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-10T06:58:41.974Z"
    }, {
      "content": "Pending Final Approval",
      "userName": "ewt2.0",
      "timestamp": "2016-02-10T06:58:46.702Z"
    }],
    "cardProducts": [{
      "name": "Consumer Premium",
      "code": "x001"
    }],
    "dynamicCampaigns": [],
    "cmNeedCategories": [{
      "oneoffDeploymentDay": 0,
      "oneoffDeploymentWeek": 1,
      "name": "Benefits and Rewards - Shopping & Retail",
      "businessUnitCode": "U004",
      "granularOptOutCode": "MKSHOP",
      "code": "CMNC04"
    }],
    "lock": {
      "isLocked": false
    },
    "__v": 21,
    "creativeMockup": {
      "creativeVersion": 0,
      "type": {

        "code": "001",
        "codeName": "attachment_mock",
        "name": "Initial Draft",
        "emailTypeCodes": ["012", "008", "006"]
      },
      "gfsID": "56b838ada4922b3420c8615a",
      "fileName": "testImage.bmp",
      "extension": ".bmp",
      "size": "0"

    },
    "arbitration": {
      "name": "Arbitrated",
      "codeName": "arbitrated",
      "code": "Y"
    },
    "esp": {},
    "subType": {},
    "type": {},
    "buDeployment": "2016-03-06T12:00:00Z",
    "cancelledDrops": []
  },
  deployedAtET: {
    "requestID": 17510,
    "createdOn": "2016-02-08T12:00:00Z",
    "endDate": "2016-03-16T12:00:00Z",
    "durationInWeeks": 2,
    "ma": {
      "maVersions": [],
      "instructionDocuments": [],
      "approvalDocuments": []
    },
    "espInstructions": "",
    "triggerRest": 12,
    "volumeCap": null,
    "conversionData": "Include detailed information about your campaign in this section. The Campaign Name must match your campaign approval documents. The Description must also be detailed and include information about the goal/objective of the campaign as well as an over",
    "description": "Include detailed information about your campaign in this section. The Campaign Name must match your campaign approval documents. The Description must also be detailed and include information about the goal/objective of the campaign as well as an overview of the targeting criteria. Please also include an initial draft or mock up of the creative.",
    "responsbilityCenter": "asdfasdfasdf",
    "budgetLine": "linea-12-2345",
    "isDynamicCampaign": false,
    "isMultiCMNeedCategory": false,
    "businessUnit": {
      "codeName": "BU_CCSG",
      "code": "U004",
      "name": "CCSG"
    },
    "emailType": {
      "codeName": "ET_ONEOFF",
      "name": "One Off",
      "code": "006"
    },
    "secondaryMarketingManager": {
      "markAsDeleted": false,
      "createdOn": "2016-01-25T10:00:14.695Z",
      "status": {
        "name": "Active",
        "codeName": "active",
        "code": "001"
      },
      "businessUnit": {
        "codeName": "BU_EGG",
        "code": "U023",
        "name": "Enterprise Growth Group (EGG)"
      },
      "role": {
        "code": "001",
        "codeName": "mm",
        "name": "manager"
      },
      "lastName": "arghese",
      "firstName": "Alfred T",
      "name": "Alfred T arghese",
      "email": "alfred.t.varghese@aexp.com",
      "phone": "212-624-9842",
      "value": "avargh3",
      "uid": "avargh3"
    },
    "primaryMarketingManager": {
      "markAsDeleted": false,
      "leader": {
        "email": "leader@aexp.com",
        "lastName": "leader",
        "firstName": "Dummy"
      },
      "lastLoggedOn": "2016-02-10T06:56:33.785Z",
      "createdOn": "2016-01-25T10:00:14.695Z",
      "status": {
        "name": "Active",
        "codeName": "active",
        "code": "001"
      },
      "businessUnit": {
        "codeName": "BU_EGG",
        "code": "U023",
        "name": "Enterprise Growth Group (EGG)"
      },
      "role": {
        "code": "001",
        "codeName": "mm",
        "name": "manager"
      },
      "lastName": "Guggino",
      "firstName": "Sarah E",
      "name": "Sarah E Guggino",
      "email": "Sarah.E.Guggino@aexp.com",
      "phone": "505-239-6368",
      "value": "sguggino",
      "uid": "sguggino"
    },
    "requestor": {
      "markAsDeleted": false,
      "leader": {
        "email": "leader@aexp.com",
        "lastName": "leader",
        "firstName": "Dummy"
      },
      "lastLoggedOn": "2016-02-08T06:38:53.876Z",
      "createdOn": "2016-01-25T10:00:14.695Z",
      "status": {
        "name": "Active",
        "codeName": "active",
        "code": "001"
      },
      "businessUnit": {
        "codeName": "BU_EGG",
        "code": "U023",
        "name": "Enterprise Growth Group (EGG)"
      },
      "role": {
        "code": "001",
        "codeName": "mm",
        "name": "manager"
      },
      "lastName": "Guggino",
      "firstName": "Sarah E",
      "name": "Sarah E Guggino",
      "email": "Sarah.E.Guggino@aexp.com",
      "phone": "505-239-6368",
      "value": "sguggino",
      "uid": "sguggino"
    },
    "name": "Oneoff date check",
    "state": {
      "code": "AID",
      "codeName": "submitted2admin",
      "name": "Pending Final Approval",
      "logDisplayName": "Pending Final Approval"
    },
    "sto": {
      "isSTO": true
    },
    "criticalDataUpdates": {
      "DEPLOYMENTDATES": false,
      "CELLS": false,
      "VERSIONS": false,
      "MHID": false
    },
    "isSubmittedToESP": true,
    "criticalDataSubmitted": [{
      "keys": {
        "REQR_CEY_DATE": "03/06/2026"
      }
    }, {
      "keys": {
        "REQR_CEY_DATE": "03/13/2026"
      }
    }, {
      "keys": {
        "REQR_CEY_DATE": "03/09/2026"
      }
    }, {
      "keys": {
        "REQR_CEY_DATE": "03/16/2026"
      }
    }, {
      "keys": {
        "REQR_CEY_DATE": "03/06/2026"
      }
    }, {
      "keys": {
        "REQR_CEY_DATE": "03/13/2026"
      }
    }, {
      "keys": {
        "REQR_CEY_DATE": "03/09/2026"
      }
    }, {
      "keys": {
        "REQR_CEY_DATE": "03/16/2026"
      }
    }],
    "espLoadDetails": [{
      "status": "esp_load"
    }, {
      "status": "esp_deployed"
    }],
    "attachments": [{
      "gfsID": "56b86646cea85d302939af71",
      "fileName": "InstructionDoc.txt",
      "extension": ".txt",
      "size": "0",

      "type": {

        "code": "004",
        "codeName": "creative_governance",
        "name": "Creative Governance",
        "emailTypeCodes": ["008", "006"]
      },
      "creativeVersion": "0"
    }, {
      "gfsID": "56b86646cea85d302939af6f",
      "fileName": "ApprovalDoc.txt",
      "extension": ".txt",
      "size": "0",

      "creativeVersion": "1",
      "type": {

        "code": "003",
        "codeName": "html_version",
        "name": "HTML Version",
        "emailTypeCodes": ["012", "008", "006"]
      }
    }, {
      "gfsID": "56b86646cea85d302939af70",
      "fileName": "htmlVersion.txt",
      "extension": ".txt",
      "size": "0",

      "creativeVersion": "1",
      "type": {

        "code": "002",
        "codeName": "text_version",
        "name": "Text Version",
        "emailTypeCodes": ["012", "008", "006"]
      }
    }, {
      "gfsID": "56b86646cea85d302939af6e",
      "fileName": "testImage.bmp",
      "extension": ".bmp",
      "size": "0",

      "creativeVersion": "1",
      "type": {

        "code": "005",
        "codeName": "images",
        "name": "Images",
        "emailTypeCodes": ["012", "008", "006"]
      }
    }, {
      "gfsID": "56b86646cea85d302939af72",
      "fileName": "textVersion.txt",
      "extension": ".txt",
      "size": "0",

      "creativeVersion": "1",
      "type": {

        "code": "006",
        "codeName": "final_creative_preview",
        "name": "Final Creative Preview",
        "emailTypeCodes": ["012", "008", "006"]
      }
    }],
    "subjectLines": [],
    "versions": [{
      "complianceCode": "234234234324",
      "description": "Version1",
      "poid": "vers:0001",
      "number": 1,
      "subjects": [{
        "espInstructions": "subject",
        "subjectLine": "subject line 1"
      }],
      "cells": [{
        "type": {
          "name": "Mailable (Test)",
          "codeName": "test",
          "code": "T"
        },
        "description": "cell 1",
        "versionNo": 1,
        "srcCode": "CELL1"
      }, {
        "type": {
          "name": "Mailable (Test)",
          "codeName": "test",
          "code": "T"
        },
        "description": "cell 2",
        "versionNo": 1,
        "srcCode": "CELL2"
      }]
    }],
    "pznFields": [{

      "code": "CMFirstName",
      "codeName": "cmFirst",
      "name": "CM First Name",
      "description": "CM First Name",
      "reserved": true
    }, {

      "code": "CMMemberSinceDate",
      "codeName": "cmMember",
      "name": "CM Member Since Date",
      "description": "CM Member Since Date",
      "reserved": true
    }],
    "approversEmailList": ["test@aexp.com"],
    "deployEmailList": ["test@aexp.com"],
    "previewEmailList": ["test@aexp.com"],
    "mailHistory": [{
      "mhid": "MANNAR09"
    }],
    "comments": [],
    "deploymentDates": ["2016-03-06T12:00:00Z"],
    "log": [{
      "content": "Initiated",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T06:41:49.033Z"
    }, {
      "content": "Pending Initial Approval",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T09:49:58.025Z"
    }, {
      "content": "Request Approved",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T09:54:37.680Z"
    }, {
      "content": "Pending Final Approval",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T09:57:19.428Z"
    }, {
      "content": "Queued For ESP Submission",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T09:59:39.019Z"
    }, {
      "content": "Queued For ESP Submission",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T10:09:45.149Z"
    }, {
      "content": "Queued For ESP Submission",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T10:18:51.332Z"
    }, {
      "content": "Queued For ESP Submission",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T10:20:22.548Z"
    }, {
      "content": "Queued For ESP Submission",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T10:21:29.262Z"
    }, {
      "content": "Queued For ESP Submission",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-08T10:24:17.534Z"
    }, {
      "content": "Pending Final Approval",
      "userName": "ewt2.0",
      "timestamp": "2016-02-08T10:24:23.161Z"
    }, {
      "content": "Queued For ESP Submission",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-10T06:57:53.220Z"
    }, {
      "content": "Pending Final Approval",
      "userName": "ewt2.0",
      "timestamp": "2016-02-10T06:58:00.349Z"
    }, {
      "content": "Queued For ESP Submission",
      "userName": "Roopa Andrew",
      "timestamp": "2016-02-10T06:58:41.974Z"
    }, {
      "content": "Pending Final Approval",
      "userName": "ewt2.0",
      "timestamp": "2016-02-10T06:58:46.702Z"
    }],
    "cardProducts": [{
      "name": "Consumer Premium",
      "code": "x001"
    }],
    "dynamicCampaigns": [],
    "cmNeedCategories": [{
      "oneoffDeploymentDay": 0,
      "oneoffDeploymentWeek": 1,
      "name": "Benefits and Rewards - Shopping & Retail",
      "businessUnitCode": "U004",
      "granularOptOutCode": "MKSHOP",
      "code": "CMNC04"
    }],
    "lock": {
      "isLocked": false
    },
    "__v": 21,
    "creativeMockup": {
      "creativeVersion": 0,
      "type": {

        "code": "001",
        "codeName": "attachment_mock",
        "name": "Initial Draft",
        "emailTypeCodes": ["012", "008", "006"]
      },
      "gfsID": "56b838ada4922b3420c8615a",
      "fileName": "testImage.bmp",
      "extension": ".bmp",
      "size": "0"

    },
    "arbitration": {
      "name": "Arbitrated",
      "codeName": "arbitrated",
      "code": "Y"
    },
    "esp": {},
    "subType": {},
    "type": {},
    "buDeployment": "2016-03-06T12:00:00Z",
    "cancelledDrops": []
  }
};
module.exports = data;
