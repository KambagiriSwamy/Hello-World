'use strict';
var userObj = {
  user1: {
    'businessUnit': {
      'codeName': 'BU_GMS',
      'code': 'U007',
      'name': 'Global Merchant Services (GMS)',
      '_id': '563786f4206f1cb00f5ab01d'
    },
    'role': {
      'name': 'admin',
      'codeName': 'axpi',
      'code': '002',
      '_id': '56693ca65b1ca35de14e12e2'
    },
    'createdOn': '2015-12-16T14:34:39.569Z',
    'lastUpdatedOn': '2015-12-16T14:34:39.569Z',
    'uid': 'test',
    'status': {
      'code': '001',
      'codeName': 'active',
      'name': 'Active'
    },
  },
  userInfo: {
    'givenName': 'testuser',
    'sn': 'testname',
    'mail': 'test@aexp.com',
    'telephoneNumber': '123-456-789',
    'axppmanageremail': 'test1@aexp.com'
  },
  userReqObj: {
    'uid': 'testuid',
    'name': 'testName',
    'email': 'testemail'
  }
};
module.exports = userObj;
