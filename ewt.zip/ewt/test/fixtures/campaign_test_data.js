//'use strict';
var campaignObj = {
  campaignLockObject: {
    'lock': {
      'isLocked': true,
      'key': '123',
      'owner': 'randrew',
      'timer': 12345
    },
    'requestID': 80
  },
  draftObject: {
    'requestID': 0,
    'ma': {
      'maVersions': [],
      'instructionDocuments': [],
      'approvalDocuments': []
    },
    'lock': {
      'isLocked': true,
      'owner': {
        'leader': {
          'email': 'leader@aexp.com',
          'lastName': 'leader',
          'firstName': 'Dummy'
        },
        'role': {
          'code': '001',
          'codeName': 'mm',
          'name': 'manager'
        },
        'name': ' Roopa Andrew',
        'email': 'roopa.a.andrew1@aexp.com',
        'phone': '212-624-9822',
        'value': 'randrew',
        'uid': 'randrew',
        '_id': '55f68c1a569211d9ae55f0c6'
      }
    },
    'espInstructions': '',
    'triggerRest': 0,
    'volumeCap': 0,
    'conversionData': 'test',
    'description': 'testtesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttest',
    'budgetLine': '1234',
    'isDynamicCampaign': false,
    'isMultiCMNeedCategory': false,
    'businessUnit': {
      'codeName': 'BU_MR',
      'code': 'U020',
      'name': 'MR',
      '_id': '5614e54c1a941785978c05ec'
    },
    'emailType': {
      'codeName': 'ET_SERVICING',
      'name': 'Servicing',
      'code': '012',
      '_id': '560a34d30e5c17c9bf802348'
    },
    'primaryMarketingManager': {
      'role': {
        'code': '001',
        'codeName': 'mm',
        'name': 'manager'
      },
      'name': ' Roopa Andrew',
      'email': 'roopa.a.andrew1@aexp.com',
      'phone': '212-624-9822',
      'value': 'randrew',
      'uid': 'randrew',
      '_id': '55f68c1a569211d9ae55f0c6'
    },
    // 'isSTO': false,
    'sto': {
      'isSTO': false,
      'isThrottled': false,
      'isSpecificTime': false,
      'isSpecialTestingReq': false
    },
    'requestor': {
      'leader': {
        'email': 'leader@aexp.com',
        'lastName': 'leader',
        'firstName': 'Dummy'
      },
      'role': {
        'code': '001',
        'codeName': 'mm',
        'name': 'manager'
      },
      'name': ' Roopa Andrew',
      'email': 'roopa.a.andrew1@aexp.com',
      'phone': '212-624-9822',
      'value': 'randrew',
      'uid': 'randrew',
      '_id': '55f68c1a569211d9ae55f0c6'
    },
    'name': 'test',
    'state': {
      'code': 'RPG',
      'codeName': 'draft',
      'name': 'Initiated',
      'logDisplayName': 'Initiated'
    },
    'attachments': [],
    'subjectLines': [],
    'versions': [],
    'pznFields': [],
    'deployEmailList': [],
    'previewEmailList': [],
    'mailHistory': [],
    'comments': [],
    'deploymentDates': ['2015-10-27T18:30:00Z'],
    'log': [{
      'content': 'Initiated',
      'timestamp': '2015-10-08T13:18:08.542Z',
    }],
    'cardProducts': [{
      'name': 'Consumer Premium',
      'code': 'x001'
    }, {
      'name': 'OPEN Premium',
      'code': 'x005'
    }],
    'dynamicCampaigns': [],
    'cmNeedCategories': [],
    '__v': 0,
    'creativeMockup': {
      'type': {
        'code': '001',
        'codeName': 'attachment_mock',
        'name': 'Initial Draft',
        'emailTypeCodes': [
          '012',
          '008'
        ]
      },
      'gfsID': '56166d10097dc5dc2bb2012f',
      'creativeVersion': 0,
      'fileName': 'IE_Restore_Settings.png',
      'extension': '.png',
      'size': '67721',
    }
  },
  submitted4approval: {
    'requestID': 280,
    'durationInWeeks': 1,
    'ma': {
      'maVersions': [],
      'instructionDocuments': [],
      'approvalDocuments': []
    },
    'lock': {
      'isLocked': true,
      'owner': {
        'leader': {
          'email': 'leader@aexp.com',
          'lastName': 'leader',
          'firstName': 'Dummy'
        },
        'role': {
          'code': '001',
          'codeName': 'mm',
          'name': 'manager'
        },
        'name': ' Roopa Andrew',
        'email': 'roopa.a.andrew1@aexp.com',
        'phone': '212-624-9822',
        'value': 'randrew',
        'uid': 'randrew',
        '_id': '55f68c1a569211d9ae55f0c6'
      }
    },
    //'isSTO': false,
    'sto': {
      'isSTO': false,
      'isThrottled': false,
      'isSpecificTime': false,
      'isSpecialTestingReq': false
    },
    'espInstructions': '',
    'triggerRest': 12,
    'volumeCap': 0,
    'conversionData': 'dsadsadas',
    'description': 'fs sdf sd fsd fsdf sdf sdfs sdf sd fsd fsdf sdf sdfs sdf sd fsd fsdf sdf sdfs sdf sd fsd fsdf sdf sdfs sdf sd fsd fsdf sdf sd',
    'budgetLine': '1234',
    'isDynamicCampaign': false,
    'isMultiCMNeedCategory': false,
    'emailType': {
      'codeName': 'ET_SERVICING',
      'name': 'Servicing',
      'code': '012',
      '_id': '560a34d30e5c17c9bf802348'
    },
    'primaryMarketingManager': {
      'role': {
        'code': '001',
        'codeName': 'mm',
        'name': 'manager'
      },
      'name': ' Roopa Andrew',
      'email': 'roopa.a.andrew1@aexp.com',
      'phone': '212-624-9822',
      'value': 'randrew',
      'uid': 'randrew',
      '_id': '55f68c1a569211d9ae55f0c6'
    },
    'requestor': {
      'leader': {
        'email': 'leader@aexp.com',
        'lastName': 'leader',
        'firstName': 'Dummy'
      },
      'role': {
        'code': '001',
        'codeName': 'mm',
        'name': 'manager'
      },
      'name': ' Roopa Andrew',
      'email': 'roopa.a.andrew1@aexp.com',
      'phone': '212-624-9822',
      'value': 'randrew',
      'uid': 'randrew',
      '_id': '55f68c1a569211d9ae55f0c6'
    },
    'name': 'test abc',
    'state': {
      'code': 'RID',
      'codeName': 'submitted4approval',
      'name': 'Campaign Requested',
      'logDisplayName': 'Pending Initial Approval'
    },
    'criticalDataUpdates': {
      'DEPLOYMENTDATES': false,
      'CELLS': false,
      'VERSIONS': false,
      'MHID': false
    },
    'isSubmittedToESP': false,
    'espLoadDetails': [],
    'attachments': [],
    'subjectLines': [],
    'versions': [],
    'pznFields': [],
    'deployEmailList': [],
    'previewEmailList': [],
    'mailHistory': [],
    'comments': [],
    'deploymentDates': ['2015-10-27T18:30:00Z'],
    'log': [{
      'content': 'Initiated',
      'timestamp': '2015-10-27T05:11:58.702Z',
    }, {
      'content': 'Pending Initial Approval',
      'timestamp': '2015-10-27T05:12:25.863Z',
    }],
    'cardProducts': [{
      'code': 'x001',
      'name': 'Consumer Premium'
    }, {
      'code': 'x005',
      'name': 'OPEN Premium'
    }],
    'dynamicCampaigns': [],
    'cmNeedCategories': [],
    '__v': 1,
    'creativeMockup': {
      'type': {
        'code': '001',
        'codeName': 'attachment_mock',
        'name': 'Initial Draft',
        'emailTypeCodes': [
          '012',
          '008'
        ]
      },
      'gfsID': '562f07ad3ed531dc0a05c896',
      'creativeVersion': 0,
      'fileName': '11.jpg',
      'extension': '.jpg',
      'size': '131348',
    },
    'arbitration': {
      'name': 'Non Arbitrated',
      'codeName': 'nonArbitrated',
      'code': 'Y'
    },
    'businessUnit': {
      'codeName': 'BU_CARD_SERVICES',
      'code': 'U021',
      'name': 'Card Services',
      '_id': '5614e54c1a941785978c05ed'
    },
    'esp': {
      'code': 'E'
    },
    'secondaryMarketingManager': {

    },
    'subType': {

    },
    'type': {

    }
  },
  submitted2admin: {
    'requestID': 280,
    'durationInWeeks': 1,
    'ma': {
      'maVersions': [],
      'instructionDocuments': [],
      'approvalDocuments': []
    },
    'lock': {
      'isLocked': true,
      'owner': {
        'leader': {
          'email': 'leader@aexp.com',
          'lastName': 'leader',
          'firstName': 'Dummy'
        },
        'role': {
          'code': '001',
          'codeName': 'mm',
          'name': 'manager'
        },
        'name': ' Roopa Andrew',
        'email': 'roopa.a.andrew1@aexp.com',
        'phone': '212-624-9822',
        'value': 'randrew',
        'uid': 'randrew',
        '_id': '55f68c1a569211d9ae55f0c6'
      }
    },
    //'isSTO': false,
    'sto': {
      'isSTO': false,
      'isThrottled': false,
      'isSpecificTime': false,
      'isSpecialTestingReq': false
    },
    'espInstructions': '',
    'triggerRest': 12,
    'volumeCap': 0,
    'conversionData': 'dsadsadas',
    'description': 'fs sdf sd fsd fsdf sdf sdfs sdf sd fsd fsdf sdf sdfs sdf sd fsd fsdf sdf sdfs sdf sd fsd fsdf sdf sdfs sdf sd fsd fsdf sdf sd',
    'budgetLine': '11234-12-1111',
    "responsbilityCenter": "12",
    'isDynamicCampaign': false,
    'isMultiCMNeedCategory': false,
    'emailType': {
      'codeName': 'ET_SERVICING',
      'name': 'Servicing',
      'code': '012',
      '_id': '560a34d30e5c17c9bf802348'
    },
    'primaryMarketingManager': {
      'role': {
        'code': '001',
        'codeName': 'mm',
        'name': 'manager'
      },
      'name': ' Roopa Andrew',
      'email': 'roopa.a.andrew1@aexp.com',
      'phone': '212-624-9822',
      'value': 'randrew',
      'uid': 'randrew',
      '_id': '55f68c1a569211d9ae55f0c6'
    },
    'requestor': {
      'leader': {
        'email': 'leader@aexp.com',
        'lastName': 'leader',
        'firstName': 'Dummy'
      },
      'role': {
        'code': '001',
        'codeName': 'mm',
        'name': 'manager'
      },
      'name': ' Roopa Andrew',
      'email': 'roopa.a.andrew1@aexp.com',
      'phone': '212-624-9822',
      'value': 'randrew',
      'uid': 'randrew',
      '_id': '55f68c1a569211d9ae55f0c6'
    },
    'name': 'test abc',
    'state': {
      'code': 'RID',
      'codeName': 'submitted2admin',
      'name': 'Campaign Requested',
      'logDisplayName': 'Pending Initial Approval'
    },
    'criticalDataUpdates': {
      'DEPLOYMENTDATES': false,
      'CELLS': false,
      'VERSIONS': false,
      'MHID': false
    },
    'isSubmittedToESP': false,
    'espLoadDetails': [],
    'attachments': [],
    'subjectLines': [],
    'versions': [],
    'pznFields': [],
    'deployEmailList': ['aa@aexp.com'],
    'previewEmailList': ['aa@aexp.com'],
    'mailHistory': [{
      'mhid': '23231213'
    }],
    'comments': [],
    'deploymentDates': ['2015-10-27T18:30:00Z'],
    'log': [{
      'content': 'Initiated',
      'timestamp': '2015-10-27T05:11:58.702Z',
    }, {
      'content': 'Pending Initial Approval',
      'timestamp': '2015-10-27T05:12:25.863Z',
    }],
    'cardProducts': [{
      'code': 'x001',
      'name': 'Consumer Premium'
    }, {
      'code': 'x005',
      'name': 'OPEN Premium'
    }],
    'dynamicCampaigns': [],
    'cmNeedCategories': [],
    '__v': 1,
    'creativeMockup': {
      'type': {
        'code': '001',
        'codeName': 'attachment_mock',
        'name': 'Initial Draft',
        'emailTypeCodes': [
          '012',
          '008'
        ]
      },
      'gfsID': '562f07ad3ed531dc0a05c896',
      'creativeVersion': 0,
      'fileName': '11.jpg',
      'extension': '.jpg',
      'size': '131348',
    },
    'arbitration': {
      'name': 'Non Arbitrated',
      'codeName': 'nonArbitrated',
      'code': 'Y'
    },
    'businessUnit': {
      'codeName': 'BU_CARD_SERVICES',
      'code': 'U021',
      'name': 'Card Services',
      '_id': '5614e54c1a941785978c05ed'
    },
    'esp': {
      'code': 'E'
    },
    'secondaryMarketingManager': {

    },
    'subType': {

    },
    'type': {

    }
  },
  invalidCampaignObject: {
    'requestID': 225,
    'durationInWeeks': 1,
    'ma': {
      'maVersions': [],
      'instructionDocuments': [],
      'approvalDocuments': []
    },
    'lock': {
      'isLocked': true,
      'owner': {
        'leader': {
          'email': 'leader@aexp.com',
          'lastName': 'leader',
          'firstName': 'Dummy'
        },
        'role': {
          'code': '001',
          'codeName': 'mm',
          'name': 'manager'
        },
        'name': ' Roopa Andrew',
        'email': 'roopa.a.andrew1@aexp.com',
        'phone': '212-624-9822',
        'value': 'randrew',
        'uid': 'randrew',
        '_id': '55f68c1a569211d9ae55f0c6'
      }
    },
    //'isSTO': false,
    'sto': {
      'isSTO': false,
      'isThrottled': false,
      'isSpecificTime': false,
      'isSpecialTestingReq': false
    },
    'espInstructions': '',
    'triggerRest': 12,
    'volumeCap': 0,
    'conversionData': 'dsadsadas',
    'description': 'fs sdf sd fsd fsdf sdf sdfs sdf sd fsd fsdf sdf sdfs sdf sd fsd fsdf sdf sdfs sdf sd fsd fsdf sdf sdfs sdf sd fsd fsdf sdf sd',
    'budgetLine': '1234',
    'isDynamicCampaign': false,
    'isMultiCMNeedCategory': false,
    'emailType': {
      'codeName': 'ET_SERVICING',
      'name': 'Servicing',
      'code': '012',
      '_id': '560a34d30e5c17c9bf802348'
    },
    'primaryMarketingManager': {
      'role': {
        'code': '001',
        'codeName': 'mm',
        'name': 'manager'
      },
      'name': ' Roopa Andrew',
      'email': 'roopa.a.andrew1@aexp.com',
      'phone': '212-624-9822',
      'value': 'randrew',
      'uid': 'randrew',
      '_id': '55f68c1a569211d9ae55f0c6'
    },
    'requestor': {
      'leader': {
        'email': 'leader@aexp.com',
        'lastName': 'leader',
        'firstName': 'Dummy'
      },
      'role': {
        'code': '001',
        'codeName': 'mm',
        'name': 'manager'
      },
      'name': ' Roopa Andrew',
      'email': 'roopa.a.andrew1@aexp.com',
      'phone': '212-624-9822',
      'value': 'randrew',
      'uid': 'randrew',
      '_id': '55f68c1a569211d9ae55f0c6'
    },
    'name': 'test abc',
    'state': {
      'code': 'RID',
      'codeName': 'submitted4approval',
      'name': 'Campaign Requested',
      'logDisplayName': 'Pending Initial Approval'
    },
    'criticalDataUpdates': {
      'DEPLOYMENTDATES': false,
      'CELLS': false,
      'VERSIONS': false,
      'MHID': false
    },
    'isSubmittedToESP': false,
    'espLoadDetails': [],
    'attachments': [],
    'subjectLines': [],
    'versions': [],
    'pznFields': [],
    'deployEmailList': [],
    'previewEmailList': [],
    'mailHistory': [],
    'comments': [],
    'deploymentDates': ['2015-10-27T18:30:00Z'],
    'log': [{
      'content': 'Initiated',
      'timestamp': '2015-10-27T05:11:58.702Z',
    }, {
      'content': 'Pending Initial Approval',
      'timestamp': '2015-10-27T05:12:25.863Z',
    }],
    'cardProducts': [{
      'code': 'x001',
      'name': 'Consumer Premium'
    }, {
      'code': 'x005',
      'name': 'OPEN Premium'
    }],
    'dynamicCampaigns': [],
    'cmNeedCategories': [],
    '__v': 1,
    'creativeMockup': {
      'type': {
        'code': '001',
        'codeName': 'attachment_mock',
        'name': 'Initial Draft',
        'emailTypeCodes': [
          '012',
          '008'
        ]
      },
      'gfsID': '562f07ad3ed531dc0a05c896',
      'creativeVersion': 0,
      'fileName': '11.jpg',
      'extension': '.jpg',
      'size': '131348',
    },
    'arbitration': {
      'name': 'Non Arbitrated',
      'codeName': 'nonArbitrated',
      'code': 'Y'
    },
    'businessUnit': {
      'codeName': 'BU_CARD_SERVICES',
      'code': 'U021',
      'name': 'Card Services',
      '_id': '5614e54c1a941785978c05ed'
    },
    'esp': {
      'code': 'E'
    },
    'secondaryMarketingManager': {

    },
    'subType': {

    },
    'type': {

    }
  },
  newMHID: {
    "mhid": "5555555",
    "startDate": "2/17/2016",
    "cell": {
      "srcCode": "2",
      "description": "2",
      "type": {
        "_id": "568f81748a5251c59d8ddf85",
        "code": "C",
        "codeName": "control",
        "name": "Holdout (Control)"
      }
    },
    "cellError": true,
    "mhidDateOpened": false
  },
  oldMHID: {
    "mhid": "55555555",
    "startDate": "2016-02-16T18:30:00.000Z",
    "cell": {
      "srcCode": "1",
      "description": "1",
      "type": {
        "_id": "568f81748a5251c59d8ddf84",
        "code": "T",
        "codeName": "test",
        "name": "Mailable (Test)"
      }
    },
    "tempIndx": 0,
    "incomplete": false
  },
  mhidData: {
    'requestID': 18,
    'durationInWeeks': 1,
    'ma': {
      'disengagementValue': 1,
      'mailHistory': [{
        'cells': [{
          'editAleternative': 'Cannot edit as linked to a MHID',
          'removeAlternative': 'Cannot remove as linked to a MHID',
          'isLinkedToMHID': true,
          'type': {
            'name': 'Mailable (Test)',
            'codeName': 'test',
            'code': 'T',
            '_id': '563786f5206f1cb00f5ab0a1'
          },
          'description': '2',
          'srcCode': '2'
        }],
        'mhid': '11111111',
        'startDate': '2016-01-14T09:12:26.565Z'
      }, {
        'startDate': '2016-01-14T11:48:36.772Z',
        'mhid': '55555555',
        'cells': [{
          'editAleternative': 'Cannot edit as linked to a MHID',
          'removeAlternative': 'Cannot remove as linked to a MHID',
          'isLinkedToMHID': true,
          'type': {
            'name': 'Mailable (Test)',
            'codeName': 'test',
            'code': 'T',
            '_id': '563786f5206f1cb00f5ab0a1'
          },
          'description': '1',
          'srcCode': '1'
        }]
      }, {
        'startDate': '2016-01-14T11:48:36.772Z',
        'mhid': '55555512',
        'cells': [{
          'editAleternative': 'Cannot edit as linked to a MHID',
          'removeAlternative': 'Cannot remove as linked to a MHID',
          'isLinkedToMHID': true,
          'type': {
            'name': 'Mailable (Test)',
            'codeName': 'test',
            'code': 'T',
            '_id': '563786f5206f1cb00f5ab0a1'
          },
          'description': '1',
          'srcCode': '2'
        }, {
          'editAleternative': 'Cannot edit as linked to a MHID',
          'removeAlternative': 'Cannot remove as linked to a MHID',
          'isLinkedToMHID': true,
          'type': {
            'name': 'Mailable (Test)',
            'codeName': 'test',
            'code': 'T',
            '_id': '563786f5206f1cb00f5ab0a1'
          },
          'description': '1',
          'srcCode': '1'
        }]
      }],
      'cell': [{
        'editAleternative': 'Cannot edit as linked to a MHID',
        'removeAlternative': 'Cannot remove as linked to a MHID',
        'isLinkedToMHID': true,
        'type': {
          'name': 'Mailable (Test)',
          'codeName': 'test',
          'code': 'T',
          '_id': '563786f5206f1cb00f5ab0a1'
        },
        'description': '1',
        'srcCode': '1'
      }],
      'maCells': [{
        'editAleternative': 'Cannot edit as linked to a MHID',
        'removeAlternative': 'Cannot remove as linked to a MHID',
        'isLinkedToMHID': true,
        'type': {
          'name': 'Mailable (Test)',
          'codeName': 'test',
          'code': 'T',
          '_id': '563786f5206f1cb00f5ab0a1'
        },
        'description': '1',
        'srcCode': '1'
      }, {
        'editAleternative': 'Cannot edit as linked to a MHID',
        'removeAlternative': 'Cannot remove as linked to a MHID',
        'isLinkedToMHID': true,
        'type': {
          'name': 'Mailable (Test)',
          'codeName': 'test',
          'code': 'T',
          '_id': '563786f5206f1cb00f5ab0a1'
        },
        'description': '2',
        'srcCode': '2'
      }],
      'maVersions': [{
        'creativeDocument': [{
          'type': {
            'emailTypeCodes': [
              '008'
            ],
            'name': 'Creative Governance',
            'codeName': 'creative_governance',
            'code': '004',
            '_id': '563786f5206f1cb00f5ab065'
          },
          '_id': '565d2b6df78787b8794afced',
          'size': '0',
          'extension': '.uccplog',
          'fileName': 'LiveMeeting-uccp-0.uccplog',
          'gfsID': '565d2b6df78787b8794afceb'
        }],
        '_id': '565d2b6df78787b8794afce9',
        'versionId': 1,
        'versionName': '1',
        'subjectLine': '1',
        'complianceCode': 11111111,
        'triggerEvent': {
          'name': 'Email Driven',
          'codeName': 'EMAIL_DRIVEN'
        }
      }, {
        'creativeDocument': [{
          'type': {
            'emailTypeCodes': [
              '008'
            ],
            'name': 'Creative Governance',
            'codeName': 'creative_governance',
            'code': '004',
            '_id': '563786f5206f1cb00f5ab065'
          },
          '_id': '565d2b6df78787b8794afced',
          'size': '0',
          'extension': '.uccplog',
          'fileName': 'LiveMeeting-uccp-0.uccplog',
          'gfsID': '565d2b6df78787b8794afceb'
        }],
        '_id': '565d2b6df78787b8794afce9',
        'versionId': 12,
        'versionName': '1',
        'subjectLine': '1',
        'complianceCode': 11111111,
        'triggerEvent': {
          'name': 'Email Driven',
          'codeName': 'EMAIL_DRIVEN'
        }
      }],
      'instructionDocuments': [{
        '_id': '565d2b63f78787b8794afce7',
        'size': '0',
        'extension': '.uccplog',
        'fileName': 'LiveMeeting-uccp-0.uccplog',
        'gfsID': '565d2b63f78787b8794afce5'
      }],
      'approvalDocuments': [{
        '_id': '565d2b61f78787b8794afce3',
        'size': '0',
        'extension': '.uccplog',
        'fileName': 'LiveMeeting-uccp-0.uccplog',
        'gfsID': '565d2b61f78787b8794afce1'
      }]
    },
    'espInstructions': '',
    'triggerRest': 12,
    'volumeCap': null,
    'conversionData': 'asdsa',
    'description': 'das das sdadas das sdadas das sdadas das sdadas das sdadas das sdadas das sdadas das sdadas das sdadas das sdadas das sdadas das sdadas das sdadas das sdadas das sda',
    'budgetLine': '122222222222222',
    'isDynamicCampaign': false,
    'isMultiCMNeedCategory': false,
    'businessUnit': {
      'codeName': 'BU_GMS',
      'code': 'U007',
      'name': 'Global Merchant Services (GMS)',
      '_id': '563786f4206f1cb00f5ab01d'
    },
    'emailType': {
      'codeName': 'ET_MA',
      'name': 'Marketing Automation',
      'code': '008',
      '_id': '563786f4206f1cb00f5ab01c'
    },
    'primaryMarketingManager': {
      'role': {
        'code': '001',
        'codeName': 'mm',
        'name': 'manager'
      },
      'name': 'Roopa Andrew',
      'email': 'roopa.a.andrew1@aexp.com',
      'phone': '212-624-9822',
      'value': 'randrew',
      'uid': 'randrew',
      '_id': '563786f5206f1cb00f5ab09f'
    },
    'requestor': {
      'leader': {
        'email': 'leader@aexp.com',
        'lastName': 'leader',
        'firstName': 'Dummy'
      },
      'role': {
        'code': '001',
        'codeName': 'mm',
        'name': 'manager'
      },
      'name': 'Roopa Andrew',
      'email': 'roopa.a.andrew1@aexp.com',
      'phone': '212-624-9822',
      'value': 'randrew',
      'uid': 'randrew',
      '_id': '563786f5206f1cb00f5ab09f'
    },
    'name': 'test MA',
    'state': {
      'code': 'RPS',
      'codeName': 'ewt2Save',
      'name': 'In Progress',
      'logDisplayName': 'In Progress'
    },
    'criticalDataUpdates': {
      'DEPLOYMENTDATES': false,
      'CELLS': false,
      'VERSIONS': false,
      'MHID': false
    },
    'isSubmittedToESP': false,
    'espLoadDetails': [],
    'attachments': [{
      '_id': '565d6f1e488836b41ddf3b64',
      'size': '0',
      'extension': '.uccplog',
      'fileName': 'LiveMeeting-uccp-0.uccplog',
      'gfsID': '565d6f1e488836b41ddf3b62'
    }],
    'subjectLines': [],
    'versions': [],
    'pznFields': [],
    'deployEmailList': [],
    'previewEmailList': [],
    'mailHistory': [],
    'comments': [],
    'deploymentDates': [
      '2015-12-02T10:40:37.306Z'
    ],
    'log': [{
      'content': 'Pending Initial Approval',
      'timestamp': '2015-11-30T09:14:15.628Z'
    }, {
      'content': 'Request Approved',
      'timestamp': '2015-11-30T09:15:34.694Z'
    }, {
      'content': 'In Progress',
      'timestamp': '2015-11-30T09:17:22.117Z'
    }, {
      'content': 'Saved',
      'timestamp': '2015-11-30T09:23:47.205Z'
    }],
    'cardProducts': [{
      'name': 'Consumer Premium',
      'code': 'x001'
    }, {
      'name': 'OPEN Premium',
      'code': 'x005'
    }],
    'dynamicCampaigns': [],
    'cmNeedCategories': [{
      'name': 'Benefits and Rewards - Travel',
      'businessUnitCode': 'U007',
      'granularOptOutCode': 'MKTRVL',
      'code': 'CMNC03',
      '_id': '563786f6206f1cb00f5ab0a3'
    }],
    '__v': 59,
    'creativeMockup': {
      'type': {
        'code': '001',
        'codeName': 'attachment_mock',
        'name': 'Initial Draft',
        'emailTypeCodes': [
          '012',
          '008'
        ]
      },
      'gfsID': '565c136797279ee874d7ccbf',
      'creativeVersion': 0,
      'fileName': 'LiveMeeting-uccp-0.uccplog',
      'extension': '.uccplog',
      'size': '0'
    },
    'arbitration': {
      'name': 'Non Arbitrated',
      'codeName': 'nonArbitrated',
      'code': 'N'
    },
    'esp': {
      'code': 'E'
    },
    'secondaryMarketingManager': {

    },
    'subType': {

    },
    'type': {

    }
  },
  mhidObj: {
    'cell': {
      'editAleternative': 'Cannot edit as linked to a MHID',
      'removeAlternative': 'Cannot remove as linked to a MHID',
      'isLinkedToMHID': true,
      'type': {
        'name': 'Mailable (Test)',
        'codeName': 'test',
        'code': 'T',
        '_id': '563786f5206f1cb00f5ab0a1'
      },
      'description': '2',
      'srcCode': '2'
    },
    'mhid': '11111111',
    'startDate': '2016-01-14T09:12:26.565Z'
  },
  approved: {
    'requestID': 225,
    'durationInWeeks': 1,
    'ma': {
      'maVersions': [],
      'instructionDocuments': [],
      'approvalDocuments': []
    },
    'lock': {
      'isLocked': true,
      'owner': {
        'leader': {
          'email': 'leader@aexp.com',
          'lastName': 'leader',
          'firstName': 'Dummy'
        },
        'role': {
          'code': '001',
          'codeName': 'mm',
          'name': 'manager'
        },
        'name': ' Roopa Andrew',
        'email': 'roopa.a.andrew1@aexp.com',
        'phone': '212-624-9822',
        'value': 'randrew',
        'uid': 'randrew',
        '_id': '55f68c1a569211d9ae55f0c6'
      }
    },
    'espInstructions': '',
    'triggerRest': 12,
    'volumeCap': 0,
    'conversionData': 'dsadsadas',
    'description': 'fs sdf sd fsd fsdf sdf sdfs sdf sd fsd fsdf sdf sdfs sdf sd fsd fsdf sdf sdfs sdf sd fsd fsdf sdf sdfs sdf sd fsd fsdf sdf sd',
    'budgetLine': '1234',
    'isDynamicCampaign': false,
    'sto': {
      'isSTO': false,
      'isThrottled': false,
      'isSpecificTime': false,
      'isSpecialTestingReq': false,
      'stoEmailTrackingType': {},
      'stoEventToTrack': {}
    },
    'isMultiCMNeedCategory': false,
    'emailType': {
      'codeName': 'ET_SERVICING',
      'name': 'Servicing',
      'code': '012',
      '_id': '560a34d30e5c17c9bf802348'
    },
    'primaryMarketingManager': {
      'role': {
        'code': '001',
        'codeName': 'mm',
        'name': 'manager'
      },
      'name': ' Roopa Andrew',
      'email': 'roopa.a.andrew1@aexp.com',
      'phone': '212-624-9822',
      'value': 'randrew',
      'uid': 'randrew',
      '_id': '55f68c1a569211d9ae55f0c6'
    },
    'requestor': {
      'leader': {
        'email': 'leader@aexp.com',
        'lastName': 'leader',
        'firstName': 'Dummy'
      },
      'role': {
        'code': '001',
        'codeName': 'mm',
        'name': 'manager'
      },
      'name': ' Roopa Andrew',
      'email': 'roopa.a.andrew1@aexp.com',
      'phone': '212-624-9822',
      'value': 'randrew',
      'uid': 'randrew',
      '_id': '55f68c1a569211d9ae55f0c6'
    },
    'name': 'test abc',
    'state': {
      'code': 'RID',
      'codeName': 'approved',
      'name': 'Campaign Requested',
      'logDisplayName': 'Pending Initial Approval'
    },
    'criticalDataUpdates': {
      'DEPLOYMENTDATES': false,
      'CELLS': false,
      'VERSIONS': false,
      'MHID': false
    },
    'isSubmittedToESP': false,
    'espLoadDetails': [],
    'attachments': [],
    'subjectLines': [],
    'versions': [],
    'pznFields': [],
    'deployEmailList': [],
    'previewEmailList': [],
    'mailHistory': [],
    'comments': [],
    'deploymentDates': ['2015-10-27T18:30:00Z'],
    'log': [{
      'content': 'Initiated',
      'timestamp': '2015-10-27T05:11:58.702Z',
    }, {
      'content': 'Pending Initial Approval',
      'timestamp': '2015-10-27T05:12:25.863Z',
    }],
    'cardProducts': [{
      'code': 'x001',
      'name': 'Consumer Premium'
    }, {
      'code': 'x005',
      'name': 'OPEN Premium'
    }],
    'dynamicCampaigns': [],
    'cmNeedCategories': [],
    '__v': 1,
    'creativeMockup': {
      'type': {
        'code': '001',
        'codeName': 'attachment_mock',
        'name': 'Initial Draft',
        'emailTypeCodes': [
          '012',
          '008'
        ]
      },
      'gfsID': '562f07ad3ed531dc0a05c896',
      'creativeVersion': 0,
      'fileName': '11.jpg',
      'extension': '.jpg',
      'size': '131348',
    },
    'arbitration': {
      'name': 'Non Arbitrated',
      'codeName': 'nonArbitrated',
      'code': 'Y'
    },
    'businessUnit': {
      'codeName': 'BU_CARD_SERVICES',
      'code': 'U021',
      'name': 'Card Services',
      '_id': '5614e54c1a941785978c05ed'
    },
    'esp': {
      'code': 'E'
    },
    'secondaryMarketingManager': {

    },
    'subType': {

    },
    'type': {

    }
  },
  mockCampaignObject: {
    'requestID': 225,
    'durationInWeeks': 1,
    'ma': {
      'maVersions': [],
      'instructionDocuments': [],
      'approvalDocuments': []
    },
    //'isSTO': false,
    'sto': {
      'isSTO': false,
      'isThrottled': false,
      'isSpecificTime': false,
      'isSpecialTestingReq': false
    },
    'espInstructions': '',
    'triggerRest': 12,
    'volumeCap': 0,
    'conversionData': 'dsadsadas',
    'description': 'fs sdf sd fsd fsdf sdf sdfs sdf sd fsd fsdf sdf sdfs sdf sd fsd fsdf sdf sdfs sdf sd fsd fsdf sdf sdfs sdf sd fsd fsdf sdf sd',
    'budgetLine': '1234',
    'isDynamicCampaign': false,
    'isMultiCMNeedCategory': false,
    'emailType': {
      'codeName': 'ET_SERVICING',
      'name': 'Servicing',
      'code': '012',
      '_id': '560a34d30e5c17c9bf802348'
    },
    //  'isSTO': false,
    'sto': {
      'isSTO': false,
      'isThrottled': false,
      'isSpecificTime': false,
      'isSpecialTestingReq': false
    },
    'primaryMarketingManager': {
      'role': {
        'code': '001',
        'codeName': 'mm',
        'name': 'manager'
      },
      'name': ' Roopa Andrew',
      'email': 'roopa.a.andrew1@aexp.com',
      'phone': '212-624-9822',
      'value': 'randrew',
      'uid': 'randrew',
      '_id': '55f68c1a569211d9ae55f0c6'
    },
    'requestor': {
      'leader': {
        'email': 'leader@aexp.com',
        'lastName': 'leader',
        'firstName': 'Dummy'
      },
      'role': {
        'code': '001',
        'codeName': 'mm',
        'name': 'manager'
      },
      'name': ' Roopa Andrew',
      'email': 'roopa.a.andrew1@aexp.com',
      'phone': '212-624-9822',
      'value': 'randrew',
      'uid': 'randrew',
      '_id': '55f68c1a569211d9ae55f0c6'
    },
    'name': 'test abc',
    'state': {
      'code': 'RID',
      'codeName': 'submitted4approval',
      'name': 'Campaign Requested',
      'logDisplayName': 'Pending Initial Approval'
    },
    'criticalDataUpdates': {
      'DEPLOYMENTDATES': false,
      'CELLS': false,
      'VERSIONS': false,
      'MHID': false
    },
    'isSubmittedToESP': false,
    'espLoadDetails': [],
    'attachments': [],
    'subjectLines': [],
    'versions': [],
    'pznFields': [],
    'deployEmailList': [],
    'previewEmailList': [],
    'mailHistory': [],
    'comments': [],
    'deploymentDates': ['2015-10-27T18:30:00Z'],
    'log': [{
      'content': 'Initiated',
      'timestamp': '2015-10-27T05:11:58.702Z',
    }, {
      'content': 'Pending Initial Approval',
      'timestamp': '2015-10-27T05:12:25.863Z',
    }],
    'cardProducts': [{
      'code': 'x001',
      'name': 'Consumer Premium'
    }, {
      'code': 'x005',
      'name': 'OPEN Premium'
    }],
    'dynamicCampaigns': [],
    'cmNeedCategories': [],
    '__v': 1,
    'creativeMockup': {
      'type': {
        'code': '001',
        'codeName': 'attachment_mock',
        'name': 'Initial Draft',
        'emailTypeCodes': [
          '012',
          '008'
        ]
      },
      'gfsID': '562f07ad3ed531dc0a05c896',
      'creativeVersion': 0,
      'fileName': '11.jpg',
      'extension': '.jpg',
      'size': '131348',
    },
    'arbitration': {
      'name': 'Non Arbitrated',
      'codeName': 'nonArbitrated',
      'code': 'Y'
    },
    'businessUnit': {
      'codeName': 'BU_CARD_SERVICES',
      'code': 'U021',
      'name': 'Card Services',
      '_id': '5614e54c1a941785978c05ed'
    },
    'esp': {
      'code': 'E'
    },
    'secondaryMarketingManager': {

    },
    'subType': {

    },
    'type': {

    }
  },
  cellsobject: {
    "cells": [{
      "type": {
        "name": "Mailable (Test)",
        "codeName": "test",
        "code": "T",
        "_id": "568f81748a5251c59d8ddf84"
      },
      "description": "1",
      "srcCode": "1"
    }]
  },
  finalETObject: {
    'requestID': 16,
    'durationInWeeks': 1,
    'ma': {
      'maVersions': [],
      'instructionDocuments': [],
      'approvalDocuments': []
    },
    'espInstructions': '',
    'triggerRest': 12,
    'volumeCap': null,
    'conversionData': 'dsadas',
    'description': 'fasdasdvavdasvdadva vf vxcv xc vxcfasdasdvavdasvdadva vf vxcv xc vxcfasdasdvavdasvdadva vf vxcv xc vxcfasdasdvavdasvdadva vf vxcv xc vxcfasdasdvavdasvdadva vf vxcv xc vxcfasdasdvavdasvdadva vf vxcv xc vxcfasdasdvavdasvdadva vf vxcv xc vxcfasdasdvavdasvdadva vf vxcv xc vxcfasdasdvavdasvdadva vf vxcv xc vxcfasdasdvavdasvdadva vf vxcv xc vxcfasdasdvavdasvdadva vf vxcv xc vxcfasdasdvavdasvdadva vf vxcv xc vxcfasdasdvavdasvdadva vf vxcv xc vxcfasdasdvavdasvdadva vf vxcv xc vxc',
    'budgetLine': '423423423',
    'isDynamicCampaign': false,
    'isMultiCMNeedCategory': false,
    'primaryMarketingManager': {
      'role': {
        'code': '001',
        'codeName': 'mm',
        'name': 'manager'
      },

      'name': 'Roopa Andrew',
      'email': 'roopa.a.andrew1@aexp.com',
      'phone': '212-624-9822',
      'value': 'randrew',
      'uid': 'randrew',
      '_id': '563786f5206f1cb00f5ab09f'
    },
    // 'isSTO': false,
    'sto': {
      'isSTO': false,
      'isThrottled': false,
      'isSpecificTime': false,
      'isSpecialTestingReq': false
    },
    'requestor': {
      'leader': {
        'email': 'leader@aexp.com',
        'lastName': 'leader',
        'firstName': 'Dummy'
      },
      'role': {
        'code': '001',
        'codeName': 'mm',
        'name': 'manager'
      },
      'name': 'Roopa Andrew',
      'email': 'roopa.a.andrew1@aexp.com',
      'phone': '212-624-9822',
      'value': 'randrew',
      'uid': 'randrew',
      '_id': '563786f5206f1cb00f5ab09f'
    },
    'name': 'dsadsa',
    'state': {
      'code': 'AID',
      'codeName': 'submitted2admin',
      'name': 'Pending Final Approval',
      'logDisplayName': 'Pending Final Approval'
    },
    'criticalDataUpdates': {
      'DEPLOYMENTDATES': false,
      'CELLS': false,
      'VERSIONS': false,
      'MHID': false
    },
    'isSubmittedToESP': false,
    'espLoadDetails': [],
    'attachments': [{
      'creativeVersion': '0',
      'type': {
        '_id': '563786f5206f1cb00f5ab069',
        'code': '007',
        'codeName': 'rasc',
        'name': 'RASC Approval',
        'emailTypeCodes': [
          '012'
        ]
      },
      'gfsID': '565bec42271a4a547507a009',
      'fileName': 'LiveMeeting-uccp-0.uccplog',
      'extension': '.uccplog',
      'size': '0',
      '_id': '565bec43271a4a547507a00b'
    }, {
      'gfsID': '565bfa266710b57c7bae0e23',
      'fileName': 'LiveMeeting-uccp-0.uccplog',
      'extension': '.uccplog',
      'size': '0',
      '_id': '565bfa276710b57c7bae0e25',
      'type': {
        '_id': '563786f5206f1cb00f5ab062',
        'code': '001',
        'codeName': 'attachment_mock',
        'name': 'Initial Draft',
        'emailTypeCodes': [
          '012',
          '008'
        ]
      },
      'creativeVersion': '1'
    }],
    'subjectLines': [],
    'versions': [{
      'number': 1,
      'subjects': [{
        'espInstructions': 'dsadsa',
        'subjectLine': 'sub1'
      }, {
        'espInstructions': 'dadsadsa',
        'subjectLine': 'sub2'
      }, {
        'espInstructions': 'dsadsa',
        'subjectLine': 'sub3'
      }],
      'cells': [{
        'type': {
          'name': 'Mailable (Test)',
          'codeName': 'test',
          'code': 'T',
          '_id': '563786f5206f1cb00f5ab0a1'
        },
        'description': 'dsadsa',
        'versionNo': 1,
        'srcCode': 'CELL1'
      }]
    }],
    'pznFields': [{
      '_id': '563786f5206f1cb00f5ab075',
      'code': 'CMFirstName',
      'codeName': 'cmFirst',
      'name': 'CM First Name',
      'description': 'CM First Name',
      'reserved': true
    }],
    'deployEmailList': [
      'aa@aexp.com'
    ],
    'previewEmailList': [
      'aa@aexp.com'
    ],
    'mailHistory': [{
      'mhid': '11111114'
    }],
    'comments': [],
    'deploymentDates': [
      '2015-12-03T09:07:10.265Z'
    ],
    'log': [{
      'content': 'Initiated',
      'timestamp': '2015-11-26T06:44:25.939Z'
    }, {
      'content': 'Pending Initial Approval',
      'timestamp': '2015-11-26T06:46:03.214Z'
    }, {
      'content': 'Request Approved',
      'timestamp': '2015-11-26T06:46:46.762Z'
    }, {
      'content': 'In Progress',
      'timestamp': '2015-11-26T06:47:23.914Z'
    }, {
      'content': 'Saved',
      'timestamp': '2015-11-26T06:48:06.710Z'
    }, {
      'content': 'Saved',
      'timestamp': '2015-11-26T06:52:11.116Z'
    }, {
      'content': 'Saved',
      'timestamp': '2015-11-26T06:53:29.473Z'
    }, {
      'content': 'Saved',
      'timestamp': '2015-11-26T06:53:47.228Z'
    }, {
      'content': 'Saved',
      'timestamp': '2015-11-26T06:54:08.047Z'
    }, {
      'content': 'Saved',
      'timestamp': '2015-11-26T09:09:45.459Z'
    }, {
      'content': 'Saved',
      'timestamp': '2015-11-26T09:13:22.427Z'
    }, {
      'content': 'Saved',
      'timestamp': '2015-11-26T09:14:24.066Z'
    }, {
      'content': 'Saved',
      'timestamp': '2015-11-27T09:13:46.947Z'
    }, {
      'content': 'Saved',
      'timestamp': '2015-11-30T07:28:42.982Z'
    }, {
      'content': 'Saved',
      'timestamp': '2015-11-30T07:28:55.937Z'
    }, {
      'content': 'Saved',
      'timestamp': '2015-11-30T07:29:10.204Z'
    }, {
      'content': 'Saved',
      'timestamp': '2015-11-30T07:29:16.701Z'
    }, {
      'content': 'Saved',
      'timestamp': '2015-11-30T07:52:25.793Z'
    }, {
      'content': 'Saved',
      'timestamp': '2015-11-30T07:52:32.272Z'
    }, {
      'content': 'Saved',
      'timestamp': '2015-11-30T07:52:41.222Z'
    }, {
      'content': 'Saved',
      'timestamp': '2015-11-30T08:59:49.998Z'
    }, {
      'content': 'Saved',
      'timestamp': '2015-12-01T05:14:47.065Z'
    }, {
      'content': 'Pending Final Approval',
      'timestamp': '2015-12-01T06:06:19.183Z'
    }, {
      'content': 'Saved',
      'timestamp': '2015-12-01T09:07:10.258Z'
    }],
    'cardProducts': [{
      'code': 'x001',
      'name': 'Consumer Premium'
    }, {
      'code': 'x005',
      'name': 'OPEN Premium'
    }],
    'dynamicCampaigns': [],
    'cmNeedCategories': [],
    '__v': 25,
    'creativeMockup': {
      'type': {
        'code': '001',
        'codeName': 'attachment_mock',
        'name': 'Initial Draft',
        'emailTypeCodes': [
          '012',
          '008'
        ]
      },
      'gfsID': '5656aa7f861d6dfc55fcf0e2',
      'creativeVersion': 0,
      'fileName': 'Clarissa_Recommendations_todevteam_10_28_updated.xlsx',
      'extension': '.xlsx',
      'size': '19577'
    },
    'arbitration': {

    },
    'businessUnit': {
      'codeName': 'BU_AXPI',
      'code': 'U017',
      'name': 'AXPi',
      '_id': '563786f4206f1cb00f5ab025'
    },
    'emailType': {
      'codeName': 'ET_SERVICING',
      'name': 'Servicing',
      'code': '012',
      '_id': '563786f4206f1cb00f5ab01b'
    },
    'esp': {
      'code': 'E'
    },
    'secondaryMarketingManager': {

    },
    'subType': {

    },
    'type': {

    }
  },
  versionReqObj: {
    "versionName": "dsa",
    "subjectLine": "dsa",
    "creativeDocument": [{
      "fileName": "4MB File.txt"
    }],
    "complianceCode": "dsadsa",
    "triggerEvent": {
      "name": "Email Driven",
      "codeName": "EMAIL_DRIVEN"
    },
    "versionId": 12
  }
};
module.exports = campaignObj;