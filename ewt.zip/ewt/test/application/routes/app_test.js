/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-POC - <DESC_HERE>
 */

/*global describe, beforeEach, afterEach, it, expect, should, assert, chai, sinon, proxyquire (see /test/helpers.js)*/
// 'use strict';
// var noop = function(){};
// var config = require('config');
// var request = require('supertest');
// var logObj = {
//   internal: {
//     info: noop,
//     warn: noop,
//     debug: noop,
//     audit: noop,
//     appReport: noop,
//     error: noop
//   }
// };
// var logger = function() {
//   return logObj;
// }

// var proxy = proxyquire('jumpstart-engine', {
//   './lib/logger': noop,
//   'jumpstart-logging': logger
// });
// var jumpstart = proxy(config);

// describe('The Route', function () {
//   var route;

//   // mock our function call
//   var routerSpy = {
//     route: function () {
//       return routerSpy;
//     }
//   };
//   routerSpy.get = sinon.spy();

//   beforeEach(function () {
//     route = requireApplication('routes/demo.js');
//   });

//   it('Should be an Function', function () {
//     route.should.be.a('function');
//   });

//   it('Check that Router / get method is called', function () {
//     route(routerSpy);
//     expect(routerSpy.route().get).to.have.been.called;
//   });
// });

// describe('Check the Route response using SuperTest', function () {
//   before(function() {
//     global.loggerStub();
//   });
//   var app = jumpstart.app;

//   it('Check the get routes response', function(done) {
//     request(app).get('/').set('Accept','application/json').expect(200).end(function (err, res) {
//       done();
//     });
//   });

// });
