/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-POC - <DESC_HERE>
 */

/*global describe, beforeEach, afterEach, it, expect, should, assert, chai, sinon, proxyquire (see /test/helpers.js)*/

'use strict';
var app = requireApplication('controllers/app');

// it('should be an object', function() {
//   expect(app).to.be.a('object');
// });

describe('app.get', function() {
  console.log('commented all tests');
  // var res = {
  //   render:function(url,returnObject){

  //   }
  // },
  // emailTypes,
  // buseinssUnits,
  // users,
  // usersSpy = sinon.spy(function(error,usersResponse){
  //               usersResponse(null,{});
  //             }),
  // emailTypesSpy = sinon.spy(function(error,emailTypeResponse){
  //                 emailTypeResponse(null,{});
  //                 }),
  // businessUnitsSpy = sinon.spy(function(error,businessUnitResponse){

  //                 }),
  // DBAPI = {
  //           emailTypeClass: function(emailTypes) {
  //             emailTypes = {};
  //             emailTypes.find = emailTypesSpy
  //             return emailTypes;
  //           },
  //            businessUnitClass:function(buseinssUnits){
  //               buseinssUnits = {}
  //               buseinssUnits.find = businessUnitsSpy;
  //               return buseinssUnits;
  //            },
  //            userClass:function(users){
  //             users = {};
  //             users.find = usersSpy;
  //             return users;
  //            }
  //         },
  // req = {};
  // app = proxyquire('../application/controllers/app', {
  //     '../lib/db.js': DBAPI
  //   });
  // describe('with valid data', function () {
  //   app.get(req,res);
  //    it('should fetch the marketing manager details', function() {
  //       expect(usersSpy.calledOnce).to.be.true;
  //     });
  //    it('should fetch the email types', function() {
  //       expect(emailTypesSpy.calledOnce).to.be.true;
  //     });
  //     it('should fetch the business units', function() {
  //       expect(businessUnitsSpy.calledOnce).to.be.true;
  //     });
  // });
});
