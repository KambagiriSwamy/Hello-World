/**
 * Module: ERA
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: Unit test cases for the campaign curd operations
 */
'use strict';

var Campaign = requireApplication('controllers/api/v1/campaign'),
  campaignTestData = require('../../../../fixtures/campaign_test_data');
var EventEmitter = require('events').EventEmitter,
  proxyemitter = sinon.spy(function() {
    return function() {
      var obj = {};
      obj.once = function(name, cb) {
        {
          console.log('proxy method called');
          cb([]);
        }
        return obj;
      };

    };
  });
it('should be an object', function() {
  expect(Campaign).to.be.a('object');
});

describe('Campaign.create', function() {
  it('Should be a function', function(done) {
    Campaign.create.should.be.a('function');
    done();
  });
  //common variables for test cases
  var campaignObj = {},
    getCampaignObjSpy = sinon.spy(function(campaignObj, req) {
      return campaignObj;
    }),
    isValidCampaignSpy = sinon.spy(function(req) {
      var isValid = true;
      return isValid;
    }),
    subittoETSpy = sinon.spy(function(campaignObj, cb) {
      cb(null);
    }),
    campaignLibSpy = {
      getCampaignObject: getCampaignObjSpy,
      isValidCampaign: isValidCampaignSpy
    },
    espObj = {
      submitToET: subittoETSpy,
      getCampaignDeploymentDetails: function(campaign, cb) {
        cb({}, null);
      }
    },
    saveSpy = sinon.spy(function(cb) {
      cb(null);
    }),
    findByIdSpy = sinon.spy(function(campaign_id, callback) {
      callback(errorObj, respObj);
    }),
    campaignStatusSpy = sinon.spy(function(queryObj, cb) {
      cb(null, campaignTestData.approved.state);
    }),
    findSpy = sinon.spy(function(options, columns, sort, callback) {
      callback(errorObj, respObj);
    }),
    removeSpy = sinon.spy(function(callback) {
      callback(errorObj);
    }),
    counterObj = {},
    counterSpy,
    invalidCampaignObject = JSON.parse(JSON.stringify(campaignTestData.invalidCampaignObject)),
    respObj = null,
    errorObj = null,
    EMAILAPI = {
      sendEmail: function(req, campaign) {
        console.log('send email called:::');
      }
    },
    req = {
      'query': {
        'columns': 'campaignName,description'
      },
      'body': invalidCampaignObject,
      'params': {
        'campaign_id': 0
      },
      'session': {
        'loggedInUser': {
          'name': 'Test User'
        }
      }
    },
    code = 0,
    Campaign,
    res = {
      status: function(arg) {
        code = arg;
        var obj = {};
        obj.send = function(message) {};
        obj.jsonp = function(message) {};
        obj.json = function(message) {};
        return obj;
      },
      send: function(err) {
        return err;
      },
      jsonp: function(response) {
        return response;
      },
      json: function(response) {
        return response;
      }
    };
  //proxy db api declarations for create campaign
  var DBAPICMP = {
      campaignClass: function(draftCampaignObject) {
        return function(draftCampaignObject) {
          var campaignObj = {};
          campaignObj.save = saveSpy;
          return campaignObj;
        };
      },
      sequenceGeneratorClass: function() {
        counterObj.findOneAndUpdate = counterSpy;
        return counterObj;
      },
      campaignStateClass: function() {
        var stateObj = {};
        stateObj.findOne = campaignStatusSpy;
        return stateObj;
      },
      campaignLogClass: function() {
        return function(draftCampaignObject) {
          var campaignLogObj = {};
          return campaignLogObj;
        };
      }
    },
    campaignLibrary = {
      addLog: function(loggedInUerName, campaign, content) {
        return campaign;
      },
      processMAAttachments: function(req, cmp) {
        return cmp;
      }
    };
  //proxy db api declarations for update,show and lock campaign
  var DBAPI = {
      campaignClass: function() {
        var campaignObj = {};
        campaignObj.save = saveSpy;
        campaignObj.findById = findByIdSpy;
        campaignObj.find = findSpy;
        return campaignObj;
      },
      sequenceGeneratorClass: function() {
        counterObj.findOneAndUpdate = counterSpy;
        return counterObj;
      },
      campaignStateClass: function() {
        var stateObj = {};
        stateObj.findOne = campaignStatusSpy;
        return stateObj;
      },
      campaignLogClass: function() {
        return function(submitted4approval) {
          var campaignLogObj = {};
          return campaignLogObj;
        };
      }
    },
    utils = {
      setCampaignUnlockTimer: sinon.spy(function(campaignId, tabId, campaignLockMaxTimeout) {})
    };
  Campaign = proxyquire('../application/controllers/api/v1/campaign', {
    '../../../lib/db.js': DBAPI,
    '../../../lib/esp.js': espObj,
    '../../../lib/campaign.js': campaignLibrary,
    '../../../lib/utils.js': utils,
    EventEmitter: proxyemitter
  });
  var CampaignCreate = proxyquire('../application/controllers/api/v1/campaign', {
    '../../../lib/db.js': DBAPICMP,
    '../../../lib/esp.js': espObj,
    '../../../lib/campaign.js': campaignLibrary,
    EventEmitter: proxyemitter
  });
  describe('campaign create scenarios', function() {
    it('should fail to save if the mandatory fields fields are missing', function() {
      req.body = JSON.parse(JSON.stringify(campaignTestData.submitted4approval));
      delete req.body.name;
      CampaignCreate.create(req, res);
      expect(code).to.be.equal(412);
    });
    it('should fail to create a camapign with invalid state', function() {
      req.body = JSON.parse(JSON.stringify(campaignTestData.submitted4approval));
      req.body.state.codeName = 'approved';
      CampaignCreate.create(req, res);
      expect(code).to.be.equal(412);
    });
    it('should failed to load the campaign status from db', function() {
      req.body = JSON.parse(JSON.stringify(campaignTestData.submitted4approval));
      req.body.state.codeName = 'draft';
      campaignStatusSpy = sinon.spy(function(queryObj, cb) {
        cb({}, null);
      });
      CampaignCreate.create(req, res);
      expect(code).to.be.equal(412);
    });
    it('should fail to generate the sequence generator counter', function() {
      req.body = JSON.parse(JSON.stringify(campaignTestData.submitted4approval));
      req.body.state.codeName = 'draft';
      campaignStatusSpy = sinon.spy(function(queryObj, cb) {
        cb(null, req.body.state);
      });
      counterSpy = sinon.spy(function(query, update, options, cb) {
        var counter = {
          name: 'campaign',
          sequence: 2
        };
        cb({}, 2);
      });
      CampaignCreate.create(req, res);
      expect(code).to.be.equal(412);
    });
    it('should fail to create the campaign', function() {
      req.body = JSON.parse(JSON.stringify(campaignTestData.submitted4approval));
      req.body.state.codeName = 'draft';
      campaignStatusSpy = sinon.spy(function(queryObj, cb) {
        cb(null, req.body.state);
      });
      counterSpy = sinon.spy(function(query, update, options, cb) {
        var counter = {
          name: 'campaign',
          sequence: 2
        };
        cb(null, 2);
      });
      saveSpy = sinon.spy(function(cb) {
        cb({});
      });
      CampaignCreate.create(req, res);
      expect(code).to.be.equal(500);
    });
    it('should create the campaign', function() {
      req.body = JSON.parse(JSON.stringify(campaignTestData.submitted4approval));
      req.body.state.codeName = 'draft';
      campaignStatusSpy = sinon.spy(function(queryObj, cb) {
        cb(null, req.body.state);
      });
      counterSpy = sinon.spy(function(query, update, options, cb) {
        var counter = {
          name: 'campaign',
          sequence: 2
        };
        cb(null, 2);
      });
      saveSpy = sinon.spy(function(cb) {
        cb(null);
      });
      CampaignCreate.create(req, res);
      expect(code).to.be.equal(200);
    });
  });
  describe('Campaign.update valid campaign object', function() {
    var approvedData = campaignTestData.approved;
    beforeEach(function() {
      code = 0;
      respObj = null;
      errorObj = null;
      findByIdSpy.calledOnce = false;
      req.body = JSON.parse(JSON.stringify(campaignTestData.approved));
    });
    it('should save the campaign after campaign is approved', function() {
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        var respObj = JSON.parse(JSON.stringify(campaignTestData.approved));
        respObj.save = saveSpy;
        callback(null, respObj);
      });
      Campaign.update(req, res);
      expect(findByIdSpy.calledOnce).to.be.true;
    });
  });
  describe('Campaign.update  With Invalid Campaign object', function() {
    beforeEach(function() {
      code = 0;
      respObj = null;
      errorObj = null;
      findByIdSpy.calledOnce = false;
      req.body = JSON.parse(JSON.stringify(campaignTestData.invalidCampaignObject));
    });
    it('should fail to save campaign with invalid state', function() {
      errorObj = null;
      respObj = JSON.parse(JSON.stringify(campaignTestData.invalidCampaignObject));
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        callback(errorObj, respObj);
      });
      req.body.state.codeName = 'draft';
      Campaign.update(req, res);
      expect(code).to.equal(412);
    });
    it('Should fail to load the campaign with invalid campaign id', function() {
      errorObj = {};
      respObj = null;
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        callback(errorObj, respObj);
      });
      Campaign.update(req, res);
      expect(code).to.equal(500);
    });
    it('Should fail to load the campaign with wrong campaign id', function() {
      errorObj = null;
      respObj = null;
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        callback(errorObj, respObj);
      });
      req.body.requestID = 1234;
      Campaign.update(req, res);
      expect(code).to.equal(404);
    });
    it('Should fail to update the campaign if campaign is declined', function() {
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        var mockrespObj = JSON.parse(JSON.stringify(campaignTestData.invalidCampaignObject));
        mockrespObj.state.codeName = 'declined';
        req.session.loggedInUser.uid = mockrespObj.lock.owner.uid;
        callback(null, mockrespObj);
      });
      Campaign.update(req, res);
      expect(code).to.equal(412);
    });
    it('Should fail to submit campaign if the campaign is declined and approve action triggered', function() {
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        invalidCampaignObject.save = saveSpy;
        var respObj = JSON.parse(JSON.stringify(campaignTestData.invalidCampaignObject));
        respObj.state.codeName = 'declined';
        req.body.state.codeName = 'approved';
        callback(null, respObj);
      });
      req.session = {};
      req.session.loggedInUser = {
        'uid': 'randrew'
      };
      Campaign.update(req, res);
      expect(code).to.equal(412);
    });
    it('Should fail to update the campaign with invalid state transition', function() {
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        invalidCampaignObject.save = saveSpy;
        var respObj = JSON.parse(JSON.stringify(campaignTestData.invalidCampaignObject));
        respObj.state.codeName = 'approved';
        req.body.state.codeName = 'submitted4approval';
        callback(null, respObj);
      });
      req.session = {};
      req.session.loggedInUser = {
        'uid': 'randrew'
      };
      Campaign.update(req, res);
      expect(code).to.equal(412);
    });
    it('Should update the campaign with valid state transition', function() {
      findByIdSpy = sinon.spy(function(campaign_id, callback) {

        var respObj = JSON.parse(JSON.stringify(campaignTestData.submitted4approval));
        req.body.state.codeName = 'submitted4approval';
        respObj.save = sinon.spy(function(cb) {
          cb(null);
        });;
        callback(null, respObj);
      });
      campaignStatusSpy = sinon.spy(function(queryObj, cb) {
        var state = {
          'code': 'RID',
          'codeName': 'submitted4approval',
          'name': 'Campaign Requested',
          'logDisplayName': 'Pending Initial Approval'
        };
        cb(null, state);
      });
      req.session = {};
      req.session.loggedInUser = {
        'uid': 'randrew'
      };
      Campaign.update(req, res);
      expect(code).to.equal(200);
    });
    it('Should update and add log if campaign state names are not equal', function() {
      findByIdSpy = sinon.spy(function(campaign_id, callback) {

        var respObj = JSON.parse(JSON.stringify(campaignTestData.submitted4approval));
        req.body.state.codeName = 'submitted4approval';
        respObj.save = sinon.spy(function(cb) {
          cb(null);
        });;
        callback(null, respObj);
      });
      campaignStatusSpy = sinon.spy(function(queryObj, cb) {
        var state = {
          'code': 'RID',
          'codeName': 'approved',
          'name': 'Campaign Requested',
          'logDisplayName': 'Pending Initial Approval'
        };
        cb(null, state);
      });
      req.session = {};
      req.session.loggedInUser = {
        'uid': 'randrew'
      };
      Campaign.update(req, res);
      expect(code).to.equal(200);
    });
    it('Should fail to update the campaign', function() {
      saveSpy = sinon.spy(function(cb) {
        cb({});
      });
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        invalidCampaignObject.save = saveSpy;
        var respObj = JSON.parse(JSON.stringify(campaignTestData.invalidCampaignObject));
        respObj.state.codeName = 'approved';
        req.body.state.codeName = 'approved';
        respObj.save = saveSpy;
        callback(null, respObj);
      });
      campaignStatusSpy = sinon.spy(function(queryObj, cb) {
        cb(null, campaignTestData.approved.state);
      });
      req.session = {};
      req.session.loggedInUser = {
        'uid': 'randrew'
      };
      Campaign.update(req, res);
      expect(code).to.equal(500);
    });
    it('Should fail to save  campaign with empty name', function() {
      delete req.body.name;
      req.body.state.codeName = 'submitted4approval';
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        var respObj = JSON.parse(JSON.stringify(campaignTestData.invalidCampaignObject));
        respObj.state.codeName = 'draft';
        callback(null, respObj);
      });
      Campaign.update(req, res);
      expect(code).to.equal(412);
    });
  });


  describe('Fect All Campaigns', function() {
    var session = {
      'role': {
        'codeName': 'mm'
      }
    }
    beforeEach(function() {

      respObj = null;
      errorObj = null;
      code = 0;
      findSpy.calledOnce = false;
    });
    it('should fetch all campaigns', function() {
      respObj = {}, errorObj = null;
      req.session.loggedInUser = session;
      req.body = '';
      Campaign.index(req, res);
      expect(findSpy.calledOnce).to.be.true;
    });
    it('should fetch all campaings with filter', function() {
      respObj = {}, errorObj = null;
      req.session.loggedInUser = session;
      req.body = {};
      req.body.requestID = '12345';
      req.body.mhid = '2222222';
      req.body.emailType = 'ET_MA';
      req.body.businessUnit = 'test BA';
      req.body.campaignStatus = 'active';
      req.body.deploymentStartDate = '02/23/2015';
      req.body.deploymentEndDate = '02/23/2015';
      req.body.requestedStartDate = '02/23/2015';
      req.body.requestedEndDate = '02/23/2015';
      req.body.action = 'filter';
      req.body.uid = 'testaxpi';
      req.body.edis = true;
      Campaign.index(req, res);
      expect(code).to.equal(200);
    });
    it('should fetch all campaings with out filter', function() {
      respObj = {}, errorObj = null;
      req.session.loggedInUser = session;
      req.body = {};
      req.body.requestID = null;
      req.body.mhid = null;
      req.body.emailType = null;
      req.body.businessUnit = null;
      req.body.campaignStatus = null;
      req.body.deploymentStartDate = null;
      req.body.deploymentEndDate = null;
      req.body.requestedStartDate = null;
      req.body.requestedEndDate = null;
      req.body.action = 'filter';
      req.body.uid = null;
      req.body.edis = false;
      Campaign.index(req, res);
      expect(code).to.equal(200);
    });
    it('should fail to fetch campaigns', function() {
      respObj = null, errorObj = {};
      req.query.columns = '';
      req.body = '';
      Campaign.index(req, res);
      expect(code).to.equal(500);
    });
    it('should fetch campaigns with partial search', function() {
      respObj = null, errorObj = {};
      respObj = [JSON.parse(JSON.stringify(campaignTestData.mockCampaignObject))];
      req.query.columns = '';
      req.body = {};
      req.body.action = 'filter';
      req.body.requestID = '2';
      findSpy = sinon.spy(function(options, columns, sort, callback) {
        callback(null, respObj);
      });
      Campaign.index(req, res);
      expect(code).to.equal(200);
    });
    it('should return empty campaigns with partial search', function() {
      respObj = null, errorObj = {};
      respObj = [JSON.parse(JSON.stringify(campaignTestData.mockCampaignObject))];
      req.query.columns = '';
      req.body = {};
      req.body.action = 'filter';
      req.body.requestID = '89';
      findSpy = sinon.spy(function(options, columns, sort, callback) {
        callback(null, respObj);
      });
      Campaign.index(req, res);
      expect(code).to.equal(200);
    });
    it('should export the campaing with selected fields', function() {
      respObj = null, errorObj = {};
      respObj = [JSON.parse(JSON.stringify(campaignTestData.mockCampaignObject))];
      req.body = {};
      req.body.columns = ["mailHistory,ma.mailHistory", "requestID"];
      req.body.action = 'export';
      req.body.heading = ["Mail History ID", "Request ID"];
      findSpy = sinon.spy(function(options, columns, sort, callback) {
        callback(null, respObj);
      });
      Campaign.index(req, res);
      expect(code).to.equal(200);
    });
    it('should fetch the campaigns by Id', function() {
      respObj = JSON.parse(JSON.stringify(campaignTestData.mockCampaignObject)), errorObj = {};
      req.params.campaign_id = 268;
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        callback(null, respObj);
      });
      Campaign.show(req, res);
      expect(code).to.be.equal(0);
    });
    it('should fail to load the campaign with invalid id', function() {
      req.params.campaign_id = 0;
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        callback({}, null);
      });
      Campaign.show(req, res);
      expect(code).to.be.equal(500);
    });
    it('should fail to load the campaign with wrong campaign id', function() {
      req.params.campaign_id = 1212;
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        callback(null, null);
      });
      Campaign.show(req, res);
      expect(code).to.be.equal(412);
    });
    it('should fail to get the campaign deployment details', function() {
      req.params.campaign_id = 1212;
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        var campaign = {};
        campaign.state = {};
        campaign.state.codeName = 'rollBack2Manager';
        callback(null, campaign);
      });
      Campaign.show(req, res);
      expect(code).to.be.equal(500);
    });
    it('should fail to get the campaign deployment details', function() {
      req.params.campaign_id = 1212;
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        var campaign = {};
        campaign.state = {};
        campaign.state.codeName = 'rollBack2Manager';
        callback(null, campaign);
      });
      espObj.getCampaignDeploymentDetails = function(campaign, cb) {
        cb(null, {});
      }
      Campaign.show(req, res);
      expect(code).to.be.equal(200);
    });
  });
  describe('Campaign UnLock scenarios', function() {
    beforeEach(function() {
      respObj = null;
      errorObj = null;
      code = 0;
    });
    it('should fail to find the campaign by id', function() {
      req.params.campaignId = 1212;
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        callback({}, null);
      });
      Campaign.unlock(req, res);
      expect(code).to.be.equal(500);
    });
    it('should fail to load the campaign with valid id', function() {
      req.params.campaignId = 280;
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        callback(null, null);
      });
      Campaign.unlock(req, res);
      expect(code).to.be.equal(200);
    });
    it('should fail to unlock the campaing if the campaing is not locked to any user', function() {
      req.params.campaignId = 280;
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        var cmp = {};
        cmp.lock = {};
        cmp.lock.isLocked = false;
        cmp.lock.key = '123';
        cmp.lock.owner = 'randrew';
        callback(null, cmp);
      });
      Campaign.unlock(req, res);
      expect(code).to.be.equal(200);
    });
    it('should fail to unlock the campaing for non-admin users', function() {
      req.params.campaignId = 280;
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        var cmp = JSON.parse(JSON.stringify(campaignTestData.campaignLockObject));
        cmp.lock.owner = {
          'uid': 'randrew1'
        };
        req.session = {};
        req.session.loggedInUser = {
          'role': {
            'codeName': 'mm'
          },
          'uid': 'randrew'
        };
        callback(null, cmp);
      });
      Campaign.unlock(req, res);
      expect(code).to.be.equal(200);
    });
    it('should  unlock the campaing and save in the db', function() {
      req.params.campaignId = 280;
      saveSpy = sinon.spy(function(cb) {
        cb(null);
      });
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        var cmp = JSON.parse(JSON.stringify(campaignTestData.campaignLockObject));
        cmp.save = saveSpy;
        req.session = {};
        req.session.loggedInUser = {
          'role': {
            'codeName': 'axpi'
          },
          'uid': 'randrew',
          'name': 'name'
        };
        callback(null, cmp);
      });
      Campaign.unlock(req, res);
      expect(code).to.be.equal(200);
    });
    it('should  fail to update the unlock details in db', function() {
      req.params.campaignId = 280;
      saveSpy = sinon.spy(function(cb) {
        cb({});
      });
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        var cmp = JSON.parse(JSON.stringify(campaignTestData.campaignLockObject));
        cmp.lock.owner = {
          'uid': 'randrew'
        };
        cmp.save = saveSpy;
        req.session = {};
        req.session.loggedInUser = {
          'role': {
            'codeName': 'axpi'
          },
          'uid': 'randrew',
          'name': 'name'
        };
        callback(null, cmp);
      });
      Campaign.unlock(req, res);
      expect(code).to.be.equal(500);
    });
  });
  describe('Campaign extend lock timer  scenarios', function() {
    it('should fail to find the campaign by id', function() {
      req.params.campaignId = 1212;
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        callback({}, null);
      });
      Campaign.extendLockTimer(req, res);
      expect(code).to.be.equal(500);
    });
    it('should fail to load the campaign with valid id', function() {
      req.params.campaignId = 280;
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        callback(null, null);
      });
      Campaign.extendLockTimer(req, res);
      expect(code).to.be.equal(200);
    });
    it('should fail to unlock the campaing if the campaing is not locked to any user', function() {
      req.params.campaignId = 280;
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        var cmp = JSON.parse(JSON.stringify(campaignTestData.campaignLockObject));
        cmp.lock.isLocked = false;
        callback(null, cmp);
      });
      Campaign.extendLockTimer(req, res);
      expect(code).to.be.equal(200);
    });
    it('should fail to extend the campaing lock time if the campaing is not locked by loggedin user', function() {
      req.params.campaignId = 280;
      req.params.tabId = '23';
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        var cmp = JSON.parse(JSON.stringify(campaignTestData.campaignLockObject));
        callback(null, cmp);
      });
      Campaign.extendLockTimer(req, res);
      expect(code).to.be.equal(200);
    });
    it('should fail to extend the campaing lock time if the campaing lock has timeout', function() {
      req.params.campaignId = 280;
      req.params.tabId = '123';
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        var cmp = JSON.parse(JSON.stringify(campaignTestData.campaignLockObject));
        cmp.lock.expiresAt = new Date(new Date().setDate(new Date().getDate() - 1));
        callback(null, cmp);
      });
      Campaign.extendLockTimer(req, res);
      expect(code).to.be.equal(200);
    });
    it('should extend the campaing lock time', function() {
      req.params.campaignId = 280;
      req.params.tabId = '123';
      saveSpy = sinon.spy(function(cb) {
        cb(null);
      });
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        var cmp = JSON.parse(JSON.stringify(campaignTestData.campaignLockObject));
        cmp.lock.expiresAt = new Date(new Date().setDate(new Date().getDate() + 1));
        cmp.save = saveSpy;
        callback(null, cmp);
      });
      Campaign.extendLockTimer(req, res);
      expect(code).to.be.equal(200);
    });
    it('should fail to save extend the campaing lock time', function() {
      req.params.campaignId = 280;
      req.params.tabId = '123';
      saveSpy = sinon.spy(function(cb) {
        cb({});
      });
      findByIdSpy = sinon.spy(function(campaign_id, callback) {
        var cmp = JSON.parse(JSON.stringify(campaignTestData.campaignLockObject));
        cmp.lock.expiresAt = new Date(new Date().setDate(new Date().getDate() + 1));
        cmp.save = saveSpy;
        callback(null, cmp);
      });
      Campaign.extendLockTimer(req, res);
      expect(code).to.be.equal(500);
    });
  });

});
