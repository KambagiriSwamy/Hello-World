/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 (ERA) - This file defines test cases for excel.js controller for doing all excel related operations at Node end.
 */
'use strict'
var excelReader = requireApplication('controllers/api/v1/excel');

it('should be an object', function() {
  expect(excelReader).to.be.a('object');
});
describe('excel', function() {
  var responseCode, res = {
      status: function(code) {
        var obj = {};
        obj.jsonp = function() {};
        obj.json = function() {};
        obj.send = function() {};
        responseCode = code;
        return obj;
      },
      send: function(message) {

      }
    },
    req = {
      files: {
        file: {}
      }
    },
    fs = {
      readFile: function(path, encodetype, cb) {
        cb({}, null);
      }
    },
    jsontocsv = {
      csv2json: function(stream, callback) {
        callback({}, null);
      }
    },
    utils = {
      cellDartValidator: function(fileData, cb) {
        cb({}, null);
      }
    },
    excelExtractor = {
      getJson: function(path) {
        return {};
      }
    };
  excelReader = proxyquire('../application/controllers/api/v1/excel', {
    'fs': fs,
    'json-2-csv': jsontocsv,
    '../../../lib/utils': utils,
    '../../../lib/excel-reader': excelExtractor
  });
  describe('Fetch campaing subtype by campaign id', function() {
    it('should fail to read other than excel or csv file', function() {
      req.files.file.originalFilename = 'test.doc';
      console.log(excelReader);
      excelReader.excelReader(req, res);
      expect(responseCode).to.equal(412);
    });
    it('should fail to read with empty file', function() {
      req.files.file.originalFilename = null;
      console.log(excelReader);
      excelReader.excelReader(req, res);
      expect(responseCode).to.equal(412);
    });
    it('should fail to read csv', function() {
      req.files.file.originalFilename = 'test.csv';
      excelReader.excelReader(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should fail to convert csv to json', function() {
      req.files.file.originalFilename = 'test.csv';
      fs.readFile = function(path, encodetype, cb) {
        cb(null, {});
      }
      excelReader.excelReader(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should fail parse if there is any data issue', function() {
      req.files.file.originalFilename = 'test.csv';
      fs.readFile = function(path, encodetype, cb) {
        cb(null, {});
      }
      jsontocsv.csv2json = function(stream, callback) {
        callback(null, {});
      }
      req.params = {};
      req.params.excel_for = 'cells';
      excelReader.excelReader(req, res);
      expect(responseCode).to.equal(412);
    });
    it('should  parse csv and respond the data for client', function() {
      req.files.file.originalFilename = 'test.csv';
      fs.readFile = function(path, encodetype, cb) {
        cb(null, {});
      }
      jsontocsv.csv2json = function(stream, callback) {
        callback(null, {});
      }
      utils.cellDartValidator = function(fileData, cb) {
        cb(null, {});
      }
      req.params = {};
      req.params.excel_for = 'cells';
      excelReader.excelReader(req, res);
      expect(responseCode).to.equal(200);
    });
    it('should fail parse if there is any data issue xls', function() {
      req.files.file.originalFilename = 'test.xls';
      fs.readFile = function(path, encodetype, cb) {
        cb(null, {});
      }
      jsontocsv.csv2json = function(stream, callback) {
        callback(null, {});
      }
      utils.cellDartValidator = function(fileData, cb) {
        cb({}, {});
      }
      req.params = {};
      req.params.excel_for = 'cells';
      excelReader.excelReader(req, res);
      expect(responseCode).to.equal(412);
    });
    it('should  parsexsl file and send data to client', function() {
      req.files.file.originalFilename = 'test.xls';
      fs.readFile = function(path, encodetype, cb) {
        cb(null, {});
      }
      jsontocsv.csv2json = function(stream, callback) {
        callback(null, {});
      }
      utils.cellDartValidator = function(fileData, cb) {
        cb(null, {});
      }
      req.params = {};
      req.params.excel_for = 'cells';
      excelReader.excelReader(req, res);
      expect(responseCode).to.equal(200);
    });
  });

});
