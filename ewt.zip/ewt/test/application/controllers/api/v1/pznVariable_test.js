/**
 * Module: ERA
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: Unit test cases for pznVariable
 */
'use strict';

var pznVariable = requireApplication('controllers/api/v1/pznVariable.js');
describe('pznVariable.index', function() {
  it('Should be a function : this protects function from getting renamed', function(done) {
    pznVariable.index.should.be.a('function');
    done();
  });
  var responseCode;
  var res = {
      status: function(code) {
        var obj = {};
        obj.jsonp = function() {};
        obj.send = function() {};
        obj.json = function() {};
        responseCode = code;
        return obj;
      },
      send: function(message) {

      }
    },
    req = {},
    findSpy = sinon.spy(function(queryOptions, columns, sort, callback) {
      callback({}, null);
    }),
    DBAPI = {
      pznVariableClass: function() {
        var pznObj = {};
        pznObj.find = findSpy;
        return pznObj;
      }
    };
  pznVariable = proxyquire('../application/controllers/api/v1/pznVariable', {
    '../../../lib/db.js': DBAPI
  });
  describe('pznVariable find scenarios', function() {

    it('should fail to load pznVariable', function() {
      pznVariable.index(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should load pznVariable', function() {
      findSpy = sinon.spy(function(queryOptions, columns, sort, callback) {
        callback(null, {});
      });
      pznVariable.index(req, res);
      expect(responseCode).to.equal(200);
    });
  });
});
