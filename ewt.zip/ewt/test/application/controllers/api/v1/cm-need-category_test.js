/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description:EWT-2.0 (ERA) - Unit test cases for cm-need-category
 */
'use strict'

var cmNeedCategory = requireApplication('controllers/api/v1/cm-need-category');
describe('cmNeedCategory.showByBusinessUnitId', function() {
  describe('with valid data', function() {
    var code = 0,
      error = null,
      res = {
        send: function(message) {

        },
        status: function(response) {
          code = response;
          var statusObj = {};
          statusObj.json = function(data) {};
          statusObj.send = function(data) {}
          return statusObj;
        },
        json: function(cmNeedCategoryResponse) {

        }
      },
      req = {
        "params": {
          "business_unit_id": "U200"
        }
      },
      cmNeedCategoryObj = {},
      findSpy = sinon.spy(function(foreignkey, cb) {
        var cmNeedCategoryResponse = {};
        cb(error, {});
      }),
      DBAPI = {
        cmNeedCategoryClass: function() {
          cmNeedCategoryObj.find = findSpy;
          return cmNeedCategoryObj;
        }
      };
    cmNeedCategory = proxyquire('../application/controllers/api/v1/cm-need-category', {
      '../../../lib/db.js': DBAPI
    });

    it('should fetch the cm-need-category for business_unit_code', function() {
      req.params = {};
      req.params.business_unit_code = '002';
      cmNeedCategory.showByBusinessUnitCode(req, res);
      expect(code).to.equal(200);
    });
    it('should fail to fetch the cm-need-category for business_unit_code', function() {
      req.params = {};
      req.params.business_unit_code = '002';
      findSpy = sinon.spy(function(foreignkey, cb) {
        var cmNeedCategoryResponse = {};
        cb({}, null);
      });
      cmNeedCategory.showByBusinessUnitCode(req, res);
      expect(code).to.equal(500);
    });
  });
});