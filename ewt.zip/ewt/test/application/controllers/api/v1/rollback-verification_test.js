/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 (ERA) - Unit test for rollback verification service
 */

'use strict';

var campaignTestData = require('../../../../fixtures/rollback_validcampaign');

var rollbackVerificationSrvc = requireApplication('controllers/api/v1/rollback-verification');

it('should be an object', function() {
  expect(rollbackVerificationSrvc).to.be.a('object');
});

describe('rollbackVerificationSrvc.verify', function() {
  describe('test for invalid campaign id', function() {
    var responseCode = 0;
    var error = null;
    var res = {
        send: function(message) {},
        status: function(response) {
          responseCode = response;
          return this;
        },
        json: function(attachmentTypes) {}
      },
      req = {
        "params": {
          "requestID": "008"
        }
      },
      campaignObj = {},
      findOneSpy = sinon.spy(function(requestID, cb) {
        return cb(null, null);
      }),
      DBAPI = {
        campaignClass: function() {
          campaignObj.findOne = findOneSpy;
          return campaignObj;
        }
      };

    rollbackVerificationSrvc = proxyquire('../application/controllers/api/v1/rollback-verification', {
      '../../../lib/db.js': DBAPI
    });
    rollbackVerificationSrvc.verify(req, res);
    it('validate return code', function() {
      expect(responseCode).to.equal(500);
    });
  });
  describe('test for DB error', function() {
    var responseCode = 0;
    var error = null;
    var res = {
        send: function(message) {},
        status: function(response) {
          responseCode = response;
          return this;
        },
        json: function(attachmentTypes) {}
      },
      req = {
        "params": {
          "requestID": "008"
        }
      },
      campaignObj = {},
      findOneSpy = sinon.spy(function(requestID, cb) {
        return cb('Data base error', null);
      }),
      DBAPI = {
        campaignClass: function() {
          campaignObj.findOne = findOneSpy;
          return campaignObj;
        }
      };

    rollbackVerificationSrvc = proxyquire('../application/controllers/api/v1/rollback-verification', {
      '../../../lib/db.js': DBAPI
    });
    rollbackVerificationSrvc.verify(req, res);
    it('validate return code', function() {
      expect(responseCode).to.equal(500);
    });
  });
  describe('test for ET error', function() {
    var responseCode = 0;
    var error = null;
    var res = {
        send: function(message) {},
        status: function(response) {
          responseCode = response;
          return this;
        },
        json: function(attachmentTypes) {}
      },
      req = {
        "params": {
          "requestID": "17510"
        }
      },
      campaignObj = {},
      findOneSpy = sinon.spy(function(requestID, cb) {
        return cb(null, campaignTestData.validCampaignObj);
      }),
      getCampaignDeploymentDetailsSpy = sinon.spy(function(campaignObj, cb) {
        return cb('et communication error', null);
      }),

      DBAPI = {
        campaignClass: function() {
          campaignObj.findOne = findOneSpy;
          return campaignObj;
        }
      },
      espMock = {
        getCampaignDeploymentDetails: getCampaignDeploymentDetailsSpy
      };;

    rollbackVerificationSrvc = proxyquire('../application/controllers/api/v1/rollback-verification', {
      '../../../lib/db.js': DBAPI,
      '../../../lib/esp.js': espMock
    });
    rollbackVerificationSrvc.verify(req, res);
    it('validate return code', function() {
      expect(responseCode).to.equal(500);
    });
  });
  describe('test for ET valid response : rollback allowed, all future dates', function() {
    var responseCode = 0;
    var response = {};
    var error = null;
    var res = {
        send: function(message) {},
        status: function(response) {
          responseCode = response;
          return this;
        },
        json: function(attachmentTypes) {
          response = attachmentTypes;
        }
      },
      req = {
        "params": {
          "requestID": "17510"
        }
      },
      campaignObj = {},
      findOneSpy = sinon.spy(function(requestID, cb) {
        campaignObj = campaignTestData.validCampaignObj;
        console.log('spied find called' + campaignTestData);
        return cb(null, campaignTestData.validCampaignObj);
      }),
      getCampaignDeploymentDetailsSpy = sinon.spy(function(campaignObj, cb) {
        return cb(null, campaignTestData.validCampaignObj);
      }),
      DBAPI = {
        campaignClass: function() {
          campaignObj.findOne = findOneSpy;
          return campaignObj;
        }
      },
      espMock = {
        getCampaignDeploymentDetails: getCampaignDeploymentDetailsSpy
      };

    rollbackVerificationSrvc = proxyquire('../application/controllers/api/v1/rollback-verification', {
      '../../../lib/db.js': DBAPI,
      '../../../lib/esp.js': espMock
    });
    rollbackVerificationSrvc.verify(req, res);
    it('validate return code', function() {
      expect(responseCode).to.equal(200);
    });
  });
  describe('test for ET valid response : rollback not allowed, all campaign drops are in the past', function() {
    var responseCode = 0;
    var response = {};
    var error = null;
    var res = {
        send: function(message) {},
        status: function(response) {
          responseCode = response;
          return this;
        },
        json: function(attachmentTypes) {
          response = attachmentTypes;
        }
      },
      req = {
        "params": {
          "requestID": "17510"
        }
      },
      campaignObj = {},
      findOneSpy = sinon.spy(function(requestID, cb) {
        campaignObj = campaignTestData.deployedCampaign;
        console.log('spied find called' + campaignTestData);
        return cb(null, campaignTestData.deployedCampaign);
      }),
      getCampaignDeploymentDetailsSpy = sinon.spy(function(campaignObj, cb) {
        return cb(null, campaignTestData.deployedCampaign);
      }),
      DBAPI = {
        campaignClass: function() {
          campaignObj.findOne = findOneSpy;
          return campaignObj;
        }
      },
      espMock = {
        getCampaignDeploymentDetails: getCampaignDeploymentDetailsSpy
      };

    rollbackVerificationSrvc = proxyquire('../application/controllers/api/v1/rollback-verification', {
      '../../../lib/db.js': DBAPI,
      '../../../lib/esp.js': espMock
    });
    rollbackVerificationSrvc.verify(req, res);
    it('validate return code', function() {
      expect(responseCode).to.equal(412);
    });
  });
  describe('test for ET valid response : rollback not allowed, some drops are deployed', function() {
    var responseCode = 0;
    var response = {};
    var error = null;
    var res = {
        send: function(message) {},
        status: function(response) {
          responseCode = response;
          return this;
        },
        json: function(attachmentTypes) {
          response = attachmentTypes;
        }
      },
      req = {
        "params": {
          "requestID": "17510"
        }
      },
      campaignObj = {},
      findOneSpy = sinon.spy(function(requestID, cb) {
        campaignObj = campaignTestData.deployedAtET;
        console.log('spied find called' + campaignTestData);
        return cb(null, campaignTestData.deployedAtET);
      }),
      getCampaignDeploymentDetailsSpy = sinon.spy(function(campaignObj, cb) {
        return cb(null, campaignTestData.deployedAtET);
      }),
      DBAPI = {
        campaignClass: function() {
          campaignObj.findOne = findOneSpy;
          return campaignObj;
        }
      },
      espMock = {
        getCampaignDeploymentDetails: getCampaignDeploymentDetailsSpy
      };

    rollbackVerificationSrvc = proxyquire('../application/controllers/api/v1/rollback-verification', {
      '../../../lib/db.js': DBAPI,
      '../../../lib/esp.js': espMock
    });
    rollbackVerificationSrvc.verify(req, res);
    it('validate return code', function() {
      expect(responseCode).to.equal(412);
    });
  });
});
