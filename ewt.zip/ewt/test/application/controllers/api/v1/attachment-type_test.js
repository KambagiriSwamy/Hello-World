/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: Unit test for attachment type service.
 */
'use strict'

var attachmentTypeSrvc = requireApplication('controllers/api/v1/attachment-type');

it('should be an object', function() {
  expect(attachmentTypeSrvc).to.be.a('object');
});

describe('attachmentTypeSrvc.showByEmailTypeCode', function() {
  describe('with valid data', function() {
    var responseCode = 0;
    var error = null;
    var res = {
        send: function(message) {

        },
        status: function(response) {
          responseCode = response;
          return this;
        },
        json: function(attachmentTypes) {

        }
      },
      req = {
        "params": {
          "campaign_email_type_code": "008"
        }
      },
      attachementTypesObj = {},
      findSpy = sinon.spy(function(emailTypeCode, cb) {
        var attachementTypesObj = {};
        return cb(null, attachementTypesObj);
      }),
      DBAPI = {
        attachmentTypeClass: function() {
          attachementTypesObj.find = findSpy;
          return attachementTypesObj;
        }
      };
    attachmentTypeSrvc = proxyquire('../application/controllers/api/v1/attachment-type', {
      '../../../lib/db': DBAPI
    });
    attachmentTypeSrvc.showByEmailTypeCode(req, res);
    it('validate return code', function() {
      expect(responseCode).to.equal(200);
    });
  });

  describe('test for error callback', function() {
    var responseCode = 0;
    var error = null;
    var res = {
        send: function(message) {

        },
        status: function(response) {
          responseCode = response;
          return this;
        },
        json: function(attachmentTypes) {

        }
      },
      req = {
        "params": {
          "campaign_email_type_code": "008"
        }
      },
      attachementTypesObj = {},
      findSpy = sinon.spy(function(emailTypeCode, cb) {
        var attachementTypesObj = {};
        return cb('spied error object');
      }),
      DBAPI = {
        attachmentTypeClass: function() {
          attachementTypesObj.find = findSpy;
          return attachementTypesObj;
        }
      };
    attachmentTypeSrvc = proxyquire('../application/controllers/api/v1/attachment-type', {
      '../../../lib/db': DBAPI
    });
    attachmentTypeSrvc.showByEmailTypeCode(req, res);
    it('validate return code', function() {
      expect(responseCode).to.equal(500);
    });
  });
});
