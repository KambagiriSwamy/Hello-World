/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-POC - <DESC_HERE>
 */
'use strict';

var mhidValidator = requireApplication('controllers/api/v1/mhid-validator.js'),
  campaignTestData = require('../../../../fixtures/campaign_test_data.js');
it('should be an object : this protects file from getting renamed', function() {
  expect(mhidValidator).to.be.a('object');
});

describe('Validator.validate', function() {
  it('Should be a function : this protects function from getting renamed', function(done) {
    mhidValidator.validate.should.be.a('function');
    done();
  });
  //common variables for test cases
  var responseCode;
  var res = {
      status: function(code) {
        var obj = {};
        obj.jsonp = function() {};
        obj.send = function() {};
        responseCode = code;
        return obj;
      },
      send: function(message) {

      }
    },
    countSpy = sinon.spy(function(options, cb) {}),
    findByIdSpy = sinon.spy(function(queryOptions, callback) {}),
    saveSpy = sinon.spy(function(cb) {
      cb(null, {});
    }),
    findOneSpy = sinon.spy(function(options, cb) {
      cb(null, JSON.parse(JSON.stringify(campaignTestData.mhidData)));
    }),
    req = {
      params: {},
      body: {
        'mailHistory': []
      }
    },
    DBAPI = {
      campaignClass: function(validCampaignObj) {
        var campaignObj = {};
        campaignObj.count = countSpy;
        campaignObj.findById = findByIdSpy;
        campaignObj.findOne = findOneSpy;
        return campaignObj;
      },
      maMailHistoryClass: function() {
        return function() {};
      }
    };
  mhidValidator = proxyquire('../application/controllers/api/v1/mhid-validator', {
    '../../../lib/db.js': DBAPI
  });
  describe('Validate MHID exsists', function() {
    var validCampaignObj = campaignTestData.submitted4approval;
    beforeEach(function() {
      responseCode = 0;
      req.body = JSON.parse(JSON.stringify(campaignTestData.submitted4approval));
    });

    it('should fail to validate with mhid length less than 8 digits', function() {
      req.params.mhid = '12345';
      mhidValidator.validate(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should fail validate if mhid is already exsists', function() {
      countSpy = sinon.spy(function(options, cb) {
        cb({}, 1);
      });
      req.params.mhid = '12345678';
      mhidValidator.validate(req, res);
      expect(responseCode).to.equal(200);
    });
    it('should return success if mhid doesn;t exsists', function() {
      countSpy = sinon.spy(function(options, cb) {
        cb(null, 0);
      });
      req.body.mailHistory[0] = {};
      req.body.mailHistory[0].mhid = '12345678';
      mhidValidator.validate(req, res);
      expect(responseCode).to.equal(200);
    });
  });
  describe('MHID create', function() {
    var validCampaignObj = campaignTestData.mhidData;
    beforeEach(function() {
      responseCode = 0;
      req.body = JSON.parse(JSON.stringify(campaignTestData.mhidData));
    });
    it('should fail to create mhid with invalid campaign', function() {
      findOneSpy = sinon.spy(function(options, cb) {
        cb({}, req.body);
      });
      req.body.requestID = '1234';
      mhidValidator.create(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should fail create mhid with same mhid and same cell', function() {
      req.body = JSON.parse(JSON.stringify(campaignTestData.mhidObj));
      findOneSpy = sinon.spy(function(options, cb) {
        cb(null, JSON.parse(JSON.stringify(campaignTestData.mhidData)));
      });
      req.body.requestID = '1234';
      mhidValidator.create(req, res);
      expect(responseCode).to.equal(412);
    });
    it('should fail to create mhid with cellId', function() {
      req.body = JSON.parse(JSON.stringify(campaignTestData.mhidObj));
      req.body.cell.srcCode = '12';
      saveSpy = sinon.spy(function(cb) {
        cb({}, null);
      });
      findOneSpy = sinon.spy(function(options, cb) {
        var campaignObj1 = JSON.parse(JSON.stringify(campaignTestData.mhidData));
        campaignObj1.save = saveSpy;
        campaignObj1.markModified = function(key) {};
        cb(null, campaignObj1);
      });
      req.body.requestID = '1234';
      mhidValidator.create(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should  create mhid with cellId', function() {
      req.body = JSON.parse(JSON.stringify(campaignTestData.mhidObj));
      req.body.cell.srcCode = '12';
      saveSpy = sinon.spy(function(cb) {
        cb({}, null);
      });
      findOneSpy = sinon.spy(function(options, cb) {
        var campaignObj1 = JSON.parse(JSON.stringify(campaignTestData.mhidData));
        campaignObj1.save = saveSpy;
        campaignObj1.markModified = function(key) {};
        cb(null, campaignObj1);
      });
      req.body.requestID = '1234';
      mhidValidator.create(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should fail to create mhid with invalid mhid', function() {
      req.body = JSON.parse(JSON.stringify(campaignTestData.mhidData));
      req.body.newMHID = campaignTestData.newMHID;
      req.body.oldMHID = campaignTestData.oldMHID;
      req.body.newMHID.mhid = 55555556;
      req.body.oldMHID.mhid = 55555556;
      saveSpy = sinon.spy(function(cb) {
        cb({}, null);
      });
      findOneSpy = sinon.spy(function(options, cb) {
        var campaignObj2 = JSON.parse(JSON.stringify(campaignTestData.mhidData));
        campaignObj2.save = saveSpy;
        campaignObj2.markModified = function(key) {};
        cb(null, campaignObj2);
      });
      req.body.requestID = '1234';
      mhidValidator.create(req, res);
      expect(responseCode).to.equal(412);
    });
    it('should fail to create mhid with invalid cellid', function() {
      req.body = JSON.parse(JSON.stringify(campaignTestData.mhidData));
      req.body.newMHID = campaignTestData.newMHID;
      req.body.oldMHID = campaignTestData.oldMHID;
      req.body.oldMHID.cell.srcCode = '1234';
      req.body.newMHID.mhid = '55555555';
      req.body.oldMHID.mhid = '55555555';
      saveSpy = sinon.spy(function(cb) {
        cb({}, null);
      });
      findOneSpy = sinon.spy(function(options, cb) {
        var campaignObj2 = JSON.parse(JSON.stringify(campaignTestData.mhidData));
        campaignObj2.save = saveSpy;
        campaignObj2.markModified = function(key) {};
        cb(null, campaignObj2);
      });
      req.body.requestID = '1234';
      mhidValidator.create(req, res);
      expect(responseCode).to.equal(412);
    });
    it('should fail to create mhid with unique mhid and cellid', function() {
      req.body = JSON.parse(JSON.stringify(campaignTestData.mhidData));
      req.body.newMHID = campaignTestData.newMHID;
      req.body.oldMHID = campaignTestData.oldMHID;
      req.body.oldMHID.cell.srcCode = '2';
      req.body.newMHID.cell.srcCode = '1';
      req.body.newMHID.mhid = '55555512';
      req.body.oldMHID.mhid = '55555512';
      saveSpy = sinon.spy(function(cb) {
        cb({}, null);
      });
      findOneSpy = sinon.spy(function(options, cb) {
        var campaignObj2 = JSON.parse(JSON.stringify(campaignTestData.mhidData));
        campaignObj2.save = saveSpy;
        campaignObj2.markModified = function(key) {};
        cb(null, campaignObj2);
      });
      req.body.requestID = '1234';
      mhidValidator.create(req, res);
      expect(responseCode).to.equal(412);
    });
    it('should  fail create mhid with  mhid and cellid', function() {
      req.body = JSON.parse(JSON.stringify(campaignTestData.mhidData));
      req.body.newMHID = campaignTestData.newMHID;
      req.body.oldMHID = campaignTestData.oldMHID;
      req.body.oldMHID.cell.srcCode = '2';
      req.body.newMHID.cell.srcCode = '3';
      req.body.newMHID.mhid = '55555512';
      req.body.oldMHID.mhid = '55555512';
      saveSpy = sinon.spy(function(cb) {
        cb({}, null);
      });
      findOneSpy = sinon.spy(function(options, cb) {
        var campaignObj2 = JSON.parse(JSON.stringify(campaignTestData.mhidData));
        campaignObj2.save = saveSpy;
        campaignObj2.markModified = function(key) {};
        cb(null, campaignObj2);
      });
      req.body.requestID = '1234';
      mhidValidator.create(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should create mhid with  mhid and cellid', function() {
      req.body = JSON.parse(JSON.stringify(campaignTestData.mhidData));
      req.body.newMHID = campaignTestData.newMHID;
      req.body.oldMHID = campaignTestData.oldMHID;
      req.body.oldMHID.cell.srcCode = '2';
      req.body.newMHID.cell.srcCode = '3';
      req.body.newMHID.mhid = '55555512';
      req.body.oldMHID.mhid = '55555512';
      saveSpy = sinon.spy(function(cb) {
        cb(null, {});
      });
      findOneSpy = sinon.spy(function(options, cb) {
        var campaignObj2 = JSON.parse(JSON.stringify(campaignTestData.mhidData));
        campaignObj2.save = saveSpy;
        campaignObj2.markModified = function(key) {};
        cb(null, campaignObj2);
      });
      req.body.requestID = '1234';
      mhidValidator.create(req, res);
      expect(responseCode).to.equal(200);
    });
    it('should create new mhid with cellid', function() {
      req.body = JSON.parse(JSON.stringify(campaignTestData.mhidObj));
      req.body.newMHID = JSON.parse(JSON.stringify(campaignTestData.newMHID));
      req.body.newMHID.mhid = '12121212';
      req.body.mhid = '13131313';
      saveSpy = sinon.spy(function(cb) {
        cb(null, {});
      });
      findOneSpy = sinon.spy(function(options, cb) {
        var campaignObj2 = JSON.parse(JSON.stringify(campaignTestData.mhidData));
        campaignObj2.save = saveSpy;
        campaignObj2.markModified = function(key) {};
        cb(null, campaignObj2);
      });
      req.body.requestID = '1234';
      mhidValidator.create(req, res);
      expect(responseCode).to.equal(200);
    });
    it('should create new mhid and remove the old mhid during update', function() {
      req.body = JSON.parse(JSON.stringify(campaignTestData.mhidObj));
      req.body.newMHID = JSON.parse(JSON.stringify(campaignTestData.newMHID));
      req.body.oldMHID = JSON.parse(JSON.stringify(campaignTestData.oldMHID));
      req.body.newMHID.mhid = '12121212';
      req.body.oldMHID.mhid = '11111111';
      saveSpy = sinon.spy(function(cb) {
        cb(null, {});
      });
      findOneSpy = sinon.spy(function(options, cb) {
        var campaignObj2 = JSON.parse(JSON.stringify(campaignTestData.mhidData));
        campaignObj2.save = saveSpy;
        campaignObj2.markModified = function(key) {};
        cb(null, campaignObj2);
      });
      req.body.requestID = '1234';
      mhidValidator.create(req, res);
      expect(responseCode).to.equal(200);
    });
    it('should update the mhid', function() {
      req.body = JSON.parse(JSON.stringify(campaignTestData.mhidObj));
      req.body.newMHID = JSON.parse(JSON.stringify(campaignTestData.newMHID));
      req.body.oldMHID = JSON.parse(JSON.stringify(campaignTestData.oldMHID));
      req.body.newMHID.mhid = '55555555';
      req.body.oldMHID.mhid = '11111111';
      saveSpy = sinon.spy(function(cb) {
        cb(null, {});
      });
      findOneSpy = sinon.spy(function(options, cb) {
        var campaignObj2 = JSON.parse(JSON.stringify(campaignTestData.mhidData));
        campaignObj2.save = saveSpy;
        campaignObj2.markModified = function(key) {};
        cb(null, campaignObj2);
      });
      req.body.requestID = '1234';
      mhidValidator.create(req, res);
      expect(responseCode).to.equal(200);
    });
  });
  describe('MHID destroy', function() {
    var validCampaignObj = campaignTestData.mhidData;
    beforeEach(function() {
      responseCode = 0;
      req.body = JSON.parse(JSON.stringify(campaignTestData.mhidData));
    });
    it('should fail to destroy mhid with invalid campaign id', function() {
      req.body.id = '1234';
      findByIdSpy = sinon.spy(function(queryOptions, callback) {
        callback({}, null);
      });
      mhidValidator.destroy(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should fail to destroy mhid with invalid mhid', function() {
      req.body.mhid = '77777777';
      findByIdSpy = sinon.spy(function(queryOptions, callback) {
        callback(null, req.body);
      });
      mhidValidator.destroy(req, res);
      expect(responseCode).to.equal(412);
    });
    it('should fail to destroy mhid with invalid cellid', function() {
      req.body.mhid = '55555555';
      req.body.cell = {};
      req.body.cell.srcCode = 'cell1234';
      findByIdSpy = sinon.spy(function(queryOptions, callback) {
        callback(null, req.body);
      });
      mhidValidator.destroy(req, res);
      expect(responseCode).to.equal(412);
    });
    it('should fail to destroy mhid with valid mhid and valid cellid', function() {
      var campaignObj = {};
      req.body.mhid = '55555555';
      req.body.cell = {};
      req.body.cell.srcCode = '1';
      saveSpy = sinon.spy(function(cb) {
        cb({}, null);
      });
      findByIdSpy = sinon.spy(function(queryOptions, callback) {
        campaignObj = req.body;
        campaignObj.save = saveSpy;
        campaignObj.markModified = function(key) {};
        callback(null, campaignObj);
      });
      mhidValidator.destroy(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should destroy mhid with valid mhid and valid cellid', function() {
      var campaignObj = {};
      req.body.mhid = '55555555';
      req.body.cell = {};
      req.body.cell.srcCode = '1';
      saveSpy = sinon.spy(function(cb) {
        cb(null, {});
      });
      findByIdSpy = sinon.spy(function(queryOptions, callback) {
        campaignObj = req.body;
        campaignObj.save = saveSpy;
        campaignObj.markModified = function(key) {};
        callback(null, campaignObj);
      });
      mhidValidator.destroy(req, res);
      expect(responseCode).to.equal(200);
    });
  });
});
