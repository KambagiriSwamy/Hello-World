/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: Unit test for cancel esp drops service.
 */
'use strict'

var cancelDropsService = requireApplication('controllers/api/v1/cancel-esp-drops');
var campaignTestData = require('../../../../fixtures/rollback_validcampaign');


it('should be an object', function() {
  expect(cancelDropsService).to.be.a('object');
});

describe('cancelDropsService.cancelCampaignDrops', function() {
  describe('validate succesful marking of cells as cancelled', function() {
    var responseCode = 0;
    var responseBody = {};
    var campaignObj = campaignTestData.validCampaignObj;
    var req = {
        "body": {
          "requestID": "17501",
          "canceledDrops": [{
            "keys": {
              "REQR_CEY_DATE": "03/16/2026"
            }
          }]
        }
      },
      res = {
        status: function(code) {
          responseCode = code;
          return this;
        },
        json: function(data) {
          responseBody = data;
        },
        send: function(message) {

        }
      },
      findOneSpy = sinon.spy(function(requestID, callback) {
        return callback(null, campaignObj);
      }),
      saveSpy = sinon.spy(function(callback) {
        return callback(null);
      }),
      markModifiedSpy = sinon.spy(function(field) {
        //do nothing
      }),
      dbMock = {
        campaignClass: function() {
          campaignObj.findOne = findOneSpy;
          campaignObj.save = saveSpy;
          campaignObj.markModified = markModifiedSpy;
          return campaignObj;
        }
      },
      markCellAsCancelledSpy = sinon.spy(function(campaign, cancelledDrops, callBack) {
        return callBack(null);
      }),
      espUtilMock = {
        markCellAsCancelled: markCellAsCancelledSpy
      };

    cancelDropsService = proxyquire('../application/controllers/api/v1/cancel-esp-drops', {
      '../../../lib/db': dbMock,
      '../../../lib/esp-intg-utils': espUtilMock
    });

    cancelDropsService.cancelCampaignDrops(req, res);

    it('validate return code', function() {
      expect(responseCode).to.equal(200);
    });
  });
  describe('validate error on save', function() {
    var responseCode = 0;
    var responseBody = {};
    var campaignObj = campaignTestData.validCampaignObj;
    var req = {
        "body": {
          "requestID": "17501",
          "canceledDrops": [{
            "keys": {
              "REQR_CEY_DATE": "03/16/2026"
            }
          }]
        }
      },
      res = {
        status: function(code) {
          responseCode = code;
          return this;
        },
        json: function(data) {
          responseBody = data;
        },
        send: function(message) {

        }
      },
      findOneSpy = sinon.spy(function(requestID, callback) {
        return callback(null, campaignObj);
      }),
      saveSpy = sinon.spy(function(callback) {
        return callback('data base error');
      }),
      markModifiedSpy = sinon.spy(function(field) {
        //do nothing
      }),
      dbMock = {
        campaignClass: function() {
          campaignObj.findOne = findOneSpy;
          campaignObj.save = saveSpy;
          campaignObj.markModified = markModifiedSpy;
          return campaignObj;
        }
      },
      markCellAsCancelledSpy = sinon.spy(function(campaign, cancelledDrops, callBack) {
        return callBack(null);
      }),
      espUtilMock = {
        markCellAsCancelled: markCellAsCancelledSpy
      };

    cancelDropsService = proxyquire('../application/controllers/api/v1/cancel-esp-drops', {
      '../../../lib/db': dbMock,
      '../../../lib/esp-intg-utils': espUtilMock
    });

    cancelDropsService.cancelCampaignDrops(req, res);

    it('validate return code', function() {
      expect(responseCode).to.equal(500);
    });
  });
  describe('validate error on find', function() {
    var responseCode = 0;
    var responseBody = {};
    var campaignObj = campaignTestData.validCampaignObj;
    var req = {
        "body": {
          "requestID": "17501",
          "canceledDrops": [{
            "keys": {
              "REQR_CEY_DATE": "03/16/2026"
            }
          }]
        }
      },
      res = {
        status: function(code) {
          responseCode = code;
          return this;
        },
        json: function(data) {
          responseBody = data;
        },
        send: function(message) {

        }
      },
      findOneSpy = sinon.spy(function(requestID, callback) {
        return callback('data base error');
      }),
      saveSpy = sinon.spy(function(callback) {
        return callback('data base error');
      }),
      markModifiedSpy = sinon.spy(function(field) {
        //do nothing
      }),
      dbMock = {
        campaignClass: function() {
          campaignObj.findOne = findOneSpy;
          campaignObj.save = saveSpy;
          campaignObj.markModified = markModifiedSpy;
          return campaignObj;
        }
      },
      markCellAsCancelledSpy = sinon.spy(function(campaign, cancelledDrops, callBack) {
        return callBack(null);
      }),
      espUtilMock = {
        markCellAsCancelled: markCellAsCancelledSpy
      };

    cancelDropsService = proxyquire('../application/controllers/api/v1/cancel-esp-drops', {
      '../../../lib/db': dbMock,
      '../../../lib/esp-intg-utils': espUtilMock
    });

    cancelDropsService.cancelCampaignDrops(req, res);

    it('validate return code', function() {
      expect(responseCode).to.equal(500);
    });
  });
});
