// /**
//  * Module: EWT-POC
//  *
//  * --------------------------------------------------------------------------
//  *
//  * (C) Copyright 2014 American Express, Inc. All rights reserved.
//  * The contents of this file represent American Express trade secrets and
//  * are confidential. Use outside of American Express is prohibited and in
//  * violation of copyright law.  Licence information of all dependent modules
//  * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
//  *
//  *
//  * Description: EWT-POC - <DESC_HERE>
//  */
//  'use strict'

// var campaignSubType = requireApplication('controllers/api/v1/campaign-sub-type');

// it('should be an object', function() {
//   expect(campaignSubType).to.be.a('object');
// });
// describe('campaignSubType.showByCampaignTypeId', function () {
//   describe('with valid data',function(){
//     var code = 0,
//         error = null,
//         res = {
//           send: function(message) {

//           },
//           status: function(response) {
//            code = response;
//            return code;
//           },
//           json: function(campaignSubTypes) {

//           }
//         },
//         req = {
//           "params":{"campaign_types_id":"024"}
//         },
//         campaignSubTypeObj = {},
//         findSpy = sinon.spy(function(foreignkey,cb){
//           var campaignSubType = {};
//           cb(error, campaignSubType);
//         }),
//         DBAPI = {
//                 campaignSubTypesClass: function() {
//                     campaignSubTypeObj.find = findSpy;
//                     return campaignSubTypeObj;
//                 }
//               };
//     campaignSubType = proxyquire('../application/controllers/api/v1/campaign-sub-type', {
//       '../../../lib/db.js': DBAPI
//     });
//     campaignSubType.showByCampaignTypeId(req,res);
//     it('validate campaign type id',function(){
//        expect(code).to.equal(200);
//     });
//     it('should fetch campaign sub types based on campaign type', function() {
//         expect(findSpy.calledOnce).to.be.true;
//     });
//   });
//   describe('with in-valid data',function(){
//     var code = 0,
//         error = null,
//         res = {
//           send: function(message) {

//           },
//           status: function(response) {
//            code = response;
//            return code;
//           },
//           json: function(campaignSubTypes) {

//           }
//        },
//        req = {
//           "params":{}
//         },
//        campaignSubTypeObj = {},
//          findSpy = sinon.spy(function(foreignkey,cb){
//           var campaignSubType = {};
//           cb(error, campaignSubType);
//         }),
//         DBAPI = {
//             campaignSubTypesClass: function() {
//                 campaignSubTypeObj.find = findSpy;
//                 return campaignSubTypeObj;
//             }
//           };
//     campaignSubType = proxyquire('../application/controllers/api/v1/campaign-sub-type', {
//       '../../../lib/db.js': DBAPI
//     });
//     campaignSubType.showByCampaignTypeId(req,res);
//     it('Invalid campaign type id',function(){
//        expect(code).to.equal(412);
//     });
//      it('should failed to fetch campaign sub types based on campaign type', function() {
//          expect(findSpy.calledOnce).to.be.false;
//       });
//   });
// describe('with in-valid data fetch failed',function(){
//     var code = 0,
//         error = {},
//         res = {
//           send: function(message) {

//           },
//           status: function(response) {
//            code = response;
//            return code;
//           },
//           json: function(campaignSubTypes) {

//           }
//        },
//        req = {
//           "params":{"campaign_types_id":"U024"}
//         },
//        campaignSubTypeObj = {},
//          findSpy = sinon.spy(function(foreignkey,cb){
//           var campaignSubType = {};
//           cb(error, campaignSubType);
//         }),
//         DBAPI = {
//             campaignSubTypesClass: function() {
//                 campaignSubTypeObj.find = findSpy;
//                 return campaignSubTypeObj;
//             }
//           };
//     campaignSubType = proxyquire('../application/controllers/api/v1/campaign-sub-type', {
//       '../../../lib/db.js': DBAPI
//     });
//     campaignSubType.showByCampaignTypeId(req,res);
//     it('Invalid campaign type id',function(){
//        expect(code).to.equal(500);
//     });
//   });
// });
