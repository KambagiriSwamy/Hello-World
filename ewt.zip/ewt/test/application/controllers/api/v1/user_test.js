/**
 * Module: ERA
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: Unit test cases for user CURD operations
 */
'use strict';

var user = requireApplication('controllers/api/v1/user.js'),
  userTestData = require('../../../../fixtures/user_test_data.js');

it('should be an object : this protects file from getting renamed', function() {
  expect(user).to.be.a('object');
});
describe('User.user', function() {
  it('Should be a function : this protects function from getting renamed', function(done) {
    user.index.should.be.a('function');
    done();
  });
  //common variables for test cases
  var responseCode;
  var res = {
      status: function(code) {
        var obj = {};
        obj.jsonp = function() {};
        obj.json = function() {};
        obj.send = function(err) {};
        responseCode = code;
        return obj;
      },
      send: function(message) {

      }
    },
    findSpy = sinon.spy(function(queryOptions, columns, sort, callback) {}),
    findOneSpy = sinon.spy(function(queryOptions, callback) {}),
    statusFindOneSpy = sinon.spy(function(queryOptions, callback) {}),
    findbyIdSpy = sinon.spy(function(queryOptions, callback) {}),
    createSpy = sinon.spy(function(usercreateObj, callback) {
      callback(null, {});
    }),
    saveSpy = sinon.spy(function(cb) {
      cb(null, {});
    }),
    removeSpy = sinon.spy(function(callback) {}),
    req = {
      params: {},
      query: {
        'columns': 'campaingName'
      }

    },
    DBAPI = {
      userClass: function() {
        var userObj = {};
        userObj.find = findSpy;
        userObj.findOne = findOneSpy;
        userObj.findById = findbyIdSpy;
        userObj.create = createSpy;
        return userObj;
      },
      userStatusClass: function() {
        var userStatus = {};
        userStatus.findOne = statusFindOneSpy;
        return userStatus;
      }
    },
    LDAPAPI = {
      getUserDetails: function(uid, callback) {
        callback(null, JSON.stringify(userTestData.userInfo));
      }
    },
    userUtils = {
      addUser2DB: function(req, ldapUser, dbUser, callback) {
        callback(null, JSON.stringify(userTestData.userInfo));
      }
    },
    emailAPI = {
      notifyRequestAccess: function(userDetails, toList, ccList, optional, callback) {
        callback({});
      }
    };

  user = proxyquire('../application/controllers/api/v1/user', {
    '../../../lib/db.js': DBAPI,
    '../../../lib/ldap': LDAPAPI,
    '../../../lib/user.js': userUtils,
    '../../email.js': emailAPI
  });
  describe('User search scenarios', function() {
    beforeEach(function() {
      responseCode = 0;
    });
    it('should fetch all users with out filter options', function() {
      findSpy = sinon.spy(function(queryOptions, columns, sort, callback) {
        callback(null, []);
      });
      user.index(req, res);
      expect(responseCode).to.equal(200);
    });
    it('should fail to fetch all users with invalid data', function() {
      findSpy = sinon.spy(function(queryOptions, columns, sort, callback) {
        callback({}, null);
      });
      user.index(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should  fetch all users with filter data', function() {
      findSpy = sinon.spy(function(queryOptions, columns, sort, callback) {
        callback(null, {});
      });
      req.query.columns = null;
      req.body = {};
      req.body.name = 'testuser';
      req.body.uid = 'testuid';
      req.body.lastName = 'testuid';
      req.body.businessUnit = 'testbussunit';
      req.body.role = 'admin';
      req.body.status = 'active';
      user.index(req, res);
      expect(responseCode).to.equal(200);
    });
    it('should  fetch all users with filter data', function() {
      findSpy = sinon.spy(function(queryOptions, columns, sort, callback) {
        callback(null, {});
      });
      req.query.columns = null;
      req.body = {};
      req.body.name = 'testuser';
      req.body.uid = 'testuid';
      req.body.lastName = 'testuid';
      req.body.businessUnit = 'testbussunit';
      req.body.role = 'admin';
      req.body.status = 'inactive';
      user.index(req, res);
      expect(responseCode).to.equal(200);
    });
    it('should  fetch all users with filter data', function() {
      findSpy = sinon.spy(function(queryOptions, columns, sort, callback) {
        callback(null, {});
      });
      req.body = {};
      req.body.firstName = null;
      req.body.lastName = null;
      req.body.uid = null;
      req.body.businessUnit = null;
      req.body.role = null;
      req.body.status = null;
      user.index(req, res);
      expect(responseCode).to.equal(200);
    });
  });
  describe('Fetch user based on the user id', function() {
    beforeEach(function() {
      responseCode = 0;
    });
    it('should  fetch user with valid userid', function() {
      req.params.user_id = '1234';
      findbyIdSpy = sinon.spy(function(queryOptions, callback) {
        callback(null, {});
      });
      user.show(req, res);
      expect(responseCode).to.equal(200);
    });
    it('should  fail to fetch user with invalid userid', function() {
      req.params.user_id = '0000';
      findbyIdSpy = sinon.spy(function(queryOptions, callback) {
        callback({}, null);
      });
      user.show(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should fail to fetch user with deleted userid', function() {
      req.params.user_id = '1234';
      findbyIdSpy = sinon.spy(function(queryOptions, callback) {
        var userObj = {};
        userObj.markAsDeleted = true;
        callback(null, userObj);
      });
      user.show(req, res);
      expect(responseCode).to.equal(412);
    });
  });
  describe('User.create method', function() {
    beforeEach(function() {
      responseCode = 0;
      req.body = JSON.parse(JSON.stringify(userTestData.user1));
    });
    it('should  fail to create user with invalid data', function() {
      req.body.uid = '';
      user.create(req, res);
      expect(responseCode).to.equal(412);
    });
    it('should  fail to create user with duplicate uid', function() {
      findOneSpy = sinon.spy(function(queryOptions, callback) {
        var tempUser = {};
        tempUser.markAsDeleted = false;
        callback(null, tempUser);
      });
      user.create(req, res);
      expect(responseCode).to.equal(422);
    });
    it('should  fail to create user while validing the user exsistence', function() {
      findOneSpy = sinon.spy(function(queryOptions, callback) {
        callback({}, null);
      });
      user.create(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should  fail to add user to db if ldap return error', function() {
      process.env.NODE_ENV = 'integration';
      findOneSpy = sinon.spy(function(queryOptions, callback) {
        var userObj = {};
        userObj.markAsDeleted = true;
        callback(null, userObj);
      });
      LDAPAPI.getUserDetails = function(uid, ldapFilter, callback) {
        callback({}, null);
      };
      user.create(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should  fail to add user to db if ldap returns empty user', function() {
      process.env.NODE_ENV = 'integration';
      findOneSpy = sinon.spy(function(queryOptions, callback) {
        var userObj = {};
        userObj.markAsDeleted = true;
        callback(null, userObj);
      });
      LDAPAPI.getUserDetails = function(uid, ldapFilter, callback) {
        callback(null, null);
      };
      user.create(req, res);
      expect(responseCode).to.equal(412);
    });
    it('should  fail to add user to db if ldap returns inactive status for user', function() {
      process.env.NODE_ENV = 'integration';
      findOneSpy = sinon.spy(function(queryOptions, callback) {
        var userObj = {};
        userObj.markAsDeleted = true;
        callback(null, userObj);
      });
      LDAPAPI.getUserDetails = function(uid, ldapFilter, callback) {
        var ldapobj = {};
        ldapobj.userAccountControl = '514';
        callback(null, ldapobj);
      };
      user.create(req, res);
      expect(responseCode).to.equal(412);
    });
    it('should  fail to add user to db if db opeartion fails', function() {
      process.env.NODE_ENV = 'integration';
      findOneSpy = sinon.spy(function(queryOptions, callback) {
        var userObj = {};
        userObj.markAsDeleted = true;
        callback(null, userObj);
      });
      LDAPAPI.getUserDetails = function(uid, ldapFilter, callback) {
        var ldapobj = {};
        ldapobj.userAccountControl = '200';
        callback(null, ldapobj);
      };
      userUtils.addUser2DB = function(req, ldapUser, dbUser, callback) {
        callback({}, JSON.stringify(userTestData.userInfo));
      };
      user.create(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should add user to db if db', function() {
      process.env.NODE_ENV = 'integration';
      findOneSpy = sinon.spy(function(queryOptions, callback) {
        var userObj = {};
        userObj.markAsDeleted = true;
        callback(null, userObj);
      });
      LDAPAPI.getUserDetails = function(uid, ldapFilter, callback) {
        var ldapobj = {};
        ldapobj.userAccountControl = '200';
        callback(null, ldapobj);
      };
      userUtils.addUser2DB = function(req, ldapUser, dbUser, callback) {
        callback(null, JSON.stringify(userTestData.userInfo));
      };
      user.create(req, res);
      expect(responseCode).to.equal(200);
    });
    it('should add user to db if db', function() {
      process.env.NODE_ENV = 'development';
      findOneSpy = sinon.spy(function(queryOptions, callback) {
        var userObj = {};
        userObj.markAsDeleted = true;
        callback(null, userObj);
      });
      LDAPAPI.getUserDetails = function(uid, ldapFilter, callback) {
        var ldapobj = {};
        ldapobj.userAccountControl = '200';
        callback(null, ldapobj);
      };
      userUtils.addUser2DB = function(req, ldapUser, dbUser, callback) {
        callback(null, JSON.stringify(userTestData.userInfo));
      };
      user.create(req, res);
      expect(responseCode).to.equal(200);
    });
    it('should fail add user to db in development mode', function() {
      process.env.NODE_ENV = 'development';
      findOneSpy = sinon.spy(function(queryOptions, callback) {
        var userObj = {};
        userObj.markAsDeleted = true;
        callback(null, userObj);
      });
      LDAPAPI.getUserDetails = function(uid, ldapFilter, callback) {
        var ldapobj = {};
        ldapobj.userAccountControl = '200';
        callback(null, ldapobj);
      };
      userUtils.addUser2DB = function(req, ldapUser, dbUser, callback) {
        callback({}, JSON.stringify(userTestData.userInfo));
      };
      user.create(req, res);
      expect(responseCode).to.equal(500);
    });
  });
  describe('update user method', function() {
    var userData = JSON.parse(JSON.stringify(userTestData.user1));
    beforeEach(function() {
      responseCode = 0;
      req.body = JSON.parse(JSON.stringify(userTestData.user1));
    });
    it('should  update user with valid data', function() {
      findbyIdSpy = sinon.spy(function(queryOptions, callback) {
        userData.save = saveSpy;
        callback(null, userData);
      });
      user.update(req, res);
      expect(responseCode).to.equal(200);
    });
    it('should fail to update user with invalid data', function() {
      findbyIdSpy = sinon.spy(function(queryOptions, callback) {
        userData.save = saveSpy;
        callback(null, userData);
      });
      req.body.uid = '';
      user.update(req, res);
      expect(responseCode).to.equal(412);
    });
    it('should fail to update user with invalid user id', function() {
      findbyIdSpy = sinon.spy(function(queryOptions, callback) {
        userData.save = saveSpy;
        callback({}, null);
      });
      user.update(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should fail to update user with valid user id', function() {
      findbyIdSpy = sinon.spy(function(queryOptions, callback) {
        userData.save = saveSpy;
        callback(null, null);
      });
      user.update(req, res);
      expect(responseCode).to.equal(204);
    });
    it('should fail to update user with valid user id', function() {
      saveSpy = sinon.spy(function(cb) {
        cb({}, null);
      });
      findbyIdSpy = sinon.spy(function(queryOptions, callback) {
        userData.save = saveSpy;
        callback(null, userData);
      });
      user.update(req, res);
      expect(responseCode).to.equal(500);
    });

  });
  describe('Delete user based on the user id', function() {
    it('should  fail to delete user with invalid userid', function() {
      req.params.user_id = '0000';
      findbyIdSpy = sinon.spy(function(queryOptions, callback) {
        callback({}, null);
      });
      user.destroy(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should  fail to delete user if user not found', function() {
      req.params.user_id = '1234';
      findbyIdSpy = sinon.spy(function(queryOptions, callback) {
        callback(null, null);
      });
      user.destroy(req, res);
      expect(responseCode).to.equal(204);
    });
    it('should  fail to delete user with valid user id', function() {
      req.params.user_id = '1234';
      findbyIdSpy = sinon.spy(function(queryOptions, callback) {
        var userObj = {};
        userObj.save = saveSpy;
        callback(null, userObj);
      });
      saveSpy = sinon.spy(function(callback) {
        callback({}, null);
      });
      user.destroy(req, res);
      expect(responseCode).to.equal(500);

    });
    it('should delete user with valid user id', function() {
      req.params.user_id = '1234';
      findbyIdSpy = sinon.spy(function(queryOptions, callback) {
        var userObj = {};
        userObj.save = saveSpy;
        callback(null, userObj);
      });
      saveSpy = sinon.spy(function(callback) {
        callback(null, {});
      });
      user.destroy(req, res);
      expect(responseCode).to.equal(200);

    });
  });
  describe('User Access request', function() {
    var userObj = {};
    beforeEach(function() {
      responseCode = 0;
      userObj = JSON.parse(JSON.stringify(userTestData.userReqObj));
      req.body = userObj;
    });

    it('should fail to fetch the admin users', function() {
      findSpy = sinon.spy(function(queryOptions, cb) {
        var obj = {};
        obj.select = function(options) {}
        cb({}, {});
        return obj;
      });
      user.requestAccess(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should fail to fetch the admin users with invalid request object', function() {
      findSpy = sinon.spy(function(queryOptions, cb) {
        var obj = {};
        obj.select = function(options) {}
        cb({}, {});
        return obj;
      });
      req.body = null;
      user.requestAccess(req, res);
      expect(responseCode).to.equal(412);
    });
    it('should fail to send the email to admin for access', function() {
      findSpy = sinon.spy(function(queryOptions, cb) {
        var obj = {};
        obj.select = function(options) {}
        cb(null, [userObj]);
        return obj;
      });
      user.requestAccess(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should send the email to admin for access', function() {
      findSpy = sinon.spy(function(queryOptions, cb) {
        var obj = {};
        obj.select = function(options) {}
        cb(null, [userObj]);
        return obj;
      });
      emailAPI.notifyRequestAccess = function(userDetails, toList, ccList, optional, callback) {
        callback(null);
      }
      user.requestAccess(req, res);
      expect(responseCode).to.equal(200);
    });
  });
});
