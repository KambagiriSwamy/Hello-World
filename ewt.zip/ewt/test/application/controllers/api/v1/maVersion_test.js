/**
 * Module: EWT-2.0
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 (ERA) - It has test cases to save,update and delete versions for MA Emailtype.
 */
'use strict';

var maVersion = requireApplication('controllers/api/v1/maVersion.js'),
  campaignTestData = require('../../../../fixtures/campaign_test_data.js');

describe('maVersion', function() {
  var responseCode;
  var res = {
      status: function(code) {
        var obj = {};
        obj.jsonp = function() {};
        obj.send = function(message) {};
        responseCode = code;
        return obj;
      },
      send: function(message) {

      }
    },
    saveSpy = sinon.spy(function(cb) {
      cb(null, {});
    }),
    findOneSpy = sinon.spy(function(options, cb) {
      cb(null, JSON.parse(JSON.stringify(campaignTestData.mhidData)));
    }),
    removeSpy = sinon.spy(function(file, cb) {
      cb(null);
    }),
    req = {
      params: {},
      body: {}
    },
    DBAPI = {
      campaignClass: function(validCampaignObj) {
        var campaignObj = {};
        campaignObj.findOne = findOneSpy;
        return campaignObj;
      },
      marketingAutomationClass: function() {
        return function(testObj) {
          return testObj;
        };
      },
      gridfs: function() {
        var gridObj = {};
        gridObj.remove = removeSpy;
        return gridObj;
      },
      marketingAutomationVersionsClass: function() {
        return function() {}
      }
    },
    fileAPI = {
      saveMAAttachment: function(filesArr, attachment_type, campaign_id, versionId, res, attachmentSize) {
        return res.status(200);
      }
    };
  maVersion = proxyquire('../application/controllers/api/v1/maVersion', {
    '../../../lib/db.js': DBAPI,
    './file.js': fileAPI
  });
  describe('maVersion create and update scenarios', function() {
    it('should fail to load a campaign', function() {
      req.params.campaign_id = '1234';
      req.body.data = JSON.stringify(campaignTestData.versionReqObj);
      findOneSpy = sinon.spy(function(options, cb) {
        cb({}, JSON.parse(JSON.stringify(campaignTestData.mhidData)));
      });
      maVersion.saveMAVersion(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should fail to load a campaign with invalid campaing id', function() {
      req.params.campaign_id = '1234';
      req.body.data = JSON.stringify(campaignTestData.versionReqObj);
      findOneSpy = sinon.spy(function(options, cb) {
        cb(null, null);
      });
      maVersion.saveMAVersion(req, res);
      expect(responseCode).to.equal(204);
    });

    it('should create a version if doesnt exsist', function() {
      req.params.campaign_id = '1234';
      req.body.data = JSON.stringify(campaignTestData.versionReqObj);
      var campaign = JSON.parse(JSON.stringify(campaignTestData.mhidData));
      saveSpy = sinon.spy(function(cb) {
        cb(null);
      });
      campaign.save = saveSpy;
      findOneSpy = sinon.spy(function(options, cb) {
        cb(null, campaign);
      });
      req.files = {};
      maVersion.saveMAVersion(req, res);
      expect(responseCode).to.equal(200);
    });
    it('should create a version and save the files to db', function() {
      req.params.campaign_id = '1234';
      req.body.data = JSON.stringify(campaignTestData.versionReqObj);
      var campaign = JSON.parse(JSON.stringify(campaignTestData.mhidData));
      saveSpy = sinon.spy(function(cb) {
        cb(null);
      });
      campaign.save = saveSpy;
      findOneSpy = sinon.spy(function(options, cb) {
        cb(null, campaign);
      });
      req.files = {};
      req.files.file = 'test.txt';
      maVersion.saveMAVersion(req, res);
      expect(responseCode).to.equal(200);
    });
    it('should create a version and save the multiple files to db', function() {
      req.params.campaign_id = '1234';
      req.body.data = JSON.stringify(campaignTestData.versionReqObj);
      var campaign = JSON.parse(JSON.stringify(campaignTestData.mhidData));
      saveSpy = sinon.spy(function(cb) {
        cb(null);
      });
      campaign.save = saveSpy;
      findOneSpy = sinon.spy(function(options, cb) {
        cb(null, campaign);
      });
      req.files = {};
      req.files.file = ['test.txt', 'test1.txt'];
      maVersion.saveMAVersion(req, res);
      expect(responseCode).to.equal(200);
    });
    it('should fail to create a version', function() {
      req.params.campaign_id = '1234';
      req.body.data = JSON.stringify(campaignTestData.versionReqObj);
      var campaign = JSON.parse(JSON.stringify(campaignTestData.mhidData));
      saveSpy = sinon.spy(function(cb) {
        cb({});
      });
      campaign.save = saveSpy;
      findOneSpy = sinon.spy(function(options, cb) {
        cb(null, campaign);
      });
      req.files = {};
      maVersion.saveMAVersion(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should update the exsisting version', function() {
      req.params.campaign_id = '1234';
      var bodyObj = JSON.parse(JSON.stringify(campaignTestData.versionReqObj));
      bodyObj.deletedFile = [{ '_id': '565d2b6df78787b8794afceb' }];
      req.body.data = JSON.stringify(bodyObj);
      var campaign = JSON.parse(JSON.stringify(campaignTestData.mhidData));
      saveSpy = sinon.spy(function(cb) {
        cb(null);
      });
      campaign.save = saveSpy;
      findOneSpy = sinon.spy(function(options, cb) {
        cb(null, campaign);
      });
      req.files = {};
      req.files.file = [];
      maVersion.saveMAVersion(req, res);
      expect(responseCode).to.equal(200);
    });
    it('should update the exsisting version with new creative documents', function() {
      req.params.campaign_id = '1234';
      var bodyObj = JSON.parse(JSON.stringify(campaignTestData.versionReqObj));
      bodyObj.deletedFile = [{ '_id': '565d2b6df78787b8794afceb' }];
      req.body.data = JSON.stringify(bodyObj);
      var campaign = JSON.parse(JSON.stringify(campaignTestData.mhidData));
      saveSpy = sinon.spy(function(cb) {
        cb(null);
      });
      campaign.save = saveSpy;
      findOneSpy = sinon.spy(function(options, cb) {
        cb(null, campaign);
      });
      req.files = {};
      req.files.file = {};
      maVersion.saveMAVersion(req, res);
      expect(responseCode).to.equal(200);
    });
    it('should update the exsisting version with out creative documents', function() {
      req.params.campaign_id = '1234';
      var bodyObj = JSON.parse(JSON.stringify(campaignTestData.versionReqObj));
      bodyObj.deletedFile = [{ '_id': '565d2b6df78787b8794afceb' }];
      req.body.data = JSON.stringify(bodyObj);
      var campaign = JSON.parse(JSON.stringify(campaignTestData.mhidData));
      saveSpy = sinon.spy(function(cb) {
        cb(null);
      });
      campaign.save = saveSpy;
      findOneSpy = sinon.spy(function(options, cb) {
        cb(null, campaign);
      });
      req.files = {};
      maVersion.saveMAVersion(req, res);
      expect(responseCode).to.equal(200);
    });
    it('should create the new version if doesnt exsist', function() {
      req.params.campaign_id = '1234';
      var bodyObj = JSON.parse(JSON.stringify(campaignTestData.versionReqObj));
      bodyObj.versionId = 22;
      req.body.data = JSON.stringify(bodyObj);
      var campaign = JSON.parse(JSON.stringify(campaignTestData.mhidData));
      saveSpy = sinon.spy(function(cb) {
        cb(null);
      });
      campaign.save = saveSpy;
      findOneSpy = sinon.spy(function(options, cb) {
        cb(null, campaign);
      });
      req.files = {};
      maVersion.saveMAVersion(req, res);
      expect(responseCode).to.equal(200);
    });
    it('should create the new version with creativeDocuments', function() {
      req.params.campaign_id = '1234';
      var bodyObj = JSON.parse(JSON.stringify(campaignTestData.versionReqObj));
      bodyObj.versionId = 22;
      req.body.data = JSON.stringify(bodyObj);
      var campaign = JSON.parse(JSON.stringify(campaignTestData.mhidData));
      saveSpy = sinon.spy(function(cb) {
        cb(null);
      });
      campaign.save = saveSpy;
      findOneSpy = sinon.spy(function(options, cb) {
        cb(null, campaign);
      });
      req.files = {};
      req.files.file = [];
      maVersion.saveMAVersion(req, res);
      expect(responseCode).to.equal(200);
    });
    it('should create the new version with creativeDocument', function() {
      req.params.campaign_id = '1234';
      var bodyObj = JSON.parse(JSON.stringify(campaignTestData.versionReqObj));
      bodyObj.versionId = 22;
      req.body.data = JSON.stringify(bodyObj);
      var campaign = JSON.parse(JSON.stringify(campaignTestData.mhidData));
      saveSpy = sinon.spy(function(cb) {
        cb(null);
      });
      campaign.save = saveSpy;
      findOneSpy = sinon.spy(function(options, cb) {
        cb(null, campaign);
      });
      req.files = {};
      req.files.file = {};
      maVersion.saveMAVersion(req, res);
      expect(responseCode).to.equal(200);
    });
    it('should fail to create the new version with invalid request object', function() {
      req.params.campaign_id = '1234';
      var bodyObj = JSON.parse(JSON.stringify(campaignTestData.versionReqObj));
      bodyObj.versionName = null;
      bodyObj.versionId = 22;
      req.body.data = JSON.stringify(bodyObj);
      var campaign = JSON.parse(JSON.stringify(campaignTestData.mhidData));
      saveSpy = sinon.spy(function(cb) {
        cb(null);
      });
      campaign.save = saveSpy;
      findOneSpy = sinon.spy(function(options, cb) {
        cb(null, campaign);
      });
      req.files = {};
      req.files.file = {};
      maVersion.saveMAVersion(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should fail to create the new version', function() {
      req.params.campaign_id = '1234';
      var bodyObj = JSON.parse(JSON.stringify(campaignTestData.versionReqObj));
      bodyObj.versionId = 22;
      req.body.data = JSON.stringify(bodyObj);
      var campaign = JSON.parse(JSON.stringify(campaignTestData.mhidData));
      saveSpy = sinon.spy(function(cb) {
        cb({});
      });
      campaign.save = saveSpy;
      findOneSpy = sinon.spy(function(options, cb) {
        cb(null, campaign);
      });
      req.files = {};
      maVersion.saveMAVersion(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should fail to update the exsisting version', function() {
      req.params.campaign_id = '1234';
      var bodyObj = JSON.parse(JSON.stringify(campaignTestData.versionReqObj));
      bodyObj.deletedFile = [{ '_id': '565d2b6df78787b8794afceb' }];
      req.body.data = JSON.stringify(bodyObj);
      var campaign = JSON.parse(JSON.stringify(campaignTestData.mhidData));
      saveSpy = sinon.spy(function(cb) {
        cb({});
      });
      campaign.save = saveSpy;
      findOneSpy = sinon.spy(function(options, cb) {
        cb(null, campaign);
      });
      req.files = {};
      maVersion.saveMAVersion(req, res);
      expect(responseCode).to.equal(500);
    });
  });
  describe('maVersion delete scenarios', function() {
    it('should fail to load the campaign', function() {
      req.params.campaign_id = '7546';
      req.params.version_id = 11;
      findOneSpy = sinon.spy(function(options, cb) {
        cb(null, null);
      });
      maVersion.destroy(req, res);
      expect(responseCode).to.equal(204);
    });
    it('should fail to load the campaing with invalid id', function() {
      req.params.campaign_id = 'qasd';
      req.params.version_id = 11;
      findOneSpy = sinon.spy(function(options, cb) {
        cb({}, null);
      });
      maVersion.destroy(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should fail to destroy maversion with invalid versionId', function() {
      req.params.campaign_id = '1234';
      req.params.version_id = 11;
      findOneSpy = sinon.spy(function(options, cb) {
        cb(null, JSON.parse(JSON.stringify(campaignTestData.mhidData)));
      });
      maVersion.destroy(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should fail to update the delete operation', function() {
      req.params.campaign_id = '1234';
      req.params.version_id = 1;
      var campaign = JSON.parse(JSON.stringify(campaignTestData.mhidData));
      saveSpy = sinon.spy(function(cb) {
        cb({}, {});
      });
      findOneSpy = sinon.spy(function(options, cb) {
        campaign.save = saveSpy;
        cb(null, campaign);
      });

      maVersion.destroy(req, res);
      expect(responseCode).to.equal(500);
    });
    it('should update the delete operation', function() {
      req.params.campaign_id = '1234';
      req.params.version_id = 1;
      var campaign = JSON.parse(JSON.stringify(campaignTestData.mhidData));
      saveSpy = sinon.spy(function(cb) {
        cb(null, {});
      });
      findOneSpy = sinon.spy(function(options, cb) {
        campaign.save = saveSpy;
        cb(null, campaign);
      });

      maVersion.destroy(req, res);
      expect(responseCode).to.equal(200);
    });
    it('should update the delete operation if there are no creative documents', function() {
      req.params.campaign_id = '1234';
      req.params.version_id = 1;
      var campaign = JSON.parse(JSON.stringify(campaignTestData.mhidData));
      saveSpy = sinon.spy(function(cb) {
        cb(null, {});
      });
      findOneSpy = sinon.spy(function(options, cb) {
        campaign.save = saveSpy;
        campaign.ma.maVersions[0].creativeDocument = [];
        cb(null, campaign);
      });

      maVersion.destroy(req, res);
      expect(responseCode).to.equal(200);
    });
  });
});
