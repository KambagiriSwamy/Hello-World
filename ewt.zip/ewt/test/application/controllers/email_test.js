/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-POC - <DESC_HERE>
 */

//global describe, beforeEach, afterEach, it, expect, should, assert, chai, sinon, proxyquire(see / test / helpers.js)

// 'use strict';

// describe('The Controller', function() {
//   var controller, stub;

//   before(function() {
//     controller = require('../../../application/controllers/email.js');
//   });

//   after(function() {
//     stub.restore();
//   });

//   it('Should be an Object', function() {
//     controller.should.be.a('Object');
//     expect(controller).to.have.property('sendApproval');
//   });

//   it('Send approval email', function(done) {
//     var callback = sinon.spy();
//     var model = {};

//     stub = sinon.stub(controller, 'sendApproval');
//     controller.sendApproval(model, callback);
//     expect(controller.sendApproval).to.have.been.called;
//     done();
//   });

// });
