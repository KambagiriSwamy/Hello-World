/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-POC - <DESC_HERE>
 */


'use strict';

/**
 * Common helper scripts for all the Mocha.js tests.
 *
 * This file provides a few global functions to make writing these
 * tests easier.
 */

// First, don't save any changes we might make to the config data.
process.env.NODE_CONFIG_PERSIST_ON_CHANGE = 'N';

// For all the spies, stubs and mocking
var path = require('path'),
  _sinon = require('sinon'),
  _chai = require('chai'),
  _proxyquire =  require('proxyquire');

require('chai')
  .use(require('sinon-chai'))
  .use(require('chai-fs'));


global.chai = _chai;
global.assert = _chai.assert;
global.expect = _chai.expect;
global.should = _chai.should();

global.sinon = _sinon;
global.proxyquire = _proxyquire;


global.requireApplication = function (name) {
  return require('../application/' + name);
};

global.clearApplication = function (name) {
  name = require.resolve('../application/' + name);
  delete require.cache[name];
};

global.applicationPath = function (name) {
  return path.resolve('./application/' + name);
};

global.requireLib = function (name) {
  return require('../lib/' + name);
};

global.clearLib = function (name) {
  name = require.resolve('../lib/' + name);
  delete require.cache[name];
};

global.libPath = function (name) {
  return path.resolve('./lib/' + name);
};

// dummy global logger
var noop = function () {};
global.logger = {
  debug: noop,
  info: noop,
  warn: noop,
  error: noop,
  audit: noop,
  appReport: noop
};

global.applicationPath = function (name) {
  return path.resolve('./application/' + name);
};
