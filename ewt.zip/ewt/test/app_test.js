/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-POC - <DESC_HERE>
 */

'use strict';

describe('App Module', function() {
  describe('Check basic structure of app module', function() {
    it('Should invoke the jumpstart serve', function() {
      // mock our instance of jump and serve function
      var jumpstartEngine = sinon.spy(function(config) {
        return jumpstartEngine;
      });
      jumpstartEngine.serve = sinon.spy(function(cb) {
        return cb();
      });

      var DB = {
        connect: sinon.spy(function(url, config, cb) {
          return cb();
        }),
        closeConnections: function(cb) {
          return cb();
        }
      };

      var appModule = proxyquire('../app', {
        'jumpstart-engine': jumpstartEngine,
        './application/lib/db': DB
      });
      jumpstartEngine.should.be.calledOnce;
    });
  });
});
