/**
 * Module: 
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description:  - <DESC_HERE>
 */

 /*global describe, beforeEach, afterEach, it, expect, should, assert, chai, sinon, proxyquire (see /test/helpers.js)*/

// 'use strict';

// describe('The deviceprofile middleware', function () {
//   var logger, deviceProfileSpy, middleware,next;

//   before(function () {
//  deviceProfileSpy = sinon.spy(function(config){
//    return {
//      fetch: function(req, res, cb){
//        cb('err');
//      }
//    }
//  }),
//  next = sinon.spy(); 
//   logger = {
//     internal: sinon.spy()
//   };
//   global.logger = logger;
//  middleware = proxyquire('../application/middlewares/deviceProfile.js', {
//  'jumpstart-device-profile': deviceProfileSpy 
//  });
//   middleware(null, null, next);
//  });


//   it('deviceprofile middleware should be an function', function () {
//     middleware.should.be.a('Function');
//   });

//  it('deviceprofile should be an function', function () {
//     deviceProfileSpy.should.be.a('Function');
//   });

//  it('deviceprofile should be called', function () {
//     deviceProfileSpy.should.have.been.called;
//   });

//  it('logger internal should be called with err message', function () {
//     logger.internal.calledWith('deviceProfile: ERROR occurred fetching device details err');
//   });

//  it('next() should be called', function () {
//     next.should.have.been.called;
//   });

// });
