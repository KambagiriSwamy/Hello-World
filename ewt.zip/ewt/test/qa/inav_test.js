/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-POC
 */

'use strict';
/*
var nock = require('nock');
var config = require('../../config/default');
var jumpstart = require('jumpstart-engine')(config);
var request = require('supertest');


describe('iNAV module', function () {

  var url = 'http://apdwa622.webqa.ipc.us.aexp.com:9080';
  var uri = '/NavRestSvc/NavigationService';

  // run the jumpstart
  before(function () {
    jumpstart.serve(function (config) {
      console.log('The Server started at port: ' + config.http.port);
    });
  })
  // cleanup all the prepared mocks after each test
  afterEach(function () {
    nock.cleanAll();
  });

  describe('caching capability', function () {

    it('Should get header and footer from iNAV for the first request', function (done) {

      // this guy replies to iNAV, iNAV will then strip out elements and create a NAV object
      // NAV object is used in the views NAV.footer
      // views spit out all contents to end() function below
      var api = nock(url)
        .persist()
        .post(uri)
        .reply(200, {
          "header": "nock-qa-test-header-true",
          "ttl": 1000,
          "footer": "nock-qa-test-footer-true"
        });

      // taking HTML from the view, navigation object has already been used, he will now be in display
      request(jumpstart.app).get('/demo')
        .set('Accept', 'application/json')
        .expect(200)
        .end(function (err, res) {
          expect(res.text).to.contain("nock-qa-test-header-true");
          expect(res.text).to.contain("nock-qa-test-footer-true");
          res.statusCode.should.equal(200);
          done();
        });
    });

    it('Should return a cached value if requested within the time to live period', function (done) {

      // setting the response to false, if sample app returns false, then caching isn't working
      var api = nock(url)
        .persist()
        .post(uri)
        .reply(200, {
          "header": "nock-qa-test-header-false",
          "ttl": 1000,
          "footer": "nock-qa-test-footer-false"
        });

      request(jumpstart.app).get('/demo')
        .set('Accept', 'application/json')
        .expect(200)
        .end(function (err, res) {
          expect(res.text).to.contain("nock-qa-test-header-true");
          expect(res.text).to.contain("nock-qa-test-footer-true");
          res.statusCode.should.equal(200);
          done();
        });
    });

    // TODO: check with team what the behaviour is when iNAV errors out. As of now, this test will fail if executed
    xit('Should return header and footer from cache if iNAV errors out', function (done) {

      // setting the response data to to spanish
      var api = nock(url)
        .persist()
        .post(uri, {
          "id": "12345",
          "application": "sampleApp",
          "country": "US",
          "lang": "es",
          "market": "US",
          "page": "sampleApp",
          "header": "Y",
          "footer": "Y"
        })
        .reply(500)

      // let's make a request to the demo with spanish language
      request(jumpstart.app).get('/demo?face=es_US')
        .set('Accept', 'application/json')
        .expect(200)
        .end(function (err, res) {
          expect(res.text).to.contain("nock-qa-test-header-true");
          expect(res.text).to.contain("nock-qa-test-footer-true");
          res.statusCode.should.equal(200);
          done();
        });
    });

    it('Should hit iNAV end point after the time to live expires', function (done) {

      var api = nock(url)
        .persist()
        .post(uri)
        .reply(200, {
          "header": "nock-qa-test-header-should-call-nock",
          "ttl": 1000,
          "footer": "nock-qa-test-footer-should-call-nock"
        });

      // executes after 1.2 seconds (after the time to live expires)
      var delay = 1200;
      setTimeout(function () {
        request(jumpstart.app).get('/demo')
          .set('Accept', 'application/json')
          .expect(200)
          .end(function (err, res) {
            expect(res.text).to.contain("nock-qa-test-header-should-call-nock");
            expect(res.text).to.contain("nock-qa-test-footer-should-call-nock");
            res.statusCode.should.equal(200);
            done();
          });
      }, delay);
    });
  });

  describe('internationalization', function () {

    it('Should return header and footer in English language when en_US is requested', function (done) {

      var api = nock(url)
        .persist()
        .post(uri, {
          "id": "12345",
          "application": "sampleApp",
          "country": "US",
          "lang": "en",
          "market": "US",
          "page": "sampleApp",
          "header": "Y",
          "footer": "Y"
        })
        .reply(200, {
          "header": "english-header",
          "ttl": 1000,
          "footer": "english-footer"
        });

      // executes after 1.2 seconds so that cache will be cleared
      var delay = 1200;
      setTimeout(function () {
        request(jumpstart.app).get('/demo?face=en_US')
          .set('Accept', 'application/json')
          .expect(200)
          .end(function (err, res) {
            expect(res.text).to.contain("english-header");
            expect(res.text).to.contain("english-footer");
            res.statusCode.should.equal(200);
            done();
          });
      }, delay);
    });

    it('Should return header and footer in Spanish language when es_US is requested', function (done) {

      // setting the response data to to spanish
      var api = nock(url)
        .persist()
        .post(uri, {
          "id": "12345",
          "application": "sampleApp",
          "country": "US",
          "lang": "es",
          "market": "US",
          "page": "sampleApp",
          "header": "Y",
          "footer": "Y"
        })
        .reply(200, {
          "header": "spanish-header",
          "ttl": 1000,
          "footer": "spanish-footer"
        });

      // let's make a request to the demo with spanish language
      request(jumpstart.app).get('/demo?face=es_US')
        .set('Accept', 'application/json')
        .expect(200)
        .end(function (err, res) {
          expect(res.text).to.contain("spanish-header");
          expect(res.text).to.contain("spanish-footer");
          res.statusCode.should.equal(200);
          done();
        });
    });

    // the following test is also for a functionality currently not supported, will fail if executed
    xit('Should return header and footer in English language if requested language is not supported', function (done) {

      // TODO: check if we are returning an error page or the default nav
      var api = nock(url)
        .persist()
        .post(uri, {
          "id": "12345",
          "application": "sampleApp",
          "country": "US",
          "lang": "en",
          "market": "US",
          "page": "sampleApp",
          "header": "Y",
          "footer": "Y"
        })
        .reply(200, {
          "header": "english-header",
          "ttl": 1000,
          "footer": "english-footer"
        });

      // let's make a request to the demo with unsupported language
      request(jumpstart.app).get('/demo?face=ex_US')
        .set('Accept', 'application/json')
        .expect(200)
        .end(function (err, res) {
          expect(res.text).to.contain("english-header");
          expect(res.text).to.contain("english-footer");
          res.statusCode.should.equal(200);
          done();
        });
    });
  });
});*/
