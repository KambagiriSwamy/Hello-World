/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-POC
 */

'use strict';

/*
var fs = require('fs');

describe('iCM module', function () {

  // set mocha timeout to be bigger than the default 2000ms
  this.timeout(5000000);

  // log the stdout
  function logData(date) {
    if (data.toString().indexOf("{") != -1) {
      console.log('stdout: ' + data.toString());
      // parse the result string from icm to json object
      return eval("(" + data.toString() + ")");
    }
  }

  // log the error, if any
  function logError(err) {
    console.log('stderr: ' + err.toString());
  }

  // log the exit code
  function logExitCode(code) {
    console.log('child process exited with code ' + code);
  }

  describe('icm.json config file', function () {

    before(function (done) {
      var icmConfigObject;
      fs.readFile('./icm.json', function (err, data) {
        if (err) throw err;
        icmConfigObject = JSON.parse(data.toString());
        done();
      });
    })

    it('icm.json should have all input values provided by developer', function () {
      expect(icmConfigObject.client).to.equal('AWF');
      expect(icmConfigObject.user).to.equal('mpatel37');
      expect(icmConfigObject.environment).to.equal('E1');
      expect(icmConfigObject.contentOwner).to.equal('AXPi Wissam - 030 950 809');
      expect(icmConfigObject.applicationOwner).to.equal('PZN - 131254092');
      expect(icmConfigObject.content_root).to.equal('qa-sample-app');
    });
  });

  describe('Push new content to iCM', function () {

    var process = require('child_process').spawn('bash'),
      result;

    before(function (done) {
      // get the icm result report
      process.stdout.on('data', function (data) {
        result = logData(data);
        // terminate the child process
        process.stdin.end();
      });

      process.stderr.on('data', function (err) {
        logError(err);
      });

      process.on('exit', function (code) {
        logExitCode(code);
        done();
      });

      //push files to icm
      process.stdin.write('icmpush\n');
    });

    it('Should create a folder with a name in the icm.json, add the contents and return success', function () {
      expect(result.FAIL).to.equal(undefined);
    });
  });

  describe('Modify and push content that already exist in iCM', function () {

    var process = require('child_process').spawn('bash'),
      result;
    before(function (done) {
      // make some modification to the content of index.properties file
      fs.readFile('./application/public/locales/US/en/common/index.properties', 'utf8', function (err, data) {
        if (err) {
          return console.log(err);
        }

        var content = data.replace(/Log In to Your Account/g, 'Log In to Your Account modified by developer');

        fs.writeFile('./application/public/locales/US/en/common/index.properties', content, 'utf8', function (err) {
          if (err) return console.log(err);
          done();
        });
      });
    });
    before(function (done) {
      // get the icm result report
      process.stdout.on('data', function (data) {
        result = logData(data);
        // terminate the child process
        process.stdin.end();
      });

      process.stderr.on('data', function (err) {
        logError(err);
      });

      process.on('exit', function (code) {
        logExitCode(code);
        done();
      });

      //push files to icm
      process.stdin.write('icmpush\n');
    });

    // discard the changes we made in our local index.properties file
    after(function (done) {
      fs.readFile('./application/public/locales/US/en/common/index.properties', 'utf8', function (err, data) {
        if (err) {
          return console.log(err);
        }
        var content = data.replace(/Log In to Your Account modified by developer/g, 'Log In to Your Account');
        fs.writeFile('./application/public/locales/US/en/common/index.properties', content, 'utf8', function (err) {
          if (err) return console.log(err);
        });
      });
      done();
    });

    it('Should update the content and return success response when content is modified by developer', function () {
      expect(result.FAIL).to.equal(undefined);
    });
  });

  // the following two tests need to be executed after business owner make some changes in E3
  xdescribe('iCM behavior when content is changed by business owner', function () {

    var process = require('child_process').spawn('bash'),
      result;

    before(function (done) {
      // get the icm result report
      process.stdout.on('data', function (data) {
        result = logData(data);
        // terminate the child process
        process.stdin.end();
      });
      process.stderr.on('data', function (err) {
        logError(err);
      });

      process.on('exit', function (code) {
        logExitCode(code);
        done();
      });
      //push files to icm
      process.stdin.write('icmpush\n');
    });

    it('headcheck should fail since content pushed by developer was changed or modified by business owner', function () {
      expect(result.FAIL).to.not.equal(undefined);
    });
  });

  xdescribe('iCM behavior when content is changed by business owner and is pushed forcefully', function () {

    var process = require('child_process').spawn('bash'),
      result;

    before(function (done) {
      // get the icm result report
      process.stdout.on('data', function (data) {
        result = logData(data);
        // terminate the child process
        process.stdin.end();
      });

      process.stderr.on('data', function (err) {
        logError(err);
      });

      process.on('exit', function (code) {
        logExitCode(code);
        done();
      });

      //push files to icm forcefully
      process.stdin.write('icmpush -f\n');
    });

    it('headcheck should pass when content that is changed by business owner is pushed forcefully by developer', function () {
      expect(result.FAIL).to.equal(undefined);
    });
  });
});*/