/**
 * Patch created to deduplicate deplyment dates
 */

'use strict';

var db = require('../../application/lib/db');
var asyncEach = require('async-each');
var dateFormat = require('dateformat');
var _ = require("lodash");
var utils = require('../../application/lib/utils.js');

module.exports = {
  runPatch: function(patchCallback) {
    console.log('=========== Starting: Unique Deployment dates Updates Patch ==============');
    console.log('Patch Description: This patch is done to remove the duplicate deployment dates');
    var Campaign = db.campaignClass(),
      campaignsWithErrors = '';

    // Get all the One-off campaigns  
    Campaign.find({
      'emailType.codeName': 'ET_ONEOFF'
    }, function(err, campaigns) {
      // Go over each campaign
      asyncEach(campaigns, function(campaign, cb) {
        var uniqueDt = [];
        var finalUniqueDt = [];
        var tempDT;
        var tempDtArr = [];
        var formatteddt;
        var initialDtArray;
        var initialDt = campaign.deploymentDates;
        var count = 0;
        if (campaign.deploymentDates.length > 1) {
          campaign.deploymentDates.forEach(function(dates) {
            tempDT = dateFormat(dates, 'mm/dd/yyyy');
            tempDtArr.push(tempDT);
          });
          // initialDtArray = tempDtArr.length;
          uniqueDt = _.uniq(tempDtArr);
          uniqueDt.forEach(function(dats) {
            formatteddt = utils.formatDate(dats);
            finalUniqueDt.push(formatteddt);
          });
          if (campaign.deploymentDates[0] - finalUniqueDt[0] === 0 && campaign.deploymentDates.length > finalUniqueDt.length) {
            campaign.deploymentDates = finalUniqueDt;
            console.log('For Campaign:: ' + campaign.requestID + ' Initial: ' + initialDt + 'Updated Deploy Dates: ' + campaign.deploymentDates);
            campaign.save(function(err) {
              if (err) {
                console.log('FAIL: Error occured while updating campaign with ID: ' + campaign.requestID);
                campaignsWithErrors += campaign.requestID + ', ';
              } else {
                console.log('SUCCESS: Successfully updated the campaign with ID: ' + campaign.requestID);
              }
              return cb(err);
            });
          } else {
            console.log('First element did not match - Deploy dates for ' + campaign.emailType.name + ' Campaign:: ' + campaign.requestID + ' is not updated');
            return cb();
          }
        } else {
          console.log('NO UPDATES made:: ' + campaign.requestID);
          return cb();
        }
      }, function(err) {
        if (campaignsWithErrors) {
          console.log('FAIL: DUPLICATE  Deploy Patch ==> Campaigns with errors: ' + campaignsWithErrors);
        }
        if (err) {
          console.log('FAIL: DUPLICATE  Deploy  Patch ==> Script failed with few campaigns not updated.');
        } else {
          console.log('SUCCESS: DUPLICATE  Deploy  Patch Script Executed Successfully:::' + campaigns.length);
        }
        console.log('=========== Ending: DUPLICATE  Deploy dates Patch ==============');
        patchCallback(err);
      });
    });
  }
};
