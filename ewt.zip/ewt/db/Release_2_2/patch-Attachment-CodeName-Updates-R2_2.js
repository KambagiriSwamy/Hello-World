/**
 * Patch created to update attachment.type.name if name has attachment.type.code values
 */

'use strict';

var db = require('../../application/lib/db');
var asyncEach = require('async-each');
var dateFormat = require('dateformat');
var _ = require("lodash");
var utils = require('../../application/lib/utils.js');
var oneOffImpactedCampaignID = [];
var svcImpactedCampaignID = [];
var maImpactedCampaignID = [];

module.exports = {
  runPatch: function(patchCallback) {
    console.log('=========== Starting: Update the code Names Updates Patch ==============');
    console.log('Patch Description: This patch is done to update the attachment.type.name');

    updateAttachmentCodeName(function(err) {
      console.log('=========== Ending: User DB Patch ==============');
      return patchCallback(err);
    });
  }
};


function updateAttachmentCodeName(callbk) {

  var Campaign = db.campaignClass(),
    campaignsWithErrors = '';
  var AttachmentType = db.attachmentTypeClass();

  //Getting all Attachment types to an object for updating Attachment names
  AttachmentType.find({}, function(err, attachmentTypes) {

    Campaign.find({}, function(err, campaigns) {
      // Go over each campaign
      var MA = 0;
      var Svc = 0;
      var oneOff = 0;
      var totalImpactedCampaign = 0;

      asyncEach(campaigns, function(campaign, cb) {
          var i = 0;
          var tempObj;
          var j;
          var tempAttachment = [];
          var initialName = [];
          var updatedName = [];
          //Iterate each attachments to update the names  
          if (campaign.attachments.length > 0) {
            for (j = 0; j < campaign.attachments.length; j++) {
              try {
                if (campaign.attachments[j].type.name) {
                  if (campaign.attachments[j].type.name === campaign.attachments[j].type.code) {
                    initialName.push(campaign.attachments[j].type.name);
                    i++;
                    tempObj = {};
                    tempObj = _.find(attachmentTypes, function(o) {
                      return o.code === campaign.attachments[j].type.code;
                    });
                    campaign.attachments[j].type.name = tempObj.name;
                    tempAttachment = campaign.attachments[j];
                    campaign.attachments.set(j, tempAttachment);
                    updatedName.push(campaign.attachments[j].type.name);
                  }
                }
              } catch (e) {
                console.log('Error Campaign', campaign.requestID, e);
              }
            }
          }
          //For those impacted campaigns, get the type and add to resp variables for 
          //printing
          if (i >= 1) {
            if (campaign.emailType.codeName === 'ET_ONEOFF') {
              oneOff++;
              oneOffImpactedCampaignID.push(campaign.requestID);
            } else if (campaign.emailType.codeName === 'ET_MA') {
              MA++;
              maImpactedCampaignID.push(campaign.requestID);
            } else if (campaign.emailType.codeName === 'ET_SERVICING') {
              svcImpactedCampaignID.push(campaign.requestID);
              Svc++;
            }

            campaign.save(function(err) {
              if (err) {
                console.log('FAIL: Error occured while updating campaign with ID: ' + camp.requestID);
                campaignsWithErrors += campaign.requestID + ', ';
              } else {
                console.log('SUCCESS: Successfully updated the campaign:: ', campaign.requestID + '. Initial name ' + initialName + ' and updated name ' + updatedName);
              }
              return cb(err);
            });
          } else {
            //return cb('NO UPDATES required for this campaign' + campaign.requestID);
            return cb();
          }
        },
        function(err) {
          if (campaignsWithErrors) {
            console.log('FAIL: Attachment Name updates ==> Campaigns with errors: ' + campaignsWithErrors);
          }
          if (err) {
            console.log('FAIL: Attachment Name updates ==> Script failed with few campaigns not updated.');
          } else {
            totalImpactedCampaign = oneOff + MA + Svc;
            console.log('Total impacted One off Campaign', oneOff, ' ', oneOffImpactedCampaignID);
            console.log('Total impacted MA Campaign', MA, ' ', maImpactedCampaignID);
            console.log('Total impacted Servicing Campaign', Svc, ' ', svcImpactedCampaignID);
            console.log('SUCCESS:  Patch Script Executed Successfully on total Campaigns ' + campaigns.length + 'Updated for ' + totalImpactedCampaign);
          }
          console.log('=========== Ending: Attachment Name updates Patch ==============');
          callbk(err);
        });
    });
  });
}
