/**
 * Module: EWT-2.2 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.2 (ERA) - This file adds new Dynamic records 
 */

'use strict';

var db = require('../../application/lib/db'),
  async = require('async'),
  asyncEach = require('async-each');

var dynamicCampaignRecords = [{
  "code": "D",
  "name": "Amex Offers – Consumer Multi Merchant",
  "position": 1,
  "codeName": "DYNAMIC_EMIAL"
}, {
  "code": "A",
  "name": "Acquisition Offer Reinforcement",
  "position": 2,
  "codeName": "AOR"
},  {
  "code": "3",
  "name": "Recommendations - New Merchants Only",
  "position": 3,
  "codeName": "RECOMMENDER_NEW_MERCHANT"
}, {
  "code": "O",
  "name": "Amex Offers – OPEN Multi Merchant",
  "position": 4,
  "codeName": "OPEN_DYNAMIC_MERCHANT_EMAIL"
}, {
  "code": "W",
  "name": "Current MR Point Balance",
  "position": 5,
  "codeName": "MEMBERSHIP_REWARDS"
}, {
  "code": "2",
  "name": "Recommendations - All Small Merchants",
  "position": 6,
  "codeName": "RECOMMENDER_SPEND_ONLY"
}, {
  "code": "S",
  "name": "Amex Offers – Single Merchant",
  "position": 7,
  "codeName": "STANDALONE_DYNAMIC_EMAIL"
}, {
  "code": "L",
  "name": "Lending Awareness",
  "position": 8,
  "codeName": "LENDING_AWARENESS"
// }, {
//   "code": "N",
//   "name": "Not Applicable",
//   "codeName": "NOT_APPLICABLE"
}, {
  "code": "P",
  "name": "Social Pre-Sync",
  "position": 9,
  "codeName": "PRE_SYNC"
// }, {
//   "code": "1",
//   "name": "Recommender All",
//   "codeName": "RECOMMENDER_ALL"
},  {
  "code": "E",
  "name": "Amex Everyday ROC Tracker",
  "position": 10,
  "codeName": "AED"
}, {
  "code": "M",
  "name": "Marketing API",
  "position": 11,
  "codeName": "MARKETING_API"
}];

/**
To remove collections by collection name and add the updated entries
*/

function resetCollection(collectionName, data, cb) {
  var CollectionClass = db[collectionName + 'Class']();
  CollectionClass.remove({}, function(err) {
    if (err) {
      console.log('FAIL: Error in removing all records from' + collectionName + 'collection.');
      return cb(err);
    }

    asyncEach(data, function(obj, asynCb) {
      var record = new CollectionClass(obj);
      record.save(function(err) {
        if (err) {
          console.log('FAILED while resetting ' + collectionName + ' collection. Error: ' + err);
        }
        return asynCb(err);
      });
    }, function(err) {
      if (err) {
        console.log('FAIL: Error occured while adding records to ' + collectionName + ' collection.')
        return cb(err);
      } else {
        CollectionClass.find({}, function(err, records) {
          console.log('Total records in ' + collectionName + ' collection: ' + records.length);
          console.log('SUCCESS: Added records to ' + collectionName + ' collection');
          return cb(err);
        });
      }
    });
  });
}

module.exports = {
  runPatch: function(patchCallback) {
    console.log('=========== Starting: Add master records Patch ==============');
    console.log('Patch Description: This patch will ensure add wipe out the existing records (if any) and will add new records to dynamicCampaignRecords DB collection.');

    async.parallel([function(cb) {
      return resetCollection('dynamicCampaign', dynamicCampaignRecords, cb);
    }], function(err) {
      console.log('=========== Ending: Add master records Patch ==============');
      return patchCallback(err);
    });
  }
}
