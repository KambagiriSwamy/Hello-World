/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 (ERA) - This file implements the user controller at node end. It has all the action methods related to user controller
 */

'use strict';

var db = require('../../application/lib/db'),
  async = require('async'),
  asyncEach = require('async-each');


var dynamicCampaignRecords = [{
  "code": "D",
  "name": "Dynamic Email",
  "codeName": "DYNAMIC_EMIAL"
}, {
  "code": "L",
  "name": "Lending Awareness",
  "codeName": "LENDING_AWARENESS"
}, {
  "code": "N",
  "name": "Not Applicable",
  "codeName": "NOT_APPLICABLE"
}, {
  "code": "P",
  "name": "Pre-Sync",
  "codeName": "PRE_SYNC"
}, {
  "code": "1",
  "name": "Recommender All",
  "codeName": "RECOMMENDER_ALL"
}, {
  "code": "2",
  "name": "Recommender Spend Only",
  "codeName": "RECOMMENDER_SPEND_ONLY"
}, {
  "code": "3",
  "name": "Recommender New Merchant",
  "codeName": "RECOMMENDER_NEW_MERCHANT"
}, {
  "code": "A",
  "name": "AOR",
  "codeName": "AOR"
}, {
  "code": "E",
  "name": "AED",
  "codeName": "AED"
}, {
  "code": "W",
  "name": "Membership Rewards",
  "codeName": "MEMBERSHIP_REWARDS"
}, {
  "code": "M",
  "name": "Marketing API",
  "codeName": "MARKETING_API"
}, {
  "code": "S",
  "name": "Standalone Dynamic Email",
  "codeName": "STANDALONE_DYNAMIC_EMAIL"
}, {
  "code": "O",
  "name": "OPEN Dynamic Merchant Email",
  "codeName": "OPEN_DYNAMIC_MERCHANT_EMAIL"
}];

function resetCollection(collectionName, data, cb) {
  var CollectionClass = db[collectionName + 'Class']();
  CollectionClass.remove({}, function(err) {
    if (err) {
      console.log('FAIL: Error in removing all records from dynamicCampaigns collection.');
      return cb(err);
    }

    asyncEach(data, function(obj, asynCb) {
      var record = new CollectionClass(obj);
      record.save(function(err) {
        if (err) {
          console.log('FAILED while resetting "' + collectionName + '" collection. Error: ' + err);
        }
        return asynCb(err);
      });
    }, function(err) {
      if (err) {
        console.log('FAIL: Error occured while adding records to ' + collectionName + ' collection.')
        return cb(err);
      } else {
        CollectionClass.find({}, function(err, records) {
          console.log('Total records in ' + collectionName + ' collection: ' + records.length);
          console.log('SUCCESS: Added records to ' + collectionName + ' collection');
          return cb(err);
        });
      }
    });
  });
}

module.exports = {
  runPatch: function(patchCallback) {
    console.log('=========== Starting: Add master records Patch ==============');
    console.log('Patch Description: This patch will ensure add wipe out the existing records (if any) and will add new records to userStatus DB collection.');

    async.parallel([function(cb) {
      return resetCollection('dynamicCampaign', dynamicCampaignRecords, cb);
    }], function(err) {
      console.log('=========== Ending: Add master records Patch ==============');
      return patchCallback(err);
    });
  }
}
