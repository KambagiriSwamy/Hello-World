db.emailType.remove({});
db.businessUnit.remove({});
db.campaignType.remove({});
db.campaignSubType.remove({});
db.campaignState.remove({});
db.pznField.remove({});
db.user.remove({});
db.cellType.remove({});
db.cardMemberNeedCategory.remove({});
db.sequence.remove({});
db.userRole.remove({});
db.userStatus.remove({});
db.attachmentType.remove({});
db.dynamicCampaigns.remove({});
db.commCode.remove({});
db.product.remove({});
db.product.insert(
  [{"commCode":"BLUCSH","productCode":"P001","productName":"Blue Cash","fequencey":"Monthly","productDescription":"Choose Yes, to receive the latest Blue Cashù from American Express Newsletter with exclusive member benefits and offers."},
    {"commCode":"BLUCSH","productCode":"P002","productName":"Blue Cash Every Day","fequencey":"Monthly","productDescription":"Choose Yes, to receive the latest Blue Cashù from American Express Newsletter with exclusive member benefits and offers."},
    {"commCode":"BLUCSH","productCode":"P003","productName":"Blue Cash Preferred","fequencey":"Monthly","productDescription":"Choose Yes, to receive the latest Blue Cashù from American Express Newsletter with exclusive member benefits and offers."},
    {"commCode":"BLUFSH","productCode":"P004","productName":"Blue","fequencey":"Monthly","productDescription":"The latest Blue Newsletter, exclusive member offers, and more. Delivered monthly."},
    {"commCode":"BLUSKY","productCode":"P005","productName":"Blue Sky","fequencey":"Monthly","productDescription":"The latest Blue Sky Newsletter with exclusive member benefits and offers. Delivered monthly."},
    {"commCode":"BLUSKY","productCode":"P006","productName":"Blue Sky Preferred","fequencey":"Monthly","productDescription":"The latest Blue Sky Newsletter with exclusive member benefits and offers. Delivered monthly."},
    {"commCode":"CENTEX","productCode":"P007","productName":"Centurion ","fequencey":"Monthly","productDescription":"The latest Centurionù Card travel offers, new Card benefits, special partner deals, and By Invitation Onlyù events. Delivered monthly."},
    {"commCode":"DSKYMI","productCode":"P008","productName":"Delta Reserve Credit Card","fequencey":"Every Other Month","productDescription":"The latest Delta SkyMiles(R) Credit Card mileage offers, exclusive Cardmember promotions, merchant discounts, and more. Delivered every other month."},
    {"commCode":"DSKYMI","productCode":"P009","productName":"Gold Delta SkyMiles","fequencey":"Every Other Month","productDescription":"The latest Delta SkyMiles(R) Credit Card mileage offers, exclusive Cardmember promotions, merchant discounts, and more. Delivered every other month."},
    {"commCode":"DSKYMI","productCode":"P010","productName":"Platinum Delta SkyMiles","fequencey":"Every Other Month","productDescription":"The latest Delta SkyMiles(R) Credit Card mileage offers, exclusive Cardmember promotions, merchant discounts, and more. Delivered every other month."},
    {"commCode":"EPREVW","productCode":"P011","productName":"Platinum","fequencey":"Monthly","productDescription":"The latest Platinum Cardù benefit news, travel offers, exclusive Membership Rewardsù and retail promotions, and By Invitation Onlyù event information. Delivered monthly."},
    {"commCode":"EVRDAY","productCode":"P012","productName":"Amex EveryDay","fequencey":"Bi-Monthly","productDescription":"The latest (AMEX EveryDay&#8480; Credit Card) product news, including benefits reinforcement, offers and Partner news. Delivered Bimonthly"},
    {"commCode":"EVRDAY","productCode":"P013","productName":"Amex EveryDay Preferred","fequencey":"Bi-Monthly","productDescription":"The latest (AMEX EveryDay&#8480; Credit Card) product news, including benefits reinforcement, offers and Partner news. Delivered Bimonthly"},
    {"commCode":"HILTON","productCode":"P014","productName":"Hilton Base","fequencey":"Quarterly","productDescription":"The latest news, rewards, offers and more from your Hilton HHonorsù from American Express. Delivered quarterly."},
    {"commCode":"HILTON","productCode":"P015","productName":"Hilton Surpass","fequencey":"Quarterly","productDescription":"The latest news, rewards, offers and more from your Hilton HHonorsù from American Express. Delivered quarterly."},
    {"commCode":"MEMBR0","productCode":"P016","productName":"Gold","fequencey":"Monthly","productDescription":"The latest American Express news, rewards, exclusive Cardmember offers, and more. Delivered every month."},
    {"commCode":"MEMBR0","productCode":"P017","productName":"PRG","fequencey":"Monthly","productDescription":"The latest American Express news, rewards, exclusive Cardmember offers, and more. Delivered every month."},
    {"commCode":"MEMSIN","productCode":"P018","productName":"Green","fequencey":"Monthly","productDescription":"The latest American Express news, rewards, exclusive Cardmember offers, and more. Delivered every month."},
    {"commCode":"MERCED","productCode":"P019","productName":"Mercedes-Benz","fequencey":"Quarterly","productDescription":"The latest Mercedes product news, including benefits reinforcement, offers and Partner news. Delivered quarterly."},
    {"commCode":"MORGAN","productCode":"P020","productName":"Morgan Stanley","fequencey":"Quarterly","productDescription":"The latest Morgan Stanley product news, including benefits reinforcement, offers and Partner news. Delivered quarterly."},
    {"commCode":"RWDWAT","productCode":"P021","productName":"Membership Rewards","fequencey":"No Frequency ","productDescription":"If you choose Yes, you may receive this monthly guide to exclusive Cardmember offers and exciting ways to earn and redeem points."},
    {"commCode":"STRGST","productCode":"P022","productName":"Starwood Preferred Guest","fequencey":"Every Other Month","productDescription":"The latest news, exclusive Cardmember offers, and more to help you make the most of your Starwood Preferred Guest(R) Credit Card from American Express. Delivered  every other month."},
    {"commCode":"BGRINS","productCode":"P023","productName":"Business Membership Rewards","fequencey":"Monthly","productDescription":"Monthly insights and offers for you and your business"},
    {"commCode":"PLTVEN","productCode":"P024","productName":"Business Membership Rewards","fequencey":"Monthly","productDescription":"Monthly insights and offers for you and your business"},
    {"commCode":"PLTVEN","productCode":"P025","productName":"Business Centurion","fequencey":"Monthly","productDescription":"Monthly insights and offers for you and your business"},
    {"commCode":"PLTVEN","productCode":"P026","productName":"Business Gold Rewards","fequencey":"Monthly","productDescription":"Monthly insights and offers for you and your business"},
    {"commCode":"PLTVEN","productCode":"P027","productName":"Plum","fequencey":"Monthly","productDescription":"Monthly insights and offers for you and your business"},
    {"commCode":"PLTVEN","productCode":"P028","productName":"Business Platinum ","fequencey":"Monthly","productDescription":"Monthly insights and offers for you and your business"},
    {"commCode":"PLTVEN","productCode":"P029","productName":"SimplyCash Business","fequencey":"Monthly","productDescription":"Monthly insights and offers for you and your business"},
    {"commCode":"PLTVEN","productCode":"P030","productName":"Starwood Preferred Guest Business","fequencey":"Monthly","productDescription":"Monthly insights and offers for you and your business"},
    {"commCode":"PLTVEN","productCode":"P031","productName":"Gold Delta SkyMiles Business","fequencey":"Monthly","productDescription":"Monthly insights and offers for you and your business"},
    {"commCode":"PLTVEN","productCode":"P032","productName":"Platinum Delta SkyMiles Business","fequencey":"Monthly","productDescription":"Monthly insights and offers for you and your business"},
    {"commCode":"PLTVEN","productCode":"P033","productName":"Delta Reserve for Business","fequencey":"Monthly","productDescription":"Monthly insights and offers for you and your business"},
    {"commCode":"PLTVEN","productCode":"P034","productName":"Business Green Rewards","fequencey":"Monthly","productDescription":"Monthly insights and offers for you and your business"},
    {"commCode":"PLTVEN","productCode":"P035","productName":"Blue for Business","fequencey":"Monthly","productDescription":"Monthly insights and offers for you and your business"},
    {"commCode":"PLTVEN","productCode":"P036","productName":"Lowe's Business Rewards","fequencey":"Monthly","productDescription":"Monthly insights and offers for you and your business"}]
); 
  db.commCode.insert(
    [{"businessUnit":"CCSG","commCode":"BLUCSH","campaignType":"ET_PNL","pnlDescription":"Blue Cash Newsletter"},
      {"businessUnit":"CCSG","commCode":"BLUCSH","campaignType":"ET_PNL","pnlDescription":"Blue Cash Newsletter"},
      {"businessUnit":"CCSG","commCode":"BLUCSH","campaignType":"ET_PNL","pnlDescription":"Blue Cash Newsletter"},
      {"businessUnit":"CCSG","commCode":"BLUFSH","campaignType":"ET_PNL","pnlDescription":"Blue Voice E-Newsletter"},
      {"businessUnit":"CCSG","commCode":"BLUSKY","campaignType":"ET_PNL","pnlDescription":"Blue Sky E-Newsletter"},
      {"businessUnit":"CCSG","commCode":"BLUSKY","campaignType":"ET_PNL","pnlDescription":"Blue Sky E-Newsletter"},
      {"businessUnit":"CCSG","commCode":"CENTEX","campaignType":"ET_PNL","pnlDescription":"Centurion Cardmember E-Newsletter"},
      {"businessUnit":"CCSG","commCode":"DSKYMI","campaignType":"ET_PNL","pnlDescription":"Delta SkyMiles Card E-Newsletter"},
      {"businessUnit":"CCSG","commCode":"DSKYMI","campaignType":"ET_PNL","pnlDescription":"Delta SkyMiles Card E-Newsletter"},
      {"businessUnit":"CCSG","commCode":"DSKYMI","campaignType":"ET_PNL","pnlDescription":"Delta SkyMiles Card E-Newsletter"},
      {"businessUnit":"CCSG","commCode":"EPREVW","campaignType":"ET_PNL","pnlDescription":"Platinum Experience E-Newsletter"},
      {"businessUnit":"CCSG","commCode":"EVRDAY","campaignType":"ET_PNL","pnlDescription":"Amex EveryDay Credit Card E-Newsletter"},
      {"businessUnit":"CCSG","commCode":"EVRDAY","campaignType":"ET_PNL","pnlDescription":"Amex EveryDay Credit Card E-Newsletter"},
      {"businessUnit":"CCSG","commCode":"HILTON","campaignType":"ET_PNL","pnlDescription":"Hilton HHonorsù Card E-Newsletter"},
      {"businessUnit":"CCSG","commCode":"HILTON","campaignType":"ET_PNL","pnlDescription":"Hilton HHonorsù Card E-Newsletter"},
      {"businessUnit":"CCSG","commCode":"MEMBR0","campaignType":"ET_PNL","pnlDescription":"Inside Membership E-Newsletter"},
      {"businessUnit":"CCSG","commCode":"MEMBR0","campaignType":"ET_PNL","pnlDescription":"Inside Membership E-Newsletter"},
      {"businessUnit":"CCSG","commCode":"MEMSIN","campaignType":"ET_PNL","pnlDescription":"Inside Membership E-Newsletter"},
      {"businessUnit":"CCSG","commCode":"MERCED","campaignType":"ET_PNL","pnlDescription":"Mercedes E-Newsletter"},
      {"businessUnit":"CCSG","commCode":"MORGAN","campaignType":"ET_PNL","pnlDescription":"Morgan Stanley E-Newsletter"},
      {"businessUnit":"CCSG","commCode":"RWDWAT","campaignType":"ET_PNL","pnlDescription":"RewardsWatch Newsletter"},
      {"businessUnit":"CCSG","commCode":"STRGST","campaignType":"ET_PNL","pnlDescription":"Starwood Preferred Guest(R) Card E-Newsletter"},
      {"businessUnit":"OPEN","commCode":"BGRINS","campaignType":"ET_PNL","pnlDescription":"Business RewardsWatch Newsletter"},
      {"businessUnit":"OPEN","commCode":"PLTVEN","campaignType":"ET_PNL","pnlDescription":"Business RewardsWatch Newsletter"},
      {"businessUnit":"OPEN","commCode":"PLTVEN","campaignType":"ET_PNL","pnlDescription":"Business Centurion Newsletter"},
      {"businessUnit":"OPEN","commCode":"PLTVEN","campaignType":"ET_PNL","pnlDescription":"OPEN Monthly Newsletter"},
      {"businessUnit":"OPEN","commCode":"PLTVEN","campaignType":"ET_PNL","pnlDescription":"OPEN Monthly Newsletter"},
      {"businessUnit":"OPEN","commCode":"PLTVEN","campaignType":"ET_PNL","pnlDescription":"OPEN Monthly Newsletter"},
      {"businessUnit":"OPEN","commCode":"PLTVEN","campaignType":"ET_PNL","pnlDescription":"OPEN Monthly Newsletter"},
      {"businessUnit":"OPEN","commCode":"PLTVEN","campaignType":"ET_PNL","pnlDescription":"OPEN Monthly Newsletter"},
      {"businessUnit":"OPEN","commCode":"PLTVEN","campaignType":"ET_PNL","pnlDescription":"OPEN Monthly Newsletter"},
      {"businessUnit":"OPEN","commCode":"PLTVEN","campaignType":"ET_PNL","pnlDescription":"OPEN Monthly Newsletter"},
      {"businessUnit":"OPEN","commCode":"PLTVEN","campaignType":"ET_PNL","pnlDescription":"OPEN Monthly Newsletter"},
      {"businessUnit":"OPEN","commCode":"PLTVEN","campaignType":"ET_PNL","pnlDescription":"OPEN Monthly Newsletter"},
      {"businessUnit":"OPEN","commCode":"PLTVEN","campaignType":"ET_PNL","pnlDescription":"OPEN Monthly Newsletter"},
      {"businessUnit":"OPEN","commCode":"PLTVEN","campaignType":"ET_PNL","pnlDescription":"OPEN Monthly Newsletter"}]
);
db.dynamicCampaigns.insert([{
  'code': 'D',
  'name': 'Dynamic Email',
  'codeName': 'DYNAMIC_EMIAL'
}, {
  'code': 'L',
  'name': 'Lending Awareness',
  'codeName': 'LENDING_AWARENESS'
}, {
  'code': 'N',
  'name': 'Not Applicable',
  'codeName': 'NOT_APPLICABLE'
}, {
  'code': 'P',
  'name': 'Pre-Sync',
  'codeName': 'PRE_SYNC'
}, {
  'code': '1',
  'name': 'Recommender All',
  'codeName': 'RECOMMENDER_ALL'
}, {
  'code': '2',
  'name': 'Recommender Spend Only',
  'codeName': 'RECOMMENDER_SPEND_ONLY'
}, {
  'code': '3',
  'name': 'Recommender New Merchant',
  'codeName': 'RECOMMENDER_NEW_MERCHANT'
}, {
  'code': 'A',
  'name': 'AOR',
  'codeName': 'AOR'
}, {
  'code': 'E',
  'name': 'AED',
  'codeName': 'AED'
}, {
  'code': 'W',
  'name': 'Membership Rewards',
  'codeName': 'MEMBERSHIP_REWARDS'
}, {
  'code': 'M',
  'name': 'Marketing API',
  'codeName': 'MARKETING_API'
}]);

db.emailType.insert([{
  'code': '012',
  'name': 'Servicing',
  'codeName': 'ET_SERVICING'
}, {
  'code': '008',
  'name': 'Marketing Automation',
  'codeName': 'ET_MA'
}, {
  'code': '006',
  'name': 'One Off',
  'codeName': 'ET_ONEOFF'
},{
  "code": "013",
  "name": "Product New Letter",
  "codeName": "ET_PNL"

}]);

db.businessUnit.insert([{
  'name': 'Global Merchant Services (GMS)',
  'code': 'U007',
  'codeName': 'BU_GMS'
}, {
  'name': 'GCC',
  'code': 'U006',
  'codeName': 'BU_GCC'
}, {
  'name': 'OPEN',
  'code': 'U005',
  'codeName': 'BU_OPEN'
}, {
  'name': 'CCSG',
  'code': 'U004',
  'codeName': 'BU_CCSG'
}, {
  'name': 'Publishing',
  'code': 'U003',
  'codeName': 'BU_PUBLISHING'
}, {
  'name': 'GMPI',
  'code': 'U002',
  'codeName': 'BU_GMPI'
}, {
  'name': 'Global Prepaid',
  'code': 'U019',
  'codeName': 'BU_GLOBAL_PREPAID'
}, {
  'name': 'Consumer Travel',
  'code': 'U018',
  'codeName': 'BU_CONSUMER_TRAVEL'
}, {
  'name': 'DCE',
  'code': 'U017',
  'codeName': 'BU_AXPI'
}, {
  'name': 'MR',
  'code': 'U020',
  'codeName': 'BU_MR'
}, {
  'name': 'Card Services',
  'code': 'U021',
  'codeName': 'BU_CARD_SERVICES'
}, {
  'name': 'Direct Deposits',
  'code': 'U022',
  'codeName': 'BU_DIRECT_DEPOSITS'
}, {
  'name': 'Enterprise Growth Group (EGG)',
  'code': 'U023',
  'codeName': 'BU_EGG'
}, {
  'name': 'Digital Partnerships & Development (DPD)',
  'code': 'U024',
  'codeName': 'BU_DPD'
}]);
db.campaignType.insert([{
  'name': 'Card Acquisition',
  'code': '008',
  'codeName': 'CT_CARD_ACQUISITION'
}, {
  'name': 'Balance Transfer',
  'code': '024',
  'codeName': 'CT_BALANCE_TRANSFER'
}, {
  'name': 'Card Services',
  'code': '026',
  'codeName': 'CT_CARD_SERVICES'
}, {
  'name': 'CTN',
  'code': '038',
  'codeName': 'CT_CTN'
}, {
  'name': 'LOC',
  'code': '041',
  'codeName': 'CT_LOC'
}, {
  'name': 'Loyalty',
  'code': '043',
  'codeName': 'CT_LOYALTY'
}, {
  'name': 'Self Servicing',
  'code': '048',
  'codeName': 'CT_SELF_SERVICING'
}, {
  'name': 'Spend',
  'code': '057',
  'codeName': 'CT_SPEND'
}, {
  'name': 'Publishing',
  'code': '060',
  'codeName': 'CT_PUBLISHING'
}, {
  'name': 'Market Research',
  'code': '062',
  'codeName': 'CT_MARKET_RESEARCH'
}]);
db.campaignSubType.insert([{
  'name': 'BASIC',
  'code': '008',
  'codeName': 'CST_BASIC',
  'campaignTypeCode': '008'
}, {
  'name': 'SUPP',
  'code': '009',
  'codeName': 'CST_SUPP',
  'campaignTypeCode': '008'
}, {
  'name': 'UPGRADE',
  'code': '010',
  'codeName': 'CST_UPGRADE',
  'campaignTypeCode': '008'
}, {
  'name': 'Balance Transfer',
  'code': '024',
  'codeName': 'CST_BALANCE_TRANSFER',
  'campaignTypeCode': '024'
}, {
  'name': 'ACCOUNT PROTECTOR',
  'code': '026',
  'codeName': 'CST_ACCOUNT_PROTECTOR',
  'campaignTypeCode': '026'
}, {
  'name': 'ACCOUNT PROTECTOR (BUSINESS )',
  'code': '027',
  'codeName': 'CST_ACCOUNT_PROTECTOR_B',
  'campaignTypeCode': '026'
}, {
  'name': 'AIR FLIGHT INSURANCE',
  'code': '028',
  'codeName': 'CST_AIR_FLIGHT_INSURANCE',
  'campaignTypeCode': '026'
}, {
  'name': 'BAGGAGE DELAY',
  'code': '029',
  'codeName': 'CST_BAGGAGE_DELAY',
  'campaignTypeCode': '026'
}, {
  'name': 'Card Services Bundle',
  'code': '030',
  'codeName': 'CST_CARD_SERVICES_BUNDLE',
  'campaignTypeCode': '026'
}, {
  'name': 'CREDIT CARD REGISTRY',
  'code': '031',
  'codeName': 'CST_CREDIT_CARD_REGISTRY',
  'campaignTypeCode': '026'
}, {
  'name': 'CREDITSECURE',
  'code': '032',
  'codeName': 'CST_CREDITSECURE',
  'campaignTypeCode': '026'
}, {
  'name': 'CREDITSECURE (BUSINESS)',
  'code': '033',
  'codeName': 'CST_CREDITSECURE_B',
  'campaignTypeCode': '026'
}, {
  'name': 'General Travel Insurance (TIS)',
  'code': '034',
  'codeName': 'CST_GENERAL_TRAVEL_INSURANCE',
  'campaignTypeCode': '026'
}, {
  'name': 'Global Travel Shield (GTS)',
  'code': '035',
  'codeName': 'CST_GLOBAL_TRAVEL_SHIELD',
  'campaignTypeCode': '026'
}, {
  'name': 'Premium Car Rental Protection',
  'code': '036',
  'codeName': 'CST_PREMIUM_CAR_RENTAL_PROTECTION',
  'campaignTypeCode': '026'
}, {
  'name': 'TRAVEL DELAY INS',
  'code': '037',
  'codeName': 'CST_TRAVEL_DELAY_INS',
  'campaignTypeCode': '026'
}, {
  'name': 'Retail Team',
  'code': '038',
  'codeName': 'CST_RETAIL_TEAM',
  'campaignTypeCode': '038'
}, {
  'name': 'Fine Hotels & Resopp',
  'code': '039',
  'codeName': 'CST_FINE_HOTELS_AND_RESOPP',
  'campaignTypeCode': '038'
}, {
  'name': 'CTN Online Marketing',
  'code': '040',
  'codeName': 'CST_CTN_ONLINE_MARKETING',
  'campaignTypeCode': '038'
}, {
  'name': 'LOC Acquisition',
  'code': '041',
  'codeName': 'CST_LOC_ACQUISITION',
  'campaignTypeCode': '041'
}, {
  'name': 'LOC Product Awareness/Usage',
  'code': '042',
  'codeName': 'CST_LOC_PRODUCT_AWARENESS_USAGE',
  'campaignTypeCode': '041'
}, {
  'name': 'BLUE BOX/Enterprise',
  'code': '043',
  'codeName': 'CST_BLUE_BOX',
  'campaignTypeCode': '043'
}, {
  'name': 'Card Benefits/Awareness',
  'code': '041',
  'codeName': 'CST_CARD_BENEFITS',
  'campaignTypeCode': '043'
}, {
  'name': 'Early Engagement',
  'code': '041',
  'codeName': 'CST_EARLY_ENGAGEMENT',
  'campaignTypeCode': '043'
}, {
  'name': 'Opt-in Alerts',
  'code': '041',
  'codeName': 'CST_OPT_IN_ALERTS',
  'campaignTypeCode': '043'
}, {
  'name': 'RETENTION',
  'code': '041',
  'codeName': 'CST_RETENTION',
  'campaignTypeCode': '043'
}, {
  'name': 'ACCOUNT ALERTS',
  'code': '048',
  'codeName': 'CST_ACCOUNT_ALERTS',
  'campaignTypeCode': '048'
}, {
  'name': 'Amex Mobile',
  'code': '049',
  'codeName': 'CST_AMEX_MOBILE',
  'campaignTypeCode': '048'
}, {
  'name': 'AUTHORIZED ACCESS',
  'code': '050',
  'codeName': 'CST_AUTH_ACCESS',
  'campaignTypeCode': '048'
}, {
  'name': 'AutoPay',
  'code': '051',
  'codeName': 'CST_AUTO_PAY',
  'campaignTypeCode': '048'
}, {
  'name': 'MYCA ENROLL',
  'code': '052',
  'codeName': 'CST_MYCA_ENROLL',
  'campaignTypeCode': '048'
}, {
  'name': 'Paper-off',
  'code': '053',
  'codeName': 'CST_PAPER_OFF',
  'campaignTypeCode': '048'
}, {
  'name': 'Pay by Computer',
  'code': '054',
  'codeName': 'CST_PAY_BY_PC',
  'campaignTypeCode': '048'
}, {
  'name': 'Text My Amex',
  'code': '055',
  'codeName': 'CST_TEXT_MY_AMEX',
  'campaignTypeCode': '048'
}, {
  'name': 'Incentive/Spend Accelerator',
  'code': '057',
  'codeName': 'CST_INCENTIVE',
  'campaignTypeCode': '057'
}, {
  'name': 'Partner/Merchant Promotion',
  'code': '058',
  'codeName': 'CST_PARTNER',
  'campaignTypeCode': '057'
}, {
  'name': 'RECUR PAY',
  'code': '059',
  'codeName': 'CST_RECUR_PAY',
  'campaignTypeCode': '057'
}, {
  'name': 'Publishing',
  'code': '060',
  'codeName': 'CST_PUBLISHING',
  'campaignTypeCode': '060'
}, {
  'name': 'BLUE BOX/Enterprise',
  'code': '062',
  'codeName': 'CST_BLUE_BOX',
  'campaignTypeCode': '062'
}, {
  'name': 'CCSG',
  'code': '063',
  'codeName': 'CST_CCSG',
  'campaignTypeCode': '062'
}, {
  'name': 'CTN',
  'code': '064',
  'codeName': 'CST_CTN',
  'campaignTypeCode': '062'
}, {
  'name': 'GCC',
  'code': '065',
  'codeName': 'CST_GCC',
  'campaignTypeCode': '062'
}, {
  'name': 'Merchant Services',
  'code': '066',
  'codeName': 'CST_MERCHANT_SERVICES',
  'campaignTypeCode': '062'
}, {
  'name': 'OPEN',
  'code': '067',
  'codeName': 'CST_OPEN',
  'campaignTypeCode': '062'
}, {
  'name': 'CLOSED',
  'code': '068',
  'codeName': 'CST_CLOSED',
  'campaignTypeCode': '062'
}]);
db.attachmentType.insert([{
  'code': '001',
  'codeName': 'attachment_mock',
  'name': 'Initial Draft',
  'emailTypeCodes': ['012', '008', '006','013']
}, {
  'code': '002',
  'codeName': 'text_version',
  'name': 'Text Version',
  'emailTypeCodes': ['012', '008', '006','013']
}, {
  'code': '003',
  'codeName': 'html_version',
  'name': 'HTML Version',
  'emailTypeCodes': ['012', '008', '006','013']
}, {
  'code': '004',
  'codeName': 'creative_governance',
  'name': 'Creative Governance',
  'emailTypeCodes': ['008', '006','013']
}, {
  'code': '005',
  'codeName': 'images',
  'name': 'Images',
  'emailTypeCodes': ['012', '008', '006','013']
}, {
  'code': '006',
  'codeName': 'final_creative_preview',
  'name': 'Final Creative Preview',
  'emailTypeCodes': ['012', '008', '006','013']
}, {
  'code': '008',
  'codeName': 'other',
  'name': 'Other',
  'emailTypeCodes': ['012', '008', '006','013']
}, {
  'code': '007',
  'codeName': 'rasc',
  'name': 'RASC Approval',
  'emailTypeCodes': ['012']
}]);

db.campaignState.insert([{
  'code': 'RPG',
  'codeName': 'draft',
  'name': 'Initiated',
  'logDisplayName': 'Initiated'
}, {
  'code': 'RID',
  'codeName': 'submitted4approval',
  'name': 'Campaign Requested',
  'logDisplayName': 'Pending Initial Approval'
}, {
  'code': 'RIA',
  'codeName': 'approved',
  'name': 'Request Approved',
  'logDisplayName': 'Request Approved'
}, {
  'code': 'RPS',
  'codeName': 'ewt2Save',
  'name': 'In Progress',
  'logDisplayName': 'In Progress'
}, {
  'code': 'AVF',
  'codeName': 'revisionRequired',
  'name': 'Revisions Required',
  'logDisplayName': 'Revisions Required'
}, {
  'code': 'ACD',
  'codeName': 'declined',
  'name': 'Request Declined',
  'logDisplayName': 'Request Declined'
}, {
  'code': 'AID',
  'codeName': 'submitted2admin',
  'name': 'Pending Final Approval',
  'logDisplayName': 'Pending Final Approval'
}, {
  'code': 'AVN',
  'codeName': 'submitted2esp',
  'name': 'Submitted to ESP',
  'logDisplayName': 'Submitted to ESP'
}, {
  'code': 'RBM',
  'codeName': 'rollBack2Manager',
  'name': 'Campaign Rolled Back',
  'logDisplayName': 'Rollback to Manager'
}, {
  'code': 'CBM',
  'codeName': 'cancelled',
  'name': 'Cancelled ',
  'logDisplayName': 'Cancelled'
}, {
  'code': 'QUE',
  'codeName': 'queued2esp',
  'name': 'Queued For ESP Submission',
  'logDisplayName': 'Queued For ESP Submission'
}]);
db.pznField.insert([{
  'code': 'CMFirstName',
  'codeName': 'cmFirst',
  'name': 'CM First Name',
  'description': 'CM First Name',
  'reserved': true
}, {
  'code': 'CMMemberSinceDate',
  'codeName': 'cmMember',
  'name': 'CM Member Since Date',
  'description': 'CM Member Since Date',
  'reserved': true
}, {
  'code': 'CMCardProduct',
  'codeName': 'cmCardProd',
  'name': 'CM Card Product',
  'description': 'CM Card Product',
  'reserved': true
}, {
  'code': 'DCEReserved1',
  'codeName': 'dceRese1',
  'name': 'DCE Reserved 1',
  'description': 'DCE Reserved',
  'reserved': true
}, {
  'code': 'DCEReserved2',
  'codeName': 'dceRese2',
  'name': 'DCE Reserved 2',
  'description': 'DCE Reserved',
  'reserved': true
}, {
  'code': 'pzn1',
  'codeName': 'pzn01',
  'name': 'PZN 1',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn2',
  'codeName': 'pzn02',
  'name': 'PZN 2',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn3',
  'codeName': 'pzn03',
  'name': 'PZN 3',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn4',
  'codeName': 'pzn04',
  'name': 'PZN 4',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn5',
  'codeName': 'pzn05',
  'name': 'PZN 5',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn6',
  'codeName': 'pzn06',
  'name': 'PZN 6',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn7',
  'codeName': 'pzn07',
  'name': 'PZN 7',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn8',
  'codeName': 'pzn08',
  'name': 'PZN 8',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn9',
  'codeName': 'pzn09',
  'name': 'PZN 9',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn10',
  'codeName': 'pzn10',
  'name': 'PZN 10',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn11',
  'codeName': 'pzn11',
  'name': 'PZN 11',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn12',
  'codeName': 'pzn12',
  'name': 'PZN 12',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn13',
  'codeName': 'pzn13',
  'name': 'PZN 13',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn14',
  'codeName': 'pzn14',
  'name': 'PZN 14',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn15',
  'codeName': 'pzn15',
  'name': 'PZN 15',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn16',
  'codeName': 'pzn16',
  'name': 'PZN 16',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn17',
  'codeName': 'pzn17',
  'name': 'PZN 17',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn18',
  'codeName': 'pzn18',
  'name': 'PZN 18',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn19',
  'codeName': 'pzn19',
  'name': 'PZN 19',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn20',
  'codeName': 'pzn20',
  'name': 'PZN 20',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn21',
  'codeName': 'pzn21',
  'name': 'PZN 21',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn22',
  'codeName': 'pzn22',
  'name': 'PZN 22',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn23',
  'codeName': 'pzn23',
  'name': 'PZN 23',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn24',
  'codeName': 'pzn24',
  'name': 'PZN 24',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn25',
  'codeName': 'pzn25',
  'name': 'PZN 25',
  'description': '',
  'reserved': false
}]);

db.userRole.insert([{
  'code': '001',
  'codeName': 'mm',
  'name': 'Marketing Manager'
}, {
  'code': '002',
  'codeName': 'axpi',
  'name': 'DCE Admin'
}, {
  'code': '003',
  'codeName': 'tech',
  'name': 'Tech Support'
}]);

db.userStatus.insert([{
  'code': '001',
  'codeName': 'active',
  'name': 'Active'
}, {
  'code': '002',
  'codeName': 'inactive',
  'name': 'Inactive'
}, {
  'code': '003',
  'codeName': 'reactive',
  'name': 'Active'
}]);

db.user.insert([{
  'uid': 'cseba1',
  'value': 'cseba1',
  'phone': '212-640-5091',
  'email': 'Cassandra.J.SebastianPernia@aexp.com',
  'name': 'Cassandra J SebastianPernia',
  'firstName': 'Cassandra J',
  'lastName': 'SebastianPernia',
  'role': {
    'code': '001',
    'codeName': 'mm',
    'name': 'manager'
  },
  'businessUnit': {
    'codeName': 'BU_EGG',
    'code': 'U023',
    'name': 'Enterprise Growth Group (EGG)',
  },
  'status': {
    'name': 'Active',
    'codeName': 'active',
    'code': '001'
  },
  'markAsDeleted': false,
  'createdOn': new Date()
}, {
  'uid': 'avargh3',
  'value': 'avargh3',
  'phone': '212-624-9842',
  'email': 'alfred.t.varghese@aexp.com',
  'name': 'Alfred T arghese',
  'firstName': 'Alfred T',
  'lastName': 'arghese',
  'role': {
    'code': '001',
    'codeName': 'mm',
    'name': 'manager'
  },
  'businessUnit': {
    'codeName': 'BU_EGG',
    'code': 'U023',
    'name': 'Enterprise Growth Group (EGG)',
  },
  'status': {
    'name': 'Active',
    'codeName': 'active',
    'code': '001'
  },
  'markAsDeleted': false,
  'createdOn': new Date()
}, {
  'uid': 'jaortiz',
  'value': 'jaortiz',
  'phone': '212-640-7898',
  'email': 'Jessica.A.Ortiz@aexp.com',
  'name': 'Jessica A Ortiz',
  'firstName': 'Jessica A',
  'lastName': 'Ortiz',
  'role': {
    'code': '001',
    'codeName': 'mm',
    'name': 'manager'
  },
  'businessUnit': {
    'codeName': 'BU_EGG',
    'code': 'U023',
    'name': 'Enterprise Growth Group (EGG)',
  },
  'status': {
    'name': 'Active',
    'codeName': 'active',
    'code': '001'
  },
  'markAsDeleted': false,
  'createdOn': new Date()
}, {
  'uid': 'knapoli',
  'value': 'knapoli',
  'phone': '212-640-5004',
  'email': 'Kayla.Napoli@aexp.com',
  'name': 'Kayla Napoli',
  'firstName': 'Kayla',
  'lastName': 'Napoli',
  'role': {
    'code': '001',
    'codeName': 'mm',
    'name': 'manager'
  },
  'businessUnit': {
    'codeName': 'BU_EGG',
    'code': 'U023',
    'name': 'Enterprise Growth Group (EGG)',
  },
  'status': {
    'name': 'Active',
    'codeName': 'active',
    'code': '001'
  },
  'markAsDeleted': false,
  'createdOn': new Date()
}, {
  'uid': 'azelenet',
  'value': 'azelenet',
  'phone': '212-640-3301',
  'email': 'Andrea.L.Zelenetz1@aexp.com',
  'name': 'Andrea L Zelenetz',
  'firstName': 'Andrea L',
  'lastName': 'Zelenetz',
  'role': {
    'code': '001',
    'codeName': 'mm',
    'name': 'manager'
  },
  'businessUnit': {
    'codeName': 'BU_EGG',
    'code': 'U023',
    'name': 'Enterprise Growth Group (EGG)',
  },
  'status': {
    'name': 'Active',
    'codeName': 'active',
    'code': '001'
  },
  'markAsDeleted': false,
  'createdOn': new Date()
}, {
  'uid': 'sguggino',
  'value': 'sguggino',
  'phone': '505-239-6368',
  'email': 'Sarah.E.Guggino@aexp.com',
  'name': 'Sarah E Guggino',
  'firstName': 'Sarah E',
  'lastName': 'Guggino',
  'role': {
    'code': '001',
    'codeName': 'mm',
    'name': 'manager'
  },
  'businessUnit': {
    'codeName': 'BU_EGG',
    'code': 'U023',
    'name': 'Enterprise Growth Group (EGG)',
  },
  'status': {
    'name': 'Active',
    'codeName': 'active',
    'code': '001'
  },
  'markAsDeleted': false,
  'createdOn': new Date()
}, {
  'uid': 'mjones32',
  'value': 'mjones32',
  'phone': '602-537-8954',
  'email': 'matthew.r.jones@aexp.com',
  'name': 'Matthew R Jones',
  'firstName': 'Matthew R',
  'lastName': 'Jones',
  'role': {
    'code': '001',
    'codeName': 'mm',
    'name': 'manager'
  },
  'businessUnit': {
    'codeName': 'BU_EGG',
    'code': 'U023',
    'name': 'Enterprise Growth Group (EGG)',
  },
  'status': {
    'name': 'Active',
    'codeName': 'active',
    'code': '001'
  },
  'markAsDeleted': false,
  'createdOn': new Date()
}, {
  'uid': 'cblan3',
  'value': 'cblan3',
  'phone': '602-537-8954',
  'email': 'CLARISSA.BLANCO@aexp.com',
  'name': 'CLARISSA BLANCO',
  'firstName': 'CLARISSA',
  'lastName': 'BLANCO',
  'role': {
    'code': '001',
    'codeName': 'mm',
    'name': 'manager'
  },
  'businessUnit': {
    'codeName': 'BU_EGG',
    'code': 'U023',
    'name': 'Enterprise Growth Group (EGG)',
  },
  'status': {
    'name': 'Active',
    'codeName': 'active',
    'code': '001'
  },
  'markAsDeleted': false,
  'createdOn': new Date()
}, {
  'uid': 'rallenii',
  'value': 'rallenii',
  'phone': '212-640-6980',
  'email': 'Richard.L.AllenIII@aexp.com',
  'name': 'Richard L Allen',
  'firstName': 'Richard L',
  'lastName': 'Allen',
  'role': {
    'code': '002',
    'codeName': 'axpi',
    'name': 'admin'
  },
  'businessUnit': {
    'codeName': 'BU_EGG',
    'code': 'U023',
    'name': 'Enterprise Growth Group (EGG)',
  },
  'status': {
    'name': 'Active',
    'codeName': 'active',
    'code': '001'
  },
  'markAsDeleted': false,
  'createdOn': new Date()
}, {
  'uid': 'wliu17',
  'value': 'wliu17',
  'phone': '212-640-7128',
  'email': 'William.Liu1@aexp.com',
  'name': 'William Liu',
  'firstName': 'William',
  'lastName': 'Liu',
  'role': {
    'code': '002',
    'codeName': 'axpi',
    'name': 'admin'
  },
  'businessUnit': {
    'codeName': 'BU_EGG',
    'code': 'U023',
    'name': 'Enterprise Growth Group (EGG)',
  },
  'status': {
    'name': 'Active',
    'codeName': 'active',
    'code': '001'
  },
  'markAsDeleted': false,
  'createdOn': new Date()
}, {
  'uid': 'lmacphe',
  'value': 'lmacphe',
  'phone': '602-537-8954',
  'email': 'Linsey.A.Macpherson@aexp.com',
  'name': 'Linsey A Macpherson',
  'firstName': 'Linsey A',
  'lastName': 'Macpherson',
  'role': {
    'code': '002',
    'codeName': 'axpi',
    'name': 'admin'
  },
  'businessUnit': {
    'codeName': 'BU_EGG',
    'code': 'U023',
    'name': 'Enterprise Growth Group (EGG)',
  },
  'status': {
    'name': 'Active',
    'codeName': 'active',
    'code': '001'
  },
  'markAsDeleted': false,
  'createdOn': new Date()
}, {
  'uid': 'nvishw',
  'value': 'nvishw',
  'phone': '312-624-9864',
  'email': 'Nagabhushan.a.andrew1@aexp.com',
  'name': 'Nagabhushan B Vishwanath',
  'firstName': 'Nagabhushan B',
  'lastName': 'Vishwanath',
  'role': {
    'code': '001',
    'codeName': 'mm',
    'name': 'manager'
  },
  'businessUnit': {
    'codeName': 'BU_EGG',
    'code': 'U023',
    'name': 'Enterprise Growth Group (EGG)',
  },
  'status': {
    'name': 'Active',
    'codeName': 'active',
    'code': '001'
  },
  'markAsDeleted': false,
  'createdOn': new Date()
}, {
  'uid': 'randrew',
  'value': 'randrew',
  'phone': '212-624-9822',
  'email': 'roopa.a.andrew1@aexp.com',
  'name': 'Roopa Andrew',
  'firstName': 'Roopa',
  'lastName': 'Andrew',
  'role': {
    'code': '001',
    'codeName': 'mm',
    'name': 'manager'
  },
  'businessUnit': {
    'codeName': 'BU_EGG',
    'code': 'U023',
    'name': 'Enterprise Growth Group (EGG)',
  },
  'status': {
    'name': 'Active',
    'codeName': 'active',
    'code': '001'
  },
  'markAsDeleted': false,
  'createdOn': new Date()
}, {
  'uid': 'avarghes',
  'value': 'avarghes',
  'phone': '212-624-9842',
  'email': 'alfred.t.varghese@aexp.com',
  'name': 'Alfred T arghese',
  'firstName': 'Alfred T',
  'lastName': 'arghese',
  'role': {
    'code': '001',
    'codeName': 'axpi',
    'name': 'admin'
  },
  'businessUnit': {
    'codeName': 'BU_EGG',
    'code': 'U023',
    'name': 'Enterprise Growth Group (EGG)',
  },
  'status': {
    'name': 'Active',
    'codeName': 'active',
    'code': '001'
  },
  'markAsDeleted': false,
  'createdOn': new Date()
}]);
db.cellType.insert([{
  'code': 'T',
  'codeName': 'test',
  'name': 'Mailable (Test)'
}, {
  'code': 'C',
  'codeName': 'control',
  'name': 'Holdout (Control)'
}]);

db.cardMemberNeedCategory.dropIndex({
  "code": 1,
  "granularOptOutCode": 1,
  "businessUnitCode": 1
});

db.cardMemberNeedCategory.insert([{
  'code': 'CMNC03',
  'granularOptOutCode': 'MKTRVL',
  'businessUnitCode': 'U007',
  'name': 'Benefits and Rewards - Travel',
  'oneoffDeploymentWeek': 3,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC04',
  'granularOptOutCode': 'MKSHOP',
  'businessUnitCode': 'U007',
  'name': 'Benefits and Rewards - Shopping & Retail',
  'oneoffDeploymentWeek': 3,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC05',
  'granularOptOutCode': 'MKDENT',
  'businessUnitCode': 'U007',
  'name': 'Benefits and Rewards - Dining & Entertainment',
  'oneoffDeploymentWeek': 3,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC06',
  'granularOptOutCode': 'MKOTHR',
  'businessUnitCode': 'U007',
  'name': 'Benefits and Rewards - Other Spend',
  'oneoffDeploymentWeek': 3,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC07',
  'granularOptOutCode': 'MKCBEN',
  'businessUnitCode': 'U007',
  'name': 'Benefits and Rewards - Benefit awareness',
  'oneoffDeploymentWeek': 3,
  'oneoffDeploymentDay': 0
}, { // TO DO Clarification
  'code': 'CMNC12',
  'granularOptOutCode': 'MKCORP',
  'businessUnitCode': 'U006',
  'name': 'Corporate Offers',
  'oneoffDeploymentWeek': 1,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC03',
  'granularOptOutCode': 'MKTRVL',
  'businessUnitCode': 'U005',
  'name': 'Benefits and Rewards - Travel',
  'oneoffDeploymentWeek': 1,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC04',
  'granularOptOutCode': 'MKSHOP',
  'businessUnitCode': 'U005',
  'name': 'Benefits and Rewards - Shopping & Retail',
  'oneoffDeploymentWeek': 1,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC05',
  'granularOptOutCode': 'MKDENT',
  'businessUnitCode': 'U005',
  'name': 'Benefits and Rewards - Dining & Entertainment',
  'oneoffDeploymentWeek': 1,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC06',
  'granularOptOutCode': 'MKOTHR',
  'businessUnitCode': 'U005',
  'name': 'Benefits and Rewards - Other Spend',
  'oneoffDeploymentWeek': 1,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC07',
  'granularOptOutCode': 'MKCBEN',
  'businessUnitCode': 'U005',
  'name': 'Benefits and Rewards - Benefit awareness',
  'oneoffDeploymentWeek': 1,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC01',
  'granularOptOutCode': 'MKACQU',
  'businessUnitCode': 'U005',
  'name': 'Card & Credit',
  'oneoffDeploymentWeek': 4,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC03',
  'granularOptOutCode': 'MKTRVL',
  'businessUnitCode': 'U004',
  'name': 'Benefits and Rewards - Travel',
  'oneoffDeploymentWeek': 3,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC04',
  'granularOptOutCode': 'MKSHOP',
  'businessUnitCode': 'U004',
  'name': 'Benefits and Rewards - Shopping & Retail',
  'oneoffDeploymentWeek': 3,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC05',
  'granularOptOutCode': 'MKDENT',
  'businessUnitCode': 'U004',
  'name': 'Benefits and Rewards - Dining & Entertainment',
  'oneoffDeploymentWeek': 3,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC06',
  'granularOptOutCode': 'MKOTHR',
  'businessUnitCode': 'U004',
  'name': 'Benefits and Rewards - Other Spend',
  'oneoffDeploymentWeek': 3,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC07',
  'granularOptOutCode': 'MKCBEN',
  'businessUnitCode': 'U004',
  'name': 'Benefits and Rewards - Benefit awareness',
  'oneoffDeploymentWeek': 3,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC01',
  'granularOptOutCode': 'MKACQU',
  'businessUnitCode': 'U004',
  'name': 'Card & Credit',
  'oneoffDeploymentWeek': 1,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC08',
  'granularOptOutCode': 'MKPUBL',
  'businessUnitCode': 'U003',
  'name': 'Publications',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, { // TO DO -- Clarification -- not pressent
  'code': 'CMNC13',
  'granularOptOutCode': 'MKRESR',
  'businessUnitCode': 'U002',
  'name': 'Market Research Surveys',
  'oneoffDeploymentWeek': 1,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC09',
  'granularOptOutCode': 'MKGIFT',
  'businessUnitCode': 'U019',
  'name': 'Prepaid Financial Products',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC03',
  'granularOptOutCode': 'MKTRVL',
  'businessUnitCode': 'U018',
  'name': 'Benefits and Rewards - Travel',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC04',
  'granularOptOutCode': 'MKSHOP',
  'businessUnitCode': 'U018',
  'name': 'Benefits and Rewards - Shopping & Retail',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC05',
  'granularOptOutCode': 'MKDENT',
  'businessUnitCode': 'U018',
  'name': 'Benefits and Rewards - Dining & Entertainment',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC06',
  'granularOptOutCode': 'MKOTHR',
  'businessUnitCode': 'U018',
  'name': 'Benefits and Rewards - Other Spend',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC07',
  'granularOptOutCode': 'MKCBEN',
  'businessUnitCode': 'U018',
  'name': 'Benefits and Rewards - Benefit awareness',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, { // TO DO -- Not Pressent
  'code': 'CMNC11',
  'granularOptOutCode': 'MKCBEN',
  'businessUnitCode': 'U017',
  'name': 'Account Management',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC03',
  'granularOptOutCode': 'MKTRVL',
  'businessUnitCode': 'U020',
  'name': 'Benefits and Rewards - Travel',
  'oneoffDeploymentWeek': 4,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC04',
  'granularOptOutCode': 'MKSHOP',
  'businessUnitCode': 'U020',
  'name': 'Benefits and Rewards - Shopping & Retail',
  'oneoffDeploymentWeek': 4,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC05',
  'granularOptOutCode': 'MKDENT',
  'businessUnitCode': 'U020',
  'name': 'Benefits and Rewards - Dining & Entertainment',
  'oneoffDeploymentWeek': 4,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC06',
  'granularOptOutCode': 'MKOTHR',
  'businessUnitCode': 'U020',
  'name': 'Benefits and Rewards - Other Spend',
  'oneoffDeploymentWeek': 4,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC07',
  'granularOptOutCode': 'MKCBEN',
  'businessUnitCode': 'U020',
  'name': 'Benefits and Rewards - Benefit awareness',
  'oneoffDeploymentWeek': 4,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC02',
  'granularOptOutCode': 'MKCSER',
  'businessUnitCode': 'U021',
  'name': 'Protection & Insurance',
  'oneoffDeploymentWeek': 1,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC10',
  'granularOptOutCode': 'MKFINS',
  'businessUnitCode': 'U022',
  'name': 'Other banking products',
  'oneoffDeploymentWeek': 3,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC03',
  'granularOptOutCode': 'MKTRVL',
  'businessUnitCode': 'U023',
  'name': 'Benefits and Rewards - Travel',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC04',
  'granularOptOutCode': 'MKSHOP',
  'businessUnitCode': 'U023',
  'name': 'Benefits and Rewards - Shopping & Retail',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC05',
  'granularOptOutCode': 'MKDENT',
  'businessUnitCode': 'U023',
  'name': 'Benefits and Rewards - Dining & Entertainment',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC06',
  'granularOptOutCode': 'MKOTHR',
  'businessUnitCode': 'U023',
  'name': 'Benefits and Rewards - Other Spend',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC07',
  'granularOptOutCode': 'MKCBEN',
  'businessUnitCode': 'U023',
  'name': 'Benefits and Rewards - Benefit awareness',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC03',
  'granularOptOutCode': 'MKTRVL',
  'businessUnitCode': 'U024',
  'name': 'Benefits and Rewards - Travel',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC04',
  'granularOptOutCode': 'MKSHOP',
  'businessUnitCode': 'U024',
  'name': 'Benefits and Rewards - Shopping & Retail',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC05',
  'granularOptOutCode': 'MKDENT',
  'businessUnitCode': 'U024',
  'name': 'Benefits and Rewards - Dining & Entertainment',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC06',
  'granularOptOutCode': 'MKOTHR',
  'businessUnitCode': 'U024',
  'name': 'Benefits and Rewards - Other Spend',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC07',
  'granularOptOutCode': 'MKCBEN',
  'businessUnitCode': 'U024',
  'name': 'Benefits and Rewards - Benefit awareness',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC01',
  'granularOptOutCode': 'MKACQU',
  'businessUnitCode': 'U024',
  'name': 'Card & Credit',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}]);
db.cardMemberNeedCategory.ensureIndex({
  "code": 1,
  "granularOptOutCode": 1,
  "businessUnitCode": 1
});

db.CampaignDuration.insert([{
  'code': '01',
  'duration': '1 Week'
}, {
  'code': '02',
  'duration': '2 Weeks'
}, {
  'code': '03',
  'duration': '3 Weeks'
}, {
  'code': '04',
  'duration': '4 Weeks'
}, {
  'code': '05',
  'duration': '5 Weeks'
}, {
  'code': '06',
  'duration': '6 Weeks'
}, {
  'code': '07',
  'duration': '7 Weeks'
}, {
  'code': '08',
  'duration': '8 Weeks'
}, {
  'code': '09',
  'duration': '9 Weeks'
}, {
  'code': '10',
  'duration': '10 Weeks'
}, {
  'code': '11',
  'duration': '11 Weeks'
}, {
  'code': '12',
  'duration': '12 Weeks'
}, {
  'code': '13',
  'duration': '13 Weeks'
}, {
  'code': '14',
  'duration': '14 Weeks'
}, {
  'code': '15',
  'duration': '15 Weeks'
}, {
  'code': '16',
  'duration': '16 Weeks'
}, {
  'code': '17',
  'duration': '17 Weeks'
}, {
  'code': '18',
  'duration': '18 Weeks'
}, {
  'code': '19',
  'duration': '19 Weeks'
}, {
  'code': '20',
  'duration': '20 Weeks'
}, {
  'code': '21',
  'duration': '21 Weeks'
}, {
  'code': '22',
  'duration': '22 Weeks'
}, {
  'code': '23',
  'duration': '23 Weeks'
}, {
  'code': '24',
  'duration': '24 Weeks'
}, {
  'code': '25',
  'duration': '25 Weeks'
}, {
  'code': '26',
  'duration': '26 Weeks'
}, {
  'code': '27',
  'duration': '27 Weeks'
}, {
  'code': '28',
  'duration': '28 Weeks'
}, {
  'code': '29',
  'duration': '29 Weeks'
}, {
  'code': '30',
  'duration': '30 Weeks'
}, {
  'code': '31',
  'duration': '31 Weeks'
}, {
  'code': '32',
  'duration': '32 Weeks'
}, {
  'code': '33',
  'duration': '33 Weeks'
}, {
  'code': '34',
  'duration': '34 Weeks'
}, {
  'code': '35',
  'duration': '35 Weeks'
}, {
  'code': '36',
  'duration': '36 Weeks'
}, {
  'code': '37',
  'duration': '37 Weeks'
}, {
  'code': '38',
  'duration': '38 Weeks'
}, {
  'code': '39',
  'duration': '39 Weeks'
}, {
  'code': '40',
  'duration': '40 Weeks'
}, {
  'code': '41',
  'duration': '41 Weeks'
}, {
  'code': '42',
  'duration': '42 Weeks'
}, {
  'code': '43',
  'duration': '43 Weeks'
}, {
  'code': '44',
  'duration': '44 Weeks'
}, {
  'code': '45',
  'duration': '45 Weeks'
}, {
  'code': '46',
  'duration': '46 Weeks'
}, {
  'code': '47',
  'duration': '47 Weeks'
}, {
  'code': '48',
  'duration': '48 Weeks'
}, {
  'code': '49',
  'duration': '49 Weeks'
}, {
  'code': '50',
  'duration': '50 Weeks'
}, {
  'code': '51',
  'duration': '51 Weeks'
}, {
  'code': '52',
  'duration': '52 Weeks'
}]);
db.sequence.insert({
  'name': 'campaign',
  'sequence': 17500
});
