/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 (ERA) - This file implements the user controller at node end. It has all the action methods related to user controller
 */

'use strict';

var db = require('../../application/lib/db'),
  async = require('async'),
  asyncEach = require('async-each');

var userRoleRecords = [{
  "code": "001",
  "codeName": "mm",
  "name": "Marketing Manager"
}, {
  "code": "002",
  "codeName": "axpi",
  "name": "DCE Admin"
}, {
  "code": "003",
  "codeName": "tech",
  "name": "Tech Support"
}];

var attachmentTypeRecords = [{
  "code": "001",
  "codeName": "attachment_mock",
  "name": "Initial Draft",
  "emailTypeCodes": [
    "012",
    "008",
    "006"
  ]
}, {
  "code": "002",
  "codeName": "text_version",
  "name": "Text Version",
  "emailTypeCodes": [
    "012",
    "008",
    "006"
  ]
}, {
  "code": "003",
  "codeName": "html_version",
  "name": "HTML Version",
  "emailTypeCodes": [
    "012",
    "008",
    "006"
  ]
}, {
  "code": "004",
  "codeName": "creative_governance",
  "name": "Creative Governance",
  "emailTypeCodes": [
    "008",
    "006"
  ]
}, {
  "code": "005",
  "codeName": "images",
  "name": "Images",
  "emailTypeCodes": [
    "012",
    "008",
    "006"
  ]
}, {
  "code": "006",
  "codeName": "final_creative_preview",
  "name": "Final Creative Preview",
  "emailTypeCodes": [
    "012",
    "008",
    "006"
  ]
}, {
  "code": "008",
  "codeName": "other",
  "name": "Other",
  "emailTypeCodes": [
    "012",
    "008",
    "006"
  ]
}, {
  "code": "007",
  "codeName": "rasc",
  "name": "RASC Approval",
  "emailTypeCodes": [
    "012"
  ]
}];

var userStatusRecords = [{
  'code': '001',
  'codeName': 'active',
  'name': 'Active'
}, {
  'code': '002',
  'codeName': 'inactive',
  'name': 'Inactive'
}, {
  'code': '003',
  'codeName': 'reactive',
  'name': 'Active'
}];

var stoEventsToTrackRecords = [{
  "code": '1',
  "codeName": "OPN",
  "name": "OPEN"
}, {
  "code": '2',
  "codeName": "CLK",
  "name": "CLICK"
}];

var stoEmailTrackingTypesRecords = [{
  "code": '1',
  "codeName": "DAY_TIME",
  "name": "DAY & TIME"
}, {
  "code": '2',
  "codeName": "DAY",
  "name": "DAY"
}, {
  "code": '3',
  "codeName": "TIME",
  "name": "TIME"
}];

var dynamicCampaignRecords = [{
  "code": "D",
  "name": "Dynamic Email",
  "codeName": "DYNAMIC_EMIAL"
}, {
  "code": "L",
  "name": "Lending Awareness",
  "codeName": "LENDING_AWARENESS"
}, {
  "code": "N",
  "name": "Not Applicable",
  "codeName": "NOT_APPLICABLE"
}, {
  "code": "P",
  "name": "Pre-Sync",
  "codeName": "PRE_SYNC"
}, {
  "code": "1",
  "name": "Recommender All",
  "codeName": "RECOMMENDER_ALL"
}, {
  "code": "2",
  "name": "Recommender Spend Only",
  "codeName": "RECOMMENDER_SPEND_ONLY"
}, {
  "code": "3",
  "name": "Recommender New Merchant",
  "codeName": "RECOMMENDER_NEW_MERCHANT"
}, {
  "code": "A",
  "name": "AOR",
  "codeName": "AOR"
}, {
  "code": "E",
  "name": "AED",
  "codeName": "AED"
}, {
  "code": "W",
  "name": "Membership Rewards",
  "codeName": "MEMBERSHIP_REWARDS"
}, {
  "code": "M",
  "name": "Marketing API",
  "codeName": "MARKETING_API"
}];

var cardMemberNeedCategoryRecords = [{
  'code': 'CMNC03',
  'granularOptOutCode': 'MKTRVL',
  'businessUnitCode': 'U007',
  'name': 'Benefits and Rewards - Travel',
  'oneoffDeploymentWeek': 3,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC04',
  'granularOptOutCode': 'MKSHOP',
  'businessUnitCode': 'U007',
  'name': 'Benefits and Rewards - Shopping & Retail',
  'oneoffDeploymentWeek': 3,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC05',
  'granularOptOutCode': 'MKDENT',
  'businessUnitCode': 'U007',
  'name': 'Benefits and Rewards - Dining & Entertainment',
  'oneoffDeploymentWeek': 3,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC06',
  'granularOptOutCode': 'MKOTHR',
  'businessUnitCode': 'U007',
  'name': 'Benefits and Rewards - Other Spend',
  'oneoffDeploymentWeek': 3,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC07',
  'granularOptOutCode': 'MKCBEN',
  'businessUnitCode': 'U007',
  'name': 'Benefits and Rewards - Benefit awareness',
  'oneoffDeploymentWeek': 3,
  'oneoffDeploymentDay': 0
}, { // TO DO Clarification
  'code': 'CMNC12',
  'granularOptOutCode': 'MKCORP',
  'businessUnitCode': 'U006',
  'name': 'Corporate Offers',
  'oneoffDeploymentWeek': 1,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC03',
  'granularOptOutCode': 'MKTRVL',
  'businessUnitCode': 'U005',
  'name': 'Benefits and Rewards - Travel',
  'oneoffDeploymentWeek': 1,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC04',
  'granularOptOutCode': 'MKSHOP',
  'businessUnitCode': 'U005',
  'name': 'Benefits and Rewards - Shopping & Retail',
  'oneoffDeploymentWeek': 1,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC05',
  'granularOptOutCode': 'MKDENT',
  'businessUnitCode': 'U005',
  'name': 'Benefits and Rewards - Dining & Entertainment',
  'oneoffDeploymentWeek': 1,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC06',
  'granularOptOutCode': 'MKOTHR',
  'businessUnitCode': 'U005',
  'name': 'Benefits and Rewards - Other Spend',
  'oneoffDeploymentWeek': 1,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC07',
  'granularOptOutCode': 'MKCBEN',
  'businessUnitCode': 'U005',
  'name': 'Benefits and Rewards - Benefit awareness',
  'oneoffDeploymentWeek': 1,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC01',
  'granularOptOutCode': 'MKACQU',
  'businessUnitCode': 'U005',
  'name': 'Card & Credit',
  'oneoffDeploymentWeek': 4,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC03',
  'granularOptOutCode': 'MKTRVL',
  'businessUnitCode': 'U004',
  'name': 'Benefits and Rewards - Travel',
  'oneoffDeploymentWeek': 3,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC04',
  'granularOptOutCode': 'MKSHOP',
  'businessUnitCode': 'U004',
  'name': 'Benefits and Rewards - Shopping & Retail',
  'oneoffDeploymentWeek': 3,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC05',
  'granularOptOutCode': 'MKDENT',
  'businessUnitCode': 'U004',
  'name': 'Benefits and Rewards - Dining & Entertainment',
  'oneoffDeploymentWeek': 3,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC06',
  'granularOptOutCode': 'MKOTHR',
  'businessUnitCode': 'U004',
  'name': 'Benefits and Rewards - Other Spend',
  'oneoffDeploymentWeek': 3,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC07',
  'granularOptOutCode': 'MKCBEN',
  'businessUnitCode': 'U004',
  'name': 'Benefits and Rewards - Benefit awareness',
  'oneoffDeploymentWeek': 3,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC01',
  'granularOptOutCode': 'MKACQU',
  'businessUnitCode': 'U004',
  'name': 'Card & Credit',
  'oneoffDeploymentWeek': 1,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC08',
  'granularOptOutCode': 'MKPUBL',
  'businessUnitCode': 'U003',
  'name': 'Publications',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, { // TO DO -- Clarification -- not pressent
  'code': 'CMNC13',
  'granularOptOutCode': 'MKRESR',
  'businessUnitCode': 'U002',
  'name': 'Market Research Surveys',
  'oneoffDeploymentWeek': 1,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC09',
  'granularOptOutCode': 'MKGIFT',
  'businessUnitCode': 'U019',
  'name': 'Prepaid Financial Products',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC03',
  'granularOptOutCode': 'MKTRVL',
  'businessUnitCode': 'U018',
  'name': 'Benefits and Rewards - Travel',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC04',
  'granularOptOutCode': 'MKSHOP',
  'businessUnitCode': 'U018',
  'name': 'Benefits and Rewards - Shopping & Retail',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC05',
  'granularOptOutCode': 'MKDENT',
  'businessUnitCode': 'U018',
  'name': 'Benefits and Rewards - Dining & Entertainment',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC06',
  'granularOptOutCode': 'MKOTHR',
  'businessUnitCode': 'U018',
  'name': 'Benefits and Rewards - Other Spend',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC07',
  'granularOptOutCode': 'MKCBEN',
  'businessUnitCode': 'U018',
  'name': 'Benefits and Rewards - Benefit awareness',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, { // TO DO -- Not Pressent
  'code': 'CMNC11',
  'granularOptOutCode': 'MKCBEN',
  'businessUnitCode': 'U017',
  'name': 'Account Management',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC03',
  'granularOptOutCode': 'MKTRVL',
  'businessUnitCode': 'U020',
  'name': 'Benefits and Rewards - Travel',
  'oneoffDeploymentWeek': 4,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC04',
  'granularOptOutCode': 'MKSHOP',
  'businessUnitCode': 'U020',
  'name': 'Benefits and Rewards - Shopping & Retail',
  'oneoffDeploymentWeek': 4,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC05',
  'granularOptOutCode': 'MKDENT',
  'businessUnitCode': 'U020',
  'name': 'Benefits and Rewards - Dining & Entertainment',
  'oneoffDeploymentWeek': 4,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC06',
  'granularOptOutCode': 'MKOTHR',
  'businessUnitCode': 'U020',
  'name': 'Benefits and Rewards - Other Spend',
  'oneoffDeploymentWeek': 4,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC07',
  'granularOptOutCode': 'MKCBEN',
  'businessUnitCode': 'U020',
  'name': 'Benefits and Rewards - Benefit awareness',
  'oneoffDeploymentWeek': 4,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC02',
  'granularOptOutCode': 'MKCSER',
  'businessUnitCode': 'U021',
  'name': 'Protection & Insurance',
  'oneoffDeploymentWeek': 1,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC10',
  'granularOptOutCode': 'MKFINS',
  'businessUnitCode': 'U022',
  'name': 'Other banking products',
  'oneoffDeploymentWeek': 3,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC03',
  'granularOptOutCode': 'MKTRVL',
  'businessUnitCode': 'U023',
  'name': 'Benefits and Rewards - Travel',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC04',
  'granularOptOutCode': 'MKSHOP',
  'businessUnitCode': 'U023',
  'name': 'Benefits and Rewards - Shopping & Retail',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC05',
  'granularOptOutCode': 'MKDENT',
  'businessUnitCode': 'U023',
  'name': 'Benefits and Rewards - Dining & Entertainment',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC06',
  'granularOptOutCode': 'MKOTHR',
  'businessUnitCode': 'U023',
  'name': 'Benefits and Rewards - Other Spend',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC07',
  'granularOptOutCode': 'MKCBEN',
  'businessUnitCode': 'U023',
  'name': 'Benefits and Rewards - Benefit awareness',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC03',
  'granularOptOutCode': 'MKTRVL',
  'businessUnitCode': 'U024',
  'name': 'Benefits and Rewards - Travel',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC04',
  'granularOptOutCode': 'MKSHOP',
  'businessUnitCode': 'U024',
  'name': 'Benefits and Rewards - Shopping & Retail',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC05',
  'granularOptOutCode': 'MKDENT',
  'businessUnitCode': 'U024',
  'name': 'Benefits and Rewards - Dining & Entertainment',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC06',
  'granularOptOutCode': 'MKOTHR',
  'businessUnitCode': 'U024',
  'name': 'Benefits and Rewards - Other Spend',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC07',
  'granularOptOutCode': 'MKCBEN',
  'businessUnitCode': 'U024',
  'name': 'Benefits and Rewards - Benefit awareness',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}, {
  'code': 'CMNC01',
  'granularOptOutCode': 'MKACQU',
  'businessUnitCode': 'U024',
  'name': 'Card & Credit',
  'oneoffDeploymentWeek': 2,
  'oneoffDeploymentDay': 0
}];

function resetCollection(collectionName, data, cb) {
  var CollectionClass = db[collectionName + 'Class']();
  CollectionClass.remove({}, function(err) {
    if (err) {
      console.log('FAIL: Error in removing all records from dynamicCampaigns collection.');
      return cb(err);
    }

    asyncEach(data, function(obj, asynCb) {
      var record = new CollectionClass(obj);
      record.save(function(err) {
        if (err) {
          console.log('FAILED while resetting "' + collectionName + '" collection. Error: ' + err);
        }
        return asynCb(err);
      });
    }, function(err) {
      if (err) {
        console.log('FAIL: Error occured while adding records to ' + collectionName + ' collection.')
        return cb(err);
      } else {
        CollectionClass.find({}, function(err, records) {
          console.log('Total records in ' + collectionName + ' collection: ' + records.length);
          console.log('SUCCESS: Added records to ' + collectionName + ' collection');
          return cb(err);
        });
      }
    });
  });
}

function insertOneOffEmailType(cb) {
  var EmailTypeClass = db.emailTypeClass();
  EmailTypeClass.findOne({
    codeName: 'ET_ONEOFF'
  }, function(err, emailType) {
    if (err) {
      console.log('FAIL: Error occured while looking for One-off email type in DB');
      return cb(err);
    }
    if (emailType && emailType.codeName) {
      return cb();
    }
    var oneOffEmailType = new EmailTypeClass({
      "code": "006",
      "name": "One off",
      "codeName": "ET_ONEOFF"
    });
    oneOffEmailType.save(function(err) {
      if (err) {
        console.log('FAIL: Could not add One-Off as one of the email types.');
      } else {
        console.log('SUCCESS: Added One-Off as one of the email types.');
      }
      return cb(err);
    });
  });
}

// function changeEGG2PAP(cb) {
//   var BusinessUnitClass = db.businessUnitClass();
//   BusinessUnitClass.findOne({
//     code: 'U023'
//   }, function(err, bu) {
//     if (err) {
//       console.log('FAIL: Error occured while looking for EGG BU in DB');
//       return cb(err);
//     }
//     if (bu && bu.code) {
//       bu.name = 'Prepaid & Alternative Payments';
//       bu.save(function(err) {
//         if (err) {
//           console.log('FAIL: Could not update the BU from EGG to PAP.');
//         } else {
//           console.log('SUCCESS: BU updated successfully from EGG to PAP.');
//         }
//         return cb(err);
//       });
//     } else {
//       console.log('FAIL: Could not find EGG BU in DB.');
//       return cb(err);
//     }
//   });
// }

function changeAxpi2DCE(cb) {
  var BusinessUnitClass = db.businessUnitClass();
  BusinessUnitClass.findOne({
    code: 'U017'
  }, function(err, bu) {
    if (err) {
      console.log('FAIL: Error occured while looking for Axpi BU in DB');
      return cb(err);
    }
    if (bu && bu.code) {
      bu.name = 'DCE';
      bu.save(function(err) {
        if (err) {
          console.log('FAIL: Could not update the BU from Axpi BU to DCE in DB.');
        } else {
          console.log('SUCCESS: BU updated successfully from Axpi to DCE in DB.');
        }
        return cb(err);
      });
    } else {
      console.log('FAIL : Could not find Axpi BU in DB');
      return cb(err);
    }
  })
};

module.exports = {
  runPatch: function(patchCallback) {
    console.log('=========== Starting: Add master records Patch ==============');
    console.log('Patch Description: This patch will ensure add wipe out the existing records (if any) and will add new records to userStatus DB collection.');

    async.parallel([function(cb) {
      return resetCollection('attachmentType', attachmentTypeRecords, cb);
    }, function(cb) {
      return resetCollection('userRole', userRoleRecords, cb);
    }, function(cb) {
      return resetCollection('userStatus', userStatusRecords, cb);
    }, function(cb) {
      return resetCollection('stoEventsToTrack', stoEventsToTrackRecords, cb);
    }, function(cb) {
      return resetCollection('stoEmailTrackingTypes', stoEmailTrackingTypesRecords, cb);
    }, function(cb) {
      return resetCollection('dynamicCampaign', dynamicCampaignRecords, cb);
    }, function(cb) {
      return resetCollection('cmNeedCategory', cardMemberNeedCategoryRecords, cb);
    }, function(cb) {
      return insertOneOffEmailType(cb);
    }, function(cb) {
      //   return changeEGG2PAP(cb);
      // }, function(cb) {
      return changeAxpi2DCE(cb);
    }], function(err) {
      console.log('=========== Ending: Add master records Patch ==============');
      return patchCallback(err);
    });
  }
}
