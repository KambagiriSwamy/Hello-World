/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 (ERA) - This file implements the user controller at node end. It has all the action methods related to user controller
 */

'use strict';

var db = require('../../application/lib/db'),
  asyncEach = require('async-each'),
  utils = require('../../application/lib/utils.js'),
  ecpUtils = require('../../application/lib/ecp-utils.js'),
  async = require('async'),
  buArr = {};

function getBU(filter, cb) {
  var BusinessUnit = db.businessUnitClass();

  BusinessUnit.findOne(filter, function(err, bu) {
    if (err) {
      console.log('Error occured while reteriving BU with code ' + filter.code + ' from DB');
      return cb(err);
    }
    if (!bu) {
      err = 'Could not find the BU with code ' + filter.code + ' from DB';
      console.log(err);
      return cb(err);
    }
    buArr[filter.code] = bu;
    return cb();
  });
}


function updateCampaigns(cb) {
  var Campaign = db.campaignClass(),
    campaignsWithErrors = '';

  Campaign.find({}, function(err, campaigns) {
    if (err) {
      cb('Unable to fetch campaigns from database');
    }

    asyncEach(campaigns, function(campaign, asyncCb) {
      if (!(campaign.createdOn)) {
        var creationDate = new Date(campaign._id.getTimestamp());
        campaign.createdOn = utils.formatDate((creationDate.getMonth() + 1) + '/' + creationDate.getDate() + '/' + creationDate.getFullYear());
        console.log('SUCCESS: createdOn attribute set for campaign with ID: ' + campaign.requestID);
      }
      if (campaign.businessUnit && (campaign.businessUnit.code === 'U017')) {
        if (buArr['U017']) {
          campaign.businessUnit = buArr['U017'];
          console.log('SUCCESS: BU changed from Axpi to DCE for campaign with ID: ' + campaign.requestID);
        } else {
          console.log('FAIL: Could not find BU with code as U017');
        }
      }
      if (campaign.businessUnit && (campaign.businessUnit.code === 'U023')) {
        if (buArr['U023']) {
          campaign.businessUnit = buArr['U023'];
          console.log('SUCCESS: BU changed from Axpi to DCE for campaign with ID: ' + campaign.requestID);
        } else {
          console.log('FAIL: Could not find BU with code as U023');
        }
      }
      if (!(campaign.endDate) && campaign.emailType) {
        if (campaign.emailType.codeName === 'ET_SERVICING') {
          campaign.endDate = (campaign.deploymentDates.length > 0) ? new Date(campaign.deploymentDates[0]) : null;
          console.log('SUCCESS: Set endDate for campaign with ID: ' + campaign.requestID);
        } else if (campaign.emailType.codeName === 'ET_ONEOFF') {
          if (campaign.durationInWeeks > 0) {
            var endDate = ecpUtils.addDays(startDate, (7 * (campaign.durationInWeeks - 1)));

            while (endDate.getDay() !== 3) {
              endDate = ecpUtils.addDays(endDate, 1);
            }
            campaign.endDate = new Date(endDate);
          } else if (campaign.durationInWeeks === 0) {
            campaign.endDate = new Date(campaign.deploymentDates[0]);
          }
          console.log('SUCCESS: Set endDate for campaign with ID: ' + campaign.requestID);
        }
      }
      campaign.save(function(err, savedCampaign) {
        if (err) {
          console.log('FAIL: Error occured while updating campaign with ID: ' + campaign.requestID);
          campaignsWithErrors += campaign.requestID + ', ';
        }
        return asyncCb(err);
      });
    }, function(err) {
      if (campaignsWithErrors) {
        console.log('FAIL: Creation date patch ==> Campaigns with errors: ' + campaignsWithErrors);
      }
      if (err) {
        console.log('FAIL: Creation date patch ==> ran with few errors.');
      } else {
        console.log('SUCCESS: Creation date patch ran successfully. All campaigns now should have creation date.');
      }
      return cb(err);
    });
  });
}

module.exports = {
  runPatch: function(patchCallback) {
    console.log('=========== Starting: Creation Date Patch ==============');
    console.log('Patch Description: This patch will ensure that every campaign have the creation date.');

    async.waterfall([function(cb) {
      getBU({
        code: 'U023'
      }, cb);
    }, function(cb) {
      getBU({
        code: 'U017'
      }, cb);
    }, updateCampaigns], function(err) {
      console.log('=========== Ending: Creation Date Patch ==============');
      return patchCallback(err);
    })
  }
};
