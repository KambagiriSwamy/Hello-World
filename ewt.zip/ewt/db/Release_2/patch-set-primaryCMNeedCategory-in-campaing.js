/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 * 
 */

'use strict';
var db = require('../../application/lib/db'),
  asyncEach = require('async-each');


module.exports = {

  runPatch: function(patchCallback) {
    console.log('=========== Starting: Primary CM Need Category Patch ==============');
    console.log('Patch Description : This patch will make sure the old non-servicing campaigns get the Primary CM need Category drop down is filled with the exiting first element of cmNeedCategory list');

    var Campaign = db.campaignClass();
    var campaignsWithErrors = '';

    Campaign.find({
      'emailType.codeName': {
        '$ne': 'ET_SERVICING'
      }
    }, function(err, campaigns) {
      if (err) {
        patchCallback('Could not Fetch campaigns from database' + err);
      }

      asyncEach(campaigns, function(campaign, cb) {
        if (campaign.emailType && campaign.emailType.codeName === 'ET_SERVICING') {
          console.log('WARN: Found campaign of ET_SERVICING type. Not processing it.');
          return cb();
        } else {
          if (!campaign.primaryCmNeedCategory) {
            if (campaign.cmNeedCategories && campaign.cmNeedCategories.length > 0) {
              campaign.primaryCmNeedCategory = campaign.cmNeedCategories.shift();
              if (campaign.cmNeedCategories.length === 0) {
                campaign.isMultiCMNeedCategory = false;
              } else {
                campaign.isMultiCMNeedCategory = true;
              }
              campaign.save(function(err, savedCampaign) {
                if (err) {
                  campaignsWithErrors += campaign.requestID + ', ';
                } else {
                  console.log('SUCCESS: Updated primaryCmNeedCategory to ' + (JSON.stringify(savedCampaign.primaryCmNeedCategory)) + ', for Campaign with ID: ' + campaign.requestID);
                }
                return cb(err);
              });
            } else {
              return cb();
            }
          } else {
            return cb();
          }
        }
      }, function(err) {
        if (campaignsWithErrors) {
          console.log('FAIL: Primary CM need Category patch ==> Campaigns with errors: ' + campaignsWithErrors);
        }
        if (err) {
          console.log('FAIL: Primary CM need Category patch ==> ran with few errors.');
        } else {
          console.log('SUCCESS: Primary CM need Category patch ran successfully. All campaigns now should have Primary CM need Category.');
        }
        console.log('=========== Ending: Primary CM need Category Patch ==============');
        return patchCallback(err);
      });
    });
  }
}
