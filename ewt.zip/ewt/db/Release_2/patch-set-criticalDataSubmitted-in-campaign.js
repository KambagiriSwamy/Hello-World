/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 (ERA) - This file implements the user controller at node end. It has all the action methods related to user controller
 */

'use strict';

var db = require('../../application/lib/db');
var asyncEach = require('async-each');
var dateFormat = require('dateformat');

module.exports = {

  runPatch: function(patchCallback) {
    console.log('=========== Starting: Cancel Campaign Patch ==============');
    console.log('Patch Description: This patch will ensure that every campaign already submitted to ET must have <<criticalDataSubmitted>> object.');
    var CampaignClass = db.campaignClass(),
      campaignsWithErrors = '';

    CampaignClass.find({
      $or: [{
        'state.codeName': 'submitted2esp'
      }, {
        'state.codeName': 'rollBack2Manager'
      }]
    }, function(error, campaigns) {
      if (error) {
        logger.error('FAIL: Failed to find campaigns with the provided criteria' + JSON.stringify(error));
        return patchCallback(error);
      } else {
        console.log('INFO: Found ' + campaigns.length + ' campaigns to process');
        asyncEach(campaigns, function(campaign, campaignCallBack) {
            if (campaign.criticalDataSubmitted && campaign.criticalDataSubmitted.length > 0) {
              console.log('WARN: <<criticalDataSubmitted>> already present for the campaign :' + campaign.requestID + '. Not processing it.');
              return campaignCallBack();
            } else {
              if (campaign.emailType.codeName === 'ET_SERVICING') {
                campaign.criticalDataSubmitted = [];
                if (!campaign.deploymentDates[0]) {
                  return campaignCallBack();
                }

                if (!(campaign.mailHistory.startDate instanceof Date)) {
                  var date = new Date(campaign.deploymentDates[0]);
                  if (date == 'Invalid Date') {
                    console.log('invalid date format found for :' + campaign.requestID);
                    return campaignCallBack();
                  }
                }
                var criticalDataObj = {
                  keys: {
                    'REQST_ID': campaign.requestID + '.1',
                    'CMPGN_MAIL_ID': campaign.mailHistory[0].mhid,
                    'CMPGN_DEPLOY_DATE': dateFormat(campaign.deploymentDates[0], 'mm/dd/yyyy')
                  }
                }
                asyncEach(campaign.versions, function(version, vcb) {
                  asyncEach(version.cells, function(cell, cb) {
                    var criticalData = JSON.parse(JSON.stringify(criticalDataObj));
                    criticalData.keys.CMPGN_VER_CELL_ID = cell.srcCode;
                    campaign.criticalDataSubmitted.push(criticalData);
                    return cb();
                  }, function(err) {
                    return vcb(err);
                  });
                }, function(err) {
                  if (!err) {
                    campaign.save(function(err) {
                      if (!err) {
                        console.log('SUCCESS: Campaign of ET_SERVICING type, with ID:' + campaign.requestID + ', saved successfully.');
                      } else {
                        console.log('FAIL: Saving campaign of ET_SERVICING type, with ID:' + campaign.requestID + ', failed.');
                      }
                      return campaignCallBack(err);
                    });
                  } else {
                    console.log('FAIL: Campaign of ET_SERVICING type, with ID:' + campaign.requestID + ', could not be saved.');
                    campaignsWithErrors += campaign.requestID + ', ';
                    return campaignCallBack(err)
                  };
                });
              } else if (campaign.emailType.codeName === 'ET_MA') {
                campaign.criticalDataSubmitted = [];
                var isCellAccounted = false;
                asyncEach(campaign.ma.maVersions, function(version, versionCallback) {
                  if (!(campaign.ma.mailHistory)) {
                    return versionCallback();
                  }
                  asyncEach(campaign.ma.mailHistory, function(currentMailHistory, mhidCallback) {
                    if (!(currentMailHistory.cells)) {
                      return mhidCallback();
                    }
                    asyncEach(currentMailHistory.cells, function(cell, cb) {
                      if (cell.type && cell.type.codeName === 'control') {
                        return cb();
                      }
                      var mailHistory = JSON.parse(JSON.stringify(currentMailHistory));

                      campaign.activeMailHistory = mailHistory;
                      if (!(campaign.activeMailHistory.startDate)) {
                        return cb();
                      }

                      if (!campaign.activeMailHistory.startDate instanceof Date) {
                        var date = new Date(campaign.activeMailHistory.startDate);
                        if (date == 'Invalid Date') {
                          console.log('ERROR: Invalid date format found for :' + campaign.requestID);
                          return cb();
                        }
                      }
                      if (!isCellAccounted) {
                        var criticalDataObj = {
                          keys: {
                            'REQST_ID': campaign.requestID + '.1',
                            'CMPGN_MAIL_ID': campaign.activeMailHistory.mhid,
                            'CMPGN_DEPLOY_DATE': (campaign.activeMailHistory.startDate instanceof Date) ? dateformat(campaign.activeMailHistory.startDate, 'mm/dd/yyyy') : campaign.activeMailHistory.startDate,
                            'CMPGN_VER_CELL_ID': cell.srcCode
                          }
                        }
                        campaign.criticalDataSubmitted.push(criticalDataObj);
                      }
                      return cb();
                    }, function(err) {
                      return mhidCallback(err);
                    });
                  }, function(err) {
                    if (!err) {
                      isCellAccounted = true;
                    }
                    return versionCallback(err);
                  });
                }, function(err) {
                  if (err) {
                    return campaignCallBack(err);
                  } else {
                    campaign.save(function(err) {
                      if (!err) {
                        console.log('SUCCESS: Campaign of ET_MA type, with ID: ' + campaign.requestID + ', saved successfully.')
                      } else {
                        console.log('FAIL: Saving campaign of ET_MA type, with ID: ' + campaign.requestID + ', failed.')
                      }
                      return campaignCallBack(err);
                    });
                  }
                });
              } else {
                return campaignCallBack();
              }
            }
          },
          function(err) {
            if (campaignsWithErrors) {
              console.log('FAIL: Cancel campaign patch ==> Campaigns with errors: ' + campaignsWithErrors);
            }
            if (err) {
              console.log('FAIL: Cancel campagin patch ==> ran with few errors.');
            } else {
              console.log('SUCCESS: Cancel campagin patch ran successfully. Now all campaigns that are submitted to ESP or rolled-back and are of Servicing and MA types, should have criticalDataSubmitted attribute.');
            }
            console.log('=========== Ending: Cancel Campaign Patch ==============');
            patchCallback(err);
          });
      }
    });
  }
};
