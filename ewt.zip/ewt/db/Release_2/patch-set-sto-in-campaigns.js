/**
 * Created by smurugad on 2/10/16.
 */


'use strict';

var db = require('../../application/lib/db');
var asyncEach = require('async-each');


module.exports = {
  runPatch: function(patchCallback) {
    console.log('=========== Starting: STO Patch ==============');
    console.log('Patch Description: This patch will ensure that every One-off and Servicing campaign have the <<sto>> object.');
    var Campaign = db.campaignClass(),
      campaignsWithErrors = '';

    // Get all the campaigns of One-off and Servicing types, as STO is only applicable to them
    Campaign.find({
      $or: [{
        'emailType.codeName': 'ET_ONEOFF'
      }, {
        'emailType.codeName': 'ET_SERVICING'
      }]
    }, null, {
      sort: {
        requestID: -1
      }
    }, function(err, campaigns) {
      // Go over each campaign
      asyncEach(campaigns, function(campaign, cb) {
        campaign.sto = {
          isSTO: false,
          stoEmailTrackingType: {},
          stoEventToTrack: {},
          isThrottled: false,
          isSpecialTestingReq: false,
          isSpecificTime: false
        };

        campaign.save(function(err) {
          if (err) {
            console.log('FAIL: Error occured while updating campaign with ID: ' + campaign.requestID);
            campaignsWithErrors += campaign.requestID + ', ';
          } else {
            console.log('SUCCESS: Successfully updated the campaign with ID: ' + campaign.requestID);
          }
          return cb(err);
        });
      }, function(err) {
        if (campaignsWithErrors) {
          console.log('FAIL: STO Patch ==> Campaigns with errors: ' + campaignsWithErrors);
        }
        if (err) {
          console.log('FAIL: STO Patch ==> Script failed with few campaigns not updated.');
        } else {
          console.log('SUCCESS: STO Patch Script Executed Successfully:::');
        }
        console.log('=========== Ending: STO Patch ==============');
        patchCallback(err);
      });
    });
  }
};
