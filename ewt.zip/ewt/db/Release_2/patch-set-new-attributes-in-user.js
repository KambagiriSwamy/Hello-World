/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 (ERA) - This file implements the DB patch that will update the user collection to have more attributes like status, business-unit, etc.
 */

'use strict';

var db = require('../../application/lib/db'),
  asyncEach = require('async-each'),
  utils = require('../../application/lib/utils.js'),
  ldap = require('../../application/lib/ldap.js'),
  async = require('async'),
  businessUnitObj, userStatusObj,
  userRoleArr = {},
  usersWithErrors = '';

function getBusinessUnit(cb) {
  var BusinessUnit = db.businessUnitClass();
  BusinessUnit.findOne({
    name: 'OPEN'
  }, function(err, bu) {
    if (err) {
      return cb(err);
    }
    businessUnitObj = bu;
    return cb();
  });
}

function getUserStatus(cb) {
  var UserStatus = db.userStatusClass();
  UserStatus.findOne({
    codeName: 'active'
  }, function(err, userStatus) {
    if (err) {
      return cb(err);
    }
    userStatusObj = userStatus;
    return cb();
  });
}

function getUserRoles(cb) {
  var UserRole = db.userRoleClass();
  UserRole.find({}, function(err, roles) {
    if (err) {
      return cb(err);
    }
    asyncEach(roles, function(role, asyncCb) {
      userRoleArr[role.code] = role;
      return asyncCb();
    }, function(err) {
      return cb(err);
    });
  });
}

function updateUserRecords(cb) {
  var User = db.userClass();

  User.find({}, function(err, users) {
    if (err) {
      console.log('FAIL: Error occured while getting users from DB');
      return cb(err);
    }
    if (!users) {
      console.log('FAIL: No users found in DB');
      return cb();
    }
    asyncEach(users, function(user, asyncCb) {
      var ldapFilter = '(samaccountname=' + user.uid + ')';
      ldap.getUserDetails(ldapFilter, null, function(err, ldapUser) {
        if (err) {
          console.log('FAIL: Error occured while getting user details from LDAP for user with ID: ' + user.uid);
          return asyncCb(err);
        }
        if (!ldapUser) {
          console.log('WARN: User with ID ' + user.uid + ' does not exists in ADS. Not updating this user in ERA DB.');
          return asyncCb();
        }
        user.firstName = ldapUser.firstName || '';
        user.lastName = ldapUser.lastName || '';
        user.name = (user.firstName || user.lastName) ? user.firstName + ' ' + user.lastName : '';
        user.businessUnit = businessUnitObj;
        user.status = user.status || userStatusObj;
        if (user.role && user.role.code && userRoleArr[user.role.code]) {
          user.role = userRoleArr[user.role.code];
        }
        if ((user.uid === 'gdhim') || (user.uid === 'smurugad')) {
          user.role = userRoleArr['002'];
        }
        user.createdOn = user.createdOn || utils.formatDate((creationDate.getMonth() + 1) + '/' + creationDate.getDate() + '/' + creationDate.getFullYear());
        user.lastUpdatedOn = user.lastUpdatedOn || utils.formatDate((creationDate.getMonth() + 1) + '/' + creationDate.getDate() + '/' + creationDate.getFullYear());
        user.markAsDeleted = user.markAsDeleted || false;
        user.leader = user.leader || {
          email: 'dummy.leader@aexp.com'
        }
        user.lastLoggedOn = user.lastLoggedOn || new Date();

        user.save(function(err, savedUser) {
          if (err) {
            console.log('FAIL: Could not save the user with ID: ' + user.uid + ', to DB');
            usersWithErrors += user.uid + ', ';
          } else {
            console.log('SUCCESS: Saved the user with ID: ' + user.uid + ', to DB');
          }
          return asyncCb(err);
        });
      });
    }, function(err) {
      if (usersWithErrors) {
        console.log('FAIL: User DB patch ==> Users that could not be updated: ' + usersWithErrors);
      }
      if (err) {
        console.log('FAIL: Could not update all users.');
      } else {
        console.log('SUCCESS: User DB Patch ran successfully');
      }
      cb(err);
    })
  });
}


module.exports = {

  runPatch: function(patchCallback) {
    console.log('=========== Starting: User DB Patch ==============');
    console.log('Patch Description: This patch will update the user collection to have more attributes like status, business-unit, etc.');

    async.parallel([function(cb) {
      return getBusinessUnit(cb);
    }, function(cb) {
      return getUserStatus(cb);
    }, function(cb) {
      return getUserRoles(cb);
    }], function(err) {
      if (err) {
        return patchCallback('Some error occured. Could not get business-unit, user-status or user-role object from DB.');
      }
      updateUserRecords(function(err) {
        console.log('=========== Ending: User DB Patch ==============');
        return patchCallback(err);
      });
    });
  }
};
