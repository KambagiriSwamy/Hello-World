db.cardMemberNeedCategory.remove( {} );
db.cardMemberNeedCategory.dropIndex(
  {
    "code":               1,
    "granularOptOutCode": 1,
    "businessUnitCode":   1
  } );

db.cardMemberNeedCategory.insert( [
  {
    'code':                 'CMNC03',
    'granularOptOutCode':   'MKTRVL',
    'businessUnitCode':     'U007',
    'name':                 'Benefits and Rewards - Travel',
    'oneoffDeploymentWeek': 3,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC04',
    'granularOptOutCode':   'MKSHOP',
    'businessUnitCode':     'U007',
    'name':                 'Benefits and Rewards - Shopping & Retail',
    'oneoffDeploymentWeek': 3,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC05',
    'granularOptOutCode':   'MKDENT',
    'businessUnitCode':     'U007',
    'name':                 'Benefits and Rewards - Dining & Entertainment',
    'oneoffDeploymentWeek': 3,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC06',
    'granularOptOutCode':   'MKOTHR',
    'businessUnitCode':     'U007',
    'name':                 'Benefits and Rewards - Other Spend',
    'oneoffDeploymentWeek': 3,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC07',
    'granularOptOutCode':   'MKCBEN',
    'businessUnitCode':     'U007',
    'name':                 'Benefits and Rewards - Benefit awareness',
    'oneoffDeploymentWeek': 3,
    'oneoffDeploymentDay':  0
  }, { // TO DO Clarification
    'code':                 'CMNC12',
    'granularOptOutCode':   'MKCORP',
    'businessUnitCode':     'U006',
    'name':                 'Corporate Offers',
    'oneoffDeploymentWeek': 1,
    'oneoffDeploymentDay':  0
  },
 {
   'code':                 'CMNC03',
   'granularOptOutCode':   'MKTRVL',
   'businessUnitCode':     'U005',
   'name':                 'Benefits and Rewards - Travel',
   'oneoffDeploymentWeek': 1,
   'oneoffDeploymentDay':  0
 }, {
    'code':                 'CMNC04',
    'granularOptOutCode':   'MKSHOP',
    'businessUnitCode':     'U005',
    'name':                 'Benefits and Rewards - Shopping & Retail',
    'oneoffDeploymentWeek': 1,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC05',
    'granularOptOutCode':   'MKDENT',
    'businessUnitCode':     'U005',
    'name':                 'Benefits and Rewards - Dining & Entertainment',
    'oneoffDeploymentWeek': 1,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC06',
    'granularOptOutCode':   'MKOTHR',
    'businessUnitCode':     'U005',
    'name':                 'Benefits and Rewards - Other Spend',
    'oneoffDeploymentWeek': 1,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC07',
    'granularOptOutCode':   'MKCBEN',
    'businessUnitCode':     'U005',
    'name':                 'Benefits and Rewards - Benefit awareness',
    'oneoffDeploymentWeek': 1,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC01',
    'granularOptOutCode':   'MKACQU',
    'businessUnitCode':     'U005',
    'name':                 'Card & Credit',
    'oneoffDeploymentWeek': 4,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC03',
    'granularOptOutCode':   'MKTRVL',
    'businessUnitCode':     'U004',
    'name':                 'Benefits and Rewards - Travel',
    'oneoffDeploymentWeek': 3,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC04',
    'granularOptOutCode':   'MKSHOP',
    'businessUnitCode':     'U004',
    'name':                 'Benefits and Rewards - Shopping & Retail',
    'oneoffDeploymentWeek': 3,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC05',
    'granularOptOutCode':   'MKDENT',
    'businessUnitCode':     'U004',
    'name':                 'Benefits and Rewards - Dining & Entertainment',
    'oneoffDeploymentWeek': 3,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC06',
    'granularOptOutCode':   'MKOTHR',
    'businessUnitCode':     'U004',
    'name':                 'Benefits and Rewards - Other Spend',
    'oneoffDeploymentWeek': 3,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC07',
    'granularOptOutCode':   'MKCBEN',
    'businessUnitCode':     'U004',
    'name':                 'Benefits and Rewards - Benefit awareness',
    'oneoffDeploymentWeek': 3,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC01',
    'granularOptOutCode':   'MKACQU',
    'businessUnitCode':     'U004',
    'name':                 'Card & Credit',
    'oneoffDeploymentWeek': 1,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC08',
    'granularOptOutCode':   'MKPUBL',
    'businessUnitCode':     'U003',
    'name':                 'Publications',
    'oneoffDeploymentWeek': 2,
    'oneoffDeploymentDay':  0
  }, { // TO DO -- Clarification -- not pressent
    'code':                 'CMNC13',
    'granularOptOutCode':   'MKRESR',
    'businessUnitCode':     'U002',
    'name':                 'Market Research Surveys',
    'oneoffDeploymentWeek': 1,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC09',
    'granularOptOutCode':   'MKGIFT',
    'businessUnitCode':     'U019',
    'name':                 'Prepaid Financial Products',
    'oneoffDeploymentWeek': 2,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC03',
    'granularOptOutCode':   'MKTRVL',
    'businessUnitCode':     'U018',
    'name':                 'Benefits and Rewards - Travel',
    'oneoffDeploymentWeek': 2,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC04',
    'granularOptOutCode':   'MKSHOP',
    'businessUnitCode':     'U018',
    'name':                 'Benefits and Rewards - Shopping & Retail',
    'oneoffDeploymentWeek': 2,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC05',
    'granularOptOutCode':   'MKDENT',
    'businessUnitCode':     'U018',
    'name':                 'Benefits and Rewards - Dining & Entertainment',
    'oneoffDeploymentWeek': 2,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC06',
    'granularOptOutCode':   'MKOTHR',
    'businessUnitCode':     'U018',
    'name':                 'Benefits and Rewards - Other Spend',
    'oneoffDeploymentWeek': 2,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC07',
    'granularOptOutCode':   'MKCBEN',
    'businessUnitCode':     'U018',
    'name':                 'Benefits and Rewards - Benefit awareness',
    'oneoffDeploymentWeek': 2,
    'oneoffDeploymentDay':  0
  }, { // TO DO -- Not Pressent
    'code':                 'CMNC11',
    'granularOptOutCode':   'MKCBEN',
    'businessUnitCode':     'U017',
    'name':                 'Account Management',
    'oneoffDeploymentWeek': 2,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC03',
    'granularOptOutCode':   'MKTRVL',
    'businessUnitCode':     'U020',
    'name':                 'Benefits and Rewards - Travel',
    'oneoffDeploymentWeek': 4,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC04',
    'granularOptOutCode':   'MKSHOP',
    'businessUnitCode':     'U020',
    'name':                 'Benefits and Rewards - Shopping & Retail',
    'oneoffDeploymentWeek': 4,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC05',
    'granularOptOutCode':   'MKDENT',
    'businessUnitCode':     'U020',
    'name':                 'Benefits and Rewards - Dining & Entertainment',
    'oneoffDeploymentWeek': 4,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC06',
    'granularOptOutCode':   'MKOTHR',
    'businessUnitCode':     'U020',
    'name':                 'Benefits and Rewards - Other Spend',
    'oneoffDeploymentWeek': 4,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC07',
    'granularOptOutCode':   'MKCBEN',
    'businessUnitCode':     'U020',
    'name':                 'Benefits and Rewards - Benefit awareness',
    'oneoffDeploymentWeek': 4,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC02',
    'granularOptOutCode':   'MKCSER',
    'businessUnitCode':     'U021',
    'name':                 'Protection & Insurance',
    'oneoffDeploymentWeek': 1,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC10',
    'granularOptOutCode':   'MKFINS',
    'businessUnitCode':     'U022',
    'name':                 'Other banking products',
    'oneoffDeploymentWeek': 3,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC03',
    'granularOptOutCode':   'MKTRVL',
    'businessUnitCode':     'U023',
    'name':                 'Benefits and Rewards - Travel',
    'oneoffDeploymentWeek': 2,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC04',
    'granularOptOutCode':   'MKSHOP',
    'businessUnitCode':     'U023',
    'name':                 'Benefits and Rewards - Shopping & Retail',
    'oneoffDeploymentWeek': 2,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC05',
    'granularOptOutCode':   'MKDENT',
    'businessUnitCode':     'U023',
    'name':                 'Benefits and Rewards - Dining & Entertainment',
    'oneoffDeploymentWeek': 2,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC06',
    'granularOptOutCode':   'MKOTHR',
    'businessUnitCode':     'U023',
    'name':                 'Benefits and Rewards - Other Spend',
    'oneoffDeploymentWeek': 2,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC07',
    'granularOptOutCode':   'MKCBEN',
    'businessUnitCode':     'U023',
    'name':                 'Benefits and Rewards - Benefit awareness',
    'oneoffDeploymentWeek': 2,
    'oneoffDeploymentDay':  0
  },{
    'code':                 'CMNC03',
    'granularOptOutCode':   'MKTRVL',
    'businessUnitCode':     'U024',
    'name':                 'Benefits and Rewards - Travel',
    'oneoffDeploymentWeek': 2,
    'oneoffDeploymentDay':  0
  },  {
    'code':                 'CMNC04',
    'granularOptOutCode':   'MKSHOP',
    'businessUnitCode':     'U024',
    'name':                 'Benefits and Rewards - Shopping & Retail',
    'oneoffDeploymentWeek': 2,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC05',
    'granularOptOutCode':   'MKDENT',
    'businessUnitCode':     'U024',
    'name':                 'Benefits and Rewards - Dining & Entertainment',
    'oneoffDeploymentWeek': 2,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC06',
    'granularOptOutCode':   'MKOTHR',
    'businessUnitCode':     'U024',
    'name':                 'Benefits and Rewards - Other Spend',
    'oneoffDeploymentWeek': 2,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC07',
    'granularOptOutCode':   'MKCBEN',
    'businessUnitCode':     'U024',
    'name':                 'Benefits and Rewards - Benefit awareness',
    'oneoffDeploymentWeek': 2,
    'oneoffDeploymentDay':  0
  }, {
    'code':                 'CMNC01',
    'granularOptOutCode':   'MKACQU',
    'businessUnitCode':     'U024',
    'name':                 'Card & Credit',
    'oneoffDeploymentWeek': 2,
    'oneoffDeploymentDay':  0
  }]);
db.cardMemberNeedCategory.ensureIndex(
  {
    "code":               1,
    "granularOptOutCode": 1,
    "businessUnitCode":   1
  } );
