/**
 * Created by smurugad on 2/11/16.
 */
db.user.insert([
  {'uid':'aslotnic','name':'Allison Slotnick','email':'allison.slotnick@aexp.com','role':{'code':'001','codeName':'mm','name':'manager'}},
  {'uid':'jbalisi','name':'Jen V Balisi','email':'jen.v.balisi@aexp.com','role':{'code':'001','codeName':'mm','name':'manager'}}]);
