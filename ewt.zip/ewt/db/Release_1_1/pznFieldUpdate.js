/**
 * Created by smurugad on 2/11/16.
 */
db.pznField.remove({});
db.pznField.insert([{
  'code': 'CMFirstName',
  'codeName': 'cmFirst',
  'name': 'CM First Name',
  'description': 'CM First Name',
  'reserved': true
}, {
  'code': 'CMMemberSinceDate',
  'codeName': 'cmMember',
  'name': 'CM Member Since Date',
  'description': 'CM Member Since Date',
  'reserved': true
}, {
  'code': 'CMCardProduct',
  'codeName': 'cmCardProd',
  'name': 'CM Card Product',
  'description': 'CM Card Product',
  'reserved': true
}, {
  'code': 'DCEReserved1',
  'codeName': 'dceRese1',
  'name': 'DCE Reserved 1',
  'description': 'DCE Reserved',
  'reserved': true
}, {
  'code': 'DCEReserved2',
  'codeName': 'dceRese2',
  'name': 'DCE Reserved 2',
  'description': 'DCE Reserved',
  'reserved': true
}, {
  'code': 'pzn1',
  'codeName': 'pzn01',
  'name': 'PZN 1',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn2',
  'codeName': 'pzn02',
  'name': 'PZN 2',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn3',
  'codeName': 'pzn03',
  'name': 'PZN 3',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn4',
  'codeName': 'pzn04',
  'name': 'PZN 4',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn5',
  'codeName': 'pzn05',
  'name': 'PZN 5',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn6',
  'codeName': 'pzn06',
  'name': 'PZN 6',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn7',
  'codeName': 'pzn07',
  'name': 'PZN 7',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn8',
  'codeName': 'pzn08',
  'name': 'PZN 8',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn9',
  'codeName': 'pzn09',
  'name': 'PZN 9',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn10',
  'codeName': 'pzn10',
  'name': 'PZN 10',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn11',
  'codeName': 'pzn11',
  'name': 'PZN 11',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn12',
  'codeName': 'pzn12',
  'name': 'PZN 12',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn13',
  'codeName': 'pzn13',
  'name': 'PZN 13',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn14',
  'codeName': 'pzn14',
  'name': 'PZN 14',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn15',
  'codeName': 'pzn15',
  'name': 'PZN 15',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn16',
  'codeName': 'pzn16',
  'name': 'PZN 16',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn17',
  'codeName': 'pzn17',
  'name': 'PZN 17',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn18',
  'codeName': 'pzn18',
  'name': 'PZN 18',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn19',
  'codeName': 'pzn19',
  'name': 'PZN 19',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn20',
  'codeName': 'pzn20',
  'name': 'PZN 20',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn21',
  'codeName': 'pzn21',
  'name': 'PZN 21',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn22',
  'codeName': 'pzn22',
  'name': 'PZN 22',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn23',
  'codeName': 'pzn23',
  'name': 'PZN 23',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn24',
  'codeName': 'pzn24',
  'name': 'PZN 24',
  'description': '',
  'reserved': false
}, {
  'code': 'pzn25',
  'codeName': 'pzn25',
  'name': 'PZN 25',
  'description': '',
  'reserved': false
}]);

