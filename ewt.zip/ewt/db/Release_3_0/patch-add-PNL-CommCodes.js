/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 (ERA) -This file moves the email type inserts in DB.
 */

'use strict';

var db = require('../../application/lib/db'),
  async = require('async'),
  asyncEach = require('async-each');

var commCodesJson = [
  {
    "businessUnitCode": "U004",
    "code": "BLUCSH",
    "name": "Blue Cash Newsletter (BLUCSH)",
    "codeName": "BULE_CASH_NEWSLETTER_BLUCSH",
    "frequency": "Monthly",
    "products": "[]"
  },
  {
    "businessUnitCode": "U004",
    "code": "BLUFSH",
    "name": "Blue Voice Newsletter (BLUFSH)",
    "codeName": "BLUE_VOICE_NEWSLETTER_BLUFSH",
    "frequency": "Monthly",
    "products": "[]"
  },
  {
    "businessUnitCode": "U004",
    "code": "BLUSKY",
    "name": "Blue Sky Newsletter (BLUSKY)",
    "codeName": "BLUESKY_NEWSLETTER_BLUSKY",
    "frequency": "Monthly",
    "products": "[]"
  },
  {
    "businessUnitCode": "U004",
    "code": "CENTEX",
    "name": "Centurion Cardmember Newsletter (CENTEX)",
    "codeName": "CENTURION_CARDMEMBER_NEWSLETTER_CENTEX",
    "frequency": "Monthly",
    "products": "[]"
  },
  {
    "businessUnitCode": "U004",
    "code": "DSKYMI",
    "name": "Delta SkyMiles Card Newsletter (DSKYMI)",
    "codeName": "DELTA_SKYMILES_NEWSLETTER_DSKYMI",
    "frequency": "Every Other Month",
    "products": "[]"
  },
  {
    "businessUnitCode": "U004",
    "code": "EPREVW",
    "name": "Platinum Experience Newsletter (EPREVW)",
    "codeName": "PLATINUM_EXPERIANCE_NEWSLETTER_EPREVW",
    "frequency": "Monthly",
    "products": "[]"
  },
  {
    "businessUnitCode": "U004",
    "code": "EVRDAY",
    "name": "Amex EveryDay Credit Card Newsletter (EVRDAY)",
    "codeName": "AMEX_EVERYDAY_NEWSLETTER_EVRDAY",
    "frequency": "Bi-Monthly",
    "products": "[]"
  },
  {
    "businessUnitCode": "U004",
    "code": "HILTON",
    "name": "Hilton Honors Card Newsletter (HILTON)",
    "codeName": "HILTON_HONORS_NEWSLETTER_HILTON",
    "frequency": "Quarterly",
    "products": "[]"
  },
  {
    "businessUnitCode": "U004",
    "code": "MEMBR0",
    "name": "Inside Membership Newsletter (MEMBR0)",
    "codeName": "INSIDE_MEMBERSHIP_NEWSLETTER_MEMBR0",
    "frequency": "Monthly",
    "products": "[]"
  },
  {
    "businessUnitCode": "U004",
    "code": "MEMSIN",
    "name": "Inside Membership Newsletter (MEMSIN)",
    "codeName": "INSIDE_MEMBERSHIP_NEWSLETTER_MEMSIN",
    "frequency": "Monthly",
    "products": "[]"
  },
  {
    "businessUnitCode": "U004",
    "code": "MERCED",
    "name": "Mercedes Newsletter (MERCED)",
    "codeName": "MERCEDES_NEWSLETTER_MERCED",
    "frequency": "Quarterly",
    "products": "[]"
  },
  {
    "businessUnitCode": "U004",
    "code": "MORGAN",
    "name": "Morgan Stanley Newsletter (MORGAN)",
    "codeName": "MORGAN_STANDLEY_NEWSLETTER_MORGAN",
    "frequency": "Quarterly",
    "products": "[]"
  },
  {
    "businessUnitCode": "U004",
    "code": "RWDWAT",
    "name": "RewardsWatch Newsletter (RWDWAT)",
    "codeName": "REWARDS_WATCH_NEWSLETTER_RWDWAT",
    "frequency": "No Frequency ",
    "products": "[]"
  },
  {
    "businessUnitCode": "U004",
    "code": "STRGST",
    "name": "Starwood Preferred Guest Card Newsletter (STRGST)",
    "codeName": "STARWOOD_PREFERRED_GUEST_STRGST",
    "frequency": "Every Other Month",
    "products": "[]"
  },
  {
    "businessUnitCode": "U005",
    "code": "PLTVEN",
    "name": "Business Centurion Newsletter (PLTVEN)",
    "codeName": "BUSINESS_CENTURIAN_NEWSLETTER_PLTVEN",
    "frequency": "Monthly",
    "products": "[]"
  },
  {
    "businessUnitCode": "U005",
    "code": "OPBUS0",
    "name": "OPEN Forum Newsletter (OPBUS0)",
    "codeName": "OPEN_FORUM_NEWSLETTER_OPBUS0",
    "frequency": "Monthly",
    "products": "[]"
  },
  {
    "businessUnitCode": "U005",
    "code": "RWDWAT",
    "name": "Business RewardsWatch Newsletter (RWDWAT)",
    "codeName": "BUSINESS_REWARDS_WATCH_NEWSLETTER_RWDWAT",
    "frequency": "No Frequency ",
    "products": "[]"
  },
  {
    "businessUnitCode": "U005",
    "code": "BGRINS",
    "name": "OPEN Monthly Newsletter (BGRINS)",
    "codeName": "OPEN_MONTHLY_NEWSLETTER_BGRINS",
    "frequency": "Monthly",
    "products": "[]"
  }
];

function resetCollection(collectionName, data, cb) {
  var CollectionClass = db[collectionName + 'Class']();
  CollectionClass.remove({}, function(err) {
    if (err) {
      console.log('FAIL: Error in removing all records from ' + collectionName + ' collection.');
      return cb(err);
    }

    asyncEach(data, function(obj, asynCb) {
      var record = new CollectionClass(obj);
      record.save(function(err) {
        if (err) {
          console.log('FAILED while resetting ' + collectionName + ' collection. Error: ' + err);
        }
        return asynCb(err);
      });
    }, function(err) {
      if (err) {
        console.log('FAIL: Error occured while adding records to ' + collectionName + ' collection.')
        return cb(err);
      } else {
        CollectionClass.find({}, function(err, records) {
          console.log('Total records in ' + collectionName + ' collection: ' + records.length);
          console.log('SUCCESS: Added records to ' + collectionName + ' collection');
          return cb(err);
        });
      }
    });
  });
}

module.exports = {
  runPatch: function(patchCallback) {
    console.log('=========== Starting: Add master records Patch ==============');
    console.log('Patch Description: This patch will ensure add wipe out the existing records (if any) and will add new records to Emailtype DB collection.');
    async.parallel([function(cb) {
      return resetCollection('commCode', commCodesJson, cb);
    }], function(err) {
      console.log('=========== Ending: Add master records Patch ==============');
      return patchCallback(err);
    });
  }
}
