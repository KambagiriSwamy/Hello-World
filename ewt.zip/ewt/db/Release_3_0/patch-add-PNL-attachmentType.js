/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 (ERA) -This file moves the email type inserts in DB.
 */

'use strict';

var db = require('../../application/lib/db'),
  async = require('async'),
  asyncEach = require('async-each');

var attachmentJson = [
  {
    'code': '001',
    'codeName': 'attachment_mock',
    'name': 'Initial Draft',
    'emailTypeCodes': ['012', '008', '006', '013']
  }, {
    'code': '002',
    'codeName': 'text_version',
    'name': 'Text Version',
    'emailTypeCodes': ['012', '008', '006', '013']
  }, {
    'code': '003',
    'codeName': 'html_version',
    'name': 'HTML Version',
    'emailTypeCodes': ['012', '008', '006', '013']
  }, {
    'code': '004',
    'codeName': 'creative_governance',
    'name': 'Creative Governance',
    'emailTypeCodes': ['008', '006', '013']
  }, {
    'code': '005',
    'codeName': 'images',
    'name': 'Images',
    'emailTypeCodes': ['012', '008', '006', '013']
  }, {
    'code': '006',
    'codeName': 'final_creative_preview',
    'name': 'Final Creative Preview',
    'emailTypeCodes': ['012', '008', '006', '013']
  }, {
    'code': '008',
    'codeName': 'other',
    'name': 'Other',
    'emailTypeCodes': ['012', '008', '006', '013']
  }, {
    'code': '007',
    'codeName': 'rasc',
    'name': 'RASC Approval',
    'emailTypeCodes': ['012', '013']
  }
];

function resetCollection(collectionName, data, cb) {
  var CollectionClass = db[collectionName + 'Class']();
  CollectionClass.remove({}, function(err) {
    if (err) {
      console.log('FAIL: Error in removing all records from ' + collectionName + ' collection.');
      return cb(err);
    }

    asyncEach(data, function(obj, asynCb) {
      var record = new CollectionClass(obj);
      record.save(function(err) {
        if (err) {
          console.log('FAILED while resetting ' + collectionName + ' collection. Error: ' + err);
        }
        return asynCb(err);
      });
    }, function(err) {
      if (err) {
        console.log('FAIL: Error occured while adding records to ' + collectionName + ' collection.')
        return cb(err);
      } else {
        CollectionClass.find({}, function(err, records) {
          console.log('Total records in ' + collectionName + ' collection: ' + records.length);
          console.log('SUCCESS: Added records to ' + collectionName + ' collection');
          return cb(err);
        });
      }
    });
  });
}

module.exports = {
  runPatch: function(patchCallback) {
    console.log('=========== Starting: Add master records Patch ==============');
    console.log('Patch Description: This patch will ensure add wipe out the existing records (if any) and will add new records to Emailtype DB collection.');
    async.parallel([function(cb) {
      return resetCollection('attachmentType', attachmentJson, cb);
    }], function(err) {
      console.log('=========== Ending: Add master records Patch ==============');
      return patchCallback(err);
    });
  }
}
