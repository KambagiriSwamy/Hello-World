/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 (ERA) -This file moves the email type inserts in DB.
 */

'use strict';

var db = require('../../application/lib/db'),
  async = require('async'),
  asyncEach = require('async-each');

var productsJson = [
  {
    "businessUnitCode": "U004",
    "commCode": "BLUCSH",
    "code": "P001",
    "codeName": "BLUE_CASH",
    "name": "Blue Cash",
    "description": "Choose Yes to receive the latest Blue Cashù from American Express Newsletter with exclusive member benefits and offers."
  },
  {
    "businessUnitCode": "U004",
    "commCode": "BLUCSH",
    "code": "P002",
    "codeName": "BLUE_CASH_EVERY_DAY",
    "name": "Blue Cash Every Day",
    "description": "Choose Yes to receive the latest Blue Cashù from American Express Newsletter with exclusive member benefits and offers."
  },
  {
    "businessUnitCode": "U004",
    "commCode": "BLUCSH",
    "code": "P003",
    "codeName": "BLUE_CASH_PREFERRED",
    "name": "Blue Cash Preferred",
    "description": "Choose Yes to receive the latest Blue Cashù from American Express Newsletter with exclusive member benefits and offers."
  },
  {
    "businessUnitCode": "U004",
    "commCode": "BLUFSH",
    "code": "P004",
    "codeName": "BLUE",
    "name": "Blue",
    "description": "The latest Blue Newsletter, exclusive member offers, and more. Delivered monthly."
  },
  {
    "businessUnitCode": "U004",
    "commCode": "BLUSKY",
    "code": "P005",
    "codeName": "BLUE_SKY",
    "name": "Blue Sky",
    "description": "The latest Blue Sky Newsletter with exclusive member benefits and offers. Delivered monthly."
  },
  {
    "businessUnitCode": "U004",
    "commCode": "BLUSKY",
    "code": "P006",
    "codeName": "BLUE_SKY_PREFERRED",
    "name": "Blue Sky Preferred",
    "description": "The latest Blue Sky Newsletter with exclusive member benefits and offers. Delivered monthly."
  },
  {
    "businessUnitCode": "U004",
    "commCode": "CENTEX",
    "code": "P007",
    "codeName": "CENTURION_",
    "name": "Centurion ",
    "description": "The latest Centurionù Card travel offers, new Card benefits, special partner deals, and By Invitation Onlyù events. Delivered monthly."
  },
  {
    "businessUnitCode": "U004",
    "commCode": "DSKYMI",
    "code": "P008",
    "codeName": "DELTA_RESERVE_CREDIT_CARD",
    "name": "Delta Reserve Credit Card",
    "description": "The latest Delta SkyMiles(R) Credit Card mileage offers, exclusive Cardmember promotions, merchant discounts, and more. Delivered every other month."
  },
  {
    "businessUnitCode": "U004",
    "commCode": "DSKYMI",
    "code": "P009",
    "codeName": "GOLD_DELTA_SKYMILES",
    "name": "Gold Delta SkyMiles",
    "description": "The latest Delta SkyMiles(R) Credit Card mileage offers, exclusive Cardmember promotions, merchant discounts, and more. Delivered every other month."
  },
  {
    "businessUnitCode": "U004",
    "commCode": "DSKYMI",
    "code": "P010",
    "codeName": "PLATINUM_DELTA_SKYMILES",
    "name": "Platinum Delta SkyMiles",
    "description": "The latest Delta SkyMiles(R) Credit Card mileage offers, exclusive Cardmember promotions, merchant discounts, and more. Delivered every other month."
  },
  {
    "businessUnitCode": "U004",
    "commCode": "EPREVW",
    "code": "P011",
    "codeName": "PLATINUM",
    "name": "Platinum",
    "description": "The latest Platinum Cardù benefit news, travel offers, exclusive Membership Rewardsù and retail promotions, and By Invitation Onlyù event information. Delivered monthly."
  },
  {
    "businessUnitCode": "U004",
    "commCode": "EVRDAY",
    "code": "P012",
    "codeName": "AMEX_EVERYDAY",
    "name": "Amex EveryDay",
    "description": "The latest (AMEX EveryDay Credit Card) product news, including benefits reinforcement, offers and Partner news. Delivered Bimonthly"
  },
  {
    "businessUnitCode": "U004",
    "commCode": "EVRDAY",
    "code": "P013",
    "codeName": "AMEX_EVERYDAY_PREFERRED",
    "name": "Amex EveryDay Preferred",
    "description": "The latest (AMEX EveryDay Credit Card) product news, including benefits reinforcement, offers and Partner news. Delivered Bimonthly"
  },
  {
    "businessUnitCode": "U004",
    "commCode": "HILTON",
    "code": "P014",
    "codeName": "HILTON_BASE",
    "name": "Hilton Base",
    "description": "The latest news, rewards, offers and more from your Hilton HHonorsù from American Express. Delivered quarterly."
  },
  {
    "businessUnitCode": "U004",
    "commCode": "HILTON",
    "code": "P015",
    "codeName": "HILTON_SURPASS",
    "name": "Hilton Surpass",
    "description": "The latest news, rewards, offers and more from your Hilton HHonorsù from American Express. Delivered quarterly."
  },
  {
    "businessUnitCode": "U004",
    "commCode": "MEMBR0",
    "code": "P016",
    "codeName": "GOLD",
    "name": "Gold",
    "description": "The latest American Express news, rewards, exclusive Cardmember offers, and more. Delivered every month."
  },
  {
    "businessUnitCode": "U004",
    "commCode": "MEMBR0",
    "code": "P017",
    "codeName": "PRG",
    "name": "PRG",
    "description": "The latest American Express news, rewards, exclusive Cardmember offers, and more. Delivered every month."
  },
  {
    "businessUnitCode": "U004",
    "commCode": "MEMSIN",
    "code": "P018",
    "codeName": "GREEN",
    "name": "Green",
    "description": "The latest American Express news, rewards, exclusive Cardmember offers, and more. Delivered every month."
  },
  {
    "businessUnitCode": "U004",
    "commCode": "MERCED",
    "code": "P019",
    "codeName": "MERCEDES-BENZ",
    "name": "Mercedes-Benz",
    "description": "The latest Mercedes product news, including benefits reinforcement, offers and Partner news. Delivered quarterly."
  },
  {
    "businessUnitCode": "U004",
    "commCode": "MORGAN",
    "code": "P020",
    "codeName": "MORGAN_STANLEY",
    "name": "Morgan Stanley",
    "description": "The latest Morgan Stanley product news, including benefits reinforcement, offers and Partner news. Delivered quarterly."
  },
  {
    "businessUnitCode": "U004",
    "commCode": "RWDWAT",
    "code": "P021",
    "codeName": "MEMBERSHIP_REWARDS",
    "name": "Membership Rewards",
    "description": "If you choose Yes you may receive this monthly guide to exclusive Cardmember offers and exciting ways to earn and redeem points."
  },
  {
    "businessUnitCode": "U004",
    "commCode": "STRGST",
    "code": "P022",
    "codeName": "STARWOOD_PREFERRED_GUEST",
    "name": "Starwood Preferred Guest",
    "description": "The latest news, exclusive Cardmember offers, and more to help you make the most of your Starwood Preferred Guest(R) Credit Card from American Express. Delivered  every other month."
  },
  {
    "businessUnitCode": "U005",
    "commCode": "RWDWAT",
    "code": "P023",
    "codeName": "BUSINESS_MEMBERSHIP_REWARDS",
    "name": "Business Membership Rewards",
    "description": "If you choose Yes you may receive this monthly guide to exclusive Cardmember offers and exciting ways to earn and redeem points."
  },
  {
    "businessUnitCode": "U005",
    "commCode": "OPBUS0",
    "code": "P024",
    "codeName": "OPEN_FORUM_E-NEWSLETTER",
    "name": "OPEN Forum E-Newsletter",
    "description": "The latest content from OPEN Forum --ranging from marketing to branding to general management -- designed to help you run your small business. Delivered monthly."
  },
  {
    "businessUnitCode": "U005",
    "commCode": "PLTVEN",
    "code": "P025",
    "codeName": "BUSINESS_CENTURION",
    "name": "Business Centurion",
    "description": "Monthly insights and offers for you and your business"
  },
  {
    "businessUnitCode": "U005",
    "commCode": "PLTVEN",
    "code": "P026",
    "codeName": "BUSINESS_PLATINUM_",
    "name": "Business Platinum ",
    "description": "Monthly insights and offers for you and your business"
  },
  {
    "businessUnitCode": "U005",
    "commCode": "BGRINS",
    "code": "P027",
    "codeName": "BUSINESS_GOLD_REWARDS",
    "name": "Business Gold Rewards",
    "description": "Monthly insights and offers for you and your business"
  },
  {
    "businessUnitCode": "U005",
    "commCode": "BGRINS",
    "code": "P028",
    "codeName": "PLUM",
    "name": "Plum",
    "description": "Monthly insights and offers for you and your business"
  },
  {
    "businessUnitCode": "U005",
    "commCode": "BGRINS",
    "code": "P029",
    "codeName": "SIMPLYCASH_BUSINESS",
    "name": "SimplyCash Business",
    "description": "Monthly insights and offers for you and your business"
  },
  {
    "businessUnitCode": "U005",
    "commCode": "BGRINS",
    "code": "P030",
    "codeName": "STARWOOD_PREFERRED_GUEST_BUSINESS",
    "name": "Starwood Preferred Guest Business",
    "description": "Monthly insights and offers for you and your business"
  },
  {
    "businessUnitCode": "U005",
    "commCode": "BGRINS",
    "code": "P031",
    "codeName": "GOLD_DELTA_SKYMILES_BUSINESS",
    "name": "Gold Delta SkyMiles Business",
    "description": "Monthly insights and offers for you and your business"
  },
  {
    "businessUnitCode": "U005",
    "commCode": "BGRINS",
    "code": "P032",
    "codeName": "PLATINUM_DELTA_SKYMILES_BUSINESS",
    "name": "Platinum Delta SkyMiles Business",
    "description": "Monthly insights and offers for you and your business"
  },
  {
    "businessUnitCode": "U005",
    "commCode": "BGRINS",
    "code": "P033",
    "codeName": "DELTA_RESERVE_FOR_BUSINESS",
    "name": "Delta Reserve for Business",
    "description": "Monthly insights and offers for you and your business"
  },
  {
    "businessUnitCode": "U005",
    "commCode": "BGRINS",
    "code": "P034",
    "codeName": "BUSINESS_GREEN_REWARDS",
    "name": "Business Green Rewards",
    "description": "Monthly insights and offers for you and your business"
  },
  {
    "businessUnitCode": "U005",
    "commCode": "BGRINS",
    "code": "P035",
    "codeName": "BLUE_FOR_BUSINESS",
    "name": "Blue for Business",
    "description": "Monthly insights and offers for you and your business"
  },
  {
    "businessUnitCode": "U005",
    "commCode": "BGRINS",
    "code": "P036",
    "codeName": "LOWE'S_BUSINESS_REWARDS",
    "name": "Lowe's Business Rewards",
    "description": "Monthly insights and offers for you and your business"
  }
];

function resetCollection(collectionName, data, cb) {
  var CollectionClass = db[collectionName + 'Class']();
  CollectionClass.remove({}, function(err) {
    if (err) {
      console.log('FAIL: Error in removing all records from ' + collectionName + ' collection.');
      return cb(err);
    }

    asyncEach(data, function(obj, asynCb) {
      var record = new CollectionClass(obj);
      record.save(function(err) {
        if (err) {
          console.log('FAILED while resetting ' + collectionName + ' collection. Error: ' + err);
        }
        return asynCb(err);
      });
    }, function(err) {
      if (err) {
        console.log('FAIL: Error occured while adding records to ' + collectionName + ' collection.')
        return cb(err);
      } else {
        CollectionClass.find({}, function(err, records) {
          console.log('Total records in ' + collectionName + ' collection: ' + records.length);
          console.log('SUCCESS: Added records to ' + collectionName + ' collection');
          return cb(err);
        });
      }
    });
  });
}

module.exports = {
  runPatch: function(patchCallback) {
    console.log('=========== Starting: Add master records Patch ==============');
    console.log('Patch Description: This patch will ensure add wipe out the existing records (if any) and will add new records to Emailtype DB collection.');
    async.parallel([function(cb) {
      return resetCollection('product', productsJson, cb);
    }], function(err) {
      console.log('=========== Ending: Add master records Patch ==============');
      return patchCallback(err);
    });
  }
}
