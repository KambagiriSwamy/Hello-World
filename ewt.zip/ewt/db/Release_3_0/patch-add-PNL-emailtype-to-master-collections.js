/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 (ERA) -This file moves the email type inserts in DB.
 */

'use strict';

var db = require('../../application/lib/db'),
  async = require('async'),
  asyncEach = require('async-each');

var emailTypes = [{
  'code': '012',
  'name': 'Servicing',
  'codeName': 'ET_SERVICING'
}, {
  'code': '008',
  'name': 'Marketing Automation',
  'codeName': 'ET_MA'
}, {
  'code': '006',
  'name': 'One Off',
  'codeName': 'ET_ONEOFF'
}, {
  'code': '013',
  'name': 'Product Newsletter',
  'codeName': 'ET_PNL'
}];

function resetCollection(collectionName, data, cb) {
  var CollectionClass = db[collectionName + 'Class']();
  CollectionClass.remove({}, function(err) {
    if (err) {
      console.log('FAIL: Error in removing all records from ' + collectionName + ' collection.');
      //console.log('FAIL: Error in removing all records from Emailtype collection.');
      return cb(err);
    }

    asyncEach(data, function(obj, asynCb) {
      var record = new CollectionClass(obj);
      record.save(function(err) {
        if (err) {
          console.log('FAILED while resetting ' + collectionName + ' collection. Error: ' + err);
        }
        return asynCb(err);
      });
    }, function(err) {
      if (err) {
        console.log('FAIL: Error occured while adding records to ' + collectionName + ' collection.')
        return cb(err);
      } else {
        CollectionClass.find({}, function(err, records) {
          console.log('Total records in ' + collectionName + ' collection: ' + records.length);
          console.log('SUCCESS: Added records to ' + collectionName + ' collection');
          return cb(err);
        });
      }
    });
  });
}

module.exports = {
  runPatch: function(patchCallback) {
    console.log('=========== Starting: Add master records Patch ==============');
    console.log('Patch Description: This patch will ensure add wipe out the existing records (if any) and will add new records to Emailtype DB collection.');

    async.parallel([function(cb) {
      return resetCollection('emailType', emailTypes, cb);
    }], function(err) {
      console.log('=========== Ending: Add master records Patch ==============');
      return patchCallback(err);
    });
  }
}
