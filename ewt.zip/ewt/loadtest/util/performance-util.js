/**
 * Created by smurugad on 3/10/16.
 */
var loadtest   = require ( 'loadtest' ),
    config     = require ( 'config' ),
    db         = require ( '../../application/lib/db.js' ),
    mongoose   = require ( 'mongoose' ),
    perfSchema = require ( '../../application/models/performanceStat.js' );
var crypto = require ( 'crypto' );
var algorithm = 'aes256';
var key = 'emailworkflowtoolversiontwo'
var dbConfig = config.application.mongo;
var decipherUser = crypto.createDecipher( algorithm, key );
var decipherPass = crypto.createDecipher( algorithm, key );
var dbUser, dbPass;
var mongoAuth  = '',
    mongoURL   = '',
    dbConfig   = config.application.mongo,
    hostString = '';
var loadtst = config.application.loadtest;

function statusCallback (latency) {
  var percent = [];
  var latencyObj = JSON.parse( JSON.stringify( latency ) );
  perfstat = new perfstat1 ();
  perfstat.totalRequests = latency.totalRequests;
  perfstat.totalErrors = latency.totalErrors;
  perfstat.totalTimeSeconds = latency.totalTimeSeconds;
  perfstat.rps = latency.rps;
  perfstat.meanLatencyMs = latency.meanLatencyMs;
  perfstat.maxLatencyMs = latency.maxLatencyMs;
  perfstat.errorCodes   = latency.errorCodes;
  perfstat.percentiles  = latency.percentiles;
  perfstat.save( function (err) {
    if (err) {
      console.log( 'FAIL: Could not save the performance statistics....' );
    }
  } );
}
module.exports = {
  loadTest:    function (page, url) {
    var options = {
      url:            url,
      maxRequests:    loadtst.maxRequests,
      concurrency:    loadtst.concurrentusers,
      secureProtocol: 'TLSv1_method',
      cookies:        loadtst.cookie,
      statusCallback: statusCallback
    };
    loadtest.loadTest( options, function (error, result) {
      if (error) {
        return console.error( 'Got an error: %s', error );
      }
      console.log( '\n Tests run successfully for the page ' + page + '\n' + JSON.stringify( result, null, ' ' ) );
    } );
  },
  connectToDB: function () {
    if (dbConfig.auth.user !== '') {
      dbUser = decipherUser.update( dbConfig.auth.user, 'hex', 'utf8' ) + decipherUser.final( 'utf8' );
    }
    if (dbConfig.auth.pass !== '') {
      dbPass = decipherPass.update( dbConfig.auth.pass, 'hex', 'utf8' ) + decipherPass.final( 'utf8' );
    }
    ;
    if (dbConfig.auth.user && dbConfig.auth.pass) {
      mongoAuth = dbUser + ':' + dbPass + '@';
    }
    for (var indx = 0; indx < dbConfig.instances.length; indx++) {
      if (indx > 0) {
        hostString += ',';
      }
      hostString += dbConfig.instances[ indx ].host + ':' + dbConfig.instances[ indx ].port;
    }
    mongoURL = 'mongodb://' + mongoAuth + hostString + '/' + config.application.mongo.db;

    db.connect( mongoURL, config.application.mongo.options, function () {
      console.log( 'The Server started at port: ' + config.http.port );
    } );

    process.on( 'SIGINT', function () {
      db.closeConnections( function () {
        process.exit( 0 );
      } );
    } );
    perfstat1 = mongoose.model( 'PerformanceStat', perfSchema );
    if (!perfstat1) {
      assert.fail( 'Looks like DB connection is not established. Connect to DB before doing any DB operations.' );
    }
    return perfstat1;

  }
}