/**
 * Created by smurugad on 3/1/16.
 */
var config = require('config' ),
    perfTest = require ('./util/performance-util.js');
var loadtst =config.application.loadtest;
function runLoadTest(){
  console.log('inside runLoadTest....');
 var  perfstat1 = perfTest.connectToDB();
  console.log('perfstat1 ==> ' + perfstat1);
  perfstat1.remove({}, function(err) {
    if (err) {
      console.log('FAIL: Error in removing all records from performanceStat collection.');
      //return cb(err);
    }});
  var url ="";
  var page = "";
  for (var i=0; i < loadtst.baseurl.length;i++){
    url = loadtst.baseurl[i].url;
    page =loadtst.baseurl[i].page;
    console.log('Starting Performance Test for Page ==> '+ page);
    perfTest.loadTest(page , url);
  }

}
runLoadTest();