/**
 * Module: EWT-2.0
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 - <E3 Production Config>
 */

'use strict';
var path = require('path');
module.exports = {
  https: {
    active: true,
    port: process.env.OPENSHIFT_NODEJS_HTTPS_PORT || 3443,
    cert: path.normalize('/etc/httpd/conf/ssl.crt/server.crt'),
    key: path.normalize('/etc/httpd/conf/ssl.key/server.key')
  },
  jumpstart: {

    contentManagement: {
      cdn: {
        CDNBaseURL: '//icm.aexp-static.com/Internet/AWF/EWT-POC/application/public/'
      },
      icm: {
        environment: 'E3',
      }
    },
    logging: {
      logToCurrentDir: false,
      logToConsole: false,
      logStash: {
        redis: {
          port: 6379,
          host: 'logserver.platforms.cto.aexp.com'
        }
      }
    },
    redis: {
      cluster: [{
        port: 7100,
        host: '10.16.31.26'
      }, {
        port: 7101,
        host: '10.16.31.26'
      }, {
        port: 7102,
        host: '10.16.31.27'
      }, {
        port: 7103,
        host: '10.16.31.27'
      }, {
        port: 7104,
        host: '10.16.31.28'
      }, {
        port: 7105,
        host: '10.16.31.28'
      }]
    },
    navigation: {
      endpoint: {
        host: 'http://navigation-intg.app.intra.aexp.com/nav/v1/',
        port: 80
      }
    },
    subscriber: {
      proxy: {
        host: 'http://proxy-appgw.aexp.com',
        port: 9090
      }
    }
  },
  application: {
    ldap: {
      endpoint: {
        host: 'ldap://adsdc-vip-e3.ads.aexp.com',
        port: '389',
      },
      baseDN: 'DC=ADS,DC=AEXP,DC=COM',
      searchAttributes: ['uid', 'givenName', 'sn', 'telephoneNumber', 'mail', 'firstName', 'lastName', 'axppmanagerid', 'axppmanageremail', 'manager', 'userAccountControl', 'sAMAccountName'],
      auth: {
        user: 'SVC.eCS.E3',
        pass: '*mcwcS79'
      }
    },
    mongo: {
      db: 'EWT',
      auth: {
        user: 'c18fd1c4c175986e44cb5ba8afd157bf',
        pass: 'd23d60e9b5a23d4bad2fa50225851a5c'
      },
      instances: [{
        host: '10.22.13.34',
        port: '27017'
      }, {
        host: '10.22.14.34',
        port: '27017'
      }, {
        host: '10.22.15.34',
        port: '27017'
      }]
    },
    email: {
      endpoint: {
        host: 'USPHX-MRLYe3-VIP.phx.aexp.com',
        port: '25'
      },
      authorizedSenders: {
        approval: 'eCS.EWT.Tech.Team@aexp.com',
        rejection: 'eCS.EWT.Tech.Team@aexp.com',
        review: 'eCS.EWT.Tech.Team@aexp.com'
      },
      recievers: {
        overwriteDefaults: false,
        mmEmail: 'Matt_EWTNodeTeam@aexp.com'
      },
      addUserUrl: 'https://central479.intra.aexp.com:4720/app#/user/new'
    },
    esp: {
      et: {
        emailIntegration: {
          emailTemplatesZip: '<%=requestId%>/smtp/<%=mhid%>_<%=deploymentDate%>/',
          emailTemplatesFolderStructure: '<%=requestId%>/smtp/<%=mhid%>_<%=deploymentDate%>/amex/ewrkflow/Experian_Reports/',
          maEmailTemplatesFolderStructure: '<%=requestId%>/<%=versionNo%>/smtp/<%=mhid%>_<%=deploymentDate%>/amex/ewrkflow/Experian_Reports/',
          htmlTemplateName: '<%=mhid%>_<%=deploymentDate%>_HTML_VER_<%=versionNo%>',
          txtTemplateName: '<%=mhid%>_<%=deploymentDate%>_TEXT_VER_<%=versionNo%>',
          imagesFileNameToEmail: '<%=requestId%>/smtp/<%=mhid%>_Image/',
          maImagesFileNameToEmail: '<%=requestId%>/<%=versionNo%>/smtp/<%=mhid%>_Image/',
          recieverEmailAddress: 'amexdeployment@salesforce.com',
          ccEmailAddress: 'dce-ewt@aexp.com',
          senderEmailAddress: 'eCS.EWT.Tech.Team@aexp.com',
          subjectLine: '<%=campaignTypeIdentifier%> E-Mail Campaign (Campaign File Name <%=mhid%>)'
        },
        sftp: {
          endpoint: {
            host: 'fsgateway.intra.aexp.com',
            port: '22'
          },
          auth: {
            user: '03d3c963a21930a82feb27c00bee4183',
            pass: 'b2b3061305a28670b3eb4230c4983cf3'
          },
          timeout: '300000',
          serverPath: '/inbox/'
        },
        soap: {
          wsdl: {
            url: 'http://pservices.web.ipc.us.aexp.com/ExactTarget_0820/wsdl'
          },
          auth: {
            user: 'b46533dda5a1d52d378a04af411c13ef',
            pass: 'f57795fd54d69dda9183d3e274b0cacb'
          }
        },
        wsIntegration: {
          campaignName: '<%=name%>^<%=requestID%>^<%=version%>',
          categoryID: '203',
          defaultEmailType: 'HTML',
          defaultCharacterSet: 'UTF-8'
        }
      },
      deployedCreatives: {
        scheduleOn: 'LVPMA1303'
      }
    }
  }
};
