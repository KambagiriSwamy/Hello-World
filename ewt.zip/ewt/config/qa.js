/**
 * Module: EWT-2.0
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 - <E2 QA Config>
 */

'use strict';

var path = require('path');
module.exports = {
  https: {
    active: true,
    port: process.env.OPENSHIFT_NODEJS_HTTPS_PORT || 3443,
    cert: path.normalize('/etc/httpd/conf/ssl.crt/qcentral472.crt'),
    key: path.normalize('/etc/httpd/conf/ssl.key/qcentral472.key')
  },
  jumpstart: {
    contentManagement: {
      cdn: {
        CDNBaseURL: '//qicm.americanexpress.com/Internet/AWF/EWT-POC/application/public/'
      },
      icm: {
        environment: 'E2',
      }
    },
    logging: {
      logToCurrentDir: true,
      logToConsole: false,
      logStash: {
        redis: {
          port: 6379,
          host: 'logserver.platforms.cto.qa.aexp.com'
        }
      }
    },
    redis: {
      cluster: [{
        port: 7100,
        host: '10.16.138.90'
      }, {
        port: 7101,
        host: '10.16.138.90'
      }, {
        port: 7102,
        host: '10.16.138.90'
      }, {
        port: 7103,
        host: '10.16.138.91'
      }, {
        port: 7104,
        host: '10.16.138.91'
      }, {
        port: 7105,
        host: '10.16.138.91'
      }]
    },
    subscriber: {
      proxy: {
        host: 'http://PHXAPPGWE2-VIP.phx.aexp.com',
        port: 9090
      }
    }
  },
  application: {
    ldap: {
      endpoint: {
        host: 'ldap://SSO2-vip.sso2.aexp.com',
        port: '389',
      },
      baseDN: 'DC=ADS-SSO-2,DC=AEXP,DC=COM',
      searchAttributes: ['uid', 'givenName', 'sn', 'telephoneNumber', 'mail', 'firstName', 'lastName', 'axppmanagerid', 'axppmanageremail', 'manager', 'userAccountControl', 'sAMAccountName'],
      auth: {
        user: 'SVC.eCS.E2',
        pass: 'V<w-cz6qs'
      }
    },
    mongo: {
      db: 'EWT',
      auth: {
        user: 'c18fd1c4c175986e44cb5ba8afd157bf',
        pass: 'd23d60e9b5a23d4bad2fa50225851a5c'
      },
      instances: [{
        host: 'LPQCLDDB00038.phx.aexp.com',
        port: '27017'
      }, {
        host: 'LPQCLDDB00040.phx.aexp.com',
        port: '27017'
      }, {
        host: 'LPQCLDDB00042.phx.aexp.com',
        port: '27017'
      }]
    },
    email: {
      endpoint: {
        host: 'LPQIU523.TRCW.US.AEXP.COM',
        port: '25'
      },
      authorizedSenders: {
        approval: 'eCS.EWT.Tech.Team@aexp.com',
        rejection: 'eCS.EWT.Tech.Team@aexp.com',
        review: 'eCS.EWT.Tech.Team@aexp.com'
      },
      recievers: {
        overwriteDefaults: true,
        mmEmail: 'EWT2.0Testing@aexp.com'
      },
      addUserUrl: 'https://qcentral472.intra.aexp.com:4720/app#/user/new'
    },
    esp: {
      et: {
        sftp: {
          endpoint: {
            host: 'fsgatewaytest.intra.aexp.com',
            port: '22'
          },
          auth: {
            user: 'ce25bcf98a0cd06f7e43396ab3e8d8e2',
            pass: '78498951db7f7195e48262cbcdb834eb'
          },
          timeout: '300000',
          serverPath: '/inbox/'
        },
        soap: {
          wsdl: {
            url: 'http://qwebservices.webqa.ipc.us.aexp.com/ExactTarget_0820/wsdl'
          },
          auth: {
            user: 'b46533dda5a1d52d378a04af411c13ef',
            pass: 'f57795fd54d69dda9183d3e274b0cacb'
          }
        }
      },
      deployedCreatives: {
        scheduleOn: 'LVQMA1151'
      }
    }
  }
};
