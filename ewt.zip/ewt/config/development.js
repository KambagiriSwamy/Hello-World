/**
 * Module: EWT-2.0
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 - <E0 Development Config>
 */

'use strict';

var path = require('path'),
  rootPath = path.normalize(__dirname + '/..');

module.exports = {
  https: {
    active: true,
    port: process.env.OPENSHIFT_NODEJS_HTTPS_PORT || 3443,
    cert: path.normalize(rootPath + '/config/ssl/cert.pem'),
    key: path.normalize(rootPath + '/config/ssl/key.pem')
  },
  jumpstart: {
    logging: {
      logToCurrentDir: true,
      logToConsole: true,
      logStash: {
        redis: {
          port: 6379,
          host: 'lvdma074.phx.aexp.com'
        }
      }
    },
    session: {
      active: true,
      redis: {
        active: false,
        sessionPrefix: 'ewt_session:',
        ttl: 600
      }
    },
    redis: {
      cluster: [{
        port: 15002,
        host: 'redisdbe1q.phx.aexp.com',
        password: 'E8r259*a'
      }],
      options: {
        retryDelayOnFailover: 2000,
        maxRedirections: 16
      },
      subscriber: {
        active: false
      }
    }
  },
  application: {
    ldap: {
      endpoint: {
        host: 'ldap://e1-metaprod-v1.app.aexp.com',
        port: '401',
      },
      baseDN: 'ou=people,o=aexp',
      searchAttributes: '', //['uid', 'givenName', 'sn', 'mail', 'axppmanagerid'],
      auth: {
        user: 'uid=ewtid,o=aexp',
        pass: 'ewt123'
      }
    },
    mongo: {
      db: 'EWT',
      auth: {
        user: '',
        pass: ''
      },
      instances: [{
        host: 'localhost',
        port: '27017'
            }]
    },
    email: {
      endpoint: {
        host: 'LPQIU523.TRCW.US.AEXP.COM',
      },
      authorizedSenders: {
        approval: 'eCS.EWT.Tech.Team@aexp.com',
        rejection: 'eCS.EWT.Tech.Team@aexp.com',
        review: 'eCS.EWT.Tech.Team@aexp.com'
      },
      recievers: {
        overwriteDefaults: true,
        mmEmail: 'Matt_EWTNodeTeam@aexp.com'
      },
      addUserUrl: 'http://localhost:3000/app#/user/new'
    },
    esp: {
      et: {
        sftp: {
          endpoint: {
            host: 'fsgatewaytest.intra.aexp.com',
            port: '22'
          },
          auth: {
            user: 'ce25bcf98a0cd06f7e43396ab3e8d8e2',
            pass: '78498951db7f7195e48262cbcdb834eb'
          },
          timeout: '300000',
          serverPath: '/inbox/'
        },
        soap: {
          wsdl: {
            url: 'http://dwebservices.trcw.us.aexp.com/ExactTarget/wsdl'
          },
          auth: {
            user: 'b46533dda5a1d52d378a04af411c13ef',
            pass: 'f57795fd54d69dda9183d3e274b0cacb'
          }
        }
      },
      deployedCreatives: {
        scheduleOn: '' // Set the hostname of your local development machine here.
      }
    },
    loadtest: {
      baseurl: [{
        'page': 'History',
        'url': 'http://localhost:3000/app#/campaigns/'
      }, {
        'page': 'New Campaign',
        'url': 'http://localhost:3000/app#/campaigns/56e194f21e208eed3beac61b'
      }, {
        'page': 'User Management List',
        'url': 'http://localhost:3000/app#/user/list'
      }, {
        'page': 'Add User',
        'url': 'http://localhost:3000/app#/user/new'
      }],
      concurrentusers: 50,
      maxRequests: 1000,
      maxSeconds: 60,
      keepalive: true,
      cookie: 'lvdma756.phx.aexp.com'
    }
  }

};
