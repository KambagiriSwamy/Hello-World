/**
 * Module: EWT-2.0
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 - <E1 Integration Config>
 */

'use strict';

var path = require('path');

module.exports = {
  https: {
    active: true,
    port: process.env.OPENSHIFT_NODEJS_HTTPS_PORT || 3443,
    cert: path.normalize('/etc/httpd/conf/ssl.crt/server.crt'),
    key: path.normalize('/etc/httpd/conf/ssl.key/server.key')
  },
  jumpstart: {
    contentManagement: {
      cdn: {
        CDNBaseURL: ''
      },
      icm: {
        environment: 'E1'
      }
    },
    logging: {
      logToCurrentDir: true,
      logToConsole: true,
      logStash: {
        redis: {
          port: 6379,
          host: 'lvdma074.phx.aexp.com'
        }
      },
      stage: {
        eventLogFilePath: 'logs/en/event/',
        auditLogFilePath: 'logs/en/audit/',
        appReportLogFilePath: 'logs/en/appreport/'
      }
    },
    redis: {
      cluster: [{
        port: 15002,
        host: 'redisdbe1q.phx.aexp.com',
        password: 'E8r259*a'
      }],
      options: {
        retryDelayOnFailover: 2000,
        maxRedirections: 16
      },
      subscriber: {
        active: false
      }
    },
    subscriber: {
      proxy: {
        host: 'http://PHXAPPGWE2-VIP.phx.aexp.com',
        port: 9090
      }
    }
  },
  application: {
    ldap: {
      endpoint: {
        host: 'ldap://SSO1-vip.sso1.aexp.com',
        port: '389'
      },
      baseDN: 'DC=ADS-SSO-1,DC=AEXP,DC=COM',
      searchAttributes: ['uid', 'givenName', 'sn', 'telephoneNumber', 'mail', 'firstName', 'lastName', 'axppmanagerid', 'axppmanageremail', 'manager', 'userAccountControl', 'sAMAccountName'],
      auth: {
        user: 'SVC.eCS.E1',
        pass: '6qs+V<w-cz'
      }
    },
    mongo: {
      db: 'EWTCAMPAIGN',
      auth: {
        user: '2affd35cd64a66a4c111a5de7f28051a',
        pass: 'f9a27001bc2d09245163dfca7d3a9fef'
      },
      instances: [{
        host: 'lpdwd531.phx.aexp.com',
        port: '27017'
      }, {
        host: 'lpdwd540.phx.aexp.com',
        port: '27017'
      }, {
        host: 'lpdwd539.phx.aexp.com',
        port: '27017'
      }]
    },
    email: {
      endpoint: {
        host: 'LPQIU523.TRCW.US.AEXP.COM',
      },
      authorizedSenders: {
        approval: 'eCS.EWT.Tech.Team@aexp.com',
        rejection: 'eCS.EWT.Tech.Team@aexp.com',
        review: 'eCS.EWT.Tech.Team@aexp.com'
      },
      recievers: {
        overwriteDefaults: true,
        mmEmail: 'EWT2.0Testing@aexp.com'
      },
      addUserUrl: 'https://lvdma756.phx.aexp.com:1443/app#/user/new'
    },
    esp: {
      et: {
        sftp: {
          endpoint: {
            host: 'fsgatewaytest.intra.aexp.com',
            port: '22'
          },
          auth: {
            user: 'ce25bcf98a0cd06f7e43396ab3e8d8e2',
            pass: '78498951db7f7195e48262cbcdb834eb'
          },
          timeout: '300000',
          serverPath: '/inbox/'
        },
        soap: {
          wsdl: {
            url: 'http://dwebservices.trcw.us.aexp.com/ExactTarget/wsdl'
          },
          auth: {
            user: 'b46533dda5a1d52d378a04af411c13ef',
            pass: 'f57795fd54d69dda9183d3e274b0cacb'
          }
        }
      },
      deployedCreatives: {
        scheduleOn: 'LVDMA756'
      }
    },
    loadtest: {
      baseurl: [{
        'page': 'History',
        'url': 'http://10.20.154.175:3000/app#/campaigns/'
      }, {
        'page': 'New Campaign',
        'url': 'http://10.20.154.175:3000/app#/campaigns/56e194f21e208eed3beac61b'
      }, {
        'page': 'User Management List',
        'url': 'http://10.20.154.175:3000/app#/user/list'
      }, {
        'page': 'Add User',
        'url': 'http://10.20.154.175:3000/app#/user/new'
      }],
      concurrentusers: 50,
      maxRequests: 1000,
      maxSeconds: 60,
      keepalive: true,
      cookie: 'lvdma756.phx.aexp.com'
    }
  }
};
