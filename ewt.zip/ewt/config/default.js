/**
 * Module: EWT-2.0
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 - <E1,2,3 Common Config>
 *
 * engine-version 1.1.10
 *
 */

'use strict';

var path = require('path'),
  rootPath = path.normalize(__dirname + '/..');

module.exports = {
  applicationName: 'ewt2',
  aimID: '12345',
  root: rootPath,
  defaultURL: '/app',
  processUncaughtException: false,
  http: {
    ip: process.env.OPENSHIFT_NODEJS_IP || process.env.HOSTNAME || '0.0.0.0',
    port: process.env.OPENSHIFT_NODEJS_PORT || 3000
  },
  https: {
    active: true,
    port: process.env.OPENSHIFT_NODEJS_HTTPS_PORT || 3443
  },
  jumpstart: {
    locale: {
      default: {
        lang: 'en',
        country: 'US',
        face: 'en_US'
      },
      supportedLocales: ['en_US', 'es_US']
    },
    redis: {
      options: {
        retryDelayOnFailover: 2000,
        maxRedirections: 16
      }
    },
    sharedServices: {
      serviceTimeouts: {
        default: 6000
      }
    },
    express: {
      viewEngines: {
        defaultTemplateExt: 'dust',
        supported: {
          dust: true
        }
      }
    },
    contentManagement: {
      cdn: {
        CDNSrcFiles: ['**/*.{js,css,gif,png,jpg,jpeg}'],
        //CDNBaseURL: '//icm.aexp-static.com/Internet//EWT-POC/application/public/'
        CDNBaseURL: ''
      },
      icm: {
        //client: '', // iCM Publication
        client: 'AWF',
        user: '', // Faceless id for application
        //contentOwner: '', // Content Owner
        //applicationOwner: '', // Allication Owner,
        //content_root: '/EWT-POC', // Name of the base folder in iCM publication
        contentOwner: 'AXPi Wissam - 030 950 809', // Content Owner
        applicationOwner: 'PZN - 131254092', // Allication Owner,
        content_root: 'AWF/EWT-POC', // Name of the base folder in iCM publication
        environment: 'E1',
        endpoint: {
          host: 'http://services.icmawf.intra.aexp.com/iCMWebAPI'
        }
      }
    },
    navigation: {
      active: false,
      endpoint: {
        host: 'http://navigation-intg.app.intra.aexp.com/nav/v1',
        port: 80
      },
      timeout: 5000,
      cache: {
        segment: 'iNavigation'
      },
      postData: {
        header: true,
        footer: true
      },
      routeOptions: [{
        active: false,
        routes: ['/demo/system/info', '/demo/system/info/*']
      }]
    },
    deviceProfile: {
      active: false,
      endpoint: {
        host: 'http://mycaservicese2sonline.webqa.ipc.us.aexp.com:5555/shared/services/digital/deviceprofileservice/v1/getDeviceProfile',
      },
      timeout: 2000,
      clientID: 'webframeworks',
      msgType: 'json',
      cookieAge: 900000
    },
    logging: {
      levels: {
        info: 1,
        debug: 2,
        warning: 3,
        error: 4,
        audit: 5,
        interactiveAudit: 6,
        appReport: 7,
        internal: 8
      },
      stage: {
        eventLogFilePath: '/logs/en/event/',
        auditLogFilePath: '/logs/en/audit/',
        appReportLogFilePath: '/logs/en/appreport/'
      },
      logFiles: {
        timestamp: '.yyyy-MM-ddTHH'
      },
      internalLog: 'Elk'
    },
    spud: {
      destDirPath: '/application/public/locales/json',
      srcDirPath: '/application/public/locales'
    },
    duster: {
      destDirPath: '/application/public/js/dust-tpls',
      srcDirPath: '/application/public/views/common',
      skipPathFromTemplateId: '/application/public/views/'
    },
    broker: {
      host: '10.20.159.144',
      port: 61613,
      userID: 'admin',
      password: 'password',
      protocolVersion: '1.0',
      icmSubscribe: {
        topic: '/topic/icmpublish'
      }
    },
    session: {
      active: true,
      sessionSecretKey: 'testabc',
      redis: {
        active: true,
        sessionPrefix: 'ewt_session:',
        ttl: 3600 // user session should last 1 hour.
      }
    },
    subscriber: {
      active: false,
      proxy: {
        host: '',
        port: 0
      },
      domains: ['aexp.com', 'americanexpress.com', 'localhost']
    },
    security: {
      xframe: 'SAMEORIGIN',
      csp: {
        active: false,
        defaultSrc: [
          '\'self\'',
          'cdn.example.com'
        ],
        scriptSrc: [
          '\'self\'',
          '\'unsafe-inline\'',
          '\'unsafe-eval\'',
          'qwww.aexp-static.com',
          'nexus.ensighten.com',
          'www.aexp-static.com'
        ],
        styleSrc: [
          '\'self\'',
          '\'unsafe-inline\'',
          'qwww.aexp-static.com',
          'www.aexp-static.com'
        ],
        imgSrc: [
          '\'self\'',
          'dstatic.dev.ipc.us.aexp.com',
          'qwww.aexp-static.com',
          'omn.americanexpress.com',
          'nexus.ensighten.com',
          'l.betrad.com'
        ],
        connectSrc: ['\'self\''],
        fontSrc: [
          '\'self\'',
          'qwww.aexp-static.com'
        ],
        objectSrc: ['\'self\''],
        mediaSrc: ['media.example.com'],
        frameSrc: ['\'self\''],
        sandbox: [
          'allow-forms',
          'allow-scripts'
        ],
        reportUri: '/some-report-uri', // Error Reporting URL
        reportOnly: true, // set to true if you only want to report errors
        setAllHeaders: true, // set to true if you want to set all headers
        safari5: false // set to true if you want to force buggy CSP in Safari 5
      },
      xss: {
        escapeBody: {
          active: false
        }
      },
      csrf: {
        active: false,
        csrf_cookie: 'XSRF-TOKEN'
      }
    }
  },
  application: {
    email: {
      endpoint: {
        host: 'SN2PRD9301.PROD.outlook.com',
        port: 25
      },
      auth: {
        user: 'hehe',
        pass: 'hehe'
      }
    },
    logging: {   
      validDomains: ['\\.americanexpress\\.com$', '\\.aexp\\.com$', '\\localhost\\.aexp\\.com$', '\\localhost:', '\\.swagger\\.io']  
    },
    esp: {
      et: {
        tempFileLocation: rootPath + '/apptmp/espfiles/',
        emailIntegration: {
          emailTemplatesZip: '<%=requestId%>/smtp/<%=mhid%>_<%=deploymentDate%>/',
          emailTemplatesFolderStructure: '<%=requestId%>/smtp/<%=mhid%>_<%=deploymentDate%>/amex/ewrkflow/Experian_Reports/',
          maEmailTemplatesFolderStructure: '<%=requestId%>/<%=versionNo%>/smtp/<%=mhid%>_<%=deploymentDate%>/amex/ewrkflow/Experian_Reports/',
          htmlTemplateName: '<%=mhid%>_<%=deploymentDate%>_HTML_VER_<%=versionNo%>',
          txtTemplateName: '<%=mhid%>_<%=deploymentDate%>_TEXT_VER_<%=versionNo%>',
          imagesFileNameToEmail: '<%=requestId%>/smtp/<%=mhid%>_Image/',
          maImagesFileNameToEmail: '<%=requestId%>/<%=versionNo%>/smtp/<%=mhid%>_Image/',
          recieverEmailAddress: 'amexewttesting@salesforce.com',
          ccEmailAddress: 'EWT2.0Testing@aexp.com',
          senderEmailAddress: 'eCS.EWT.Tech.Team@aexp.com',
          subjectLine: '<%=campaignTypeIdentifier%> E-Mail Campaign (Campaign File Name <%=mhid%>)'
        },
        fileUploadIntegration: {
          finalUploadArtifactLocation: '<%=requestId%>/sftp/<%=mhid%>/',
          dataFileNameToUpload: '<%=requestId%>/sftp/<%=mhid%>/<%=cmpExtn%>_<%=mhid%>_<%=requestId%>_<%=deploymentDate%>/',
          htmlTemplateName: '<%=mhid%>_<%=deploymentDate%>_HTML_VER_<%=versionNo%>',
          txtTemplateName: '<%=mhid%>_<%=deploymentDate%>_TEXT_VER_<%=versionNo%>',
          imagesFolderStructure: 'Images_<%=mhid%>_<%=requestId%>_<%=deploymentDate%>/',
          emailTemplatesFolderStructure: 'EmailTemplate_<%=mhid%>_<%=requestId%>_<%=deploymentDate%>/',
          metaDataFileName: 'CmpgnData_<%=mhid%>_<%=requestId%>_<%=deploymentDate%>.txt'
        },
        wsIntegration: {
          campaignName: '<%=name%>^<%=requestID%>^<%=version%>',
          maCampaignName: '<%=name%>^<%=requestID%>^<%=mhid%>^<%=cellid%>^<%=depDate%>^<%=version%>',
          categoryID: '2410086',
          defaultEmailType: 'HTML',
          defaultCharacterSet: 'UTF-8'
        }
      }
    }
  },
  hostname: process.env.HOST || process.env.HOSTNAME
};
