/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-POC - <DESC_HERE>
 */

'use strict';

var gulp = require('gulp'),
  path = require('path'),
  rootPath = path.normalize(__dirname),
  gulpConfig = require('config');

// Register helper
require('gulp-help')(gulp, { description: 'you are looking at it.', aliases: ['h', '?'] });

// Register duster, spud and mandatory gulp tasks including tests
require('./application/public/gulp_build/gulps')(gulp, gulpConfig);
require('jumpstart-engine').gulps(gulp, gulpConfig);

// 'help' task is registered in the engine
gulp.task('default', false, function () {
  gulp.start('help');
});
