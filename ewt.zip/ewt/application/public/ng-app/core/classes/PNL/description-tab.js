/**
 * Module: UI - PNL-- Description Tab Service
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2016 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: ERA -  Bussiness logic specific to PNL description tabs will be handled in this file.
 */

'use strict';

angular.module('ewtApp').service('pnlDescription', ['$filter', 'ewtMasterDataService', 'ewtUtils', 'campaignDurationWeeks',
  function($filter, ewtMasterDataService, ewtUtils, campaignDurationWeeks) {
    
    var pnlDescription = {
      events: {
        /**
         * Name: emailTypeChange
         * Description: called when th emial type is changed to PNL in the drop down
         *             resets the values according to type of email selected
         */
        emailTypeChange: function(campaign, data, initLoadData) {
          campaign.arbitrationStatus = {};
          data.weeksArray = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
          
          /* Reset the CommCode and Products to Show */
          campaign.commCode = {};
          data.productsshow = [];
          data.dynamicCampaigns = angular.copy(initLoadData.dynamicCampaigns);
          data.campaignDurationWeeks = campaignDurationWeeks.ET_PNL;
          campaign.emailType = angular.copy(ewtUtils.getSelectedObject(campaign.emailType, initLoadData.emailTypes, 'codeName'));
          // removing extra dynamic campaign
          var indexToRemove = data.dynamicCampaigns.indexOf($filter('filter')(data.dynamicCampaigns, {
            'codeName': 'MEMBERSHIP_REWARDS'
          }, true)[0]);
          data.dynamicCampaigns.splice(indexToRemove, 1);
        },
        /**
         * [businessUnitChange This function in invoked when business unit changes in dropdonw
         *  and it makes a api call to get the respective cm opt out categories and update in the view]
         *  It disable the deployment date selection in case of One Off campaign
         */
        businessUnitChange: function(campaign, data, initLoadData) {
          console.log('2. BU Service Call with' + campaign.businessUnit.code);
          campaign.primaryCmNeedCategory = {};
          campaign.isMultiCMNeedCategory = 'false';
          data.commCode = $filter('filter')(initLoadData.commCodes, {
            'businessUnitCode': campaign.businessUnit.code
          }, true);
          campaign.commCode = {};
          data.productsshow = [];
          data.dynamicCampaigns = angular.copy(initLoadData.dynamicCampaigns);
          /*  campaign.allCMCategoryList = $filter('filter')(initLoadData.cmNeedCategories, {
           'businessUnitCode': campaign.businessUnit.code
           }, true);
           campaign.allCMCategoryAvailableList = $filter ('filter') (initLoadData.cmNeedCategories, {
           'businessUnitCode': campaign.businessUnit.code
           }, true);*/
        }
      } // End of Events
    }
    return pnlDescription;
  }
])
