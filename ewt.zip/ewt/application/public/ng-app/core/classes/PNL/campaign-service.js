/**
 * Module: UI StatepnlCampaign
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2016 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: ERA -- PNL Service entry for all the events and validation methods.
 */

'use strict';

angular.module('ewtApp')
  .service('pnlCampaign', ['$filter', 'ewtMasterDataService', 'ewtUtils', 'pnlDescription', 'pnlMailplan',
    function($filter, ewtMasterDataService, ewtUtils, pnlDescription, pnlMailplan) {

      var scope, campaign, campaignService, data;

      var pnlCampaign = {
        init: function($scope) {
          scope = $scope;
          campaign = $scope.campaign;
          campaignService = $scope.campaignService;
          data = $scope.data;
        },
        events: {
          description: {
            /**
             * Name: emailTypeChange
             * Description: called when th emial type is changed to PNL in the drop down
             *             resets the values according to type of email selected
             */
            emailTypeChange: function(campaign, data, initLoadData) {
              pnlDescription.events.emailTypeChange(campaign, data, initLoadData);
            },
            businessUnitChange: function(campaign, data, initLoadData) {
              pnlDescription.events.businessUnitChange(campaign, data, initLoadData);
            }
          },
          mailplan: {
            updateCell: function() {},
            updateVersion: function(campaign, version, index) {
              pnlMailplan.events.updateVersion(campaign, version, index);
            },
            addSubjectLine: function(campaign, version, subjectLine) {
              pnlMailplan.events.addSubjectLine(campaign, version, subjectLine);
            },
            updateSubjectLine: function(campaign, versionNo, slIndex, subject) {
              pnlMailplan.events.updateSubjectLine(campaign, versionNo, slIndex, subject);
            },
            removeSubjectLine: function(campaign, versionNo, index) {
              pnlMailplan.events.removeSubjectLine(campaign, versionNo, slIndex, subject);
            }
          }
        }
      }
      return pnlCampaign;
    }
  ])
