/**
 * Module: PNL -- Mailplan Tab Service
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2016 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: ERA -- PNL Mailplan tab events / validations  
 */

'use strict';

angular.module('ewtApp')
  .service('pnlMailplan', ['$filter', 'ewtMasterDataService', 'ewtUtils', 'campaignDurationWeeks', 'oneOffMailplan',
    function($filter, ewtMasterDataService, ewtUtils, campaignDurationWeeks, oneOffMailplan) {
      // PNL Mailplan tab functionality is same as One-off, so expose the one-off service -- have the logic in one place to avoid bugs.
      return oneOffMailplan;
    }
  ]);
