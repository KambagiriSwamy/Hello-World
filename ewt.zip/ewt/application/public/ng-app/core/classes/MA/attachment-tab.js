/**
 * Module: UI - PNL-- Description Tab Service
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT - <DESC_HERE>
 */

'use strict';

angular.module('ewtApp')
  .service('maAttachment', ['$filter', 'ewtMasterDataService', 'ewtUtils', 'campaignDurationWeeks',
    function($filter, ewtMasterDataService, ewtUtils, campaignDurationWeeks) {
      var maAttachment = {
        init: {
          setDeployedCreativeObject: function(mhid, startDate, cellId, description, versionId, gfsId, fileName, actualDeploymentDate) {
            this.mhid = mhid;
            this.startDate = startDate;
            this.cellId = cellId;
            this.description = description;
            this.versionId = versionId;
            this.gfsId = gfsId;
            this.fileName = fileName;
            this.actualDeploymentDate = actualDeploymentDate;
          },
          /* Construct MA creative Object */
          getDeployedDisplayObject: function() {
            for (var maindex = 0; maindex < campaign.ma.mailHistory.length; maindex++) {
              for (var cellindex = 0; cellindex < campaign.ma.mailHistory[maindex].cells.length; cellindex++) {
                for (var versionIndex = 0; versionIndex < campaign.ma.maVersions.length; versionIndex++) {

                  /* Call  getDeployedCreatives with version id and deployment date. */
                  deployedCreative = this.getDeployedCreatives(campaign.ma.maVersions[versionIndex].versionId, campaign.ma.mailHistory[maindex].startDate);

                  /* Check if the cell is not cancelled and cell is not a Holdout cell. */
                  if (deployedCreative && deployedCreative.gfsID && campaign.ma.maVersions[versionIndex].versionId !== '0' &&
                    campaign.ma.mailHistory[maindex].cells[cellindex].type.codeName !== 'control') {

                    /* Populate the object  */
                    var deployedCreativeObject = new setDeployedCreativeObject(campaign.ma.mailHistory[maindex].mhid,
                      deployedCreative.scheduledDeploymentDate,
                      campaign.ma.mailHistory[maindex].cells[cellindex].srcCode,
                      campaign.ma.mailHistory[maindex].cells[cellindex].description,
                      campaign.ma.maVersions[versionIndex].versionId,
                      deployedCreative.gfsID, deployedCreative.fileName,
                      deployedCreative.actualDeploymentDate);

                    result.push(deployedCreativeObject);
                  }
                }
              }
            }
          },
          /* The below method return the deployedCreative for a given version
           *  This method returns deployment Date, gfsID,fileName as an object
           */
          getDeployedCreatives: function(versionNo, depDate) {
            var deployedCreative = {};
            var depCreaDate = '';
            var maDepDt = depDate; // Step 1. Convert to Date format.
            if (campaign.deployedCreatives && depDate && versionNo) {
              campaign.deployedCreatives.forEach(function(dep) {
                depCreaDate = new Date(dep.scheduledDeploymentDate).dateToString();
                if (dep.scheduledDeploymentDate && dep.versionNo === versionNo && maDepDt === depCreaDate) {
                  deployedCreative.scheduledDeploymentDate = dep.scheduledDeploymentDate;
                  deployedCreative.actualDeploymentDate = dep.actualDeploymentDate;
                  deployedCreative.deploymentDate = dep.deploymentDate;
                  deployedCreative.gfsID = dep.gfsID;
                  deployedCreative.fileName = dep.fileName;
                  return deployedCreative;
                }
              });
            }
            return deployedCreative;
          }
        }
      }
    }]);