/**
 * Module: UI - PNL-- Description Tab Service
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT - <DESC_HERE>
 */

'use strict';

angular.module('ewtApp')
  .service('maDescription', ['$filter', 'ewtMasterDataService', 'ewtUtils', 'campaignDurationWeeks',
    function($filter, ewtMasterDataService, ewtUtils, campaignDurationWeeks) {

      var maDescription = {
        events: {
          /**
           * Name: emailTypeChange
           * Description: called when th emial type is changed in the drop down
           *             resets the values according to type of email selected
           */
          emailTypeChange: function(campaign, data, initLoadData) {
            campaign.isDynamicCampaign = 'false';
            campaign.dynamicCampaigns = [];
            data.dynamicCampaigns = angular.copy(initLoadData.dynamicCampaigns);
            campaign.emailType = angular.copy(ewtUtils.getSelectedObject(campaign.emailType, initLoadData.emailTypes, 'codeName'));
            //campaign.emailType          = angular.copy(ewtUtils.getSelectedObject(campaign.emailType, initLoadData.emailTypes, 'codeName'));
            if (!campaign.deploymentDates[0]) {  // && campaign.deploymentDates[0].getDate() == 0) {
              campaign.deploymentDates = [];
            }

            /**
             * removing special dynamic campaign that get added only if email type is One Off
             * check whether that dynamic campaign is present and then remove.
             * This functionality has to be revisited while in the time of Triggers and hourly triggers
             */
            campaign.arbitrationStatus = {
              code: 'N'
            };
            data.campaignDurationWeeks = campaignDurationWeeks.ET_MA;
            campaign.isMultiCMNeedCategory = 'false';
            //flag to know at least one mhid is having same date as campaign start date      weeksArray = [1];
            campaign.atleastOneDateEqual = true;
            campaign.durationInWeeks = 1;

            // removing extra dynamic campaign
            if (data.dynamicCampaigns) {
              var indexToRemove = data.dynamicCampaigns.indexOf($filter('filter')(data.dynamicCampaigns, {
                'codeName': 'MEMBERSHIP_REWARDS'
              }, true)[0])
              data.dynamicCampaigns.splice(indexToRemove, 1);
            }
          },
          /**
           * [businessUnitChange This function in invoked when business unit changes in dropdonw
           *  and it makes a api call to get the respective cm opt out categories and update in the view]
           *  It disable the deployment date selection in case of One Off campaign
           */
          businessUnitChange: function(campaign, data, initLoadData) {
            console.log('1. BU == ' + campaign.businessUnit.code);
            campaign.primaryCmNeedCategory = {};
            data.tempPrimaryCMNeedCategory = {};
            campaign.isMultiCMNeedCategory = 'false';
            campaign.allCMCategorySelectedList = [];
            // Disable the deployment date when BU changed in case of ONE OFF Campaign.
            if (campaign.emailType.codeName === "ET_ONEOFF") {
              campaign.deploymentDates = [];
              data.oneoffDeploymentWeek = '99';
            }
            if (campaign.emailType.codeName === "ET_PNL") {
              console.log(' BU == ' + campaign.businessUnit.code);
              data.commCode = $filter('filter')(initLoadData.commCodes, {
                'businessUnit': campaign.businessUnit.code
              }, true);
              campaign.commCode = {};
              data.productsshow = [];
            }
            campaign.allCMCategoryList = $filter('filter')(initLoadData.cmNeedCategories, {
              'businessUnitCode': campaign.businessUnit.code
            }, true);
            campaign.allCMCategoryAvailableList = $filter('filter')(initLoadData.cmNeedCategories, {
              'businessUnitCode': campaign.businessUnit.code
            }, true);
          },
        }
      }
      return maDescription;
    }
  ]);
