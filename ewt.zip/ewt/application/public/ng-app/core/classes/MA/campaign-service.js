/**
 * Module: UI State
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT - <DESC_HERE>
 */

'use strict';
angular.module('ewtApp')
  .service('maCampaign', ['$filter', 'ewtMasterDataService', 'ewtUtils', 'maDescription',
    function($filter, ewtMasterDataService, ewtUtils, maDescription) {

      var scope, campaign, campaignService, data;

      var maCampaign = {
        init: function($scope) {
          scope = $scope;
          campaign = $scope.campaign;
          campaignService = $scope.campaignService;
          data = $scope.data;
        },
        events: {
          description: {
            /**
             * Name: emailTypeChange
             * Description: called when th emial type is changed to PNL in the drop down
             *             resets the values according to type of email selected
             */
            emailTypeChange: function(campaign, data, initLoadData) {
              maDescription.events.emailTypeChange(campaign, data, initLoadData);
            },
            businessUnitChange: function(campaign, data, initLoadData) {
              maDescription.events.businessUnitChange(campaign, data, initLoadData);
            }
          },
          mailplan: {
            updateCell: function() {}
          }
        } // End of Events.
      }
      return maCampaign;
    }
  ]);
