'use strict';

/**
 * @ngdoc service
 * @name ewtApp.campaign
 * @description
 * # campaign 
 * Service in the ewtApp.
 */


angular.module('ewtApp')
  .factory('ewtUsers', ['$resource', 'APIServer', 'ewtUtils', '$state', function(resource, APIServer, ewtUtils, $state) {
    /**
     * url - contains URL to hit for backend actions to be performed
     * @type {[string]}
     */
    var url = APIServer + 'users/:id';

    /**
     * transformUserRequest - This function transfroms request befor sending it to http
     * @param  {Object} request - requested object to the http
     * @return {string}           Stringified form of request.
     */
    var transformUserRequest = function(req) {
      var request = angular.copy(req);

      /**
       * @ Transform request here
       */
      if (request._id) {
        request.businessUnit = ewtUtils.getSelectedObject(request.businessUnit, request.initLoadData.businessUnits, 'codeName');
        request.role = ewtUtils.getSelectedObject(request.role, request.initLoadData.userRoles, 'codeName');
        request.status = ewtUtils.getSelectedObject(request.status, request.initLoadData.userStatus, 'codeName');
      }
      delete request.initLoadData;
      delete request.modal;
      return angular.toJson(request);
    };


    /**
     * transformUserResponse - This function transforms response from http before sending to succes CallBack
     * @param  {String} response - response from http
     * @return {Object}          Object to be sent to success CallBack of http
     */
    var transformUserResponse = function(res) {
      var response = angular.fromJson(res);

      /**
       * @ Transform response here
       */
      return response;
    };

    /**
     * ewtUser - resource object for performing CRUD operations on Users
     * @type {Object}
     */
    var ewtUser = resource(url, {
      'id': '@_id'
    }, {
      get: {
        method: 'get',
        url: APIServer + 'users/search',
        isArray: true,
        transformResponse: transformUserResponse,
        interceptor: {
          response: function(response) {
            var result = response.resource;
            result.$status = response.status;
            return result;
          }
        }
      },
      search: {
        method: 'POST',
        url: APIServer + 'users/search',
        isArray: true,
        transformResponse: transformUserResponse,
        interceptor: {
          response: function(response) {
            var result = response.resource;
            result.$status = response.status;
            return result;
          }
        }
      },
      query: {
        method: 'GET',
        url: APIServer + 'user/:id',
        isArray: false,
        transformResponse: transformUserResponse
      },
      save: {
        method: 'POST',
        isArray: false,
        url: APIServer + 'users/:id',
        transformResponse: transformUserResponse,
        transformRequest: transformUserRequest
      },
      update: {
        method: 'POST',
        url: APIServer + 'users/:id',
        interceptor: {
          response: function(response) {
            var result = response.resource;
            result.$status = response.status;
            return result;
          }
        },
        transformResponse: transformUserResponse,
        transformRequest: transformUserRequest
      },
      delete: {
        method: 'GET',
        url: APIServer + 'users/delete/:id',
        interceptor: {
          response: function(response) {
            var result = response.resource;
            result.$status = response.status;
            return result;
          }
        }
      }
    });


    /**
     * This function sends the search criteria object to list state where it is resolved 
     * and result is obtained
     * @param  {Object} search [search user object containes filter keys of the users details]
     */
    ewtUser.prototype.findUser = function(search) {
      $state.go('app.auth.users.list', {
        search: search
      });
    };

    /**
     * This functions will make api call and get the data as a promise object
     * if id is provided, it will fetch only user with that _id from Database 
     * or else it will get all the user with the search criteria object sent to server
     * @param  {Object} search [Object of the Search criteria or Object with _id of the user]
     * @return {Promise}       [Returns the list of users or a single user]
     */
    ewtUser.prototype.getUsers = function(search) {
      if (search && search._id) {
        return ewtUser.query({
          id: search._id
        }).$promise;
      } else {
        return ewtUser.search(search).$promise;
      }
    };
    ewtUser.prototype.users = function(search) {
      return ewtUser.get(search).$promise;
    }

    /**
     * This function is call to add a new user into the Database using add user api call.
     * It store new user object from User form into the Database
     * @param {Object} newUser [new user information]
     * @return {Promise}       [Returns the new User data stored in Database]
     */

    ewtUser.prototype.addUser = function(newUser) {
      if (newUser) {
        return ewtUser.save(newUser).$promise;
      }
    };

    /**
     * This function update the user detials and save it into Database.
     * It stores new User data against old data by finding it usnig _id provided
     * When Update is done it will switch to list state of the application
     * @param  {Object} updateUserObj Updated user details information  
     */
    ewtUser.prototype.updateUser = function(updateUserObj) {
      if (updateUserObj) {
        ewtUser.update({
          id: updateUserObj._id
        }, updateUserObj).$promise.then(
          // Success handler
          function(response, error) {
            $state.go('app.auth.users.list');
          },
          // Error handler for non-200 responses from server
          function(response) {
            if ((response) && (response.data) && (response.data.code === 'SESSION_EXPIRED') && (response.data.reason)) {
              alert(response.data.reason);
            }
          }
        );
      }
    };

    function deleteUserModelFunction(deleteUser, deleteUserSuccessHandler) {
      ewtUser.delete({
        id: deleteUser._id
      }).$promise.then(
        // Success handler
        function(response, error) {
          if (response && response.$status === 200 && response.msg) {
            if ($state.current.name === 'app.auth.users.edit') {
              $state.go('app.auth.users.list');
            } else {
              deleteUserSuccessHandler();
            }
          } else {
            console.log('Not able to delete user');
          }
        },
        // Error handler for non-200 responses from server
        function(response) {
          if ((response) && (response.data) && (response.data.showOnUI) && (response.data.reason)) {
            alert(response.data.reason);
          }
        }
      );
    }

    /**
     * This function will delete the user from the database and navigate to user list page on success
     * @param  {object} deleteUser [object of the user to be deleted]
     * @param  {function} deleteUserSuccessHandler Callback need to be executed after delete api success
     */
    ewtUser.prototype.deleteUser = function(deleteUser, deleteUserSuccessHandler, message) {
      if (deleteUser && deleteUser._id) {
        this.modal.open({
          'message': message,
          'actionButtons': [{
            'label': 'Yes',
            'buttonType': 'success',
            'callBack': function() {
              deleteUserModelFunction(deleteUser, deleteUserSuccessHandler);
            }
          }, {
            'label': 'No',
            'buttonType': 'error',
            'callBack': function() {}
          }]
        });
      }
    };
    return ewtUser;
  }]);
