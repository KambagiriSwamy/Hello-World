/**
 * Module: Campaign-service -- to address servicing specific events , validations.
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2016 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: ERA  -- Servicing events / validation methods.
 */

'use strict';

angular.module('ewtApp')
  .service('servicingCampaign', ['$filter', 'ewtMasterDataService', 'ewtUtils', 'servicingDescription', 'servicingMailplan',
    function($filter, ewtMasterDataService, ewtUtils, servicingDescription, servicingMailplan) {

      var scope, campaign, campaignService, data;

      var servicingCampaign = {
        init: function($scope) {
          scope = $scope;
          campaign = $scope.campaign;
          campaignService = $scope.campaignService;
          data = $scope.data;
        },
        events: {
          description: {
            /**
             * Name: emailTypeChange
             * Description: called when th emial type is changed to PNL in the drop down
             *             resets the values according to type of email selected
             */
            emailTypeChange: function(campaign, data, initLoadData) {
              servicingDescription.events.emailTypeChange(campaign, data, initLoadData);
            },
            businessUnitChange: function(campaign, data, initLoadData) {
              servicingDescription.events.businessUnitChange(campaign, data, initLoadData);
            }
          },
          mailplan: {
            updateCell: function(campaign, cell, index) {
              servicingMailplan.events.updateCell(cell);
            },
            addSubjectLine: function(campaign, version, subjectLine) {
              servicingMailplan.events.addSubjectLine(campaign, version, subjectLine);
            },
            updateSubjectLine: function(campaign, versionNo, slIndex, subject) {
              servicingMailplan.events.updateSubjectLine(campaign, versionNo, slIndex, subject);
            },
            removeSubjectLine: function(campaign, versionNo, index) {
              servicingMailplan.events.removeSubjectLine(campaign, versionNo, index);
            }
          }
        }
      }
      return servicingCampaign;
    }
  ])
