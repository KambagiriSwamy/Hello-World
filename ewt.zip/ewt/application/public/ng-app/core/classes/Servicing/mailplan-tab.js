/**
 * Module: Servicing -- Mailplan Tab Service
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2016 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: ERA -- Servicing Mailplan tab events / validations  
 */

'use strict';

angular.module('ewtApp')
  .service('servicingMailplan', ['$filter', 'ewtMasterDataService', 'ewtUtils', 'campaignDurationWeeks',
    function($filter, ewtMasterDataService, ewtUtils, campaignDurationWeeks) {

      var servicingMailplan = {
        events: {
          updateCell: function(cell) {
            // For servicing only mailable cells are allowed.
            /**
             * Commenting this part of code as this is already taken care in 
             * controller method - 'populateCells'
             *
             * ideally populateCells should be moved to a service.
             */

            // cell.type = $filter('filter')(this.initLoadData.cellTypes, {
            //   codeName: 'test' // 'test' is mailable cell
            // }, true)[0];
          },
          addSubjectLine: function(campaign, version, subjectLine) {
            campaign.subjectLinesArr.push(subjectLine);
          },
          updateSubjectLine: function(campaign, versionNo, slIndex, subject) {
            campaign.subjectLinesArr.splice(slIndex, 1, subject);
          },
          removeSubjectLine: function(campaign, versionNo, index) {
            if (index >= 0 && index < campaign.subjectLinesArr.length) {
              campaign.subjectLinesArr.splice(index, 1);
            } else if (versionNo) {
              for (var indx = campaign.subjectLinesArr.length - 1; indx >= 0; indx--) {
                if (campaign.subjectLinesArr[indx].number === versionNo) {
                  campaign.subjectLinesArr.splice(indx, 1);
                }
              }
            }
          }
        }
      }
      return servicingMailplan;
    }
  ]);
