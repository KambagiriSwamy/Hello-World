/**
 * Module: Common -- Mailplan Tab Service
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2016 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: ERA -- Common Mailplan tab events / validations
 */

'use strict';

angular.module('ewtApp')
  .service('commonMailPlan', ['$filter', 'ewtMasterDataService', 'ewtUtils', 'campaignDurationWeeks',
    function($filter, ewtMasterDataService, ewtUtils, campaignDurationWeeks) {

      var campaign, campaignService, data, initLoadData;
      var commonMailPlan = {
        init: {
          init: function(camp, realData, initialData, campaignSrv) {
            campaign = camp;
            campaignService = campaignSrv;
            data = realData;
            initLoadData = initialData;
          }
        },
        validate: {
          isUniqueVersion: function(version) {
            var versions = angular.copy(campaign.versions);
            if ($filter('filter')(versions, {
                number: version.number
              }, true).length > 0) {
              version.versionUnique = true;
            } else {
              version.versionUnique = false;
            }
            return version.versionUnique;
          },
          areAllCellsDefined: function() {
            data.mailPlanUpload = $filter('filter')(campaign.cells, {
              incomplete: true
            }, true).length > 0 ? true : false;
            campaign.createVersionDropDownInfo();
            return data.mailPlanUpload;
          }
        },
        events: {
          updateCell: function(cell, action, index) {
            cell.srcCode = angular.uppercase(cell.srcCode); // Convert the cell / source code value to upper case
            if (cell.type) {
              cell.type = $filter('filter')(campaign.initLoadData.cellTypes, {
                code: cell.type.code
              }, true)[0];
            }
            campaignService.events.mailplan.updateCell(campaign, cell, index);
            if (action === 'add') {
              cell = angular.copy(cell);
              cell.versionName = cell.versionNo;
              campaign.cells.push(cell);
            }
            if (action === 'update') {
              // check if cell is updated and the unique variable is set accordingly.
              campaign.updateCell(cell, index);
            }
          },
          removeVersion: function(index) {
            var versionToDelete = angular.copy(campaign.versions[index]);
            if ($filter('filter')(campaign.cells, {
                versionNo: versionToDelete.number
              }, true).length > 0) {
              campaign.showAlert('There are Source Code / Cell IDs mapped to this version. Please update the Creative Version associated to the Source Codes to delete this version.');
            } else {
              campaign.versions.splice(index, 1);
              var versionNos = [];
              angular.forEach(campaign.versions, function(ver) {
                versionNos.push(parseInt(ver.number));
              });

              campaign.versionNos = versionNos;
              campaign.createVersionDropDownInfo();
            }
          }
        }
      }
      return commonMailPlan;
    }
  ]);
