/**
 * Module: UI StatepnlCampaign
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: ERA -- All common functions will go in to this service.
 */

'use strict';
angular.module('ewtApp').service('commonDescription', ['$filter', 'ewtMasterDataService', 'ewtUtils', 'ewtCampaign', 'oneOffDescription', 'APIServer',
  function($filter, ewtMasterDataService, ewtUtils, ewtCampaign, oneOffDescription, APIServer) {
    var campaign, data, initLoadData, tabs,validate;

    var commonDescription = {
      init: {
        init: function(campaignObject, dataObject, initLoadDataObject, tabsObject,validateObject) {
          campaign = campaignObject;
          data = dataObject;
          initLoadData = initLoadDataObject;
          tabs = tabsObject;
          validate = validateObject;
        }
      },
      events: {
        description: {
          /* Set the display email-id of selected MM / Secondary MM  */
          setEmail: function(managerType) {
            if (managerType === 'primary') {
              campaign.primaryMarketingManager.email = ewtUtils.getSelectedObject(campaign.primaryMarketingManager, data.marketingManagers, 'uid').email;
            } else {
              campaign.secondaryMarketingManager.email = ewtUtils.getSelectedObject(campaign.secondaryMarketingManager, data.marketingManagers, 'uid').email;
            }
          },
          emailTypeChange: function() {
            // On email change, the workflow may change, so check for enabling / disabling tabs.
            tabs.forEach(function(tab, indx) {
              tab.disabled = validate.isDisabled('tabs.' + tab.id);
            });
            tabs[2].emailTypeVisibility = (campaign.emailType.codeName === "ET_MA") ? true : false;
            data.campaignService =   data.campaignSvc[campaign.emailType.codeName];
            campaign.isMultiCMNeedCategory = 'false';
            campaign.isDynamicCampaign = 'false';
            campaign.businessUnit.code = '';
            campaign.primaryCmNeedCategory.code = '';
            campaign.commCode.code = '';
            campaign.products = [];
          },
          /*
           This method is called when Primary Need Category changed
           * In case of one off this method handles the logic to display secondary Need Category
           */
          primaryCMCodeChange: function() {
            var indexToRemove, primaryCmneedCategoryArray;
            this.needCategoryChange('primaryCMCodeChange');
            if (campaign.allCMCategorySelectedList && campaign.allCMCategorySelectedList.length !== 0) {
              indexToRemove = campaign.allCMCategorySelectedList.indexOf($filter('filter')(campaign.allCMCategorySelectedList, {
                'code': campaign.primaryCmNeedCategory.code
              }, true)[0]);
              if (indexToRemove !== -1) {
                campaign.allCMCategorySelectedList.splice(indexToRemove, 1);
              }
            }
            if (campaign.allCMCategoryAvailableList && campaign.allCMCategoryAvailableList.length !== 0) {
              indexToRemove = campaign.allCMCategoryAvailableList.indexOf($filter('filter')(campaign.allCMCategoryAvailableList, {
                'code': campaign.primaryCmNeedCategory.code
              }, true)[0]);
              if (indexToRemove !== -1) {
                campaign.allCMCategoryAvailableList.splice(indexToRemove, 1);
              }
            }
            if (data.tempPrimaryCMNeedCategory && data.tempPrimaryCMNeedCategory.code) {
              primaryCmneedCategoryArray = $filter('filter')(angular.copy(campaign.allCMCategoryList), {
                'code': data.tempPrimaryCMNeedCategory.code
              }, true);

              if (primaryCmneedCategoryArray) {
                data.tempPrimaryCMNeedCategory = angular.copy(primaryCmneedCategoryArray[0]);
                campaign.allCMCategoryAvailableList.push(data.tempPrimaryCMNeedCategory);
              }
            }

            if (campaign.allCMCategoryList) {
              campaign.primaryCmNeedCategory = angular.copy($filter('filter')(angular.copy(campaign.allCMCategoryList), {
                'code': campaign.primaryCmNeedCategory.code
              }, true)[0]);
            }
            data.tempPrimaryCMNeedCategory = angular.copy(campaign.primaryCmNeedCategory);
          },
          /**
           * [addcmCategory Pop's out the selected cm need category from avilable list and add's it
           *  to the seleted list]
           */
          addcmCategory: function() {
            if (campaign.cmNeedSelected) {
              campaign.allCMCategorySelectedList.push(campaign.cmNeedSelected);
              var index = campaign.allCMCategoryAvailableList.indexOf(campaign.cmNeedSelected);
              campaign.allCMCategoryAvailableList.splice(index, 1);
              //  setBUDeployment ('cmNeedChange');
            }
          },
          /**
           * [removecmCategory Removes the selected cm need category from selected list and add's it
           *  back into the available list]
           */
          removecmCategory: function() {
            if (campaign.readyForcmListRemoval) {
              campaign.allCMCategoryAvailableList.push(campaign.readyForcmListRemoval);
              var index = campaign.allCMCategorySelectedList.indexOf(campaign.readyForcmListRemoval);

              campaign.allCMCategorySelectedList.splice(index, 1);
              if (campaign.allCMCategorySelectedList.length) {
                //  setBUDeployment ('cmNeedChange');
              } else {
                data.buDeployment = '';
              }
            }
          },
          /*
           *  EDIS Values -- This method show / hide EDIS values.
           */
          dynamicCampaignChange: function() {
            campaign.sto.isThrottled = (campaign.isDynamicCampaign === 'true') ? 'true' : 'false';
          },
          /* Invoke the back-end service to fetch the comm codes from back-end*/
          /* Invoke the back-end service to fetch the related products based on the comm code selected. */
          changeCommCode: function() {
            //   data.products = ewtMasterDataService.getProductsByCommCode(campaign.commCode.commCode);
            data.productsshow = $filter('filter')(initLoadData.products, {
              'commCode': campaign.commCode.code,
              'businessUnitCode': campaign.businessUnit.code
            }, true);
          },
          /* Method to Upload a file*/
          uploadMock: function($files) {
            if ($files.length) {
              var ext = $files[0].name.toLowerCase().split('.');
              if (ext.length > 1 && ext[ext.length - 1].indexOf('exe') !== -1) {
                ewtCampaign.showAlert('Cannot upload .exe files');
                return;
              }
              if ($files.length && (($files[0].size / (1024 * 1024)) > 10)) {
                ewtCampaign.showAlert('Cannot upload file greater than 10MB in size');
                return;
              }
              var fileName = $files[0].name.replace(/\s+/g, '_');
              data.mockFile = {
                error: false,
                file: $files[0],
                fileName: fileName
              };
              console.log('data.mockFile.file ==> ' + data.mockFile.file);
              if (campaign.requestID) {
                campaign.uploadMockFile($files[0], campaign._id);
              }
            }
          },
          /* Method to preview the file */
          previewFile: function() {
            console.log('Calling preview file method...');
            if (data.mockFile.file) {
              var fd = new FormData();
              fd.append('file', data.mockFile.file);
              ewtUtils.viewMockUp(fd);
            }
          },
          /* Method to Remove the file */
          removeMock: function(file_id) {
            data.mockFile = {};
            if (campaign.creativeMockup && campaign.creativeMockup.gfsID) {
              campaign.removeMock(APIServer + 'files/' + campaign._id + '/' + file_id + '/creative-mock', function() {
                campaign.creativeMockup = {};
              });
            }
          },
          needCategoryChange: function(triggeredFrom) {
            if (campaign.emailType.codeName === 'ET_ONEOFF') {
              oneOffDescription.events.needCategoryChange(triggeredFrom, campaign, data);
            }
          }

        }
      }
    }
    return commonDescription;
  }
])
