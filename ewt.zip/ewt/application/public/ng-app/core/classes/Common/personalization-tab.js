/**
 * Module: Common -- Personalization Tab Service
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2016 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: ERA -- Common Personalization tab events / validations  
 */

'use strict';

angular.module('ewtApp')
  .service('commonPersonalization', ['$filter', 'ewtMasterDataService', 'ewtUtils', 'campaignDurationWeeks',
    function($filter, ewtMasterDataService, ewtUtils, campaignDurationWeeks) {

      var scope, campaign, campaignService, data;

      var commonPersonalization = {
        init: function($scope) {
          scope = $scope;
          campaign = $scope.campaign;
          campaignService = $scope.campaignService;
          data = $scope.data;
        },
        validate: {

        },
        events: {
          resetPznFields: function() {
            campaign.pznSelected = {};
            campaign.pznSelected.code = '';
            campaign.pznDescription = '';
            data.pznAlreadyExists = false;
          },
          hidePznError: function() {
            data.pznAlreadyExists = false;
          },
          pznDescriptionDisabled: function() {
            if ($scope.campaign.pznSelected && ($scope.campaign.pznSelected.code === '' || $scope.data.pznAlreadyExists)) {
              return true;
            }
            return false;
          },
          addPznVariable: function() {
            if (campaign.pznSelected && (campaign.pznSelected.reserved || campaign.pznDescription !== '') && !data.pznAlreadyExists) {
              campaign.pznSelected.description = campaign.pznDescription || campaign.pznSelected.description;
              campaign.pznFields.push(angular.copy(campaign.pznSelected));
              commonPersonalization.events.resetPznFields();
            }
          }
        }
      }
      return commonPersonalization;
    }
  ]);
