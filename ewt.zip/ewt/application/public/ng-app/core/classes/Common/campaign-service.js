/**
 * Module: UI StatepnlCampaign
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2016 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: ERA -- All common functions will go in to this service.
 */
'use strict';
angular.module('ewtApp')
  .service('commonMethods', ['$filter', 'commonDescription', 'commonMailPlan', 'commonAttachment', 'maAttachment',
    function($filter, commonDescription, commonMailPlan, commonAttachment, maAttachment) {
      var campaign, data, initLoadData, tabs, validate, campaignService,campaignSvc;
      var commonMethods = {
        init: {
          init: function(campaignFromUI, dataObject, initLoadDataObject, tabObject, validateObject) {

            data = dataObject;
            campaign = campaignFromUI;
            initLoadData = initLoadDataObject;
            campaignService = data.campaignService;
            tabs = tabObject;
            validate = validateObject;
            commonDescription.init.init(campaign, data, initLoadData, tabs ,validate);
            commonAttachment.init.init(campaign);
            commonMailPlan.init.init(campaign, data, initLoadData, campaignService);
          },
          getDeployDisplayObject: function() {
            if (campaign.emailType.codeName !== 'ET_MA') {
              return commonAttachment.getDeployDisplayObject();
            }
            else if (campaign.emailType.codeName === 'ET_MA') {
              return maAttachment.getDeployDisplayObject();
            }
          }
        },
        events: {
          removeFile: function(index, file_id) {
            commonAttachment.events.removeFile(index, file_id);
          },
          uploadFiles: function($files) {
            commonAttachment.events.uploadFiles($files);
          },
          description: {
            setEmail: function(managerType) {
              commonDescription.events.description.setEmail(managerType);
            },
            emailTypeChange: function() {
              commonDescription.events.description.emailTypeChange();
            },
            primaryCMCodeChange: function() {
              commonDescription.events.description.primaryCMCodeChange();
            },
            addcmCategory:function(){
              commonDescription.events.description.addcmCategory();
            },
            removecmCategory:function(){
              commonDescription.events.description.removecmCategory();
            },
            needCategoryChange: function(triggeredFrom) {
              commonDescription.events.description.needCategoryChange(triggeredFrom);
            },
            dynamicCampaignChange:function(){
              commonDescription.events.description.dynamicCampaignChange();
            },
            changeCommCode:function(){
              commonDescription.events.description.changeCommCode();
            },
            uploadMock: function($files) {
              commonDescription.events.description.uploadMock($files);
            },
            previewFile: function() {
              commonDescription.events.description.previewFile();
            },
            removeMock: function(file_id) {
              commonDescription.events.description.removeMock(file_id);
            }
          },
       
        }  // End of Events
      }
      return commonMethods;
    }]);