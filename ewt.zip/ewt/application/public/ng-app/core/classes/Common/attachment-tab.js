/**
 * Module: UI StatepnlCampaign
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2016 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 *
 * Description: ERA -- All Attachment common methods go in to this.
 */
'use strict';
angular.module('ewtApp')
  .service('commonAttachment', ['$filter', 'ewtCampaign', 'APIServer',
    function($filter, ewtCampaign, APIServer) {
      var campaign = (campaign) ? campaign : {};
      var commonAttachment = {
        init: {
          init: function(campaignFromUI) {
            campaign = campaignFromUI;
          },
          /*
           * The below method construct the Deployed Creative Object for PNL, Servicing, One Off Campaign
           */
          getDeployDisplayObject: function() {
            var result = [];

            function deployedCreativeObject(mhid, startDate, cellId, description, versionId, gfsId, fileName, actualDeploymentDate) {
              this.mhid = mhid;
              this.startDate = startDate;
              this.cellId = cellId;
              this.description = description;
              this.versionId = versionId;
              this.gfsId = gfsId;
              this.fileName = fileName;
              this.actualDeploymentDate = actualDeploymentDate;
            }

            for (var cellindex = 0; cellindex < campaign.cells.length; cellindex++) {
              var cell = campaign.cells[cellindex];
              for (var creIndex = 0; creIndex < campaign.deployedCreatives.length; creIndex++) {
                /* Check if the cell is not cancelled and cell is not a Holdout cell. */
                if (campaign.deployedCreatives[creIndex].gfsID &&
                  cell.versionNo === campaign.deployedCreatives[creIndex].versionNo && !cell.cancelled && cell.type.codeName !== 'control') {
                  /* Populate the object  */
                  var deployedCreativeObject = new deployedCreativeObject(
                    campaign.mailHistory[0].mhid,
                    campaign.deployedCreatives[creIndex].scheduledDeploymentDate,
                    cell.srcCode,
                    cell.description,
                    cell.versionNo,
                    campaign.deployedCreatives[creIndex].gfsID,
                    campaign.deployedCreatives[creIndex].fileName,
                    campaign.deployedCreatives[creIndex].actualDeploymentDate);
                  result.push(deployedCreativeObject);
                }
              }
            }
            return result;
          }
        }, // End of Init
        events: {
          /*
           * Method Name: Upload Files -- This method upload the files
           * Parms -- @$file, campaign object.
           */
          uploadFiles: function($files) {
            var size = 0;
            // Check if the total files uploaded is exceeding the 4MB.
            angular.forEach(campaign.attachments, function(attachment) {
              size += Number(attachment.size);
            });

            // Check if the file uploaded is not an EXE
            for (var cnt = 0; cnt < $files.length; cnt++) {
              if ($files[cnt] && $files[cnt].name) {
                size += Number($files[cnt].size);

                // Restrict uploading the filesize more than 4 MB.
                if ((size / (1024 * 1024)) > 10) {
                  ewtCampaign.showAlert('Overall file uploads for a campaign cannot exceed 10 MB');
                  return;
                }

                // Restrict uploading the .exe file
                var ext = $files[cnt].name.toLowerCase().split('.');
                if (ext.length > 1 && ext[ext.length - 1].indexOf('exe') !== -1) {
                  ewtCampaign.showAlert('Uploading .exe files is not allowed');
                  return;
                }

                campaign.attachFileToCampaign(APIServer + 'files/' + campaign._id, $files[cnt], this.updateAttachmentsInScope);
              }
            }
          },
          /*
           *  Callback function to add the attachments.
           */
          updateAttachmentsInScope: function(attachment) {
            campaign.attachments.push(attachment);
          },
          validateVersion: function(fileRowObj, index) {
            if (fileRowObj && fileRowObj.type && (fileRowObj.type.codeName === 'rasc' || fileRowObj.type.codeName === 'creative_governance')) {
              campaign.attachments[index].creativeVersion = 0;
            }
          },
          /*
           * Funtion to remove the file
           */
          removeFile: function(index, file_id) {
            campaign.removeFile(APIServer + 'files/' + campaign._id + '/' + file_id, function() {
              campaign.attachments.splice(index, 1);
            });
          }
        } // End of Events.
      }
      return commonAttachment;
    }]);
