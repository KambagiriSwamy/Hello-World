/**
 * Module: UI Service - Common Scheduling
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: ERA -- All common functions will go in to this service.
 */

/*
 TODO: remove the following methods from controller
 */

// begin IIFE closure - no leaking global context
(function() {
  'use strict';

  // reset the schedule options on the scope
  function createBoundInstance(state, watch) {
    var today = moment().startOf('d');
    var campaign = state.campaign.instance();

    setTimeout(function(){
      bindInternalWatchers(state, watch);
      bindEventHandlers(state);
    },10);
    
    return {
      info: {
        code: state.campaign.code()
      },
      start: {
        value: campaign.deploymentDates[0],
        min: today.clone().add(1, 'd').toDate(),
        max: today.clone().startOf('y').add(2, 'y').toDate()
      },
      duration: {
        value: campaign.durationInWeeks,
      },
      end: {
        value: campaign.endDate,
        min: campaign.deploymentDates[0] && moment(campaign.deploymentDates[0]).startOf('d').toDate() || today.clone().add(2, 'd').toDate(),
        max: moment().startOf('y').add(2, 'y').toDate()
      },
      buDeployment: {
        value: campaign.buDeployment,
        min: today.clone().add(1, 'd').toDate(),
        max: moment().startOf('y').add(2, 'y').toDate()
      },
      util: {
        isValid: isValid.bind(null, state),
        allowDate: allowDate.bind(null, state),
        checkSchedule: checkSchedule.bind(null, state)
      }
    };
  }
  
  function sameDate(a, b) {
    if (
      (a === undefined || a === null)
      && (b === undefined || b === null)
    ) return true;
    return moment(new Date(a)).startOf('d').isSame(moment(new Date(b)).startOf('d'));
  }
  
  function clearScheduling(state) {
    var campaign = state.campaign.instance();
    
    campaign.deploymentDates = [];
    campaign.buDeployment = null;
    campaign.endDate = null;
    campaign.durationInWeeks = null;

    state.scheduling.start.value = null;
    state.scheduling.end.value = null;
    state.scheduling.duration.value = null;
    state.scheduling.buDeployment.value = null;
  }

  function bindInternalWatchers(state, watch) {
    //watch('info.code', state.emit.bind(state, 'change:scheduling-start'));
    watch('start.value', state.emit.bind(state, 'change:scheduling-start'));
    watch('duration.value', state.emit.bind(state, 'change:scheduling-duration'));
    watch('end.value', state.emit.bind(state, 'change:scheduling-end'));
    watch('buDeployment.value', state.emit.bind(state, 'change:scheduling-bu-deployment'));
  }
  
  function bindEventHandlers(state) {
    state.once('init', init.bind(null, state));
    state.on('focus:scheduling-start', checkSchedule.bind(null, state, 'ng-focus'));
    state.on('focus:scheduling-bu-deployment', checkSchedule.bind(null, state, undefined));
    state.on('handle:set-bu-deployment', setBUDeployment.bind(null, state))

    state.on('change:campaign-code', changedCampaignCode.bind(null, state));
    state.on('change:scheduling-duration', changedDuration.bind(null, state));
    state.on('change:scheduling-start', changedStartDate.bind(null, state));
    state.on('change:scheduling-end', changedEndDate.bind(null, state));
    state.on('change:scheduling-bu-deployment', changedBuDeployment.bind(null, state));
  }
  
  function calcEndDate(state) {
    //get Start Date
    var campaign = state.campaign.instance();
    var code = state.scheduling.info.code;
    var duration = state.scheduling.duration.value;
    var sd = moment(new Date(state.scheduling.start.value || 'invalid'));
    if (!sd.isValid()) return null;
    
    if (code === 'ET_SERVICING') return sd.toDate();
    
    if (code === 'ET_ONEOFF') {
      if (state.scheduling.duration.week === null) return null;
      var days = state.scheduling.duration.value * 7;
      var endDateCalculated = sd.clone().add(days, 'd');
      return endDateCalculated.toDate();
    }
    
    return null;
  }

  /**
   * setEndDate check if email type is oneoffs and start date and duration are present in campaign.
   * If any of the above fail end date is not estimates.
   * Estimated end date is stored in campaign.deploymentDates array at index 1.
   * This function is triggred on changing start date and campaign duration value in dropdown.
   * for MA Campaigns the end date is caluculated like startDate + 7* (number of weeks)
   * for other campaigns the end date is same as the start date
   */
  function setEndDate(state) {
    var calc = calcEndDate(state) || null;
    changedEndDate(state, calc || null);
    state.emit('apply');
  };

  /** When Admin change the end date beyond selected duration, this method will throw an error **/
  function isValidEndDate(state) {
    var today = moment().startOf('d');
    var sd = moment(new Date(state.scheduling.start.value || 'invalid')).startOf('d');
    var ed = moment(new Date(state.scheduling.end.value || 'invalid')).startOf('d');
    
    console.log('isValidEndDate code', state.scheduling.info.code, state.scheduling.end.value);
    
    // start date must be set first
    if (!sd.isValid()) return false;
    
    // Not set for following email tupes...
    switch (state.scheduling.info.code) {
      case 'ET_MA':
      case 'ET_SERVICING':
        return true; //not required
      case 'ET_ONEOFF':
        var days = state.scheduling.duration.value * 7;
        var endDateCalculated = sd.clone().add(days, 'd');
        
        if (days === 0) return !ed.isSame(endDateCalculated)
        return ed.isSameOrAfter(endDateCalculated);
      default:
        return ed.isValid && ed.isSameOrAfter(sd);
    }
  }
  
  function isValidStartDate(state) {
    var today = moment().startOf('d');
    var sd = moment(new Date(state.scheduling.start.value || 'invalid')).startOf('d');
    return sd.isSameOrAfter(today)
      && allowDate(state, sd.toDate(), false);
  }
  
  function isValid(state) {
    return (
      isValidStartDate(state)
      && isValidEndDate(state)
    );
  }

  function calculateEndDateRange(state) {
    var campaign = state.campaign.instance();

    //use preset start date
    var today = moment().startOf('d');
    var minDate = today.clone().add(1, 'd');
    var startDate = moment(new Date(campaign.deploymentDates[0] || 'invalid')).startOf('d').clone();
    var endDate = minDate.clone();
    
    if (startDate.isValid()) {
      //set campaign start to start of existing day
      endDate = startDate.clone().add(2, 'd');
    } else {
      startDate = today.clone();
      endDate = minDate.clone();
    }
    
    // if end is before mindate, set to mindate
    if (minDate.isBefore(endDate)) endDate = minDate.clone()

    // set Default Range
    state.scheduling.end.min = endDate.clone().toDate();
    state.scheduling.end.max = endDate.clone().startOf('y').add(2, 'y').toDate();
    
    /*
     if (state.scheduling.info.code === 'ET_ONEOFF' && state.user.isAdmin()) {
     var days = state.scheduling.duration.value * 7;
     state.scheduling.end.min = startDate.clone().toDate();
     state.scheduling.end.max = startDate.clone().add(days, 'd');
     }
     */
    
    // for ET_PNL, valid when in range
    if (state.scheduling.info.code === 'ET_PNL') {
      state.scheduling.end.min = startDate.clone().toDate();
      state.scheduling.end.max = startDate.clone().add(7, 'd').toDate();
      
      //clear endDate when out of range, marked as required.
      var ed = moment(new Date(state.scheduling.end.value || 'invalid'));
      if (!ed.isValid() || ed.isBefore(startDate) || ed.isAfter(state.scheduling.end.max)) {
        state.scheduling.end.value = campaign.endDate = null;
      }
      
      return;
    }
    
    // for ET_MA
    if (state.scheduling.info.code === 'ET_MA') {
      if (!campaign.mailHistory.length) return;
      
      var allComplete = true;
      campaign.mailHistory.forEach(function(mhidObj, index) {
        mhidObj.incomplete = moment(mhidObj.startDate).isBefore(startDate);
        if (!mhidObj.incomplete) allComplete = false;
      });
      
      campaign.atleastOneDateEqual = campaign.checkForStartDate();
      
      campaign.mailHistoryValid = allComplete;
      
      return;
    }
  }
  
  function allowDate(state, date, isBUDeployment) {
    var codeName = state.scheduling.info.code;
    var campaign = state.campaign.instance();
    var today = moment().startOf('d');
    var value = moment(date);
    
    // no sundays
    if (codeName === 'ET_SERVICING') {
      return value.day() !== 0;
    }
    
    if (codeName === 'ET_ONEOFF') {
      /**
       * if date picker is for BU deployment and user is admin then enable all future sundays
       */
      if (isBUDeployment && state.user.isAdmin()) {
        return value.isAfter(today) && value.day() === 0;
      }
      
      /**
       * if the date picker is not for BU deployment  or if date picker is for Bu deployment
       * and user is MM then enable only BU specific dates
       */
      if (!isBUDeployment || state.user.isManager()) {
        //ONLY SUNDAYS
        if (value.day() != 0) return false;
        
        var week = ~~state.data.oneoffDeploymentWeek();
        var dom = value.date(); //day of month
        if (campaign.businessUnit && campaign.businessUnit.codeName === 'BU_GMS') {
          // first or third sunday only
          return dom <= 7 || (dom > 14 && dom <= 21);
        }
        
        //determine base on week
        if (week === 1) return dom <= 7;
        if (week === 2) return dom > 7 && dom <= 14;
        if (week === 3) return dom > 14 && dom <= 21;
        if (week === 4) return dom > 21 && dom <= 28;
        return false;
      }
    }
    
    return value.isAfter(today); //allowed starting today, by default
  }
  
  /**
   * setBUDeployment method can be triggered on changing CM need cateogry and also on changing start date
   *
   * triggeredFrom - holds the source from where this method called.
   */
  function setBUDeployment(state, triggeredFrom) {
    state.scheduling.buDeployment.value = getBUDeployment(state, triggeredFrom);
    state.emit('apply');
  }
  
  function getBUDeployment(state, triggeredFrom) {
    var def = state.scheduling.buDeployment.value;
    
    /**
     * BU Deployment Slot should be set only if email type of campaign is ONEOFF
     * Checking for email type of campaign
     */
    if (state.scheduling.info.code !== 'ET_ONEOFF') return def;
    
    /**
     * conditions based on the triggeredFrom
     * if triggeredFrom = 'cmNeedCange' - BUdeployment slot is calculated based on enabled dates
     *                                    for a specific business unit
     * if triggeredFrom = 'startDate'   - Bu deployment is set to start date
     *                                    (as of now - done only for MM view)
     */
    if (triggeredFrom === 'startDate') {
      if (
        state.user.isManager()
        && state.campaign.instance().state.codeName === 'draft'
        && state.scheduling.start
      ) {
        return new Date(state.scheduling.start.value);
      }
    }
    
    if (triggeredFrom === 'cmNeedChange') {
      var checkingDate = moment().startOf('d');
      var daysChecked = 0;
      //  var buDate = checkingDate();
      /**
       * Iterate through dates till we meet first drop date.
       * This will happen only for one month
       */
      while (31 > daysChecked++) {
        if (allowDate(state, checkDate.toDate(), null)) {
          return checkingDate.toDate();
        }
        checkingDate.add(1, 'd');
      }
      return null;
    }
    
    return def;
  }
  
  function areAll(values, match) {
    for (var i = 0; i < values.length; i++) {
      if (values[i] !== match) return false
    }
    return true;
  }
  
  function areAny(values, match) {
    for (var i = 0; i < values.length; i++) {
      if (values[i] === match) return true;
    }
    return false;
  }

  function numericallyEqual(d1, d2, d3) {
    if (areAll([d1, d2, d3], null) || areAll([d1, d2, d3], undefined)) return true;
    if (areAny([d1, d2, d3], null) || areAny([d1, d2, d3], undefined)) return false;
    return +d1 === +d2 && +d1 === +d3
  }

  function checkSchedule(state, reason) {
    state.emit('handle:need-category-change', reason)
    calculateEndDateRange(state);
    state.emit('handle:reset-deployment-error');
  }
  
  
  
  
  function init(state) {
      if (sameDate(null, state.scheduling.start.value)) {
        clearScheduling(state);
        return;
      }
      calculateEndDateRange(state);
      if (!state.scheduling.end.value) setEndDate(state);
      if (!state.scheduling.buDeployment.value) setBUDeployment(state);
  }
  

  function changedCampaignCode(state, value) {
    if (
      state.scheduling.info.code === value
    ) return;

    state.scheduling.info.code = value;
    
    // this module won't change campaign setting
    var campaign = state.campaign.instance();
    
    //invalid start date - reset
    if (!isValid(state)) {
      clearScheduling(state);
      state.emit('handle:need-category-change', 'ng-focus');
      state.emit('handle:reset-deployment-error');
      state.emit('apply');
    }
  }
  

  function changedStartDate(state, value) {
    var campaign = state.campaign.instance();
    value = value || null;
    /*
    console.log(
      'set start date 1\n\tvalue: ', value
      , '\n\tcd[0]', campaign.deploymentDates[0], sameDate(value, campaign.deploymentDates[0])
      , '\n\tschd.st', state.scheduling.start.value, sameDate(value, state.scheduling.start.value)
    );
    */
    if (+value < 0) value = null;
    if (
      sameDate(value, campaign.deploymentDates[0])
      && sameDate(value, state.scheduling.start.value)
    ) return;
    
    if (!+value) {
      clearScheduling(state);
      state.emit('handle:need-category-change', 'ng-change');
      state.emit('handle:reset-deployment-error');
    } else {
      campaign.deploymentDates[0] = value;
      state.scheduling.start.value = value;
      state.emit('handle:need-category-change', 'ng-change');
      calculateEndDateRange(state);
      setEndDate(state);
      state.emit('handle:reset-deployment-error');
      setBUDeployment(state, 'startDate');
    }
    
    state.emit('apply');
  }
  

  function changedDuration(state, value) {
    var campaign = state.campaign.instance();
    if (
      state.scheduling.duration.value === value
      && campaign.durationInWeeks === value
    ) return;
    
    campaign.durationInWeeks = value;
    state.scheduling.duration.value = value;
    
    setEndDate(state);
    setBUDeployment(state, 'startDate');
    state.emit('apply');
  }


  function changedEndDate(state, value) {
    if (
      sameDate(value, state.campaign.instance().endDate)
      && sameDate(value, state.scheduling.end.value)
    ) return;
    
    state.scheduling.end.value = value;
    state.campaign.instance().endDate = value;
    state.emit('apply');
  }


  function changedBuDeployment(state, value) {
    if (
      sameDate(value, state.scheduling.buDeployment.value)
      && sameDate(value, state.campaign.instance().buDeployment)
    ) return;
    
    state.scheduling.buDeployment.value = value;
    state.campaign.instance().buDeployment = value;
    
    state.emit('handle:need-category-change', 'ng-change');
    calculateEndDateRange(state);
    setEndDate(state);
    state.data.instance().buNeedCategoryChanged = false;
    state.emit('apply');
  }


  angular.module('ewtApp').service('commonScheduling', [
    function() {
      return {create: createBoundInstance};
    }
  ]);

  // end of IIFE
}());
