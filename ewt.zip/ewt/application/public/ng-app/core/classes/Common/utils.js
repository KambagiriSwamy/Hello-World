/**
 * Module: UI StatepnlCampaign
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2016 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 *
 * Description: ERA -- All Attachment common methods go in to this.
 */
'use strict';
angular.module('ewtApp')
  .service('appUtils', ['ewtCampaign',
    function(ewtCampaign) {
      var appUtils = {
        approve: function() {
          var approveConfig = {
            'message': 'You have selected Req.Id: ' + campaign.requestID + ' to be Approved. Continue ?',
            'actionButtons': [{
              'label': 'Yes',
              'buttonType': 'success',
              'callBack': function() {
                campaign.approve();
              }
            }, {
              'label': 'cancel',
              'buttonType': 'error'
            }]
          };
          campaign.modal.open(approveConfig);
        },
        decline: function() {
          var declineConfig = {
            'url': 'ng-app/partials/directives/modals/decline-form.html',
            'resolve': campaign
          };
          campaign.modal.open(declineConfig);
        },
        revisionRequired: function() {
          var revisionConfig = {
            'url': 'ng-app/partials/directives/modals/revision-required-form.html',
            'resolve': campaign
          };
          campaign.modal.open(revisionConfig);
        },
        rollBack: function() {
          ewtCampaign.verifyRollback({
            'requestID': campaign.requestID
          }).$promise.then(function(response) {
            var rollBackConfig = {
              'url': 'ng-app/partials/directives/modals/roll-back-form.html',
              'resolve': campaign
            };
            campaign.modal.open(rollBackConfig);
          }, function(error) {
            if (error.data.status === 'failure') {
              campaign.showAlert(error.data.reason);
            }
            return false;
          });
        },
        cancelCampaign: function() {
          campaign.modal.open({
            'url': 'ng-app/partials/directives/modals/cancel-campaign.html',
            'resolve': {
              'purpose': 'cancelCampaign',
              'campaign': angular.copy(campaign)
            }
          });
        }
      }
      return appUtils;
    }
  ]);
