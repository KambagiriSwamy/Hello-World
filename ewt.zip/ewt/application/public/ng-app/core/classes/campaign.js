/**
 * Module: camapign service -- core class that has all the request response transfermations.
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2016 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: ERA  -- Servicing events / validation methods.
 */
'use strict';

/**
 * @ngdoc service
 * @name ewtApp.campaign
 * @description
 * # campaign
 * Service in the ewtApp.
 */
angular.module('ewtApp')
  .service('ewtCampaign', ['$resource', 'APIServer', 'Upload', '$filter', '$state', 'ewtMasterDataService', 'cardProducts', '$http', '$window', 'ewtUtils', 'emailVendors', function($resource, APIServer, Upload, $filter, $state, ewtMasterDataService, cardProducts, $http, $window, utilities, emailVendors) {
    var url = APIServer + 'campaigns/:id';
    var campaignObject = this;
    var staticCopyCardProducts = angular.copy(cardProducts);
    var initLoadData;

    function transformMultiple(data) {
      /**
       * Transform each campaign.
       */
      var response = angular.fromJson(data);
      var revisedResponse = [];
      response.forEach(function(campaignObj, index) {
        revisedResponse.push(transformResponse(campaignObj));
      });

      return revisedResponse;
    }

    /*
     *  Method Name: transformResponse
     *  -- Any changes specific to rendering of the page goes in to this method.
     */
    function transformResponse(data) {
      /**
       * Setting Card products
       * Dynamic camaign types code has to be added here after changed to checkbox
       */
      var response = angular.fromJson(data);
      if (response.status === 'failure') {
        return response;
      }
      // Code for Card Products
      var revisedCardProducts = [];
      var found = false;
      /* This value is set to avoid the excpetion when no emailType is selected.*/
      response.emailType = (response.emailType) ? response.emailType : {
        code: "012",
        codeName: "ET_SERVICING",
        name: "Servicing"
      };
      cardProducts = angular.copy(staticCopyCardProducts);

      cardProducts.forEach(function(value, index) {
        found = false;
        response.cardProducts.forEach(function(innerVal, innerIndex) {
          if (value.code === innerVal.code) {
            found = true;
          }
        });
        if (found) {
          value.checked = true;
        }
        revisedCardProducts.push(value);
      });

      response.cardProducts = revisedCardProducts;
      // STO Related fields.
      if (response.sto) {
        response.sto.isSTO = (response.sto.isSTO) ? 'true' : 'false';
        response.sto.isThrottled = (response.sto.isThrottled) ? 'true' : 'false';
        response.sto.isSpecificTime = (response.sto.isSpecificTime) ? 'true' : 'false';
        response.sto.isSpecialTestingReq = (response.sto.isSpecialTestingReq) ? 'true' : 'false';
      }

      // response.isDynamicCampaign has to be a string to make radio box selected
      if (response.isDynamicCampaign) {
        response.isDynamicCampaign = 'true';
      } else {
        response.isDynamicCampaign = 'false';
      }
      /**
       * [if isMultiCMNeedCategory is true then update it to selected list
       *  else it will get update the singleCmNeedCategory with the single element of the selected cm need category]
       * @param  {[boolean]} response.isMultiCMNeedCategory [boolean describes whether user selected multiple category codes or not]
       */
      if (response.isMultiCMNeedCategory) {
        response.isMultiCMNeedCategory = 'true';
        if (response.cmNeedCategories) {
          response.allCMCategorySelectedList = (response.cmNeedCategories) ? response.cmNeedCategories : [];
        }
      } else {
        response.isMultiCMNeedCategory = 'false';
      }
      // Loop the 'versions' and prepared the 'cells' array for Angular to operate on
      /**
       * @ Mapping the MA/Versions cells to the cells object in the response
       * if email type is Servicing, cells are mapped from versions
       * for MA the cells are mapped from ma object say maCells.
       */
      response.cells = [];
      response.subjectLinesArr = [];

      if (response.emailType) {
        switch (response.emailType.codeName) {
          case 'ET_SERVICING':
          case 'ET_ONEOFF':
          case 'ET_PNL':
            response.minDate = new Date(new Date().getTime() + (24 * 60 * 60 * 1000));
            response.versions = response.versions || [];
            response.versions.forEach(function(version) {
              if (response.emailType.codeName === 'ET_SERVICING') {
                version.subjects.forEach(function(subject) {
                  var respObj = {};
                  respObj.number = version.number;
                  respObj.subjectLine = subject.subjectLine;
                  respObj.espInstructions = subject.espInstructions;
                  response.subjectLinesArr.push(respObj);
                });
                version.subjects = [];
              }
              version.cells.forEach(function(cell) {
                cell.versionName = cell.versionNo;
                response.cells.push(cell);
              });
              version.cells = [];
            });

            /**
             * this block populates versions dropdown in mail plan tab if email type is One offs
             */
            switch (response.emailType.codeName) {
              case 'ET_ONEOFF':
              case 'ET_PNL':
                var versionNos = [];
                angular.forEach(response.versions, function(ver) {
                  versionNos.push(parseInt(ver.number, 10));
                });
                response.versionNos = versionNos;
                break;
              default:
                break;
            }
            break;
          case 'ET_MA':
            if (response.ma.maCells) {

              response.cells = angular.copy(response.ma.maCells);
              var filteredVersions = [];
              angular.forEach(response.ma.maVersions, function(version) {
                if (version.versionId * 1 !== 0) {
                  version.versionDescription = version.versionId;
                  filteredVersions.push(version);
                }
              });
              response.ma.maVersions = filteredVersions;
              response.ma.maVersions.unshift({
                "versionId": "0",
                "versionDescription": "ALL"
              });
            } else {
              response.cells = [];
            }
            response.ma.maCells = [];
            break;
          default:
            break;
        }
      }
      /** Update the campaign state based on the esp load status
       */
      if (response.state) {
        if (response.state.codeName === 'submitted2esp' && response.espLoadDetails.length === response.criticalDataSubmitted.length) {
          response.state.codeName = 'rollBackDeployedCampaign';
        }
        if (response.isSubmittedToESP) {
          var formattedObj = {},
            criticalDataSubmitted = angular.copy(response.criticalDataSubmitted),
            criticalDataArray = [];
          for (var cnt = 0; cnt < criticalDataSubmitted.length; cnt++) {
            var rowObj = criticalDataSubmitted[cnt].keys;
            if ((new Date() < ((rowObj.CMPGN_DEPLOY_DATE).stringToDate()))) {
              if (formattedObj[rowObj.CMPGN_DEPLOY_DATE]) {
                var arr = formattedObj[rowObj.CMPGN_DEPLOY_DATE].keys;
                arr.push(rowObj);
                formattedObj[rowObj.CMPGN_DEPLOY_DATE].keys = arr;
              } else {
                var arr = [];
                arr.push(rowObj);
                formattedObj[rowObj.CMPGN_DEPLOY_DATE] = {
                  'keys': arr
                };
              }
            }
          }
          for (var key in formattedObj) {
            var dtObj = {};
            dtObj = formattedObj[key];
            dtObj.date = key;
            dtObj.formattedDate = key.stringToDate();
            criticalDataArray.push(dtObj);
          }
          response.criticalDataSubmittedCopy = criticalDataArray;
        }
      }
      // Specific to MA campaign
      if (response.emailType && response.emailType.codeName === 'ET_MA') {
        // changes Specific to MHID
        if (response.ma && response.ma.mailHistory) {
          response.mailHistory = [];
          var mHistory = {};
          angular.forEach(response.ma.mailHistory, function(mh, index) {
            angular.forEach(mh.cells, function(mhCell, cellIndex) {
              mHistory = {};
              mHistory._id = mh._id;
              mHistory.mhid = mh.mhid;
              mHistory.startDate = new Date(mh.startDate);
              mHistory.cell = mhCell;
              response.mailHistory.push(mHistory);
            });
          });
        }

        /**
         * @disabling removal of cells if associated to MHID
         */
        angular.forEach(response.mailHistory, function(mhid, mhidIndex) {
          angular.forEach(response.cells, function(value, index) {
            if (value.srcCode === mhid.cell.srcCode) {
              value.isLinkedToMHID = true;
              value.removeAlternative = 'Cannot remove as linked to a MHID';
              value.editAleternative = 'Cannot edit as linked to a MHID';
            }
          });
        });
      }

      response.deploymentDates = response.deploymentDates.map(function(dtm){
        return moment(new Date(dtm)).startOf('d').toDate();
      });
      
      response.initLoadData = initLoadData;

      if (response.buDeployment) response.buDeployment = moment(new Date(response.buDeployment)).startOf('d').toDate();
      if (response.endDate) response.endDate = moment(new Date(response.endDate)).startOf('d').toDate();

      if (response.emailType && response.emailType.codeName === 'ET_PNL' && response.commCode) {

        if (response.commCode.products && response.commCode.products.length > 0) {
          response.products = [];
          angular.forEach(response.commCode.products, function(selectedValue, key) {
            this.push(selectedValue[0].code);
          }, response.products);
        }
      } else {
        response.commCode = {};
      }
      return response;
    }

    function transformRequest(request) {
      /**
       * Setting appropriate objects for
       *  - Primary Manager
       *  - Secondary Manager
       *  - Business Unit
       *  - Email Type
       *  - Campaign Type
       *  - Campaign Sub Type
       *  - Comm Code & Product for PNL Campaigns
       * Filtering Card Products
       * ewtMasterDataService is used to get dependent values.
       * Should add code to filter dynamic campaign types once changed to checkboxes
       */
      var data = angular.copy(request);
      initLoadData = data.initLoadData;
      //delete data.initLoadData;

      /**
       * @Transformations of request data only for Servicing Campaign
       */
      if (data.emailType.codeName === 'ET_SERVICING') {
        data.durationInWeeks = 0;
        delete data.primaryCmNeedCategory;
        delete data.cmNeedCategories;
      }

      /**
       * @Transformations of request data for all type of campaigns
       */
      data.primaryMarketingManager = utilities.getSelectedObject(data.primaryMarketingManager, initLoadData.marketingManagers, 'uid');
      if (data.secondaryMarketingManager) {
        data.secondaryMarketingManager = utilities.getSelectedObject(data.secondaryMarketingManager, initLoadData.marketingManagers, 'uid');
      } else {
        data.secondaryMarketingManager = {}
      }
      if (data.businessUnit) {
        data.businessUnit = utilities.getSelectedObject(data.businessUnit, initLoadData.businessUnits, 'code');
      }

      if (data.emailType) {
        data.emailType = utilities.getSelectedObject(data.emailType, initLoadData.emailTypes, 'code');
      }

      if (data.type) {
        data.type = utilities.getSelectedObject(data.type, initLoadData.campaignTypes, 'code');
      }
      if (data.sto && data.sto.isSTO === 'true' && data.sto.stoEmailTrackingType) {
        data.sto.stoEmailTrackingType = utilities.getSelectedObject(data.sto.stoEmailTrackingType, initLoadData.stoEmailTrackingTypes, 'name');
      }
      if (data.sto && data.sto.isSTO === 'true' && data.sto.stoEventToTrack) {
        data.sto.stoEventToTrack = utilities.getSelectedObject(data.sto.stoEventToTrack, initLoadData.stoEventsToTrack, 'name');
      }

      if (data.esp) {
        data.esp = utilities.getSelectedObject(data.esp, emailVendors, 'codeName');
      }

      data.cmNeedCategories = [];
      initLoadData.cmNeedCategories = data.allCMCategoryList;

      if (data.emailType.codeName !== 'ET_SERVICING') {

        if (data.isMultiCMNeedCategory === 'false') {
          data.isMultiCMNeedCategory = false;
          data.cmNeedCategories = [];
        } else {
          data.isMultiCMNeedCategory = true;
          data.cmNeedCategories = data.allCMCategorySelectedList;
        }
      }

      /**
       * @Formating Request: if email type is servicing or ma then dynamic campaigns are reset to empty array.
       */

      /**
       * [if dynamic campaign is selected false then typecaste the string false to boolean false and reset dynamic campaigns
       *  else the boolean true is set and gets the right object from utils method getSelectedObject]
       * @param  {String} data.isDynamicCampaign [radio button selected from the UI]
       */
      if (data.isDynamicCampaign === 'false') {
        data.isDynamicCampaign = false;
        // data.sto.isThrottled = false;
        data.dynamicCampaigns = [];
      } else {
        data.isDynamicCampaign = true;
        // data.sto.isThrottled = true;

        if (data.dynamicCampaigns && data.dynamicCampaigns[0]) {
          data.dynamicCampaigns[0] = utilities.getSelectedObject(data.dynamicCampaigns[0], initLoadData.dynamicCampaigns, 'codeName');
        }
      }
      /**
       *  @Transform the aribitration object so that actual object is selected from the array using the code
       */
      if (data.arbitration) {
        initLoadData.arbitrationStatus = ewtMasterDataService.getDataObj().arbitrationStatus;
        data.arbitration = utilities.getSelectedObject(data.arbitration, initLoadData.arbitrationStatus, 'code');
      }
      var revisedCardProducts = data.cardProducts || [];
      data.cardProducts = [];

      revisedCardProducts.forEach(function(value, index) {
        if (value.checked) {
          delete value.checked;
          data.cardProducts.push(value);
        }
      });

      // Loop 'cells' array and merge them into 'versions' array for Node to consume
      /**
       * @Cells in Mail Plan tab: if email type is Servicing Cells are mapped to the campaign version in mail plan tab
       * if email type is MA then cells are mapped to ma object which embed's the versions inside it
       */
      var filteredCells = [];
      if (data.cells) {
        data.cells.forEach(function(cell) {
          if (cell.versionNo !== 0) {
            filteredCells.push(cell);
          }
        });
      }
      data.cells = filteredCells;
      if (data.cells && data.cells.length) {
        if (data.emailType.codeName === 'ET_MA') {
          data.ma.maCells = angular.copy(data.cells);
        } else { // One-off and Servicing campaigns
          // Move cells from data.cells array to data.versions.cells array
          data.cells.forEach(function(cell) {
            var cellAdded2Version = false;
            // Look if the version for this cell already exists. If it exists, simply move there.
            for (var indx = 0; indx < data.versions.length; indx++) {
              if (cell.versionNo === data.versions[indx].number) {
                data.versions[indx].cells = data.versions[indx].cells || [];
                data.versions[indx].cells.push(cell);
                cellAdded2Version = true;
                break;
              }
            }
            // If we could not find a version for this cell, create new version.
            if (!cellAdded2Version && cell.versionNo && cell.versionNo !== 0) {
              data.versions.push({
                number: cell.versionNo,
                cells: [cell]
              });
            }
          });

          // Move subject lines from data.subjectLinesArr array to data.versions.subjects array
          data.subjectLinesArr.forEach(function(subject) {
            for (var verIndx = 0; verIndx < data.versions.length; verIndx++) {
              if (subject.number === data.versions[verIndx].number) {
                var subjectObj = {};
                data.versions[verIndx].subjects = data.versions[verIndx].subjects || [];
                subjectObj.subjectLine = subject.subjectLine;
                subjectObj.espInstructions = subject.espInstructions;
                data.versions[verIndx].subjects.push(subjectObj);
              }
            }
          });
        }
        // We dont need data.cells and data.subjectLinesArr now, as allhas been moved under data.versions, so delete them now.
        delete data.cells;
        delete data.subjectLinesArr;
      }
      if (data.emailType && data.emailType.codeName === 'ET_MA') {
        // Move MHIDs from data.mailHistory array to data.ma.mailHistory array.
        var filteredVersions = [];
        angular.forEach(data.ma.maVersions, function(version) {
          if (version.versionId * 1 !== 0) filteredVersions.push(version);
        });
        data.ma.maVersions = filteredVersions;
        if (data.ma && (data.mailHistory.length > 0)) {
          data.ma.mailHistory = [];

          // For each MHID in data.mailHistory, look for that MHID in data.ma.mailHistory. If it exists, update it, else add new MHID to data.ma.mailHistory
          angular.forEach(data.mailHistory, function(mhid, index) {
            var mhidFound = false;
            /**
             * @ check for MHID and add cell if found
             */
            var initialDate;
            angular.forEach(data.ma.mailHistory, function(maMhid, maIndex) {
              initialDate = new Date(mhid.startDate);

              if (maMhid.mhid === mhid.mhid && maMhid.cells.indexOf(mhid.cell) === -1) {
                // Found the MHID under data.ma.mailHistory, so simply update it.
                mhid.startDate = (initialDate.getMonth() + 1) + '/' + initialDate.getDate() + '/' + initialDate.getFullYear();
                maMhid.cells.push(mhid.cell);
                mhidFound = true;
              }
            });
            /**
             * @ if mhid is not found create one
             */
            if (!mhidFound) {
              initialDate = new Date(mhid.startDate);
              data.ma.mailHistory.push({
                mhid: mhid.mhid,
                startDate: (initialDate.getMonth() + 1) + '/' + initialDate.getDate() + '/' + initialDate.getFullYear(),
                cells: [mhid.cell]
              });
            }
          });
        }

        if (data.ma && data.ma.maCells) {
          data.ma.maCells.forEach(function(cell) {
            delete cell.edit;
            delete cell.editing;
          });
        }
        delete data.mailHistory;
      } else { // One-off and Servicing campaigns
        // Look for all the versions that does not have any cell mapping, we need to remove that.
        if (data.versions && data.versions.length) {
          for (var verIndex = 0; verIndex < data.versions.length; verIndex++) {
            if (data.versions[verIndex].cells && data.versions[verIndex].cells.length === 0) {
              data.versions.splice(verIndex, 1);
              verIndex--;
            }
          }
          ;
        }
      }

      if (data.deploymentDates && data.deploymentDates.length) {
        data.deploymentDates = data.deploymentDates.map(function(d){
          if (!+d) return null;
          return moment(d).startOf('d').format('MM/DD/YYYY');
        });
      }
      
      if (+data.endDate) {
        data.endDate = moment(data.endDate).startOf('d').format('MM/DD/YYYY');
      }

      /**
       * This block is to set BU Deployment slot for the campaign
       * Checking campaign email type as this is applicable only for ONEOFF
       */
      if (data.emailType && data.emailType.codeName === 'ET_ONEOFF') {
        data.buDeployment = new Date(data.buDeployment).dateToString();
      }
      /* Set the Object values for the Comm Code and products selected */
      if (data.emailType && data.emailType.codeName === 'ET_PNL' && data.commCode) {
        var productObjects = {};
        var products = (data.products && data.products.length > 0) ? data.products : [];
        data.commCode = utilities.getSelectedObject(data.commCode, initLoadData.commCodes, 'code');
        data.commCode.products = [];
        angular.forEach(products, function(value, key) {
          data.commCode.products.push($filter('filter')(initLoadData.products, {
            code: value
          }, true));
        });

        // data.commCode.products = productObjects;
      }
      return angular.toJson(data);
    }

    function transformSearchRequest(request) {

      if (request.deployStartDatePicker.date) {
        request.deploymentStartDate = request.deployStartDatePicker.date.dateToString();
      }

      if (request.deployEndDatePicker.date) {
        request.deploymentEndDate = request.deployEndDatePicker.date.dateToString();
      }

      if (request.requestedStartDatePicker.date) {
        request.requestedStartDate = request.requestedStartDatePicker.date.dateToString();
      }

      if (request.requestedEndDatePicker.date) {
        request.requestedEndDate = request.requestedEndDatePicker.date.dateToString();
      }

      request.mhid = angular.uppercase(request.mhid);
      request.uid = request.uid === 'all' ? '' : request.uid;
      request.emailType = request.emailType === 'all' ? '' : request.emailType;
      request.marketingManager = request.marketingManager === 'all' ? '' : request.marketingManager;
      request.businessUnit = request.businessUnit === 'all' ? '' : request.businessUnit;
      request.campaignStatus = request.campaignStatus === 'all' ? '' : request.campaignStatus;
      // STO Changes
      request.stoEventToTrack = request.stoEventToTrack === 'all' ? '' : request.stoEventToTrack;
      request.stoEmailTrackingTypes = request.stoEmailTrackingTypes === 'all' ? '' : request.stoEmailTrackingTypes;
      if (request.edis === 'true') {
        request.edis = true;
      } else if (request.edis === 'false') {
        request.edis = false;
      } else {
        delete request.edis;
      }
      return angular.toJson(request);
    }

    var ewtCampaign = $resource(url, {
      'id': '@_id'
    }, {
      get: {
        transformResponse: transformResponse
      },
      query: {
        params: {
          'columns': 'name,emailType,requestor.name,requestID,emailType,deploymentDates,state.name,state.codeName,lock.isLocked,lock.key,lock.owner.uid'
        },
        isArray: true
      },
      search: {
        method: 'POST',
        isArray: true,
        url: APIServer + 'filter/campaigns',
        transformRequest: transformSearchRequest
      },
      cancel: { //cancel drop date api
        method: 'POST',
        isArray: true,
        url: APIServer + 'cancelCampaignDrops'
      },
      save: {
        method: 'POST',
        isArray: false,
        transformResponse: transformResponse,
        transformRequest: transformRequest
      },
      update: {
        method: 'POST',
        transformResponse: transformResponse,
        transformRequest: transformRequest
      },
      lock: {
        method: 'GET',
        url: url + '/lock/:tabId'
      },
      unlock: {
        method: 'GET',
        url: url + '/unlock/:tabId'
      },
      extendlock: {
        method: 'GET',
        url: url + '/extend-lock/:tabId'
      },
      verifyRollback: {
        method: 'GET',
        url: APIServer + 'verifyRollback/:requestID'
      }
    });

    ewtCampaign.prototype.state = {
      codeName: 'draft'
    };

    // TODO - removed if un-used
    ewtCampaign.prototype.getSelectedArrObj = function(key, array, indicator) {
      return utilities.getSelectedObject(key, array, indicator);
    };

    ewtCampaign.prototype.searchCampaigns = function(searchObject) {
      return ewtCampaign.search(angular.copy(searchObject)).$promise;
    }

    var upload = function(url, files, postData, successCallback, errorCallback) {
      var uploadSpinner;
      postData = postData || {};
      successCallback = successCallback || function() {};
      errorCallback = errorCallback || function() {};
      if (!Array.isArray(files)) {
        files = [files];
      }
      if (files && files.length) {
        uploadSpinner = $('#upload-spinner-modal');
        uploadSpinner.modal('show');
        Upload.upload({
          url: url,
          method: 'POST',
          fields: {
            id: this._id
          },
          data: postData,
          file: files
        }).success(function(attachments) {
          uploadSpinner.modal('hide');
          successCallback(attachments);
        }).error(function(error) {
          uploadSpinner.modal('hide');
          errorCallback(error);
        });
      }
    };

    /////////////////MANAGER ACTIONS

    ewtCampaign.prototype.submitted2admin = function() {
      this.state.codeName = 'submitted2admin';
      this.saveAsIs(null);
    };
    ewtCampaign.prototype.saveAsDraft = function(creativeMockup) {
      this.saveAsIs(creativeMockup, true);
    };
    ewtCampaign.prototype.deploy = function() {
      this.state.codeName = 'queued2esp';
      this.saveAsIs(null);
    };

    ///////////////ADMIN ACTIONS
    ewtCampaign.prototype.deny = function(email, declineReason) {
      this.state.codeName = 'declined';
      this.declineReason = {};
      this.declineReason.email = email;
      this.declineReason.comments = declineReason;
      this.saveAsIs(null);
    };

    ewtCampaign.prototype.approve = function() {
      this.state.codeName = 'approved';
      this.saveAsIs(null);
    };

    ewtCampaign.prototype.revisionRequired = function(resp, reason) {
      this.revisionRequired = {};
      this.revisionRequired.email = resp;
      this.revisionRequired.reason = reason;
      this.state.codeName = 'revisionRequired';
      this.saveAsIs(null);
    };

    /**
     * rollBack - prototype method added to Campaign Object
     * @param  {String} recepients   - coma seperated email addresses of recepients.
     * @param  {String} reason - reason for roll back
     */
    ewtCampaign.prototype.rollBack = function(recepients, reason) {
      /**
       * rollBack - holder of the recipients and the reason for rollback
       * @type {Object}
       */
      this.rollBack = {};
      this.rollBack.email = recepients;
      this.rollBack.reason = reason;
      /**
       * Changing the status of the campaign and saving the campaign
       * @type {String}
       */
      this.state.codeName = 'rollBack2Manager';
      this.saveAsIs(null);
    };

    ewtCampaign.prototype.submitForApproval = function(form, mockUpload) {
      // this.cmNeedSelected = this.cmNeed.available;
      this.state = {};
      this.state.codeName = 'submitted4approval';
      form.$dirty = false;
      this.saveAsIs(mockUpload);
    };

    //////////////COMMON ACTIONS
    ewtCampaign.prototype.saveAsIs = function(creativeMockup, isSaveAsDraft) {
      var dbOperation, isRequestIDExsists = false;
      if (this._id) {
        isRequestIDExsists = true;
        dbOperation = this.$update();
      } else {
        dbOperation = this.$save();
      }
      var previousState = this.state.codeName;
      var campaignObjectRef = angular.copy(this);
      dbOperation.then(
        // Success handler
        function(response) {
          if (creativeMockup) {
            var mockUploadUrl = APIServer + 'files/' + response._id + '/creative-mock';
            campaignObject.attachFiles(mockUploadUrl, creativeMockup, function(creativeMockResponse) {
              if (isSaveAsDraft) {
                campaignObjectRef.showAlert('Campaign Saved Successfully');
                $state.go('app.auth.campaigns.details', {
                  id: response._id
                }, {
                  reload: true
                });
              } else {
                $state.go('app.auth.campaigns.list');
              }
            }, function(error) {
              campaignObjectRef.showAlert('Could not upload creative mock. Please try again.');
            });
          } else {
            if (isSaveAsDraft) {
              campaignObjectRef.showAlert('Campaign Saved Successfully');
              $state.go('app.auth.campaigns.details', {
                id: response._id
              }, {
                reload: true
              });
            } else {
              $state.go('app.auth.campaigns.list');
            }
          }
        },
        // Error handler for non-200 response from server
        function(error) {
          if ((error.data) && (error.data.showOnUI)) {
            campaignObjectRef.showAlert(error.data.reason);
          }
          return false;
        }
      );
    };

    ewtCampaign.prototype.uploadMockFile = function(creativeMockup, campaignId) {
      var mockUploadUrl = APIServer + 'files/' + campaignId + '/creative-mock';
      var campaignRef = this;
      campaignObject.attachFiles(mockUploadUrl, creativeMockup, function(response) {
        campaignRef.creativeMockup = response;
      }, function(error) {
        campaignObject.showAlert('Could not upload creative mock. Please try again.');
      });
    };

    ewtCampaign.prototype.showFile = function(file_id, file_name) {
      $window.open(APIServer + 'files/' + file_id + '/name/' + file_name, '_blank');
    };

    ewtCampaign.prototype.$uploadAttachment = function($files) {
      var url = APIServer + 'files';
      return upload.call(this, url, $files);
    };

    /**
     * @ Trim all the emails in the given text at ';' and check whether they are valid emails or not
     *  check the valid email using '/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/' regular expression
     */
    ewtCampaign.prototype.validateSeedEmailList = function(emailsSourceString, emailsArray, maxEamils, name) {
      var isValidEmails = true;
      var resultSeedArray = [];
      var regEx;
      regEx = '^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$';
      if (name === 'approversList') {
        regEx = '^[a-zA-Z0-9_.+-]+@aexp\.com$';
      }

      if (!emailsSourceString) {
        return 'stringEmpty';
      }
      resultSeedArray = emailsSourceString.split(/[;,]+/);
      if (resultSeedArray[resultSeedArray.length - 1] === '') {
        resultSeedArray.splice(resultSeedArray.length - 1, 1);
      }
      if (resultSeedArray.length < 1 || resultSeedArray.length > maxEamils) {
        return 'errMAxEmails';
      }
      resultSeedArray.forEach(function(email) {
        if (!email.toLowerCase().trim().match(regEx)) {
          isValidEmails = 'invalid';
        } else {
          emailsArray.push(email);
        }
      });
      return isValidEmails;
    };

    /*
     MailPlan related action methods
     */

    ewtCampaign.prototype.addCell = function(cell) {
      cell = angular.copy(cell);
      cell.versionName = cell.versionNo;
      this.cells.push(cell);
    };

    ewtCampaign.prototype.updateCell = function(cell, atIndex) {
      cell = angular.copy(cell);
      var oldCell = this.cells[atIndex];

      // Checking if cell's version has subjectlines
      var subjectLinesRelated = $filter('filter')(this.subjectLinesArr, {
        number: oldCell.versionNo
      }, true);

      /**
       * Preventing popup if mail type is ONE OFF
       */
      if (subjectLinesRelated.length && cell.versionNo !== oldCell.versionNo && this.emailType.codeName !== 'ET_ONEOFF' && this.emailType.codeName !== 'ET_PNL') {
        /**
         * @ Enters this block only when version has been changed and old version has subjectLines.
         */
        if ($filter('filter')(this.cells, {
            versionNo: subjectLinesRelated[0].number
          }, true).length === 1) {
          // If version has a subjectline and has only one cell in it.
          var campaignobj = this;
          this.modal.open({
            'message': 'A subject line uses this version. Deleting this version will also delete the subject line.',
            'actionButtons': [{
              'label': 'Yes',
              'buttonType': 'success',
              'callBack': function() {
                // call the 'yes' action method provided by campaign service
                campaignobj.removeSubjectLine(-1, campaignobj.cells[atIndex].versionNo);
                if (campaignobj.attachments) {
                  campaignobj.attachments.forEach(function(attachment) {
                    if (campaignobj.cells[atIndex].versionNo === attachment.creativeVersion) {
                      attachment.creativeVersion = '';
                    }
                  });
                }
                // operations.onEdit is condition to check if subject removal pop up is called on editing cell
                campaignobj.cells.splice(atIndex, 1, cell);
                campaignobj.cells[atIndex].editing = false;
                campaignobj.editApproved = true;
              }
            }, {
              'label': 'No',
              'buttonType': 'error',
              'callBack': function() {}
            }]
          });
        } else {
          this.cells.splice(atIndex, 1, cell);
        }
      } else {
        this.cells.splice(atIndex, 1, cell);
      }
    };

    ewtCampaign.prototype.removeCell = function(index) {
      var versionHaveSubjectLine = false,
        cells = this.cells,
        subjectLinesArr = this.subjectLinesArr,
        attachments = this.attachments,
        count = 0,
        slIndex = [],
        deleteRelatedRecords = true;

      // check if its the last entry of version to be delete
      cells.forEach(function(cell, cellIndex) {
        if (index !== cellIndex && cells[index].versionNo === cells[cellIndex].versionNo) {
          deleteRelatedRecords = false;
        }
      });

      if (deleteRelatedRecords) {
        // identify the subject lines to be deleted
        subjectLinesArr.forEach(function(subject) {
          if (cells[index].versionNo === subject.number && (subject.subjectLine && subject.subjectLine !== '')) {
            versionHaveSubjectLine = true;
            slIndex.push(count);
          }
          count++;
        });
      }

      /**
       * Preventing popup if mail type is ONE OFF
       */
      switch (this.emailType.codeName) {
        case 'ET_ONEOFF':
        case 'ET_PNL':
          if (deleteRelatedRecords) {
            // remove version (make drop-down blank) from attachement tab, if already in use
            attachments.forEach(function(attachment) {
              if (cells[index].versionNo === attachment.creativeVersion) {
                attachment.creativeVersion = '';
              }
            });
          }
          this.cells.splice(index, 1);
          break;
        default:
          if (versionHaveSubjectLine) {
            var campaignobj = this;
            this.modal.open({
              'message': 'A subject line uses this version. Deleting this version will also delete the subject line.',
              'actionButtons': [{
                'label': 'Yes',
                'buttonType': 'success',
                'callBack': function() {
                  // call the 'yes' action method provided by campaign service
                  campaignobj.removeSubjectLine(-1, campaignobj.cells[index].versionNo);
                  if (campaignobj.attachments) {
                    campaignobj.attachments.forEach(function(attachment) {
                      if (campaignobj.cells[index].versionNo === attachment.creativeVersion) {
                        attachment.creativeVersion = '';
                      }
                    });
                  }
                  campaignobj.cells.splice(index, 1);
                }
              }, {
                'label': 'No',
                'buttonType': 'error',
                'callBack': function() {}
              }]
            });
          } else {
            if (deleteRelatedRecords) {
              // remove version (make drop-down blank) from attachement tab, if already in use
              attachments.forEach(function(attachment) {
                if (cells[index].versionNo === attachment.creativeVersion) {
                  attachment.creativeVersion = '';
                }
              });
            }
            this.cells.splice(index, 1);
          }
          break;
      }
    };

    ewtCampaign.prototype.isUniqueCell = function(newCell, action, cellParent) {
      // Check if campaign.cells have new Cell.
      var sourceCodes = [];
      if (!this.cells)
        return false;
      this.cells.forEach(function(value, index) {
        sourceCodes.push(angular.lowercase(value.srcCode));
      });
      // Check if campaign.cells have new Cell.
      if (sourceCodes.indexOf(angular.lowercase(newCell.srcCode)) !== -1) {
        // If we are editing a campaign cell.
        if (action === 'editing') {
          // If srcCode exist --> this will check for emptying CellID field.
          if (newCell.srcCode === cellParent.srcCode) {
            return true;
          } else {
            return false;
          }
        } else {
          return false;
        }
      } else {
        return true;
      }
    };
    /**
     * Checks if cell object has defined values(Depending on email type).
     */
    ewtCampaign.prototype.isCellProper = function(cell) {
      if (cell.description && cell.type && cell.srcCode) {
        // If campaign is MA then cell is valid.
        if (cell.srcCode.length < 21 && cell.srcCode.match('^[A-Za-z0-9]*$') !== null) {
          if (this.emailType.codeName === 'ET_MA') {
            return true;
          } else {
            if (cell.versionNo) {
              return true;
            } else {
              return false;
            }
          }
        } else {
          return false;
        }
      } else {
        return false;
      }
    };

    /**
     * removeSubjectLine - Removes subject line from versions
     * @param  {Number} index        Index of subjectline to be deleted
     * @param  {String} versionNo    Version number to which the subject is mapped
     */
    ewtCampaign.prototype.removeSubjectLine = function(index, versionNo) {
      switch (this.emailType.codeName) {
        case 'ET_ONEOFF':
        case 'ET_PNL':
          $filter('filter')(this.versions, {
            number: versionNo
          }, true)[0].subjects.splice(index, 1);
          break;
        default:
          if (index >= 0 && index < this.subjectLinesArr.length) {
            this.subjectLinesArr.splice(index, 1);
          } else if (versionNo) {
            for (var indx = this.subjectLinesArr.length - 1; indx >= 0; indx--) {
              if (this.subjectLinesArr[indx].number === versionNo) {
                this.subjectLinesArr.splice(indx, 1);
              }
            }
          }
          break;
      }
    };

    ewtCampaign.prototype.isVersionRequired = function(newCell) {
      if (this.emailType.codeName === 'ET_MA') {
        return false;
      } else {
        if (newCell.versionNo) {
          return false;
        } else {
          return true;
        }
      }
    };

    /*
     * Attaches the uploaded file to campaign and returns attachments of the campaign
     */
    ewtCampaign.prototype.attachFileToCampaign = function(urlToUploadSvc, fileToUpload, SCallback, ECallBack) {
      return campaignObject.attachFiles(urlToUploadSvc, fileToUpload, SCallback, ECallBack);
    };

    ewtCampaign.prototype.attachVersionFileToCampaign = function(urlToUploadSvc, fileToUpload, currentVersion, callback) {
      return upload.call(this, urlToUploadSvc, fileToUpload, angular.toJson(currentVersion), callback);
    };

    ewtCampaign.prototype.unlockCampaign = function(campaign, reAcquireLock) {
      var campaignInstance = this;
      ewtCampaign.unlock({
        id: campaign._id,
        tabId: window.sessionStorage.getItem('tabId')
      }).$promise.then(
        function(response) {
          if (response.status === 'success') {
            if (reAcquireLock) {
              ewtCampaign.lock({
                id: campaign._id,
                tabId: window.sessionStorage.tabId
              }).$promise.then(
                function(response) {
                  if (response.status === 'success') {
                    // successfully acquired the campaign, so sync up client lock status
                    campaign.lock = {
                      isLocked: response.isLocked || false,
                      owner: response.lockOwner || null,
                      expiresAt: response.expiresAt || null,
                      key: response.lockKey || null
                    }
                  }
                });
            } else {
              // successfully unclocked the campaign, so sync up client lock status
              campaign.lock = {
                isLocked: false,
                owner: null,
                expiresAt: null,
                key: null
              }
            }
          }
        });
    };

    this.attachFiles = function(urlToUploadSvc, fileToUpload, successCallback, errorCallback) {
      return upload.call(this, urlToUploadSvc, fileToUpload, {}, successCallback, errorCallback);
      // return upload.call(this, urlToUploadSvc, fileToUpload, successCallback, errorCallback);
    };

    /*
     Removes the file from campaign and returns attachments of the campaign
     */
    ewtCampaign.prototype.removeFile = function(url, callback) {
      $http({
        method: 'GET',
        url: url,
        headers: {
          'Content-Type': undefined
        }
      }).success(function(data) {
        callback(data);
      });
    };
    ewtCampaign.prototype.removeMock = function(url, callback) {
      $http({
        method: 'GET',
        url: url,
        headers: {
          'Content-Type': undefined
        }
      }).success(function(data) {
        callback(data);
      });
    };
    /*
     * This function creates the marketing automation version id's like 1A, 1B, 1C....
     */
    ewtCampaign.prototype.versionIdGenerator = function(currentVersionId) {
      currentVersionId = parseInt(currentVersionId);
      var nextVersionId = {};
      if (currentVersionId) {
        this.currentMAVersionId = currentVersionId + 1;
      } else {
        this.currentMAVersionId = 1;
      }
    };
    /**
     * @Update the Each Ma Version withe the updated fields in the MA version form
     */
    ewtCampaign.prototype.updateMAVersion = function(version) {
      var temp = $filter('filter')(this.ma.maVersions, {
        versionId: version.versionId
      })[0];
      if (temp && version.versionId !== 0) {
        temp.versionName = version.versionName;
        temp.subjectLine = version.subjectLine;
        temp.creativeDocument = version.creativeDocument;
        temp.poid = version.poid;
        temp.triggerEvent = version.triggerEvent;
      }
    };

    ewtCampaign.prototype.removeVersionFile = function(vFile) {
      this.current.deletedFile = this.current.deletedFile || [];
      if (vFile.gfsID) {
        this.current.deletedFile.push({
          '_id': vFile.gfsID
        });
      }
    };

    /**
     * @Function:Add the MHID to the list
     */
    ewtCampaign.prototype.addMHID = function(mhid) {
      var campaignObject = this;

      var mhidCells = $filter('filter')(campaignObject.mailHistory, {
        mhid: mhid.mhid
      }, true);
      if (mhidCells.length > 0) {
        angular.forEach(mhidCells, function(value, index) {
          var mhidDt = new Date(mhid.startDate);
          value.startDate = mhidDt;
          value.incomplete = false;
        });
      }

      mhid.requestID = campaignObject.requestID;

      mhid.cell = [];
      angular.forEach(mhid.newSrcCodes, function(value, index) {
        mhid.cell.push($filter('filter')(campaignObject.cells, {
          srcCode: value
        }, true)[0]);
      });
      delete mhid.newSrcCodes;
      ewtMasterDataService.MhidService(mhid, 'add').then(function(response) {
        // campaignObject.mailHistory.push(angular.copy(response.data.newMhid));
        /**
         * @disabling removal of cells if associated to MHID
         */
        angular.forEach(campaignObject.cells, function(value, index) {
          delete value.isLinkedToMHID;
          delete value.removeAlternative;
          delete value.editAleternative;
        });
        var tempMHID = response.data.newMhid;
        angular.forEach(response.data.newMhid.cell, function(cellInMHid, innerIndex) {
          var innerTempMhid = angular.copy(tempMHID);
          innerTempMhid.cell = cellInMHid;
          innerTempMhid.startDate = new Date(innerTempMhid.startDate);
          campaignObject.mailHistory.push(innerTempMhid);
        });
        angular.forEach(campaignObject.mailHistory, function(mhidObj, mhidIndex) {
          angular.forEach(campaignObject.cells, function(value, index) {
            if (value.srcCode === mhidObj.cell.srcCode) {
              value.isLinkedToMHID = true;
              value.removeAlternative = 'Cannot remove as linked to a MHID';
              value.editAleternative = 'Cannot edit as linked to a MHID';
            }
          });
        });
        campaignObject.atleastOneDateEqual = campaignObject.checkForStartDate();
      });
    };
    ewtCampaign.prototype.removeMHID = function(index) {
      var campaignObject = this;

      var mhid = this.mailHistory[index];
      mhid.id = this._id;
      ewtMasterDataService.MhidService(mhid, 'remove').then(function(response) {
        if (response.data && response.data.message === 'success') {
          campaignObject.mailHistory.splice(index, 1);
          /**
           * @disabling removal of cells if associated to MHID
           */
          angular.forEach(campaignObject.cells, function(value, index) {
            delete value.isLinkedToMHID;
            delete value.removeAlternative;
            delete value.editAleternative;
          });
          angular.forEach(campaignObject.mailHistory, function(mhidObj, mhidIndex) {
            angular.forEach(campaignObject.cells, function(value, index) {
              if (value.srcCode === mhidObj.cell.srcCode) {
                value.isLinkedToMHID = true;
                value.removeAlternative = 'Cannot remove as linked to a MHID';
                value.editAleternative = 'Cannot edit as linked to a MHID';
              }
            });
          });
        }
      });

    };
    ewtCampaign.prototype.updateMHID = function(newMhid, atIndex) {
      var campaignObject = this;

      var mhidCells = $filter('filter')(campaignObject.mailHistory, {
        mhid: newMhid.mhid
      }, true);
      if (mhidCells.length > 0) {
        angular.forEach(mhidCells, function(value, index) {
          value.startDate = new Date(newMhid.startDate);
          value.incomplete = false;
        });
      }

      newMhid.cell = $filter('filter')(this.cells, {
        srcCode: newMhid.cell.srcCode
      }, true)[0];
      var request = {
        requestID: this.requestID,
        newMHID: newMhid
      };
      var oldMHID = angular.copy(this.mailHistory[atIndex]);
      delete oldMHID.edit;
      delete oldMHID.editing;
      request.oldMHID = oldMHID;

      ewtMasterDataService.MhidService(request, 'add').then(function(response) {
        campaignObject.atleastOneDateEqual = campaignObject.checkForStartDate();
        campaignObject.mailHistory.splice(atIndex, 1, newMhid);
        /**
         * @disabling removal of cells if associated to MHID
         */
        angular.forEach(campaignObject.cells, function(value, index) {
          delete value.isLinkedToMHID;
          delete value.removeAlternative;
          delete value.editAleternative;
        });

        angular.forEach(campaignObject.mailHistory, function(mhidObj, mhidIndex) {
          angular.forEach(campaignObject.cells, function(value, index) {
            if (value.srcCode === mhidObj.cell.srcCode) {
              value.isLinkedToMHID = true;
              value.removeAlternative = 'Cannot remove as linked to a MHID';
              value.editAleternative = 'Cannot edit as linked to a MHID';
            }
          });
        });
      });
    };

    ewtCampaign.prototype.filterInArray = function(array, value, key) {
      var filterObj = {};
      filterObj[key] = value;
      return $filter('filter')(array, filterObj, true);
    };
    /**
     * @Function Which validate the MHID created.
     */
    ewtCampaign.prototype.validateMHID = function(mhidObj, atIndex) {
      // Setting negations to return for proper view rendering
      if (this.emailType.codeName === 'ET_MA') {
        if (this.filterInArray(this.mailHistory, mhidObj.mhid, 'mhid').length !== 0) {
          if (atIndex >= 0 && this.mailHistory[atIndex] && mhidObj.mhid === this.mailHistory[atIndex].mhid) {
            mhidObj.isnewMHIDValid = {
              status: false,
              message: 'Same as parent'
            };
            mhidObj.startDate = this.filterInArray(this.mailHistory, mhidObj.mhid, 'mhid')[0].startDate;
            return;
          }
          mhidObj.isnewMHIDValid = {
            status: false,
            message: 'MHID Exists locally'
          };
          mhidObj.startDate = new Date(this.filterInArray(this.mailHistory, mhidObj.mhid, 'mhid')[0].startDate);
          return;
        }
      }
      if (this.emailType.codeName === 'ET_MA' || this.emailType.codeName === 'ET_SERVICING') {
        ewtMasterDataService.verifyMhid(mhidObj.mhid).then(function(response) {
          if (response.data.errorMessage) {
            mhidObj.isnewMHIDValid = {
              status: true,
              message: 'MHID already Exists in DB'
            };
          } else {
            mhidObj.isnewMHIDValid = {
              status: false,
              message: 'New MHID'
            };
          }
        });
        return;
      }
    };

    ewtCampaign.prototype.checkForStartDate = function() {
      var dateExists = false;
      var tempDate = new Date(this.deploymentDates[0]);
      // tempDate = angular.copy(this.deploymentDates[0]);
      this.mailHistory.forEach(function(value, index) {
        value.startDate = new Date(value.startDate);
        if (tempDate.getDate() === value.startDate.getDate() && tempDate.getMonth() === value.startDate.getMonth() && tempDate.getFullYear() === value.startDate.getFullYear()) {
          dateExists = true;
          return dateExists;
        }
      });
      return dateExists;
    };

    // Campaign Comments (Notes Slide Out)

    ewtCampaign.prototype.addComment = function(comment) {
      if (comment) {
        var commentObj = {},
          currentDate = new Date();
        commentObj.timestamp = (currentDate.getMonth() + 1) + '/' + currentDate.getDate() + '/' + currentDate.getFullYear();
        commentObj.userName = this.initLoadData.loggedInUser.name;
        commentObj.content = comment;
        this.comments.push(commentObj);
        this.newComment = '';
      }
    };

    /**
     * showAlert - Shows custom alert to user
     * @param  {String} message    Message to be shown to user
     */
    ewtCampaign.prototype.showAlert = function(message) {
      if (message !== null && message) {
        this.modal.open({
          'message': message,
          'onlyInfo': true
        });
      }
    };

    ewtCampaign.prototype.cancelledAllCells = function() {
      this.state.codeName = 'cancelled';
      this.$update();
    }

    ewtCampaign.prototype.cancelCampaign = function() {
      if (this.isSubmittedToESP) {
        var formattedCells = [],
          newKeys = {};
        var finalDateSubmitted = angular.copy(this.criticalDataSubmittedCopy);
        for (var cnt = 0; cnt < finalDateSubmitted.length; cnt++) {
          var dateObj = finalDateSubmitted[cnt];
          for (var keysCnt = 0; keysCnt < dateObj.keys.length; keysCnt++) {
            var keysObj = dateObj.keys[keysCnt];
            if (this.cancelAllDrops === 'false') { // cancel only few drop dates
              if (keysObj.checked) {
                delete keysObj.checked;
                keysObj.CMPGN_DEPLOY_DATE = dateObj.date;
                newKeys = {};
                newKeys.keys = keysObj;
                formattedCells.push(newKeys);
              }
            } else { // cancel all drop date
              delete keysObj.checked;
              keysObj.CMPGN_DEPLOY_DATE = dateObj.date;
              newKeys = {};
              newKeys.keys = keysObj;
              formattedCells.push(newKeys);
            }
          }
        }
        var finalFomattedCellsObj = {};
        finalFomattedCellsObj.requestID = this.requestID;
        finalFomattedCellsObj.canceledDrops = formattedCells;
        var campaignObj = this;
        return ewtCampaign.cancel(angular.copy(finalFomattedCellsObj)).$promise;
      } else {
        this.state.codeName = 'cancelled';
        return this.$update();
      }
    };

    /**
     * This function creates array of objects required to display version drop selection drop
     * down in attachment tab. This is done by iterating the cell versions in case of servicing and
     * one off campaigns, and ma versions in case of marketing automation. When ever a new version is
     * added / updated, this function should be called to ensure that the array has latest information.
     */
    ewtCampaign.prototype.createVersionDropDownInfo = function() {
      var dropdownData = [];
      if (this.emailType.codeName === 'ET_MA' && this.ma && this.ma.maVersions) {
        this.ma.maVersions.forEach(function(version) {
          if (version.versionId !== '0') {
            if ($filter('filter')(dropdownData, {
                versionId: version.versionId,
                versionName: version.versionId
              }, true).length === 0) {
              dropdownData.push({
                versionId: version.versionId,
                versionName: version.versionId
              });
            }
          }
        });
      } else if (this.emailType.codeName === 'ET_SERVICING' && this.cells) {
        this.cells.forEach(function(cell) {
          if (cell.versionNo * 1 !== 0) {
            if ($filter('filter')(dropdownData, {
                versionId: cell.versionNo,
                versionName: cell.versionNo
              }, true).length === 0) {
              dropdownData.push({
                versionId: cell.versionNo,
                versionName: cell.versionNo
              });
            }
          }
        });

      } else if ((this.emailType.codeName === 'ET_ONEOFF' || this.emailType.codeName === 'ET_PNL') && this.versions) {
        this.versionNos.forEach(function(version) {
          if (version * 1 !== 0) {
            if ($filter('filter')(dropdownData, {
                versionId: version,
                versionName: version
              }, true).length === 0) {
              dropdownData.push({
                versionId: version,
                versionName: version
              });
            }
          }
        });
      }
      this.versionInfo = dropdownData;

    };

    return ewtCampaign;
  }]);
