/**
 * Module: UI StatepnlCampaign
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2016 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: ERA -- One Off Service entry for all the events and validation methods.
 */

'use strict';

angular.module('ewtApp')
  .service('oneoffCampaign', ['$filter', 'ewtMasterDataService', 'ewtUtils', 'oneOffDescription', 'oneOffMailplan',
    function($filter, ewtMasterDataService, ewtUtils, oneOffDescription, oneOffMailplan) {

      var scope, campaign, campaignService, data;

      var oneoffCampaign = {
        init: function($scope) {
          scope = $scope;
          campaign = $scope.campaign;
          campaignService = $scope.campaignService;
          data = $scope.data;
        },
        events: {
          description: {
            /**
             * Name: emailTypeChange
             * Description: called when th emial type is changed to PNL in the drop down
             *             resets the values according to type of email selected
             */
            emailTypeChange: function(campaign, data, initLoadData) {
              oneOffDescription.events.emailTypeChange(campaign, data, initLoadData);
            },
            businessUnitChange: function(campaign, data, initLoadData) {
              oneOffDescription.events.businessUnitChange(campaign, data, initLoadData);
            },
            /**
             * [needCategoryChange This function in invoked when Primary Need Category changes in dropdonw
             *  and it makes a api call to get the respective secondary opt out categories and update in the view]
             *
             */
            needCategoryChange: function(triggeredFrom, campaign, data) {
              oneOffDescription.events.needCategoryChange(triggeredFrom, campaign, data);
            }
          },
          mailplan: {
            updateCell: function() {},
            updateVersion: function(campaign, version, index) {
              oneOffMailplan.events.updateVersion(campaign, version, index);
            },
            addSubjectLine: function(campaign, version, subjectLine) {
              oneOffMailplan.events.addSubjectLine(campaign, version, subjectLine);
            },
            updateSubjectLine: function(campaign, versionNo, slIndex, subject) {
              oneOffMailplan.events.updateSubjectLine(campaign, versionNo, slIndex, subject);
            },
            removeSubjectLine: function(campaign, versionNo, index) {
              oneOffMailplan.events.removeSubjectLine(campaign, versionNo, slIndex, subject);
            }
          }
        }
      }
      return oneoffCampaign;
    }
  ])
