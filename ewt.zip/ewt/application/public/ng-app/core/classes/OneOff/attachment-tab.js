/**
 * Module: UI StatepnlCampaign
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2016 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.
 *
 * Description: ERA -- All Attachment common methods go in to this.
 */
'use strict';
angular.module('ewtApp')
  .service('attachmentOneOff', ['$filter', 'ewtCampaign', 'APIServer',
    function($filter, ewtCampaign, APIServer) {
      var attachment = {
        events: {
          attachment: {}
        }
      }
    }])