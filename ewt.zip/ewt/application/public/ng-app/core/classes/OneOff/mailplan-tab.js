/**
 * Module: OneOff -- Mailplan Tab Service
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2016 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: ERA -- One Off Mailplan tab events / validations  
 */

'use strict';

angular.module('ewtApp')
  .service('oneOffMailplan', ['$filter', 'ewtMasterDataService', 'ewtUtils', 'campaignDurationWeeks',
    function($filter, ewtMasterDataService, ewtUtils, campaignDurationWeeks) {

      var oneOffMailplan = {
        events: {
          updateVersion: function(campaign, version, index) {
            campaign.versions = campaign.versions || [];
            if (index > -1) {
              /**
               * checks if version number has changed and also if version has cells associated to it
               * if true shows alert to user
               * else updates the version
               */
              if ($filter('filter')(campaign.cells, {
                  versionNo: campaign.versions[index].number
                }, true).length > 0 && version.number !== campaign.versions[index].number) {
                campaign.showAlert('There are Source Code / Cell IDs mapped to this version. Please update the Creative Version associated to the Source Codes to delete this version.');
              } else {
                campaign.versions.splice(index, 1, version);
              }
            } else {
              version.subjects = [];
              version.subjectsShown = true;
              version.newSubject = true;
              campaign.versions.push(version);
            }
            var versionNos = [];
            angular.forEach(campaign.versions, function(ver) {
              versionNos.push(parseInt(ver.number, 10));
            });
            campaign.versionNos = versionNos;
            campaign.createVersionDropDownInfo();
          },
          addSubjectLine: function(campaign, version, subjectLine) {
            version.subjects.push(subjectLine);
          },
          updateSubjectLine: function(campaign, versionNo, slIndex, subject) {
            var version = $filter('filter')(campaign.versions, {
              number: versionNo
            }, true)[0];

            if (version) {
              version.subjects.splice(slIndex, 1, subject);
            }
          },
          removeSubjectLine: function(campaign, versionNo, index) {
            $filter('filter')(campaign.versions, {
              number: versionNo
            }, true)[0].subjects.splice(index, 1);
          }
        }
      }
      return oneOffMailplan;
    }
  ]);
