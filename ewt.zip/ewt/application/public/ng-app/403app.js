'use strict';

/**
 * @ngdoc overview
 * @name appNameApp
 * @description
 * # appNameApp
 *
 * 403 page module of the application.
 */
(function() {
  angular.module('ewt_403app', [])
    .factory('ewt_403Factory', ['$http', function($http) {
      return {
        requestAccess: function(requestingUser) {
          delete requestingUser.showLink;
          delete requestingUser.firstName;
          delete requestingUser.lastName;
          return $http({
            method: 'POST',
            url: '/api/v1/requestAccess',
            data: requestingUser
          });
        }
      };
    }])
    .controller('ewt_403appController', ['$scope', 'ewt_403Factory', 'requestingUser', function($scope, ewt_403Factory, requestingUser) {
      $scope.accessRequested = 'not-initiated';
      var userDetails = requestingUser.split('&quot;').join('"');
      userDetails = userDetails.split('&amp;').join('&');
      userDetails = JSON.parse(userDetails);
      $scope.requestAccess = function() {
        ewt_403Factory.requestAccess(userDetails).then(function(response) {
          if (response.data.status === 'success') {
            $scope.accessRequested = 'successful';
          } else {
            // alert('The request has not been submitted due to technical error. Please reach out to DCE-EWT@aexp.com with your request.');
            $scope.accessRequested = 'failed';
          }
        });
      }
    }]);
})()
