'use strict';

/**
 * @ngdoc function
 * @name ewtApp.controller:ewtMasterDataService
 * @description
 * # ewtMasterDataService
 * Controller of the ewtApp
 */
angular.module('ewtApp')
  .service('ewtMasterDataService', ['$http', '$q', 'APIServer', 'initialData', 'arrowMenuLables', 'versionNos', 'maDisengamentNos', 'cardProducts', 'emailVendors', 'triggerEvents', 'partialPaths',
    function($http, $q, APIServer, initialData, arrowMenuLables, versionNos, maDisengamentNos, cardProducts, emailVendors, triggerEvents, partialPaths) {
      var initLoadData = initialData.split('&quot;').join('"').split('&amp;').join('&');
      initLoadData = JSON.parse(initLoadData);
      var data = {
        subType: [],
        pznVariables: [],
        cmNeedCategorys: [],
        apiServer: APIServer,
        versionNos: versionNos,
        partialPaths: partialPaths,
        cardProducts: cardProducts,
        emailVendors: emailVendors,
        triggerEvents: triggerEvents,
        user: initLoadData.loggedInUser,
        type: initLoadData.campaignTypes || [],
        arrowMenuLables: arrowMenuLables,
        cellTypes: initLoadData.cellTypes,
        maDisengamentNos: maDisengamentNos,
        emailTypes: initLoadData.emailTypes,
        businessUnits: initLoadData.businessUnits || [],
        marketingManagers: initLoadData.marketingManagers,
        stoEventToTrack: initLoadData.stoEventsToTrack || {},
        stoEmailTrackingType: initLoadData.stoEmailTrackingTypes || {},
        allCMCategoryList: angular.copy(initLoadData.cmNeedCategories)
      };

      this.getDataObj = function() {
        return data;
      };

      this.getCampaignSubTypes = function(campaignType_id) {
        $http.get('/api/v1/campaign-sub-types/campaign-types/' + campaignType_id)
          .success(function(responseData) {
            data.subType = responseData;
          })
          .error(function(err) {
            data.subType = [];
          });
      };

      this.getCMNeedCategory = function(business_unit_id, callBack) {
        var defer = $q.defer();
        $http.get('/api/v1/cmNeedCategory/business-unit/' + business_unit_id)
          .success(function(responseData) {
            data.cmNeedCategorys = responseData;
            if (callBack) {
              return callBack(responseData);
            }
          })
          .error(function(err) {
            defer.reject(err);
            data.cmNeedCategorys = [];
          });
      };

      this.verifyMhid = function(mhid) {
        var defer = $q.defer();
        return $http.get('/api/v1/verify-mhid/' + mhid)
          .success(function(response, status) {
            defer.resolve(response.data);
            return response.data;
          })
          .error(function(data, status) {
            defer.reject(data);
          });
      };

      this.MhidService = function(mhid, action) {
        var defer = $q.defer();
        var mhidDt;
        if (mhid.newMHID) {
          mhidDt = new Date(mhid.newMHID.startDate);
          mhid.newMHID.startDate = (mhidDt.getMonth() + 1) + '/' + mhidDt.getDate() + '/' + mhidDt.getFullYear();
        } else {
          mhidDt = mhid.startDate;
          mhid.startDate = (mhidDt.getMonth() + 1) + '/' + mhidDt.getDate() + '/' + mhidDt.getFullYear();
        }

        return $http({
          method: 'POST',
          url: APIServer + 'mhid/' + action,
          data: mhid
        }).success(function(response, status) {
          defer.resolve(response.data);
          return response.data;
        }).error(function(data, status) {
          defer.reject(data);
        });
      };


      //service to render all the pzn variables
      this.getPznVariables = function() {
        var defer = $q.defer();
        return $http.get('/api/v1/pznVariables')
          .success(function(response, status) {
            defer.resolve(response.data);
            return response.data;
          })
          .error(function(data, status) {
            defer.reject(data);
          });
      };
    }
  ]);
