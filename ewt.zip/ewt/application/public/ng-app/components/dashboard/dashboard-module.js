'use strict';

/**
 * @ngdoc overview
 * @name appNameApp
 * @description
 * # appNameApp
 *
 * Main module of the application.
 */
angular
  .module('ewtDashboardModule', ['ui.router'])

.config(function($stateProvider) {
  $stateProvider
    .state('app.auth.dashboard', {
      url: '/dashboard',
      parent: 'app.auth',
      templateUrl: 'ng-app/partials/dashboard.html',
      controller: 'ewtDashboardController'
    });
});
