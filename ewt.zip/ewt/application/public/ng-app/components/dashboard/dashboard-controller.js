'use strict';

/**
 * @ngdoc function
 * @name ewtApp.controller: ewtDashboardController
 * @description
 * # ewtDashboardController
 * Controller of the ewtApp
 */
angular.module('ewtDashboardModule')
  .controller('ewtDashboardController', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
