'use strict';

/**
 * @ngdoc overview
 * @name newUserModule
 * @description
 * # newUserModule
 *
 * Module for creating new campaign.
 */
angular
  .module('newUserModule', ['ui.router'])
  .config(function($stateProvider) {
    $stateProvider
      .state('app.auth.users.new', {
        parent: 'app.auth.users',
        url: '/user/new',
        templateUrl: 'ng-app/partials/user/sections/add-user.html',
        controller: 'ewtUserManagementController',
        resolve: {
          ewtUsers: function(ewtUsers, initLoadData) {
            var response = {
              initLoadData: initLoadData
            };
            return new ewtUsers(response);
          }
        }
      });
  });
