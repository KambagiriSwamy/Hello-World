(function() {
  'use strict';

  /**
   * @ngdoc function
   * @name ewtUserManagementModule.controller:ewtUserManagementController
   * @description
   * # ewtUserManagementController
   * Controller of the ewtUserManagementModule
   */
  angular.module('ewtUserManagementModule')

  .controller('ewtUserManagementController', ['$scope', 'ewtUsers', '$state', 'ewtUtils', 'exportFields',
    function($scope, ewtUsers, $state, utilities, exportOptions) {
      /**
       * EWTUsers Object
       * @type Object
       */
      $scope.ewtUsers = ewtUsers;

      $scope.utilities = utilities;
      $scope.ewtUsers.modal = {
        'message': 'Initial Alert',
        'actionButtons': []
      };

      /**
       * BusinessUnits of the Dropdown values
       * @type Array of Objects
       */
      $scope.businessUnits = ewtUsers.initLoadData.businessUnits;
      /**
       * UserRoles of the Dropdown values
       * @type Array of Objects
       */
      $scope.userRoles = ewtUsers.initLoadData.userRoles;
      /**
       * UserStatus of Dropdown values
       * @type Array of Objects
       */
      $scope.userStatus = ewtUsers.initLoadData.userStatus;

      /**
       * Users list for the search functionality
       * @type Array of Objects
       */
      $scope.userList = ewtUsers.userList;

      /**
       * Commented code to Select All as default option
       */
      /*
       if ($scope.businessUnits[0].codeName === 'all' && $scope.userRoles[0].codeName === 'all' && $scope.userStatus[0].codeName === 'all') {
        $scope.search = {
          businessUnit = 'all',
            search.role = 'all',
            search.status = 'all'
        };
      }
      */

      /**
       * [excludeHeaders Headers List that need to be excluded from the Export Users CSV files]
       * @type {Array}
       */
      $scope.excludeHeaders = ['_id', 'name', 'email', 'value', 'phone', 'markAsDeleted'];

      /**
       * [formatUserListToExport It formats the users list from objects to strings ie user.status from Object to String(object.name)  ]
       * @param  {[Array of User Objects]} userList [List of all users from the result of search functionality]
       * @return {[Array of User Objects]}          [Formatted list of all Users ]
       */
      function formatUserListToExport(userList) {
        /**
         * [formatedUsers holds the complete formated users]
         * @type {Array of formated user objects}
         */
        /**
         * [userExport reference value which has the order and details about csv export]
         * @type {Array of reference objects specific to capture details of a user}
         */
        var formatedUsers = [],
          singleUserDetails = {},
          userExport = exportOptions.users;


        /**
         * Iterate through every selected user and then every object that has to be exported to csv
         */
        angular.forEach(userList, function(user) {
          singleUserDetails = {};
          angular.forEach(userExport, function(option) {
            if (option.type && option.type === 'date') {
              /**
               * Date is formated to mm/dd/yyyy only if date is valid
               */
              singleUserDetails[option.label] = new Date(user[option.selector]).toString() !== 'Invalid Date' ? new Date(user[option.selector]).dateToString() : '';
            } else if (option.selector.indexOf('->') !== -1) {
              var keys = option.selector.split('->');
              /**
               * keys are split and appropriate value is taken.
               * If hierarchy increases we need to replace this block with campaign export block; 
               */
              singleUserDetails[option.label] = user[keys[0]] ? user[keys[0]][keys[1]] : '';
            } else {
              singleUserDetails[option.label] = user[option.selector] || '';
            }
          });
          formatedUsers.push(singleUserDetails);
        });
        return formatedUsers;
      }

      $scope.formatedUserList = formatUserListToExport(angular.copy($scope.userList));
      /**
       * [edit Object store the updated information from the form]
       * @type Object
       */

      $scope.edit = ewtUsers;
      /**
       * [if the User Status is reactive or inactive then reactiveStatusFlag is set to true which show reactive radio button]
       * @param  {[Object]} $scope.edit &&            $scope.edit._id && ($scope.edit.status.codeName [ checks for codeName is reactive or inactive]
       */
      $scope.reactiveStatusFlag = false;
      if ($scope.edit && $scope.edit._id && ($scope.edit.status.codeName === 'reactive' || $scope.edit.status.codeName === 'inactive')) {
        $scope.reactiveStatusFlag = true;
      }
      /**
       * [cbFindUserSuccess Success callback when user is Searched]
       * @param  {[Promise Success function]} response [callback is called when users search is resolved successfully]
       */
      function cbFindUserSuccess(response) {
        $scope.userList = response;
        $scope.formatedUserList = formatUserListToExport(angular.copy($scope.userList));
      }

      /**
       * This function - call the find user core function - invoked on click of find user button
       */
      $scope.findUser = function() {
        ewtUsers.getUsers($scope.search).then(cbFindUserSuccess);
      };
      /**
       * Reset the add user form
       */
      function resetForm(resetObj, restSection) {
        if (resetObj) {
          resetObj.uid = '';
          resetObj.businessUnit = '';
          resetObj.role = '';
          resetObj.name = '';
          resetObj.status = '';
        }
        restSection.$setPristine();
        restSection.$setUntouched();
        restSection.$invalid = false;
        $scope.findUser();
      }

      $scope.clearSearchForm = function() {
        resetForm($scope.search, $scope.searchUserSection);
      };
      /**
       * addUser Success callback - navigated to list page - called when add user operation is success
       * @param  PromiseObject  response  Object returned from succes of insert operation
       * @param  ErrorObject    error     Error is returned if the operation is failed  
       */
      function cbAddUserSuccess(response) {
        $scope.ewtUsers.modal.open({
          'message': response.uid + ' has successfully been created',
          'actionButtons': [{
            'label': 'close',
            'buttonType': 'error',
            'callback': resetForm($scope.newUser, $scope.addUserSection)
          }]
        });
      }
      /**
       * [cbAddUserError Error Callback for add user functionality, 
       *                 updated the error message with the response error message]
       * @param  {[Promise Error Response]} error [Error from promise]
       */
      function cbAddUserError(error) {
        if (error.data && error.data.reason) {
          $scope.addUserError = error.data.reason;
        }
        if ((error) && (error.data) && (error.data.code === 'SESSION_EXPIRED') && (error.data.reason)) {
          alert(error.data.reason);
          return;
        }
      }

      $scope.uidChange = function() {
        $scope.addUserError = '';
      };


      /**
       * [addNewUser This function called on submitting the add user form]
       * @param {Object} newUser [new user information from the form]
       */
      $scope.addNewUser = function(newUser) {
        ewtUsers.addUser(newUser).then(cbAddUserSuccess, cbAddUserError);
      };


      /**
       * This function is called on edit user form submission and update the user information in Database
       * @param  {Object} editUserObj New object updated from the form
       */
      $scope.updateUser = function(editUserObj) {
        ewtUsers.updateUser(editUserObj);
      };

      /**
       * This function is invoked from the view and call the core delete api function of the user
       * @param  {object} deleteUserObject [User's object neeed to be deleted]
       */
      $scope.deleteUser = function(deleteUserObject) {
        var message = 'Would you like to continue removing this user?';
        if ($scope.ewtUsers.initLoadData.loggedInUser.uid === deleteUserObject.uid) {
          message = 'This user is logged in. Would you like to continue removing this user?';
        }
        ewtUsers.deleteUser(deleteUserObject, deleteUserSuccessHandler, message);
      };

      /**
       * Toggles's the Select User record from the table and set the current row index and 
       * User Object and if the same user row is selected then user selection is toggled
       * @param  {nuumber} index           [Index of the record from the list]
       * @param  {Object} selectedUserObj [User's data selected from the User]
       */
      $scope.toggleSelectUserRow = function(index, selectedUserObj) {
        if (index !== null && selectedUserObj && (!$scope.selectedUserObj || $scope.selectedUserObj !== selectedUserObj)) {
          $scope.selectedRow = index;
          $scope.selectedUserObj = selectedUserObj;
        } else {
          delete $scope.selectedUserObj;
          $scope.selectedRow = null;
        }
      };

      /**
       * This is the success callback of the delete user operation, it removes selected row 
       */
      function deleteUserSuccessHandler() {
        $scope.userList.splice($scope.selectedRow, 1);
        $scope.selectedRow = null;
        delete $scope.selectedUserObj;
      }
      /**
       * This function retrurns whether User is active or not
       * @param  {Object}  userObject User's data in an Object
       * @return {Boolean}            returns false if the user is active else returns true
       */
      $scope.isUserActive = function(userObject) {
        if (userObject.status) {
          return userObject.status.codeName === 'inactive' ? true : false;
        }
        return false;
      };
    }
  ]);
}());
