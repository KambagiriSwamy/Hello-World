'use strict';

/**
 * @ngdoc overview
 * @name appNameApp
 * @description
 * # appNameApp
 *
 * Main module of the application.
 */
angular
  .module('searchUsersModule', [])
  .config(function($stateProvider) {
    $stateProvider
      .state('app.auth.users.search', {
        parent: 'app.auth.users',
        url: '/user/search',
        templateUrl: 'ng-app/partials/user/sections/search-user-form.html',
        controller: 'ewtUserManagementController',
        resolve: {
          ewtUsers: function(ewtUsers) {
            return new ewtUsers();
          }
        }
      });
  });
