'use strict';

/**
 * @ngdoc function
 * @name searchUsersModule.controller:ewtUserSearchController
 * @description
 * # ewtUserSearchController
 * Controller of the searchUsersModule
 */
angular.module('searchUsersModule')
  .controller('ewtUserSearchController', ['$scope', function($scope) {}]);
