(function() {
  'use strict';

  /**
   * @ngdoc overview
   * @name appNameApp
   * @description
   * # appNameApp
   *
   * user management module of the application.
   */
  angular
    .module('editUserModule', [])

  .config(function($stateProvider) {
    $stateProvider
      .state('app.auth.users.edit', {
        parent: 'app.auth.users',
        url: '/user/edit/:id',
        templateUrl: 'ng-app/partials/user/sections/edit-user.html',
        controller: 'ewtUserManagementController',
        resolve: {
          ewtUsers: function(ewtUsers, $stateParams, $state, initLoadData) {
            var user = new ewtUsers();
            return user.getUsers({
              _id: $stateParams.id
            }).then(
              // Success handler
              function(response, error) {
                response.initLoadData = initLoadData;
                if (response._id) {
                  return new ewtUsers(response);
                } else {
                  $state.go('app.auth.users.list');
                }
              },
              // Error handler for non-200 responses from server
              function(response) {
                if ((response) && (response.data) && (response.data.code === 'SESSION_EXPIRED') && (response.data.reason)) {
                  alert(response.data.reason);
                }
              }
            );
          }
        }
      });
  });
})();
