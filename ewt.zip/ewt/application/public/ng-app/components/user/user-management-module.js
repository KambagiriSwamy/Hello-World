(function() {
  'use strict';

  /**
   * @ngdoc function
   * @name ewtNewCampaignModule.controller:ewtCampaignController
   * @description
   * # ewtCampaignController
   * Controller of the ewtNewCampaignModule
   */
  function autorizedUserManagement($rootScope, $state, initialData) {
    var data = initialData.split('&quot;').join('"');
    data = data.split('&amp;').join('&');
    var user = JSON.parse(data).loggedInUser;
    $rootScope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams) {
      if (user.role.codeName !== 'axpi' && toState.name && toState.name.indexOf('app.auth.users') > -1) {
        event.preventDefault();
        $state.go('app.auth.campaigns.list');
      }
    });
  }

  function userStateFunctionfunction($stateProvider, $urlRouterProvider) {
    $stateProvider
      .state('app.auth.users', {
        parent: 'app.auth',
        abstract: true,
        template: '<div ui-view></div>'
      })
      .state('app.auth.users.list', {
        parent: 'app.auth.users',
        url: '/user/list',
        templateUrl: 'ng-app/partials/user/sections/list.html',
        controller: 'ewtUserManagementController',
        params: {
          search: null
        },
        resolve: {
          ewtUsers: function(ewtUsers, $stateParams, initLoadData) {
            var initLoadUserMagementData;

            function prepInitLoadManagentData() {
              initLoadUserMagementData = angular.copy(initLoadData);
              delete initLoadUserMagementData.campaignTypes;
              delete initLoadUserMagementData.cellTypes;
              delete initLoadUserMagementData.emailTypes;
              delete initLoadUserMagementData.marketingManagers;
              initLoadUserMagementData.businessUnits.unshift({
                codeName: 'all',
                code: 'U000',
                name: 'All'
              });
              initLoadUserMagementData.userRoles.unshift({
                codeName: 'all',
                code: 'U000',
                name: 'All'
              });
              initLoadUserMagementData.userStatus.unshift({
                codeName: 'all',
                code: 'U000',
                name: 'All'
              });
              /**
               * Removing the Reactive user type from drop down
               */
              var userStatus2Show = [];
              angular.forEach(initLoadUserMagementData.userStatus, function(status, key) {
                if (status.codeName == 'reactive') {
                  return;
                }
                userStatus2Show.push(status);
              });
              initLoadUserMagementData.userStatus = userStatus2Show;
            }

            var user = new ewtUsers();
            user.userList = [];
            return user.users($stateParams.search).then(function(response, error) {
              prepInitLoadManagentData();
              response.userList = response;
              response.initLoadData = initLoadUserMagementData;
              return new ewtUsers(response);
            });
          }
        }
      });
  }

  angular.module('ewtUserManagementModule', ['newUserModule', 'editUserModule', 'searchUsersModule', 'ui.router'])
    .run(autorizedUserManagement)
    .config(userStateFunctionfunction);

}());
