'use strict';

/**
 * @ngdoc overview
 * @name appNameApp
 * @description
 * # appNameApp
 *
 * Main module of the application.
 */
angular
  .module('ewtCampaignListModule', [])

.config(function($stateProvider) {
  $stateProvider
    .state('app.auth.campaigns.list', {
      url: '/',
      templateUrl: 'ng-app/partials/campaign/list.html',
      controller: 'ewtCampaignsListController',
      resolve: {
        campaigns: function(ewtCampaign, initLoadData) {
          var data = {};
          return ewtCampaign.query().$promise.then(
            // Success handler
            function(response) {
              /**
               * Resolving the campaign history data before loading controller
               */
              data.campaignsList = response;
              data.searchObject = data.searchObject || {};
              data.searchObject = {
                deployStartDatePicker: {
                  open: false
                },
                deployEndDatePicker: {
                  open: false
                },
                requestedStartDatePicker: {
                  open: false
                },
                requestedEndDatePicker: {
                  open: false
                }
              };

              data.initLoadData = angular.copy(initLoadData);
              /**
               * Adding all as a option for the dropdowns
               */
              data.initLoadData.marketingManagers.unshift({
                name: 'All',
                uid: 'all',
                value: null
              });
              data.initLoadData.businessUnits.unshift({
                name: 'All',
                codeName: 'all',
                value: null
              });
              data.initLoadData.emailTypes.unshift({
                name: 'All',
                codeName: 'all',
                value: null
              });
              data.initLoadData.campaignStates.unshift({
                name: 'All',
                codeName: 'all',
                value: null
              });
              /**
               *  If user is manager will have his name by default in search drop down of Marketing mangers 
               * else Admin/Tech support will have all
               */
              if (data.initLoadData.loggedInUser.role.codeName === 'mm') {
                data.searchObject.uid = data.initLoadData.loggedInUser.uid;
              } else {
                data.searchObject.uid = 'all';
              }
              data.searchObject.businessUnit = 'all';
              data.searchObject.emailType = 'all';
              data.searchObject.campaignStatus = 'all';
              data.searchObject.edis = 'all';


              data.initLoadData.edis = [{
                name: 'All',
                codeName: 'all',
                value: null
              }, {
                name: 'Yes',
                codeName: 'true',
                value: true
              }, {
                name: 'No',
                codeName: 'false',
                value: false
              }];
              return data;
            },
            // Error handler to handle non-200 response from server.
            function(response) {
              // If the session has expired, show the error message to user
              if ((response) && (response.data) && (response.data.code === 'SESSION_EXPIRED') && (response.data.reason)) {
                alert(response.data.reason);
              }
            }
          );
        }
      }
    });
});
