'use strict';

/**
 * @ngdoc function
 * @name ewtCampaignListModule.controller:ewtCampaignsListController
 * @description
 * # ewtCampaignsListController
 * Controller of the ewtCampaignListModule
 */
angular.module('ewtCampaignListModule')
  .controller('ewtCampaignsListController', ['$scope', 'campaigns', 'ewtCampaign', 'ewtUIState', 'ewtUtils', '$filter', function ($scope, campaigns, ewtCampaign, ewtUIState, utilities, $filter) {
    // TODO - remove if unused
    var loggedInUser = JSON.parse(window.sessionStorage.getItem('loggedInUser'));

    // Instantiate the ewtCampaign constructor
    var ewtCampaign = new ewtCampaign();

    /**
     * Load the Initial Data to search and filter form controls and set default values 
     */
    $scope.campaigns = campaigns;
    $scope.campaignsList = campaigns.campaignsList;
    $scope.emailTypes = campaigns.initLoadData.emailTypes;
    $scope.marketingManagers = campaigns.initLoadData.marketingManagers;
    $scope.businessUnits = campaigns.initLoadData.businessUnits;
    $scope.edis = campaigns.initLoadData.edis;
    $scope.campaignStates = campaigns.initLoadData.campaignStates;
    $scope.dateFormat = 'MM/dd/yyyy';

    /**
     * serachObjectCopy maintains a copy of search criteria to populate campaign list
     * @type {Object}
     */
    var serachObjectCopy = $scope.campaigns.searchObject;
    /**
     * Toggle the datePickers open status
     * @param  {object} $event     [click event parameter from the date-picker]
     * @param  {object} datePicker [It is the object to which picker you want to toggle state and it should have open a boolen type property to it ]
     */
    $scope.toggleDatePicker = function ($event, datePicker) {
      $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1,
        showWeeks: true
      };
      $event.preventDefault();
      $event.stopPropagation();
      if(datePicker.open !== undefined) {
        datePicker.open = !datePicker.open;
      } else {
        datePicker.open = false;
      }
    };

    $scope.checkEndDate = function (startDate, endDate) {
      endDate.date = endDate.date < startDate.date ? null : endDate.date;
    }

    /**
     * @function searchCampaigns will make an core function call to search the campaign from db using search filter object
     * and the resolved promise obtained will update the list of campaigns
     * @param  {Object} searchObject [It is Search object filled in search form in the campaign history]
     */
    
    $scope.searchCampaigns = function (searchObject) {
      serachObjectCopy = angular.copy(searchObject);
      searchObject.action = 'filter';
      ewtCampaign.searchCampaigns(searchObject).then(function (response) {
        $scope.campaignsList = response;
      });
    };

    /**
     * Set default sort to the requestID and Most recent ID first
     */
    $scope.sortType = 'requestID';
    $scope.sortOrderReverse = true;

    /**
     * Toggle the sort header by setting sort type(column) and sort order(asce or desc) if the sort is already applied
     * then sort order is toggled to the same header 
     * @param  {string} type [column header name to which the sort must apply]
     */
    $scope.changeSort = function (type) {
      if(type === $scope.sortType) {
        $scope.sortOrderReverse = !$scope.sortOrderReverse;
      } else {
        $scope.sortType = type;
        $scope.sortOrderReverse = false;
      }
    };

    $scope.uiState = {
      isVisible: function (fieldName, campaign, user) {
        user = user || loggedInUser;
        return ewtUIState.isVisible(fieldName, campaign, user);
      },
      isHidden: function (fieldName, campaign, user) {
        user = user || loggedInUser;
        return ewtUIState.isHidden(fieldName, campaign, user);
      },
      isEnabled: function (fieldName, campaign, user) {
        user = user || loggedInUser;
        return ewtUIState.isEnabled(fieldName, campaign, user);
      },
      isDisabled: function (fieldName, campaign, user) {
        user = user || loggedInUser;
        return ewtUIState.isDisabled(fieldName, campaign, user);
      }
    };

    /**
     * scope objet to display modal in list.html (search screen of campaigns)
     * @type {Object} This is the skeliton of a modal object which triggers EWT modal
     */
    $scope.listModal = {
      'message': 'Initial Alert',
      'actionButtons': []
    };

    /**
     * openExportFilterScreen - This method only opens a modal pop-up which facilitates
     *                          user to check only the fields he needs to be exported
     *
     * searchObjectCopy maintains the search criteria based on which we a retrieved the 
     * listed campaigns in UI.
     * We use this object to make another api call that will retrieve all the required 
     * information from database and apply formating on it based on the export fields 
     * selected.
     */
    $scope.openExportFilterScreen = function () {
      $scope.listModal.open({
        'url': 'ng-app/partials/directives/modals/campaign-export.html',
        'resolve': {
          'purpose': 'exportCampaigns',
          'serachObjectCopy' : serachObjectCopy
        }
      });
    };
  }]);

