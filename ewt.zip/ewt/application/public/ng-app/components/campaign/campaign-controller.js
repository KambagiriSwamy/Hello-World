/**
 * Module: Campaign Controller.
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2016 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: ERA -- Application Controller.
 */
(function() {
  'use strict';
  /**
   * @ngdoc function
   * @name ewtNewCampaignModule.controller:ewtCampaignController
   * @description
   * # ewtCampaignController
   * Controller of the ewtNewCampaignModule
   */
  angular.module('ewtNewCampaignModule')
    .controller('ewtCampaignController', ['$scope', '$rootScope', '$q', '$filter', '$state', '$window', '$timeout', 'initLoadData', 'versionNos', 'maDisengamentNos', 'emailVendors', 'triggerEvents', 'arrowMenuLables', 'campaign', 'attachmentTypes', 'ewtCampaign', 'commonDescription', 'commonScheduling', 'commonMailPlan', 'commonPersonalization', 'maCampaign', 'servicingCampaign', 'oneoffCampaign', 'pnlCampaign', 'commonMethods', 'ewtMasterDataService', 'ewtUIState', 'ewtUtils', 'arbitrationStatus', 'campaignDurationWeeks', 'APIServer',
      function($scope, $rootScope, $q, $filter, $state, $window, $timeout, initLoadData, versionNos, maDisengamentNos, emailVendors, triggerEvents, arrowMenuLables, campaign, attachmentTypes, ewtCampaign, commonDescription, commonScheduling, commonMailPlan, commonPersonalization, maCampaign, servicingCampaign, oneoffCampaign, pnlCampaign, commonMethods, ewtMasterDataService, ewtUIState, ewtUtils, arbitrationStatus, campaignDurationWeeks, APIServer) {

        var today = new Date();
        var campaignLockTimer = null;
        var tempPrimaryCMNeedCategory;
        var editLockKey = window.sessionStorage.getItem('tabId');
        var loggedInUser = $scope.user = JSON.parse(window.sessionStorage.getItem('loggedInUser'));

        var data = $scope.data = Object.assign(
          ewtMasterDataService.getDataObj(), {
            versionNos: versionNos,
            arbitrationStatus: arbitrationStatus,
            emailVendors: emailVendors,

            //set farther down inlined, why?
            campaignDurationWeeks: null,
            weeksArray: null,
            pznVariables: null,
            mailPlanUpload: null,
            maDisengamentValues: null,
          }
        );

        //contextual state, inheritting EventEmitter
        //  Used for context rendering and context binding with services
        var state = $scope.state = Object.create(EventEmitter.prototype);
        // add specific state trees
        state.validation = createStateValidation(state)
        state.user = createStateUser(state, initLoadData, loggedInUser);
        state.data = createStateData(state, data);
        state.campaign = createStateCampaign(state, campaign, bindWatch('campaign'));
        state.scheduling = commonScheduling.create(state, bindWatch('state.scheduling'));

          // expose for dev debugging
          window.__state = state;

        //allow views to emit more easily
        $scope.emit = state.emit.bind(state);

        // cleanup
        $scope.$on('$destroy', state.removeAllListeners.bind(state, undefined));

        /**
         * emailTypeCampaign - holds all the campaign service types
         * @type {Object}
         */
        // TO DO Move to init.
        $scope.campaign = campaign;
        $scope.campaign.createVersionDropDownInfo();
        $scope.opened = false;
        $scope.showWeeks = false;
        /* Initialize the campaign variables */
        ewtUtils.initCampaign($scope.campaign, state.data.instance(), initLoadData);

        delete $rootScope.allowStateChange;
        // set default value for campaign.sto.stoEmailTrackingType .
        $scope.campaign.sto.stoEmailTrackingType = ($scope.campaign.sto.stoEmailTrackingType === undefined) ? data.stoEmailTrackingType[2] : $scope.campaign.sto.stoEmailTrackingType;

        //Atachment tab static values
        $scope.attachmentTypes = attachmentTypes.data;

        /* campaignSvc: It willl be mapped to email-type specific service. If email-type is not yet set, servicing service will be take as default. */
        $scope.data.campaignService = servicingCampaign;
        $scope.data.campaignSvc = [];
        $scope.data.campaignSvc["ET_SERVICING"] = servicingCampaign;
        $scope.data.campaignSvc["ET_PNL"] = pnlCampaign;
        $scope.data.campaignSvc["ET_MA"] = maCampaign;
        $scope.data.campaignSvc["ET_ONEOFF"] = oneoffCampaign;
        $scope.data.campaignService = ($scope.campaign.emailType.codeName) ? $scope.data.campaignSvc[$scope.campaign.emailType.codeName] : $scope.data.campaignSvc["ET_SERVICING"];

        // for One Off campaign, limit the campaign Duration to 6 Weeks.
        if ($scope.campaign.emailType.codeName === 'ET_ONEOFF') {
          $scope.data.campaignDurationWeeks = campaignDurationWeeks.ET_ONEOFF;
        } else {
          $scope.data.campaignDurationWeeks = campaignDurationWeeks.ET_MA;
        }
        /* Initialize the campaign service object */
        /* TODO Add the initServie methods in respective services*/
        //campaignService.initService($scope.campaign, initLoadData, data);

        // Modal Objects
        $scope.campaign.modal = {
          'message': 'Initial Alert',
          'actionButtons': []
        };

        /**
         * [if this email list formatting should be done if the state is after submitted for approval]
         * @param  {[string]} $scope.campaign.state.codeName              [campaign state's codename]
         */
        if ($scope.campaign.state.codeName !== 'draft' && $scope.campaign.state.codeName !== 'submitted4approval') {
          $scope.campaign.seedList = {};
          $scope.campaign.deployList = {};
          $scope.campaign.approversList = {};
          $scope.campaign.seedList.emailText = emailListtostring($scope.campaign.previewEmailList);
          $scope.campaign.deployList.emailText = emailListtostring($scope.campaign.deployEmailList);
          $scope.campaign.approversList.emailText = emailListtostring($scope.campaign.approversEmailList);

          /**
           * [seedPreviewListUpdated This function will validate the list of email addresses provided in the text area
           *  and show appropriate error message]
           */
          $scope.seedPreviewListUpdated = function() {
            $scope.campaign.seedList.name = 'seedList';
            $scope.campaign.seedList.isErrorVisible = true;
            $scope.campaign.seedList.errorMessage = '';
            $scope.campaign.seedList.limit = 15;
            $scope.campaign.previewEmailList = [];
            setEmailListErrorMessage($scope.campaign.seedList, $scope.campaign.previewEmailList);
          };
          /**
           * [seedDeployListUpdated This function will validate the list of email addresses provided in the text area
           *  and show appropriate error message]
           */
          $scope.seedDeployListUpdated = function() {
            $scope.campaign.deployList.name = 'deployList';
            $scope.campaign.deployList.isErrorVisible = true;
            $scope.campaign.deployList.errorMessage = '';
            $scope.campaign.deployList.limit = 15;
            $scope.campaign.deployEmailList = [];
            setEmailListErrorMessage($scope.campaign.deployList, $scope.campaign.deployEmailList);
          };
          /**
           * [campaignApproversListUpdated This function will validate the list of email addresses(@aexp.com) provided in the text area
           *  and show appropriate error message]
           */
          $scope.campaignApproversListUpdated = function() {
            $scope.campaign.approversList.name = 'approversList';
            $scope.campaign.approversList.isErrorVisible = true;
            $scope.campaign.approversList.errorMessage = '';
            $scope.campaign.approversList.limit = 10;
            $scope.campaign.approversEmailList = [];
            setEmailListErrorMessage($scope.campaign.approversList, $scope.campaign.approversEmailList);
          };
        }

        /** Restructured Code Starts from here.*/
        $scope.validate = {
          isVisible: function(fieldName, campaign, user) {
            campaign = campaign || $scope.campaign;
            user = user || $scope.user || loggedInUser;
            return ewtUIState.isVisible(fieldName, campaign, user);
          },
          isHidden: function(fieldName, campaign, user) {
            campaign = campaign || $scope.campaign;
            user = user || $scope.user || loggedInUser;
            return ewtUIState.isHidden(fieldName, campaign, user);
          },
          isEnabled: function(fieldName, campaign, user) {
            campaign = campaign || $scope.campaign;
            user = user || $scope.user || loggedInUser;
            return ewtUIState.isEnabled(fieldName, campaign, user);
          },
          isDisabled: function(fieldName, campaign, user) {
            campaign = campaign || $scope.campaign;
            user = user || $scope.user || loggedInUser;
            return ewtUIState.isDisabled(fieldName, campaign, user);
          },
          isMultiCMNeedCategoryRequired: function() {
            if (($scope.campaign.emailType.codeName === 'ET_ONEOFF' && $scope.campaign.primaryCmNeedCategory.code && $scope.campaign.allCMCategoryList.length >= 2)) {
              return false;
            } else {
              return true;
            }
          },
          mailplan: {
            isUniqueVersion: function(version) {
              commonMailPlan.validate.isUniqueVersion(version);
            },
            areAllCellsDefined: function() {
              commonMailPlan.validate.areAllCellsDefined();
            }
          }
        };

        /* Define the tabs for the ERA application  */
        $scope.tabs = [{
          label: arrowMenuLables[0].label,
          id: 'descriptionTab',
          disabled: $scope.validate.isDisabled('tabs.descriptionTab'),
          emailTypeVisibility: true
        }, {
          label: arrowMenuLables[1].label,
          id: 'deploymentTab',
          disabled: $scope.validate.isDisabled('tabs.deploymentTab'),
          emailTypeVisibility: true
        }, {
          label: arrowMenuLables[2].label,
          id: 'marketingAutomationTab',
          disabled: $scope.validate.isDisabled('tabs.marketingAutomationTab'),
          emailTypeVisibility: false

        }, {
          label: arrowMenuLables[3].label,
          id: 'mailPlan',
          disabled: $scope.validate.isDisabled('tabs.mailPlanTab'),
          emailTypeVisibility: true
        }, {
          label: arrowMenuLables[4].label,
          id: 'personalizationTab',
          disabled: $scope.validate.isDisabled('tabs.personalizationTab'),
          emailTypeVisibility: true
        }, {
          label: arrowMenuLables[5].label,
          id: 'attachments',
          disabled: $scope.validate.isDisabled('tabs.attachmentsTab'),
          emailTypeVisibility: true
        }];
        $scope.tabs[ewtUtils.activeTab].active = true;
        // On email change, the workflow may change, so check for enabling / disabling tabs.
        $scope.tabs.forEach(function(tab, indx) {
          $scope.tabs.disabled = $scope.validate.isDisabled('tabs.' + tab.id);
        });

        //Initialize common tab level services
        commonMethods.init.init($scope.campaign, $scope.data, initLoadData,  $scope.tabs, $scope.validate);
        commonPersonalization.init($scope);
        // Initialize email-type specific services
        servicingCampaign.init($scope);
        maCampaign.init($scope);
        oneoffCampaign.init($scope);
        pnlCampaign.init($scope);
        /*
         * Restructred Angular code starts from here.
         */
        $scope.events = {
          /* All Common Event Methods will go into this block */
          common: {
            uploadFiles: function($files) {
              commonMethods.events.uploadFiles($files);
            },
            removeFile: function(index, file_id) {
              commonMethods.events.removeFile(index, file_id);
            }
          },
          /* All Description Tab events will go in here. */
          description: {
            setEmail: function(managerType) {
              commonMethods.events.description.setEmail(managerType);
            },
            /**
             * Name: emailTypeChange
             * Description: called when th emial type is changed in the drop down
             *             resets the values according to type of email selected
             */
            emailTypeChange: function() {
              commonMethods.events.description.emailTypeChange();
              $scope.data.campaignService.events.description.emailTypeChange($scope.campaign, $scope.data, initLoadData);
            },
            /**
             * [businessUnitChange This function in invoked when business unit changes in dropdonw
             *  and it makes a api call to get the respective cm opt out categories and update in the view]
             *  It disable the deployment date selection in case of One Off campaign
             */
            businessUnitChange: function() {
              $scope.data.campaignService.events.description.businessUnitChange($scope.campaign, $scope.data, initLoadData);
            },
            primaryCMCodeChange: function() {
              commonMethods.events.description.primaryCMCodeChange();
            },
            needCategoryChange: function(triggeredFrom) {
              commonMethods.events.description.needCategoryChange(triggeredFrom); 
              if (state.user.isManager()) {
              //     state.emit('handle:set-bu-deployment', triggeredFrom || 'cmNeedChange');
              }
            },
            /**
             * [addcmCategory Pop's out the selected cm need category from avilable list and add's it
             *  to the seleted list]
             */
            addcmCategory: function() {
              commonMethods.events.description.addcmCategory();
             // commonDescription.events.description.addcmCategory($scope.campaign);
            },
            /**
             * [removecmCategory Removes the selected cm need category from selected list and add's it
             *  back into the available list]
             */
            removecmCategory: function() {
              commonMethods.events.description.removecmCategory();
            },
            /*
             *  EDIS Values -- This method show / hide EDIS values.
             */
            dynamicCampaignChange: function() {
              commonMethods.events.description.dynamicCampaignChange();
            },
            /* Invoke the back-end service to fetch the comm codes from back-end*/
            /* Invoke the back-end service to fetch the related products based on the comm code selected. */
            changeCommCode: function() {
              commonMethods.events.description.changeCommCode();
            },
            /* Method to Upload a file*/
            uploadMock: function($files) {
              commonMethods.events.description.uploadMock($files);
            },
            /* Method to preview the file */
            previewFile: function() {
              commonMethods.events.description.previewFile();
            },
            /* Method to Remove the file */
            removeMock: function(file_id) {
              commonMethods.events.description.removeMock(file_id);
            },
          },
          /* Description Tab events Ends here.*/
          /* All MailPlan Tab events will go in here. */
          mailplan: {
            /**
             * Mthods to do CRUD operations on cells.
             */
            /* Method to add cell */
            addCell: function(cell) {

            },
            /* Method to add or update cell */
            updateCell: function(cell, action, index) {
              commonMailPlan.events.updateCell(cell, action, index);
              // Check if all cells are complete or not. For incomplete cells, set flag to show error on UI
              $scope.validate.mailplan.areAllCellsDefined();
              $scope.campaignForm.creativeSection.$setUntouched();
            },
            /**
             * Mthods to do CRUD operations on versions.
             */
            /* Method to add or update version */
            updateVersion: function(version, index) {
              $scope.data.campaignService.events.mailplan.updateVersion($scope.campaign, version, index);
            },
            /* Method to remove version */
            removeVersion: function(index) {
              commonMailPlan.events.removeVersion(index);
            },
            /**
             * Methods to do CRUD operations on Subject Line
             */
            /* Method to add subject line */
            addSubjectLine: function(subjectLine, version) {
              $scope.data.campaignService.events.mailplan.addSubjectLine($scope.campaign, version, subjectLine);
            },
            /* Method to update subject line */
            updateSubjectLine: function(subject, slIndex, versionNo) {
              $scope.data.campaignService.events.mailplan.updateSubjectLine($scope.campaign, versionNo, slIndex, subject);
            },
            /* Method to remove subject line */
            removeSubjectLine: function(slIndex, version) {
              $scope.data.campaignService.events.mailplan.removeSubjectLine($scope.campaign, version, slIndex);
            }
          },
          /* Mailplan Tab events Ends here.*/
          personalization: {
            resetPznFields: function() {
              commonPersonalization.events.resetPznFields();
            },
            hidePznError: function() {
              commonPersonalization.events.hidePznError();
            },
            addPznVariable: function() {
              commonPersonalization.events.addPznVariable();
            }
          },
          /* Mailplan Tab events Ends here.*/
          /* All Attachment Tab events will go in here. */
          attachment: {
            validateVersion: function(fileRowObj, index) {
              commonMethods.events.validateVersion(fileRowObj, index);
            },
            getDeployDisplayObject: function() {
              return commonMethods.init.getDeployDisplayObject();
            }
          } /* Attachment Tab events Ends here.*/
        };

        // Mapping util functions to $scope, so that same can be used in HTML templates.
        $scope.utils = ewtUtils;
        /** Restructured Code ends here.*/

        if ($scope.campaign.emailType.codeName === 'ET_MA') {
          $scope.data.arbitrationStatus = [{
            code: 'N',
            codeName: 'nonArbitrated',
            name: 'Non Arbitrated'
          }];
        }

        $scope.whoOwnsLock = function() {
          if ($scope.campaign.requestID) {
            if (!state.user.isAdmin() && (campaign.requestor.uid !== loggedInUser.uid) &&
              (campaign.primaryMarketingManager.uid !== loggedInUser.uid) && ((!campaign.secondaryMarketingManager) ||
              (campaign.secondaryMarketingManager.uid !== loggedInUser.uid))) {
              return 'someone-not-related';
            }
            if (($scope.campaign.lock) && ($scope.campaign.lock.isLocked === true) && ($scope.campaign.lock.key !== editLockKey)) {
              return 'someone-related';
            }
            return 'me';
          } else {
            // this is a new campaign
            return 'no-one';
          }
        };
        /**
         * Returns true if parent and child are equal.
         * If necesseray delete keys from parent if required.
         * Will be modified with new scenario.
         */
        $scope.isSameAsParent = function(child, parent) {
          parent = angular.copy(parent);
          child = angular.copy(child);
          delete parent.edit;
          delete parent.editing;
          delete parent.incomplete;
          delete parent.$$hashKey;
          return angular.equals(child, parent);
        };

        /*
         * US234070 -- Ability to enable only certain dates/weeks selectable based on BU selection
         * This user story is specific to One Off campaign. below method isBuNeedCategoryChanged() is
         * wrtten to achive this functionality.
         */
        $scope.isBuNeedCategoryChanged = function() {
          if (!state.user.isAdmin()) {
            if ($scope.buNeedCategoryChanged) {
              $scope.campaign.deploymentDates = [];
            }
            return $scope.buNeedCategoryChanged;
          }
        }
        $scope.campaign.atleastOneDateEqual = true;

        /**
         * Validation: Enable the start date for admin only in MA campaign
         */
        $scope.isStartDateEnabled = function() {
          if ($scope.campaign.emailType && $scope.campaign.emailType.codeName === 'ET_MA' && $scope.campaign.state.codeName !== 'draft' && state.user.isManager()) {
            return true;
          }
          return false;
        };

        $scope.campaignSTOChange = function() {
          if (!$scope.campaign.sto.isSTO) {
            $scope.data.weeksArray = [0].concat($scope.data.weeksArray);
          } else {
            $scope.data.weeksArray.splice(0, 1);
          }
        };

        // Personalization Tab for MA and Broadcast

        /**
         * @ Initialize the variable required for the MA.
         */
        $scope.campaign.mailHistory = $scope.campaign.mailHistory || [];
        $scope.mhidWarning = false;
        $scope.campaign.mailHistoryValid = false;
        $scope.campaign.editingOneMhid = false; // flag is set to true when one of the mhid is getting edited.

        /**
         * Date picker open function in the Personalization Tab.
         * Toggle the date picker to select the MHID drop date.
         */
        $scope.openNewMHIDDatePicker = function($event, mhid) {
          $event.preventDefault();
          $event.stopPropagation();
          mhid.mhidDateOpened = !mhid.mhidDateOpened;
        };

        $scope.isUniqueCombination = function(mhid, itsOwnIndex, oldMHID) {
          mhid.cellError = true;
          var sameMHID = [];
          angular.forEach($scope.campaign.mailHistory, function(value, index) {
            if (value.mhid === mhid.mhid) {
              value.tempIndx = index;
              sameMHID.push(value);
            }
          });

          angular.forEach(sameMHID, function(value, index) {
            if (mhid.newSrcCodes) {
              angular.forEach(mhid.newSrcCodes, function(srcCode, index) {
                if (value.cell.srcCode === srcCode) {
                  mhid.cellError = false;
                }
              });
            } else if (mhid.cell && value.cell.srcCode === mhid.cell.srcCode && value.tempIndx !== itsOwnIndex) {
              mhid.cellError = false;
            }
          });
          return mhid.cellError;
        };

        /**
         * @ Feature: today date validation with the start date and return true if it greater than today else returns false
         */
        $scope.isGreaterThanToday = function() {
          var sd = moment(new Date($scope.campaign.deploymentDates[0] || 'invalid')).startOf('d');
          return sd.isValid() && moment().isBefore(sd);
        }

        /**
         * @Fuction: add or update the MHID to the campaign.
         */
        $scope.addNewMHID = function(mhid, action, atIndex) {
          mhid.mhid = angular.uppercase(mhid.mhid);
          // delete mhid.cellError;
          if (action === 'add') {
            $scope.campaign.addMHID(mhid);
          } else if (action === 'update') {
            $scope.campaign.updateMHID(mhid, atIndex);
          }
          $scope.campaign.mailHistoryValid = $filter('filter')($scope.campaign.mailHistory, {
            incomplete: true
          }, true).length > 0 ? true : false;
          /**
           * @Commented: We are checking for the validation in API success call back
           */
          // $scope.campaign.atleastOneDateEqual = $scope.campaign.checkForStartDate();
          $scope.campaign.newMhidObj = {};
        };
        if ($scope.campaign.mailHistory.length > 0 && $scope.campaign.emailType.codeName === 'ET_MA') {
          $scope.campaign.mailHistoryValid = $filter('filter')($scope.campaign.mailHistory, {
            incomplete: true
          }, true).length > 0 ? true : false;

          $scope.campaign.atleastOneDateEqual = $scope.campaign.checkForStartDate();
        }
        $scope.editMHIDClick = function(mhidObj) {
          mhidObj.editing = true;
          mhidObj.edit = $scope.utils.replicateObj(mhidObj);
          mhidObj.edit.cellError = true;
          $scope.campaign.editingOneMhid = true;
          $scope.campaign.newMhidObj = {};
          $scope.campaignForm.personalizationSection.newMHIDForm.$setUntouched();
        };
        /**
         * @MUltiple MHID: remove the mhid from the table when remove button is clicked.
         */
        $scope.removeMHID = function(index) {
          //$scope.campaign.removeMHID(index);
          $scope.campaign.mailHistoryValid = $filter('filter')($scope.campaign.mailHistory, {
            incomplete: true
          }, true).length > 0 ? true : false;
          $scope.campaign.atleastOneDateEqual = $scope.campaign.checkForStartDate();
        };

        $scope.validateNewMHID = function(mhidObj, atIndex, oldMHID) {
          delete mhidObj.isnewMHIDValid;
          mhidObj.mhid = angular.uppercase(mhidObj.mhid);
          if (mhidObj.mhid && mhidObj.mhid.length === 8) {
            mhidObj.isnewMHIDValid = {
              status: true,
              message: true
            };
            $scope.campaign.mailHistoryValid = $filter('filter')($scope.campaign.mailHistory, {
              incomplete: true
            }, true).length > 0 ? true : false;

            $scope.campaign.validateMHID(mhidObj, atIndex);
            if (mhidObj.newSrcCodes && mhidObj.newSrcCodes.length > 0) {
              $scope.isUniqueCombination(mhidObj);
            } else {
              $scope.isUniqueCombination(mhidObj, atIndex, oldMHID);
            }
          }
        };

        $scope.campaign.canMhidDrafted = false;
        var initialCampaignMhid = $scope.campaign.mailHistory.length !== 0 ? angular.copy($scope.campaign.mailHistory) : [{
          'mhid': ''
        }];
        $scope.checkMhid = function() {
          $scope.mhidWarning = false;
          if ($scope.campaign.mailHistory && $scope.campaign.mailHistory[0] && $scope.campaign.mailHistory[0].mhid && $scope.campaign.mailHistory[0].mhid.length === 8) {
            if (initialCampaignMhid[0].mhid.toUpperCase() !== $scope.campaign.mailHistory[0].mhid.toUpperCase()) {
              ewtMasterDataService.verifyMhid($scope.campaign.mailHistory[0].mhid.toUpperCase()).then(function(response) {
                if (response.data.errorMessage) {
                  $scope.mhidWarning = true;
                }
              });
            }
          } else {
            $scope.mhidWarning = false;
          }
        };
        $scope.checkPersonalizantionTab = function() {
          if ($scope.campaign.seedList && $scope.campaign.deployList && $scope.campaign.approversList && ($scope.campaign.seedList.errorMessage || !$scope.campaign.seedList.emailText || !$scope.campaign.deployList.emailText || $scope.campaign.deployList.errorMessage || !$scope.campaign.approversList.emailText || $scope.campaign.approversList.errorMessage)) {
            return false;
          }

          if ($scope.campaign.emailType.codeName === 'ET_SERVICING' || $scope.campaign.emailType.codeName === 'ET_ONEOFF') {
            if ($scope.campaign.mailHistory && $scope.campaign.mailHistory[0] && ($scope.mhidWarning || !$scope.campaign.mailHistory[0].mhid || $scope.campaign.mailHistory[0].mhid.length !== 8)) {
              return false;
            }
          }
          if ($scope.campaign.emailType.codeName === 'ET_MA') {
            var isIncomeplete = $filter('filter')($scope.campaign.mailHistory, {
                incomplete: true
              }, true).length > 0;
            if ($scope.campaign.mailHistory.length === 0 || !$scope.campaign.checkForStartDate() || isIncomeplete) {
              $scope.campaign.mailHistoryValid = isIncomeplete ? true : false;
              return false;
            }
          }
          return true;
        };

        /**
         * @PZN related code
         */

        /**
         * @ reset the pzn fields dropdown to null and description to empty string so the respective description text and add button gets disabled
         * This function is called when campaign is loaded and everytime after each PZN field is added.
         */
        // var resetPznFields = function() {
        //   $scope.campaign.pznSelected = {};
        //   $scope.campaign.pznSelected.code = '';
        //   $scope.campaign.pznDescription = '';
        //   $scope.pznAlreadyExists = false;
        // };

        /**
         * @ resetting pzn fields called once initially.
         */
        commonPersonalization.events.resetPznFields();
        /**
         * @ Data Service call to get all PZN Variable information and assing the to the data object
         * this serivce call will invoke a method when campaign is loaded in EWT2 stage
         */
        ewtMasterDataService.getPznVariables().then(function(response) {
          $scope.data.pznVariables = response.data;
        });

        /**
         * @PZN form: checks where the Respective PZN variable the user is trying to add is valid or not
         * Checks for Uniqueness of the PZN variables while adding to the list
         *
         */
        $scope.verifyPzn = function() {
          if ($scope.campaign.pznSelected.code && $filter('filter')($scope.campaign.pznFields, {
              code: $scope.campaign.pznSelected.code
            }, true).length > 0) {
            $scope.data.pznAlreadyExists = true;
            return;
          }
          $scope.data.pznAlreadyExists = false;
          $scope.campaign.pznDescription = '';
        };

        /**
         * @ Checks if edited mhid is same as unedited mhid
         */
        $scope.isMhidUnchanged = function(child, parent) {
          child = angular.copy(child);
          parent = angular.copy(parent);
          if (child.mhid === parent.mhid && angular.equals(child.startDate, parent.startDate) && angular.equals(child.cell, parent.cell)) {
            return true;
          } else {
            return false;
          }
        };

        /**
         * @verify the PZN Description enabled/disabled and return boolean value.
         * it is enabled once pzn variable is selected in dropdown
         */
        $scope.pznDescriptionEnabled = function() {
          if ($scope.campaign.pznSelected && ($scope.campaign.pznSelected.code === '' || $scope.data.pznAlreadyExists)) {
            return true;
          }
          return false;
        };

        /**
         * @verify the PZN Description enabled/disabled.
         * it is enabled once pzn variable is selected in dropdown
         */
        $scope.disableADDPzn = function() {
          if ($scope.data.pznAlreadyExists || !$scope.campaign.pznSelected || $scope.campaign.pznSelected.code === '' || ($scope.campaign.pznDescription === '' && !$scope.campaign.pznSelected.reserved)) {
            return true;
          }
          return false;
        };

        // $scope.hidePznError = function() {
        //   $scope.pznAlreadyExists = false;
        // };

        /**
         * Get the PZN variable and add it to the list
         * finally it resets the pzn fields
         */
        // $scope.addPznVariable = function() { // Move to campaign.js
        //   if ($scope.campaign.pznSelected && ($scope.campaign.pznSelected.reserved || $scope.campaign.pznDescription !== '') && !$scope.pznAlreadyExists) {
        //     $scope.campaign.pznSelected.description = $scope.campaign.pznDescription || $scope.campaign.pznSelected.description;
        //     $scope.campaign.pznFields.push(angular.copy($scope.campaign.pznSelected));
        //     resetPznFields();
        //   }
        // };

        /**
         * @seed list for test and deplyoment purpose.
         */
        /**
         * [emailListtostring convets the array of emails list into string using join method]
         * @param  {[string]} emailList [list of emails which are already enter or an empty array]
         * @return {[string]}           [list of emails joined semi-colon and form a string]
         */
        function emailListtostring(emailList) {
          return emailList.join(';') || '';
        }

        /**
         * [setEmailListErrorMessage It will set the error message depending on the validation function]
         * @param {[object]} listType [The list object with error message , list string, isErrorVisible and other properties]
         */
        function setEmailListErrorMessage(listType, list) {
          listType.isErrorVisible = true;
          var errorStatus = $scope.campaign.validateSeedEmailList(listType.emailText, list, listType.limit, listType.name);
          if (errorStatus === 'stringEmpty') {
            listType.errorMessage = 'This is a required field; at least one valid email must be included.';
          } else if (errorStatus === 'errMAxEmails') {
            listType.errorMessage = 'There is a maximum of ' + listType.limit + ' emails.';
          } else if (errorStatus === 'invalid') {
            if (listType.name !== 'approversList') {
              listType.errorMessage = 'Please enter at least one valid email address in the format of EWT-DCE@aexp.com';
            } else {
              listType.errorMessage = 'Campaign approvers must have @aexp.com email addresses.';
            }
          } else {
            listType.isErrorVisible = false;
          }
        }

        $scope.campaign.closeNotes = function(comment) { // Move to campaign.js
          if (comment) {
            var notesOptions = {
              'message': 'Do you want to save the notes ?',
              'actionButtons': [{
                'label': 'Yes',
                'buttonType': 'success',
                'callBack': function() {
                  $scope.campaign.addComment($scope.campaign.newComment);
                  $scope.campaign.showNotes = false;
                }
              }, {
                'label': 'No',
                'buttonType': 'secondary',
                'callBack': function() {
                  $scope.campaign.newComment = '';
                  $scope.campaign.showNotes = false;
                }
              }, {
                'label': 'cancel',
                'buttonType': 'error',
                'callBack': function() {}
              }]
            };
            $scope.campaign.modal.open(notesOptions);
          } else {
            $scope.campaign.showNotes = false;
          }
        };

        // while campaing is loading again set the MA visibility ture.
        if ($scope.campaign.emailType.codeName === 'ET_MA') {
          $scope.tabs[2].emailTypeVisibility = true;
        }

        /*actionBar commands*/
        $scope.setPMM = function($item) {
          $scope.campaign.requestorPrimary = $item.value;
        };

        $scope.setSMM = function($item) {
          $scope.campaigncampaign.requestorSecondary = $item.value;
        };

        $scope.getMHIDFreeWeeks = function() {
          $scope.availableWeeks = [];
          for (var i = 1; i < $scope.campaign.deployWindow + 1; i++) {
            if (!$filter('filter')($scope.campaign.mhids, {
                week: i
              }).length) {
              $scope.availableWeeks.push(i);
            }
          }
          return $scope.availableWeeks;
        };
        $scope.freeHistoryWeek = function($index) {
          $scope.campaign.mhids.splice($index, 1);
          $scope.campaign.$update().finally(
            function() {
              $scope.getMHIDFreeWeeks();
            });
        };
        $scope.getMHIDFreeWeeks();
        $scope.draftCampaign = function() {
          $scope.campaignForm.$dirty = false;
          if ($scope.cMockuploadedFile && $scope.cMockuploadedFile[0] && (($scope.cMockuploadedFile[0].size / (1024 * 1024)) > 10)) {
            $scope.cMockuploadedFile = null;
          }
          if ($scope.cMockuploadedFile) {
            $scope.campaign.saveAsDraft($scope.cMockuploadedFile);
          } else {
            $scope.campaign.saveAsDraft(null);
          }
          setCampaignLockTimer();
        };

        $scope.removeFile = function(index, file_id) {
          $scope.campaign.removeFile(APIServer + 'files/' + $scope.campaign._id + '/' + file_id, function() {
            $scope.campaign.attachments.splice(index, 1);
          });
        };

        $scope.uploadFiles = function($files) {
          var size = 0;
          for (var cnt = 0; cnt < $files.length; cnt++) {
            if ($files[cnt] && $files[cnt].name) {
              var ext = $files[cnt].name.toLowerCase().split('.');
              if (ext.length > 1 && ext[ext.length - 1].indexOf('exe') !== -1) {
                $scope.campaign.showAlert('Uploading .exe files is not allowed');
                return;
              }
              if ($files[cnt]) {
                size += Number($files[cnt].size);
              }
            }
          }
          angular.forEach($scope.campaign.attachments, function(attachment) {
            size += Number(attachment.size);
          });
          if ((size / (1024 * 1024)) > 10) {
            $scope.campaign.showAlert('Overall file uploads for a campaign cannot exceed 10 MB');
            return;
          }
          for (var i in $files) {
            if ($files[i] && $files[i].name) {
              $scope.campaign.attachFileToCampaign(APIServer + 'files/' + $scope.campaign._id, $files[i], $scope.updateAttachmentsInScope);
            }
          }
        };

        $scope.excelReader = function(file, successCallBack, errorCallBack) { // Move to campaign.js
          if (file.length) {
            var allowableFormats = ['xlsx', 'csv', 'xls', 'xlsb', 'xlsm', 'ods'];
            var format = file[0].name.substring(file[0].name.indexOf('.') + 1);
            if (allowableFormats.indexOf(format.toLowerCase()) !== -1) {
              $scope.campaign.attachFileToCampaign(APIServer + 'excel/import/cells', file, successCallBack, errorCallBack);
            } else {
              $scope.campaign.showAlert('Files with this format(' + format + ') cannot be uploaded. Please choose from these formats - ' + allowableFormats.join(', ') + '.');
            }
          }
        };
        $scope.cellsErrorCalBack = function(response) {
          if (response.status === 'failure') {
            $scope.cellErrorMessage = response.reason;
          }
        };
        $scope.populateCells = function(cells) { // Move to campaign.js
          $scope.cellErrorMessage = '';
          var updatedCells = [];
          var tempCell = {};
          var requiredKeys = ['cellid/sourceid/sourcecode', 'creativeversion', 'description/segmentdetails', 'mailable/holdout'];

          // Formating the cells from Excel Sheet. Defaulted to first worksheet !!
          angular.forEach(Object.keys(cells), function(tabName) {
            cells[tabName].forEach(function(cell) {
              tempCell = {};
              Object.keys(cell).forEach(function(key) {
                var keyRef = angular.lowercase(key.split(' ').join(''));

                if ('description/segmentdetails'.search(keyRef) !== -1) {
                  tempCell.description = cell[key] || null;
                }
                if ('mailable/holdout'.search(keyRef) !== -1) {
                  if ($scope.campaign.emailType.codeName === 'ET_SERVICING') {
                    tempCell.type = $filter('filter')($scope.data.cellTypes, {
                      codeName: 'test'
                    }, true)[0];
                  } else {
                    if (cell[key] !== null) {
                      var typeKey = '';
                      if (angular.lowercase(cell[key].split(' ').join('')).search('mailable') !== -1) {
                        typeKey = 'test';
                      }
                      if (angular.lowercase(cell[key].split(' ').join('')).search('holdout') !== -1) {
                        typeKey = 'control';
                      }
                      tempCell.type = $filter('filter')($scope.data.cellTypes, {
                        codeName: typeKey
                      }, true)[0];
                    }
                  }
                }
                if ('cellid/sourceid/sourcecode'.search(keyRef) !== -1) {
                  tempCell.srcCode = cell[key] !== null ? angular.uppercase(cell[key].toString()) : '';
                }
              });
              if (!$scope.campaign.isCellProper(tempCell)) {
                tempCell.incomplete = true;
              }
              if (tempCell.srcCode !== undefined && tempCell.srcCode !== null && tempCell.srcCode !== '') {
                updatedCells.push(tempCell);
              }
            });
          });
          cells = updatedCells;
          updatedCells = null;

          // Iterate through all the cells for each cell from sheet and update or add accordingly.
          if (cells.length !== 0) {
            cells.forEach(function(newCell) {
              $scope.campaign.cells.forEach(function(campaignCell) {
                if (angular.lowercase(newCell.srcCode.toString()) === angular.lowercase(campaignCell.srcCode.toString())) {
                  if (newCell.description) {
                    campaignCell.description = newCell.description.toString();
                  } else {
                    campaignCell.description = '';
                  }
                  if (newCell.type) {
                    campaignCell.type = newCell.type;
                  }
                  if (!$scope.campaign.isCellProper(campaignCell)) {
                    campaignCell.incomplete = true;
                  }
                  newCell.added = true;
                }
              });
              if (!newCell.added) {
                if (!$scope.campaign.isCellProper(newCell)) {
                  newCell.incomplete = true;
                }
                $scope.campaign.cells.push(newCell);
              }
            });
            $scope.data.mailPlanUpload = $filter('filter')($scope.campaign.cells, {
              incomplete: true
            }, true).length > 0 ? true : false;
          } else {
            $scope.campaign.showAlert('Upoloaded file does not have appropreate fields.');
          }
        };

        // $scope.updateCells = function(cell, action, atIndex) {
        //   cell.srcCode = angular.uppercase(cell.srcCode);
        //   $scope.campaign.cellAddUpdate(cell, action, atIndex, $scope.removeCellPopUpOptions);
        //   $scope.allCellsDefined();
        //   $scope.campaignForm.creativeSection.$setUntouched();
        // };
        $scope.isMailPlanTabValid = function() {
          var uniqueCells = $filter('unique')($scope.campaign.cells);
          var allVersions = [],
            uniqueVersions = [];
          if (!$scope.campaign.cells.length) { // there should be at least one cell defined
            return false;
          }

          if ($scope.campaign.emailType.codeName === 'ET_SERVICING') {
            $scope.campaign.cells.forEach(function(cell) {
              if (cell.versionNo) {
                allVersions.push(cell.versionNo);
              }
            });
            // Versions are already unique so check if there is subjectLine in each version.
            if ($scope.campaign.cells.length > 0) {
              // checking if length of versions with subjects and length of unique cells are same
              var flag = true;
              $scope.campaign.cells.forEach(function(version) {
                if (version.versionNo === 0) {
                  flag = true;
                } else if ($filter('filter')($scope.campaign.subjectLinesArr, {
                    number: version.versionNo
                  }).length === 0) {
                  flag = false;
                }
              });
              if (!flag) {
                return flag;
              }
            } else {
              return false;
            }
          }
          /**
           * Validations to be fired specific to One offs campaigns
           * Should check if ever subject lin has atleast one subject and one cell associated to it.
           * return false if failing.
           */
          if ($scope.campaign.emailType.codeName === 'ET_ONEOFF') {
            var oneOffValidator = false;
            angular.forEach($scope.campaign.versions, function(version) {
              if (version.subjects.length === 0) {
                oneOffValidator = true;
              }
              if ($filter('filter')($scope.campaign.cells, {
                  versionNo: version.number
                }, true).length === 0) {
                oneOffValidator = true;
              }
            });
            if (oneOffValidator) {
              return false;
            }
          }
          if ($filter('filter')($scope.campaign.cells, {
              incomplete: true
            }, true).length > 0) {
            $scope.data.mailPlanUpload = true;
            return false;
          }
          return true;
        };

        $scope.campaign.closeAdminSlideOut = function() { // Move to campaign.js
          var currentVal = {
            volumeCap: $scope.campaign.volumeCap,
            triggerRest: $scope.campaign.triggerRest,
            esp: {
              code: $scope.campaign.esp.code
            },
            arbitration: {
              code: $scope.campaign.arbitration.code
            }
          };
          if (!angular.equals(currentVal, $scope.campaign.adminDefaults)) {
            // $scope.campaign.modal = ;
            $scope.campaign.modal.open({
              'message': 'Would you like to save your changes?',
              'actionButtons': [{
                'label': 'Yes',
                'buttonType': 'success',
                'callBack': function() {
                  $scope.campaign.adminDefaults = {
                    volumeCap: $scope.campaign.volumeCap,
                    triggerRest: $scope.campaign.triggerRest,
                    esp: {
                      code: $scope.campaign.esp.code
                    },
                    arbitration: {
                      code: $scope.campaign.arbitration.code
                    }
                  };
                  if ($scope.campaign.arbitration) {
                    $scope.campaign.arbitration = $scope.campaign.getSelectedArrObj($scope.campaign.arbitration, arbitrationStatus, 'code');
                  }
                  if ($scope.campaign.esp) {
                    $scope.campaign.esp = $scope.campaign.getSelectedArrObj($scope.campaign.esp, emailVendors, 'code');
                  }
                  $scope.campaign.closeAdminSlide = false;
                }
              }, {
                'label': 'No',
                'buttonType': 'secondary',
                'callBack': function() {
                  $scope.campaign.volumeCap = $scope.campaign.adminDefaults.volumeCap;
                  $scope.campaign.triggerRest = $scope.campaign.adminDefaults.triggerRest;
                  $scope.campaign.esp.code = $scope.campaign.adminDefaults.esp.code;
                  $scope.campaign.arbitration.code = $scope.campaign.adminDefaults.arbitration.code;
                  $scope.campaign.closeAdminSlide = false;
                }
              }, {
                'label': 'cancel',
                'buttonType': 'error'
              }]
            });
          } else {
            $scope.campaign.closeAdminSlide = false;
          }
        };
        $scope.campaign.discardAndClose = function() { // Move to campaign.js
          $scope.campaign.triggerRest = $scope.campaign.adminDefaults.triggerRest;
          $scope.campaign.volumeCap = $scope.campaign.adminDefaults.volumeCap;
          $scope.campaign.esp.code = $scope.campaign.adminDefaults.esp.code;
          $scope.campaign.arbitration.code = $scope.campaign.adminDefaults.arbitration.code;
          $scope.campaign.closeAdminSlide = false;
        };
        $scope.validateVersion = function(fileRowObj, index) {
          if ($scope.campaign.emailType.codeName === 'ET_ONEOFF') {
            /**
             * fileRowObj is version for Oneoffs only for validation purpose
             */
            if (fileRowObj && fileRowObj.description && fileRowObj.complianceCode && !fileRowObj.versionUnique && fileRowObj.poid.length === 9 && !fileRowObj.isPOIDValid) {
              return false;
            } else {
              return true;
            }
          } else {
            if (fileRowObj && fileRowObj.type && (fileRowObj.type.codeName === 'rasc' || fileRowObj.type.codeName === 'creative_governance')) {
              $scope.campaign.attachments[index].creativeVersion = 0;
            }
          }
        };

        $scope.saveSelectionsAndValidate = function(index) {
          var attachmentTypeObj;
          if ($scope.campaign.attachments[index] && $scope.campaign.attachments[index].type.code) {
            for (var i in $scope.attachmentTypes) {
              if ($scope.attachmentTypes[i].code === $scope.campaign.attachments[index].type.code) {
                attachmentTypeObj = angular.copy($scope.attachmentTypes[i]);
                if ($scope.attachmentTypes[i].codeName !== 'text_version' && $scope.attachmentTypes[i].codeName !== 'html_version')
                  $scope.campaign.attachments[index].creativeVersion = 0;
                else
                  $scope.campaign.attachments[index].creativeVersion = null;
                break;
              }
            }
            $scope.campaign.attachments[index].type = attachmentTypeObj;
          }
          var attachmentObj = $scope.campaign.attachments[index];
        };

        $scope.validateMAVersionFileLimit = function(creativeFile) {
          if ($scope.campaign.emailType.codeName === 'ET_MA' && creativeFile.creativeVersion > 0) {
            var MAVersionsArr = $scope.campaign.ma.maVersions,
              versionIdIndex = -1,
              attachmentTypeObj = {},
              versionID = creativeFile.creativeVersion,
              MAVersionObj, versionCreativeDocuments, size = 0;
            for (var verCnt = 0; verCnt < MAVersionsArr.length; verCnt++) {
              var versionIDObj = MAVersionsArr[verCnt];
              if (parseInt(versionIDObj.versionId) === parseInt(versionID)) {
                versionIdIndex = verCnt;
                break;
              }
            }
            MAVersionObj = $scope.campaign.ma.maVersions[versionIdIndex];
            if (versionIdIndex !== -1 && MAVersionObj.creativeDocument[creativeDocumentIndex] && MAVersionObj.creativeDocument[creativeDocumentIndex].type.code) {
              for (var i in $scope.attachmentTypes) {
                if ($scope.attachmentTypes[i].code === MAVersionObj.creativeDocument[creativeDocumentIndex].type.code) {
                  attachmentTypeObj = angular.copy($scope.attachmentTypes[i]);
                  break;
                }
              }
              $scope.campaign.ma.maVersions[versionIdIndex].creativeDocument[creativeDocumentIndex].type = attachmentTypeObj;
            }
          }
        };

        $scope.validateAttachmentsForm = function() {
          var doc,
            versions, version,
            status = false,
            attachment,
            creativeDocuemnts, creativeDocument;
          // Ensure that all the attachments have some type and version mapped to them. If any attachment is not mapped to type or version, we are not good to go.
          // angular.forEach($scope.campaign.attachments, function(attachment, attachmentIndex) {
          for (var indx = 0; indx < $scope.campaign.attachments.length; indx++) {
            attachment = $scope.campaign.attachments[indx];
            if (!attachment.type) {
              return false;
            }
            if ((attachment.creativeVersion === null) || (attachment.creativeVersion === 'undefined') || (attachment.creativeVersion === '')) {
              return false;
            }
          }

          /**
           * We are sure that all attachments have some mapping, so now check for email-type specific validation rules.
           * Broadly speaking, below are the rules for different email-type campaigns:
           * ==> MA Campaign: Atleast one creative_governance attachment should be present
           * ==> One-Off Campaign: Atleast one creative_governance AND one final_creative_preview attachment should be present
           * ==> Servicing Campaign: Atleast one RASC attachment should be present
           */
          switch ($scope.campaign.emailType.codeName) {
            case 'ET_MA':
              // Ensure that attachments of versions should have some type mapped to it.
              versions = $scope.campaign.ma.maVersions || [];
              for (var verIndx = 0; verIndx < versions.length; verIndx++) {
                version = versions[verIndx];
                creativeDocuemnts = version.creativeDocument || [];
                for (var docIndx = 0; docIndx < creativeDocuemnts.length; docIndx++) {
                  creativeDocument = creativeDocuemnts[docIndx];
                  if (!creativeDocument.type) {
                    return false;
                  }
                }
              }

              // Check if there is some attachment with 'creative_governance' type or not. If we dont find, look under ma.maVersions.
              doc = $filter('filter')($scope.campaign.attachments, {
                $: 'creative_governance'
              }, true);

              status = (doc && doc.length) ? true : false;

              if (!status) {
                // 'creative_governance' can be under maVersions, so check for it there too.
                versions = $scope.campaign.ma.maVersions || [];
                for (var verIndx = 0; verIndx < versions.length; verIndx++) {
                  creativeDocuemnts = versions[verIndx].creativeDocument || [];
                  doc = $filter('filter')(creativeDocuemnts, {
                    $: 'creative_governance'
                  }, true);

                  if (doc.length) {
                    status = true;
                  }
                }
              }
              break;
            case 'ET_ONEOFF':
              // If campaign have at least one creative_governance and one final_creative_preview attachment, we are good to go
              doc = $filter('filter')($scope.campaign.attachments, {
                $: 'creative_governance'
              }, true);

              if (doc.length) {
                // We found the creative_governance, so now look for final_creative_preview
                doc = $filter('filter')($scope.campaign.attachments, {
                  $: 'final_creative_preview'
                }, true);
                status = (doc.length) ? true : false;
              }
              break;
            case 'ET_SERVICING':
              // If campaign have at least one 'rasc' attachment, we are good to go.
              doc = $filter('filter')($scope.campaign.attachments, {
                $: 'rasc'
              }, true);

              status = (doc.length) ? true : false;
              break;
          }
          ;
          return status;
        };

        $scope.validateMA = function() { // Move to campaign.js
          if ($scope.campaign.emailType.codeName === 'ET_MA') {
            if ((100 > $scope.campaign.ma.disengagementValue) && ($scope.campaign.ma.disengagementValue > 0) && $scope.campaign.ma.maVersions.length > 0 && ($scope.campaign.ma.instructionDocuments.length > 0) && ($scope.campaign.ma.approvalDocuments.length > 0)) {
              return true;
            } else {
              return false;
            }
          }
          return true;
        };

        /**
         * @Validate Campain Deployment sectiona and return a boolean value
         */
        $scope.validateDeploymentSection = function() {
          if ($scope.campaign.emailType) {
            if ($scope.campaign.deploymentDates[0]) {
              return false;
            }
          }
          return true;
        };

        // Marketing Automation TAB code
        $scope.resetCurrentVersionForm = function() {
          $scope.campaign.current = {};
          $scope.campaign.current.creativeDocument = [];
          $scope.campaign.current.poid = '';
          $scope.campaign.current.deletedFile = [];
        };

        $scope.initializeMA = function() {
          $scope.resetCurrentVersionForm();
          $scope.campaign.ma = $scope.campaign.ma || {};
          $scope.campaign.ma.approvalDocuments = $scope.campaign.ma.approvalDocuments || [];
          $scope.campaign.ma.instructionDocuments = $scope.campaign.ma.instructionDocuments || [];
          $scope.campaign.ma.maVersions = $scope.campaign.ma.maVersions || [];
          $scope.campaign.maNewVersionForm = false;
          $scope.campaign.ma.maVersions.creativeDocuments = $scope.campaign.ma.maVersions.creativeDocuments || [];
        };
        $scope.initializeMA();
        /**
         * Set dropdown values from the values files @triggerEvents
         */
        $scope.triggerEvents = triggerEvents;

        /**
         * @ Format the trigger Event dropdown value with the getSelectObject function
         */
        $scope.triggerEventChange = function() {
          $scope.campaign.current.triggerEvent = $scope.campaign.getSelectedArrObj($scope.campaign.current.triggerEvent, $scope.triggerEvents, 'codeName');
        };

        /*
         * Add or Update the version to the campaign.
         */
        $scope.saveVersion = function() {
          $scope.campaign.current.versionId = $scope.campaign.currentMAVersionId;
          if ($scope.campaign.current.versionId) {
            /**
             * @ Update ma version to the campaign and resets the form using core a function.
             */
            $scope.campaign.updateMAVersion($scope.campaign.current);
          }
          var newFilesArr = [];
          for (var index = 0; index < $scope.campaign.current.creativeDocument.length; index++) {
            var fileObj = $scope.campaign.current.creativeDocument[index];
            if (!fileObj.hasOwnProperty('gfsID')) {
              newFilesArr.push(fileObj);
            }
          }
          $scope.campaign.attachVersionFileToCampaign(APIServer + 'campaigns/version/' + $scope.campaign.requestID + '/versionAttachment/' + $scope.campaign.current.versionId,
            newFilesArr,
            $scope.campaign.current,
            $scope.versionSuccesshandler);
        };

        $scope.versionSuccesshandler = function(version) {
          /**
           *Temporary fix to check no error from backend
           */
          if (version && Array.isArray(version) && version.length > 0) {
            $scope.campaign.ma.maVersions = version;
            $scope.campaign.createVersionDropDownInfo();
            angular.forEach($scope.campaign.ma.maVersions, function(version) {
              version.versionDescription = version.versionId;
            });
            $scope.campaign.ma.maVersions.unshift({
              "versionId": "0",
              "versionDescription": "ALL"
            });
          }
        };

        /**
         * Edit version function to just fill the form with required version to be clicked.
         */
        $scope.editVersion = function(version) {
          $scope.campaign.maNewVersionForm = true;
          $scope.campaign.current.deletedFile = [];
          $scope.campaign.currentMAVersionId = version.versionId;
          $scope.campaign.current = JSON.parse(JSON.stringify(version));
          $scope.validatePOID($scope.campaign.current);
        };

        /**
         *  MA files upload function
         */
        $scope.uploadMAFiles = function(files, type) {
          var filesArray = [];
          if (type === 'approvalDocument') {
            filesArray = $scope.campaign.ma.approvalDocuments || [];
          } else {
            filesArray = $scope.campaign.ma.instructionDocuments || [];
          }
          $scope.campaign.maAttachmentType = type;
          for (var i in files) {
            if (files[i]) {
              var ext = files[i].name.toLowerCase().split('.');
              if (ext.length > 1 && ext[ext.length - 1].indexOf('exe') !== -1) {
                $scope.campaign.showAlert('Uploading .exe files is not allowed');
                return;
              }
              var size = files[i].size;
              if (((size / (1024 * 1024)) > 10)) {
                $scope.campaign.showAlert(files[i].name + ' is larger than allowable limit of 10 MB');
                return;
              }
              angular.forEach(filesArray, function(attachment) {
                size += Number(attachment.size);
              });

              if ((size / (1024 * 1024)) > 10) {
                $scope.campaign.showAlert('File uploads cannot exceed 10 MB');
                return;
              }
              files[i].fileName = files[i].name;
            }
          }
          if (files && files.length > 0) {
            $scope.campaign.attachFileToCampaign(APIServer + 'ma/attachment/' + $scope.campaign.requestID + '/' + $scope.campaign.maAttachmentType, files, $scope.uploadMAFilesSuccessHandler);
          }
        };

        $scope.uploadMAFilesSuccessHandler = function(attachments) {
          if ($scope.campaign.maAttachmentType === 'instructionDocuments') {
            $scope.campaign.ma.instructionDocuments = attachments;
          } else if ($scope.campaign.maAttachmentType === 'approvalDocument') {
            $scope.campaign.ma.approvalDocuments = attachments;
          }
        };

        $scope.uploadMAVersionFile = function(files) {
          $scope.campaign.maAttachmentType = 'versionAttachment';
          for (var i in files) {
            if (files[i] && files[i].name) {
              var ext = files[i].name.toLowerCase().split('.');
              if (ext.length > 1 && ext[ext.length - 1].indexOf('exe') !== -1) {
                $scope.campaign.showAlert('Uploading .exe files is not allowed');
                return false;
              }
              var size = files[i].size;
              if (((size / (1024 * 1024)) > 4)) {
                $scope.campaign.showAlert(files[i].name + ' is larger than allowable limit of 4 MB');
                return false;
              }
              angular.forEach($scope.campaign.current.creativeDocument, function(attachment) {
                size += Number(attachment.size);
              });

              if ((size / (1024 * 1024)) > 4) {
                $scope.campaign.showAlert('File uploads for a version cannot exceed 4 MB');
                return false;
              }
              files[i].fileName = files[i].name;
              $scope.campaign.current.creativeDocument = $scope.campaign.current.creativeDocument || [];
              $scope.campaign.current.creativeDocument.push(files[i]);
            }
          }
        };

        /**
         * @Preview the local files and vFile has gridFS id then preview the file from the db.
         */
        $scope.previewMA = function(vFile) {
          if (vFile.gfsID) {
            $scope.campaign.showFile(vFile.gfsID, vFile.fileName);
          } else {
            var fd = new FormData();
            fd.append('file', vFile);
            ewtMasterDataService.viewMockUp(fd);
          }
        };

        /**
         * @ Funcion to remove approval documents and instruction documents
         */
        $scope.removeMAFile = function(index, file_id, attachmentType) { // Move to campaign.js
          if (file_id) {
            $scope.campaign.removeFile(APIServer + 'files/' + $scope.campaign._id + '/' + file_id + '/' + attachmentType, function(data) {
              if (attachmentType === 'instructionDocuments') {
                $scope.campaign.ma.instructionDocuments.splice(index, 1);
              } else if (attachmentType === 'approvalDocument') {
                $scope.campaign.ma.approvalDocuments.splice(index, 1);
              }
            });
          }
        };

        $scope.removeVersion = function(version, index) { // Move to campaign.js
          $scope.campaign.modal.open({
            'message': 'Do you want to delete this creative version?',
            'actionButtons': [{
              'label': 'Yes',
              'buttonType': 'success',
              'callBack': function() {
                $scope.campaign.removeFile(APIServer + 'campaigns/delete/version/' + $scope.campaign.requestID + '/' + version.versionId, function(data) {
                  $scope.campaign.ma.maVersions.splice(index, 1);
                });
              }
            }, {
              'label': 'No',
              'buttonType': 'secondary'
            }, {
              'label': 'Cancel',
              'buttonType': 'error'
            }]
          });
        };

        /**
         * Dynamically set the drop-down list values for disengagment dropdown based on duration.
         */
        $scope.setDisengagementList = function() {
          var disengagementduration = [];
          angular.forEach(maDisengamentNos, function(value, key) {
            if (key < $scope.campaign.durationInWeeks) {
              disengagementduration.push(value);
            }
          });
          $scope.data.maDisengamentValues = disengagementduration;
          // Rest the value of disengagement Value when the duration exceeds the previously selected value
          if ($scope.campaign.ma.disengagementValue > $scope.campaign.durationInWeeks) {
            $scope.campaign.ma.disengagementValue = 0;
          }
        };

        var disengagementduration = [];
        angular.forEach(maDisengamentNos, function(value, key) {
          if (key < $scope.campaign.durationInWeeks) {
            disengagementduration.push(value);
          }
        });
        $scope.data.maDisengamentValues = disengagementduration;

        /**
         * @Checks whether validate POID is enter or not. if it is blank no validation is applicable
         */
        $scope.campaign.isPOIDValid = false;
        $scope.validatePOID = function(model, isRequired) {
          var validateForChange;
          model.isPOIDValid = false;
          if (isRequired) {
            validateForChange = (model.poid.length === 9) ? true : false;
          } else {
            validateForChange = true;
          }

          if (model.poid && validateForChange) {
            if (model.poid.length > 0 && (model.poid.length !== 9 || model.poid[4] !== ':')) {
              model.isPOIDValid = true;
            } else {
              model.isPOIDValid = false;
            }
          }
        };

        $scope.cancelMAEdit = function() {
          $scope.campaign.maNewVersionForm = false;
          $scope.campaign.current = {};
        };

        $scope.approve = function() {
          var approveConfig = {
            'message': 'You have selected Req.Id: ' + $scope.campaign.requestID + ' to be Approved. Continue ?',
            'actionButtons': [{
              'label': 'Yes',
              'buttonType': 'success',
              'callBack': function() {
                $scope.campaign.approve();
              }
            }, {
              'label': 'cancel',
              'buttonType': 'error'
            }]
          };
          $scope.campaign.modal.open(approveConfig);
        };

        $scope.decline = function() {
          var declineConfig = {
            'url': 'ng-app/partials/directives/modals/decline-form.html',
            'resolve': $scope.campaign
          };
          $scope.campaign.modal.open(declineConfig);
        };

        $scope.revisionRequired = function() {
          var revisionConfig = {
            'url': 'ng-app/partials/directives/modals/revision-required-form.html',
            'resolve': $scope.campaign
          };
          $scope.campaign.modal.open(revisionConfig);
        };

        $scope.rollBack = function() {
          ewtCampaign.verifyRollback({
            'requestID': $scope.campaign.requestID
          }).$promise.then(function(response) {
            var rollBackConfig = {
              'url': 'ng-app/partials/directives/modals/roll-back-form.html',
              'resolve': $scope.campaign
            };
            $scope.campaign.modal.open(rollBackConfig);
          }, function(error) {
            if (error.data.status === 'failure') {
              $scope.campaign.showAlert(error.data.reason);
            }
            return false;
          });

        };

        var cancelCampaignLockTimer = function() {
          if (campaignLockTimer) {
            $timeout.cancel(campaignLockTimer);
          }
        };

        var setCampaignLockTimer = function() {
          // cancel the previous timer, if any.
          cancelCampaignLockTimer();
          campaignLockTimer = $timeout(function() {
            // if user is still editing the campaign after 25 mins, show timeout modal
            $scope.campaign.modal.open({
              'message': 'Time to edit campaign is going to expire in 5 minutes. Do you want to continue editing or leave it without saving ?',
              'actionButtons': [{
                'label': 'Continue editing',
                'buttonType': 'success',
                'callBack': function(option) {
                  // Make API call to extend campaign lock timer
                  ewtCampaign.extendlock({
                    id: $scope.campaign._id,
                    tabId: editLockKey
                  }).$promise.then(
                    function(response) {
                      if (response.status === 'failure') {
                        // if we could not extend the lock, means something wrong with lock, so better to release / unlock it.
                        cancelCampaignLockTimer();
                        $timeout(function() {
                          ewtCampaign.unlock({
                            id: $scope.campaign._id,
                            tabId: editLockKey
                          }).$promise.then(
                            function(response) {
                              return (response.status === 'success') ? true : false;
                            });
                          $scope.allowStateChange = true;
                          $state.go('app.auth.campaigns.list');
                        }, 50);

                        if (response.reason) {
                          $scope.campaign.modal.open({
                            'message': response.reason,
                            'actionButtons': [{
                              'label': 'OK',
                              'buttonType': 'success',
                              'callback': function() {}
                            }]
                          });
                        }
                      } else {
                        setCampaignLockTimer();
                      }
                    },
                    function(error) {
                      if (error.data.status === 'failure') {
                        $scope.campaign.showAlert(error.data.reason);
                      }
                      return false;
                    });
                }
              }, {
                'label': 'Leave without saving',
                'buttonType': 'secondary',
                'callBack': function() {
                  $rootScope.allowStateChange = true;
                  cancelCampaignLockTimer();
                  $timeout(function() {
                    // Move to campaign history page
                    ewtCampaign.unlock({
                      id: $scope.campaign._id,
                      tabId: editLockKey
                    }).$promise.then(
                      function(response) {
                        return (response.status === 'success') ? true : false;
                      });
                    $state.go('app.auth.campaigns.list');
                  });
                }
              }]
            });
          }, 1500000 /*25 mins*/);
        };

        if ($scope.whoOwnsLock() === 'me') {
          setCampaignLockTimer();
        }

        $scope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams) {
          /**
           * activetab has to be set to zero just befor moving to list or new campaign
           * THis might not be the appropriate palce to perfom this operation - to be reviewed later
           */
          if (toState.name === 'app.auth.campaigns.list' || toState.name === 'app.auth.campaigns.new') {
            ewtUtils.activeTab = 0;
          }
          if ($scope.campaignForm.$dirty || $scope.campaign.elementRemoved) {
            if (!$scope.allowStateChange) {
              $scope.campaign.modal.open({
                'message': 'Your EWT Campaign Request is not complete. Would you like to save your changes ?',
                'actionButtons': [{
                  'label': 'Yes',
                  'buttonType': 'success',
                  'callBack': function(option) {
                    $scope.campaign.saveAsIs();
                    $scope.allowStateChange = true;
                    $timeout(function() {
                      if ((fromState.name == 'app.auth.campaigns.details') && fromParams.id) {
                        // We were on edit campaign page and as we are now moving away from it, so cancle the timer and release the campaign lock
                        // We should unlock, only if loggedin user is the owner of campaign edit lock.
                        if ($scope.campaign.lock.isLocked && ($scope.campaign.lock.key === editLockKey)) {
                          cancelCampaignLockTimer();
                          ewtCampaign.unlock({
                            id: fromParams.id,
                            tabId: editLockKey
                          }).$promise.then(
                            function(response) {
                              return (response.status === 'success') ? true : false;
                            });
                        }
                      }
                      $state.go(toState.name);
                    }, 50);
                  }
                }, {
                  'label': 'No',
                  'buttonType': 'secondary',
                  'callBack': function() {
                    $rootScope.allowStateChange = true;
                    $timeout(function() {
                      if ((fromState.name == 'app.auth.campaigns.details') && fromParams.id) {
                        // We should unlock, only if loggedin user is the owner of campaign edit lock.
                        if ($scope.campaign.lock.isLocked && ($scope.campaign.lock.key === editLockKey)) {
                          cancelCampaignLockTimer();
                          // We were on edit campaign page and as we are now moving away from it, release the campaign lock
                          ewtCampaign.unlock({
                            id: fromParams.id,
                            tabId: editLockKey
                          }).$promise.then(
                            function(response) {
                              return (response.status === 'success') ? true : false;
                            });
                        }
                      }
                      $state.go(toState.name);
                    });
                  }
                }, {
                  'label': 'cancel',
                  'buttonType': 'error'
                }]
              });
              event.preventDefault();
            } else {
              if ((fromState.name == 'app.auth.campaigns.details') && fromParams.id) {
                // We should unlock, only if loggedin user is the owner of campaign edit lock.
                if ($scope.campaign.lock.isLocked && ($scope.campaign.lock.key === editLockKey)) {
                  cancelCampaignLockTimer();
                  // We were on edit campaign page and as we are now moving away from it, release the campaign lock
                  ewtCampaign.unlock({
                    id: fromParams.id,
                    tabId: editLockKey
                  }).$promise.then(
                    function(response) {
                      return (response.status === 'success') ? true : false;
                    });
                }
              }
            }
          } else {
            if ((fromState.name == 'app.auth.campaigns.details') && fromParams.id) {
              // We should unlock, only if loggedin user is the owner of campaign edit lock.
              if ($scope.campaign.lock.isLocked && ($scope.campaign.lock.key === editLockKey)) {
                cancelCampaignLockTimer();
                // We were on edit campaign page and as we are now moving away from it, release the campaign lock
                ewtCampaign.unlock({
                  id: fromParams.id,
                  tabId: editLockKey
                }).$promise.then(
                  function(response) {
                    return (response.status === 'success') ? true : false;
                  });
              }
            }
          }
        });

        $scope.campaign.cancelAllDrops = "true"; // set default selection of radio button in cancel popup

        /**
         * cancelCampaign - method that opens pop up on clicking cancel campaign button
         *                  on actions bar
         */
        $scope.cancelCampaign = function() {
          $scope.campaign.modal.open({
            'url': 'ng-app/partials/directives/modals/cancel-campaign.html',
            'resolve': {
              'purpose': 'cancelCampaign',
              'campaign': angular.copy($scope.campaign)
            }
          });
        };

        /**
         * canCampaignCancelled - This function is used to validate ng-if state of cancel campaign button
         * this function is called once when the campaign is loaded by default.
         * if the campaign is not having requestID then it returns false which inturn hides cancel campaign button
         * if the campaign is having valid requestID and it is not submitted to ESP, we neet to show cancel campaign button
         * if the campaign is submitted to ESP and all the cells are in past dates then return false to hide cancel campaign button
         * if none of the contions met then we return false which hides cancel buttons - this is exception
         * @return {boolean} [return boolean values which set the hide/show state of cancel campaign button]
         */
        var canCampaignCancelled = function() {
          var validRequestID,
            cancellationCellsLength;

          validRequestID = typeof($scope.campaign.requestID) === 'number' ? true : false;

          if (!validRequestID) {
            return false;
          }

          if (validRequestID && !$scope.campaign.isSubmittedToESP) {
            return true;
          }

          cancellationCellsLength = $scope.campaign.criticalDataSubmittedCopy.length;

          if ($scope.campaign.isSubmittedToESP && cancellationCellsLength > 0) {
            return true;
          }
          return false;
        }
        /**
         * isValidCancelCampaign - Scope variable which bound to ng-if of cancel button
         * @type {Boolean}
         */
        $scope.isValidCancelCampaign = false;
        $scope.isValidCancelCampaign = canCampaignCancelled();

        // create watch bindings to event emitter
        bindListeners(state, $scope);
        setTimeout(bindWatchers.bind(null, state, $scope), 10);
        setTimeout(state.emit.bind(state, 'init'), 20);

        function bindWatch(prefix) {
          return function(path, fn) {
            $scope.$watch(prefix + '.' + path, function(newValue, oldValue) {
              if (
                (oldValue == null || oldValue === undefined)
                && (newValue == null || newValue === undefined)
              ) return;
              fn(newValue, oldValue);
              $scope.$applyAsync();
            })
          }
        }
      } //controller
    ]);

  // TODO: after webpack, refactor state.user, state.validation to separate components
  function isAdmin(role) {
    return role === 'axpi' || role === 'axpiAdmin';
  }

  function isTech(role) {
    return role === 'tech';
  }

  function isManager(role) {
    return role === 'mm';
  }

  function createStateValidation(state) {
    // array of functions used to validate forms
    return [
      /* function isValid(state, campaign){ ... } */
    ];
  }

  function createStateUser(state, initLoadData, loggedInUser) {
    var ret = {
      instance: function() {
        return loggedInUser;
      },
      getRole: function() {
        return ret.instance().role.codeName
      },
      isAdmin: function() {
        return isAdmin(ret.getRole());
      },
      isTech: function() {
        return isTech(ret.getRole());
      },
      isManager: function() {
        return isManager(ret.getRole());
      }
    };
    return ret;
  }

  function createStateCampaign(state, campaign, watch) {
    var ret = {
      instance: function() {
        return campaign;
      },
      code: function() {
        return ret.instance().emailType.codeName;
      }
    };

    return ret;
  }

  function createStateData(state, data) {
    var ret = {
      instance: function() {
        return data;
      },
      oneoffDeploymentWeek: function() {
        return ret.instance().oneoffDeploymentWeek;
      }
    }
    return ret;
  }

  // create watchers against scope changes to trigger on state
  function bindWatchers(state, $scope) {
    // listen for campaign changes, emit on state
    $scope.$watch('campaign.emailType.codeName', state.emit.bind(state, 'change:campaign-code'));
    $scope.$watch('campaign.deploymentDates[0]', state.emit.bind(state, 'change:scheduling-start'));
    $scope.$watch('campaign.durationInWeeks', state.emit.bind(state, 'change:scheduling-duration'));
    $scope.$watch('campaign.endDate', state.emit.bind(state, 'change:scheduling-end'));
    $scope.$watch('campaign.buDeployment', state.emit.bind(state, 'change:scheduling-bu-deployment'));
  }

  function sameDate(a, b) {
    if (
      (a === undefined || a === null)
      && (b === undefined || b === null)
    ) return true;
    return moment(new Date(a)).startOf('d').isSame(moment(new Date(b)).startOf('d'));
  }

  // create listners on state to handle results
  function bindListeners(state, $scope) {
    var _a;
    state.on('apply', function() {
      window.clearTimeout(_a);
      _a = window.setTimeout($scope.$applyAsync.bind($scope), 0);
    });

    // event handlers - from subcontrollers
    state.on('handle:need-category-change', function(reason) {
      $scope.events.description.needCategoryChange(reason);
    });
  }
  
}());
