'use strict';

/**
 * @ngdoc overview
 * @name ewtNewCampaignModule
 * @description
 * # ewtNewCampaignModule
 *
 * Module for creating new campaign.
 */
angular
  .module('ewtNewCampaignModule', [])

.config(function($stateProvider) {
  $stateProvider
    .state('app.auth.campaigns.new', {
      url: '/new',
      templateUrl: 'ng-app/partials/campaign/new.html',
      controller: 'ewtCampaignController',
      resolve: {
        campaign: function(ewtCampaign, initLoadData, cardProducts) {
          return new ewtCampaign({
            state: {
              codeName: 'draft'
            },
            requestor: initLoadData.loggedInUser,
            requestorPrimary: initLoadData.loggedInUser,
            initLoadData: initLoadData,
            arbitrationStatus: {},
            creativeMockup: {},
            isMultiCMNeedCategory: 'false',
            mhids: [],
            versions: [],
            cells: [],
            pznVariables: [],
            dynamicCampaigns: [],
            businessUnit: {},
            emailType: {},
            commCode: {
              businessUnitCode: '',
              code: '',
              name: '',
              codeName: '',
              frequency: '',
              products: []
            },
            type: {},
            isDynamicCampaign: 'false',
            allCMCategorySelectedList: [],
            allCMCategoryAvailableList: [],
            primaryMarketingManager: angular.copy(initLoadData.loggedInUser) || {},
            secondaryMarketingManager: {},
            subType: {},
            comments: [],
            cardProducts: angular.copy(cardProducts),
            deploymentDates: [],
            cmNeed: {
              selected: [],
              available: []
            },
            sto: {
              isSTO: 'false',
              isThrottled: 'false',
              isSpecificTime: 'false',
              isSpecialTestingReq: 'false'
            }
          });
        },
        attachmentTypes: function() {
          return {
            'data': []
          };
        }
      }
    });
});
