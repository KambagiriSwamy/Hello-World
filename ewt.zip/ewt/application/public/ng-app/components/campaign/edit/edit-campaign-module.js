'use strict';

/**
 * @ngdoc overview
 * @name appNameApp
 * @description
 * # appNameApp
 *
 * Main module of the application.
 */
angular
  .module('ewtEditCampaignModule', ['ewtNewCampaignModule', 'ewtCampaignListModule', 'ui.router'])

.config(function($stateProvider) {
  $stateProvider
    .state('app.auth.campaigns', {
      parent: 'app.auth',
      abstract: true,
      template: '<ui-view/>',
      url: '/campaigns',
    })
    .state('app.auth.campaigns.details', {
      url: '/:id',
      templateUrl: 'ng-app/partials/campaign/new.html',
      controller: 'ewtCampaignController',
      resolve: {
        // before opening the campaign in edit mode, try to get the campaign lock
        // if you get the campaign edit lock, you will be able to edit, else campaign will be shown as read only.
        isLocked: function(ewtCampaign, $stateParams, ewtMasterDataService, initLoadData) {
          return ewtCampaign.lock({
              id: $stateParams.id,
              tabId: window.sessionStorage.getItem('tabId')
            })
            .$promise.then(
              function(response) {
                return (response.status === 'success') ? true : false;
              },
              // If error occurs in acquiring lock, simply ignore it as anyway lock details will be available in campaign that we
              // will get from DB
              function() {}
            );
        },
        campaign: function(ewtCampaign, $stateParams, ewtMasterDataService, initLoadData, isLocked) {
          return ewtCampaign.get({
              id: $stateParams.id
            })
            .$promise.then(
              // Success handler
              function(response) {
                if (response.type && response.type.code) {
                  ewtMasterDataService.getCampaignSubTypes(response.type.code);
                }
                response.initLoadData = angular.copy(initLoadData);
                return response;
              },
              // Error handler to handle non-200 response from server.
              function(response) {
                // If the session has expired, show the error message to user.
                if ((response) && (response.data) && (response.data.code === 'SESSION_EXPIRED') && (response.data.reason)) {
                  alert(response.data.reason);
                }
              }
            );
        },
        attachmentTypes: function(campaign, $http) {
          if (campaign.emailType) {
            return $http.get('/api/v1/attachment-types/' + campaign.emailType.code).success(function(responseData) {
              return responseData.data;
            });
          } else {
            return {
              'data': []
            };
          }
        }
      }
    });
});