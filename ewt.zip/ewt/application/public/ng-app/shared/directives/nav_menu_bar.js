'use strict';

/**
 * @ngdoc directive
 * @name ewtApp.directive:menuBar
 * @description
 * # menuBar
 */
angular.module('ewtApp')
  .directive('navMenuBar', ['initialData', function(initialData) {
    return {

      templateUrl: 'ng-app/partials/directives/navigation.html',
      restrict: 'EA',
      link: function postLink(scope, element, attrs) {
        var data = initialData.split('&quot;').join('"');
        data = data.split('&amp;').join('&');
        var user = JSON.parse(data).loggedInUser;
        scope.routes = [
          // {
          //     label: 'My Dashboard',
          //     state: 'app.auth.dashboard'
          //   },
          {
            label: 'User Management',
            state: 'app.auth.users.list',
            visibleTo: user.role.codeName === 'axpi' ? true : false
          }, {
            label: 'Submit a New Campaign',
            state: 'app.auth.campaigns.new',
            visibleTo: true
          }, {
            label: 'Campaign History',
            state: 'app.auth.campaigns.list',
            visibleTo: true
          }
          //{label: 'Logout', state: 'app.login'}
        ];
      }
    };
  }]);
