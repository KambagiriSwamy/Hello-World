'use strict';

/**
 * @ngdoc directive
 * @name ewtApp.directive:menuBar
 * @description
 * # menuBar
 */
angular.module('ewtApp')
  .directive('menuBar', function () {
    return {
      /*template: '<nav>' +
      '<ul class='navigation'>' +
      '<a ng-repeat='route in routes' ui-href='{{route.state}}'>' +
      '<li  ui-sref='.create'>' +
      '<span >{{route.label}}</span>' +
      '</li>' +
      '</a>' +
      '</ul>' +
      '</nav>',*/
      templateUrl:'views/directives/usersPage.html',
      restrict: 'EA',
      link: function postLink(scope, element, attrs) {
        scope.routes = [
          {label: 'My Dashboard', state: 'app.auth.dashboard'},
          {label: 'Submit a New Campaign', state: 'app.auth.campaigns.new'},
          {label: 'Campaign History', state: 'app.auth.campaigns.list'},
          /*{label: 'Contact List', state: '},
          {label: 'Help Documents', state: '},*/
          {label: 'Logout', state: 'app.login'}
        ];
      }
    };
  });
