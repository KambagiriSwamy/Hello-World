'use strict';

/**
 * @ngdoc directive
 * @name ewtApp.directive:ewtPopUp
 * @description
 * # ewtPopUp
 */
angular.module('ewtApp')
  .directive('ewtPopUp', ['$modal', '$compile', function($modal, compile) {
    return {
      restrict: 'A',
      scope: {
        operational: '=',
        options: '='
      },
      link: function(scope, element, attrs) {
        /**
         * About directive scope variables
         * operational -> Decides type of modal (type: boolean, default: false).
         *                This variable will autamatically set based on options passed.
         *                true   - requires templateUrl to open modal. (Operational Pop Up)
         *                false  - requires a message and action options (Informative pop up with buttons)
         * options     -> There are two types of options that can be passed based on type of Modal
         *                Type 1 - {
         *                           message: String       - Require, Message to display in Modal
         *                           actionButtons: [
         *                            {
         *                              label: String      - Require, Lable to be displayed the button.
         *                              callBack: Function - Optional, Function to be called on clicking the button.
         *                              buttonType: String - Class to be added to button.
         *                            }
         *                           ]
         *                           onlyInfo: Boolean     - Decides if modal is only for information
         *                         }
         *                Type 2 - {
         *                          url: String            - Required, TemplateUrl of the html to be displayed in modal.
         *                          resolve: *             - Optional, any option that you want to be available in 
         *                                                   controller spectific to modal - ewtModalController.
         *                         }
         */

        scope.operational = scope.operational ? scope.operational : false;

        var modalObject = {
          templateUrl: '',
          template: '',
          controller: 'ewtModalController',
          resolve: {
            resolved: function() {
              return {};
            }
          },
          animation: true,
          backdrop: 'static',
          keyboard: false,
          backdropClass: '',
          windowClass: 'dasdasdadasda',
          windowTopClass: 'windowTopClass',
          windowTemplateUrl: '',
          size: '',
          openedClass: ''
        };

        scope.codeError = {
          // message : ['Following are the errors in your code :']
          message: [],
          onlyInfo: true
        };

        scope.checkOptions = function(options, keys) {
          var optionKeys = Object.keys(options);
          keys.forEach(function(value) {
            if (optionKeys.indexOf(value) === -1) {
              scope.setUpError = true;
              scope.codeError.message.push('Options provided for popup doesnot contain the key - \'' + value + '\'');
            }
          });
        };

        scope.validateType = function(value, type, ref) {
          if (typeof(value) === type) {
            return true;
          } else {
            scope.setUpError = true;
            scope.codeError.message.push('Expected a \'' + type + '\' for \'' + ref + '\' attribute in options');
          }
        };

        scope.validateOptions = function() {
          if (scope.operational) {
            // modal to be opened is operational. (Options should be type 2)
            scope.checkOptions(scope.options, ['url', 'resolve']);
            if (scope.options.url) {
              scope.validateType(scope.options.url, 'string', 'url');
            }
          } else {
            // modal to be opened is not operational. (Options should be type 1)
            scope.options.onlyInfo = scope.options.onlyInfo ? true : false;
            if (scope.options.onlyInfo) {
              scope.checkOptions(scope.options, ['message']);
            } else {
              scope.checkOptions(scope.options, ['message', 'actionButtons']);
            }
            if (scope.options.message) {
              scope.validateType(scope.options.message, 'string', 'message');
            }
            if (scope.options.actionButtons && angular.isArray(scope.options.actionButtons)) {
              scope.options.actionButtons.forEach(function(button, index) {
                scope.validateType(button.label, 'string', 'actionButtons[' + index + ']');
                if (button.callBack) {
                  scope.validateType(button.callBack, 'function', 'actionButtons[' + index + ']');
                }
                button.buttonType = button.buttonType || 'secondary';
              });
            }
          }
        };

        scope.renderPopUp = function(renderObject, typeFlag) {
          scope.renderObject = {};
          scope.renderObject = angular.copy(renderObject);
          // If typeFlag is true then operational pop up will open up
          if (!typeFlag) {
            if (!(renderObject) || !(renderObject.message)) {
              // If we dont have anything to render, simply return back
              return;
            }
            delete modalObject.templateUrl;

            var template = '<form>' +
              '<div class="modal-body">' +
              '<p style="font-size: 20px;text-align: center;font-weight: 500;">{{renderObject.message}}' +
              '</p>' +
              '</div>' +
              '<div class="modal-footer" style="text-align: center;border: none;">' +
              '<button ng-if="!renderObject.onlyInfo" ng-repeat="action in renderObject.actionButtons" ng-class="action.buttonType" ng-click="action.callBack();close($event)" ng-bind="action.label"></button>' +
              '<button ng-if="renderObject.onlyInfo" class="error" ng-click="close()" >Close</button>' +
              '</div>' +
              '</form>';
            modalObject.template = 'Action';
          } else {
            delete modalObject.template;
            modalObject.templateUrl = scope.renderObject.url;
            if (scope.renderObject.resolve) {
              modalObject.resolve.resolved = function() {
                // if the same reference is passed then then we can have a Circular Object.
                return angular.copy(scope.renderObject.resolve);
              };
            }
          }

          scope.renderObject.closeOn = scope.renderObject.closeOn || [];

          if (scope.renderObject.closeOn.indexOf('background') !== -1) {
            modalObject.backdrop = true;
          } else {
            modalObject.backdrop = 'static';
          }

          if (scope.renderObject.closeOn.indexOf('escape') !== -1) {
            modalObject.keyboard = true;
          } else {
            modalObject.keyboard = false;
          }

          var modalInstance = $modal.open(modalObject);
          modalInstance.result.then(function(response) {
            // Do nothing
          });

          modalInstance.opened.then(function(response) {
            // Do nothing
          });
          modalInstance.rendered.then(function(response) {
            if (!typeFlag) {
              scope.close = modalInstance.close;
              $('.modal-content').children().remove();
              $('.modal-content').append(compile(template)(scope));
            }
          });
        };

        scope.openPopUp = function(options) {
          scope.options = scope.options || {}
          if (options) {
            // scope.options = angular.copy(options);
            if (options.url) {
              delete scope.options.message;
              delete scope.options.actionButtons;
              delete scope.options.onlyInfo;
            } else if (options.message) {
              delete scope.options.url;
              delete scope.options.resolve;
              options.onlyInfo = (options.actionButtons && options.actionButtons.length > 0) ? false : true;
            }
            delete scope.options.closeOn;
            scope.options = angular.extend({}, scope.options, options);
          }

          if (Object.keys(scope.options).indexOf('url') !== -1) {
            scope.operational = true;
          } else {
            scope.operational = false;
          }

          /**
           * @ Validate if options passed are valid
           */
          scope.validateOptions();

          if (scope.setUpError) {
            // Show code errors.
            scope.codeError.message = scope.codeError.message.join(', ');
            scope.renderPopUp(scope.codeError, false);
          } else {
            // render pop up.
            scope.renderPopUp(scope.options, scope.operational);
          }
        };

        if (scope.options) {
          scope.options.open = scope.openPopUp;
        } else {
          scope.codeError.message = 'Directive ewt-pop-up should have a attribute \'options\' with a defined object';
          scope.renderPopUp(scope.codeError, false);
        }
      }
    };
  }]);
