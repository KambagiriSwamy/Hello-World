'use strict';

/**
 * @ngdoc directive
 * @name static-include.directive:staticInclude
 * @description
 * # staticInclude
 */

 angular.module('static-include', [])
  .directive('staticInclude', function ($http, $templateCache, $compile) {
    return {
      restrict: 'A',
      transclude: true,
      replace: true,
      link: function($scope, element, attrs, ctrl, transclude) {
        var templatePath = attrs.staticInclude;

        try{
          templatePath = $scope.$eval(templatePath);
        }catch(err){
          throw new Error(attrs.staticInclude+' is not a valid object');
        }

        $http.get(templatePath, { cache: $templateCache })
          .success(function(response) {
            var contents = element.html(response).contents();
            $compile(contents)($scope);
          });
      }
    };
  });
