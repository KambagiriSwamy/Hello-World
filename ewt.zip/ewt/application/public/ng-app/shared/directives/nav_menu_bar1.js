'use strict';

/**
 * @ngdoc directive
 * @name ewtApp.directive:menuBar
 * @description
 * # menuBar
 */
angular.module('ewtApp')
  .directive('navMenuBar', function () {
    return {
      template:'<div></div>',
      //templateURL:'ng-app/partials/directives/navigation.html',
      restrict: 'EA',
      link: function postLink(scope, element, attrs) {
        scope.routes = [
          {label: 'My Dashboard', state: 'app.auth.dashboard'},
          {label: 'Submit a New Campaign', state: 'app.auth.campaigns.new'},
          {label: 'Campaign History', state: 'app.auth.campaigns.list'},
          /*{label: 'Contact List', state: '},
          {label: 'Help Documents', state: '},*/
          {label: 'Logout', state: 'app.login'}
        ];
      }
    };
  });
