'use strict';

(function(){

function chooseDate(scope, elem, $rootScope) {
  if (scope.isDisabled) return;
  
  scope.ngFocus();
  scope.$applyAsync();
  
  var options = {
    min: scope.min() || null,
    max: scope.max() || null,
    value: scope.ngModel && new Date(scope.ngModel) || null,
    startOfWeek: 1,
    monthsToShow: ~~scope.months() || 1,
    checkDate: function(date) {
      return scope.checkDate({ date:date, mode:'day' });; 
    },
  };
  
  if (typeof options.min === 'number' && options.max < 9999) options.min = options.min.toString();
  if (typeof options.max === 'number' && options.max < 9999) options.max = options.max.toString();
  //console.log('options', options);
  
  window.__datepicker_modal = DatePickerModal.date(
    options, 
    function(err,dtm){
      if (err) {
        //window.console.error('Error in DatePickerModal', err);
        console.error('DatePickerModal Error', err.message, err.stack);
        alert('Error in DatePickerModal');
        return;
      }
      
      scope.ngModel = dtm;
      scope.$apply();
      scope.ngChange({value:dtm});
      $(elem).find('button').focus();
    }
  );
}

function getBoundValue(dtm, format) {
  //console.log('getBoundValue', dtm, format);
  if (!dtm) return '';
  return moment(dtm).format(format);
}

/**
 * @ngdoc directive
 * @name ewtApp.directive:datePicker
 * @description
 * # datePicker
 */

angular.module('ewtApp')
.directive('mdDatepicker', [
  '$rootScope', 
  function($rootScope){
    return {
      restrct: 'E',
      
      scope: {
        ngModel: '=',

        name: '@',
        min: '&',
        max: '&',
        months: '&',
        
        format: '@',
        
        checkDate: '&',
        ngRequired: '&',
        ngDisabled: '&',
        ngFocus: '&',
        ngChange: '&'
      },
      
      template: '' +
        '<input class="form-control md-datepicker-input" ng-click="choose()" type="text" name="{{name}}" ng-model="displayValue" readonly ng-required="ngRequired()" ng-disabled="ngDisabled()" />' +
        '<button class="btn btn-primary md-datepicker-button" ng-click="choose()" ng-disabled="ngDisabled()"><i class="glyphicon glyphicon-calendar "></i></button>' +
        '',
      
      link: function linkDatePicker(scope, element, attrs) {
        if (!attrs.checkDate) scope.checkDate = function() { return true; };
        //console.log('attrs', attrs);
        scope.className = attrs.class || '';
        scope.format = scope.format || 'MM/DD/YYYY';
        scope.choose = function(){ chooseDate(scope, element, $rootScope); };
        scope.displayValue = getBoundValue(scope.ngModel, scope.format);
        
        //console.log('scope', window.__dps = Object.assign({}, scope));
        
        scope.$watch('ngModel', function(value){
          scope.displayValue = getBoundValue(value, scope.format);
          scope.$applyAsync();
        });
        
        scope.$watch('ngRequired', function(value){
          scope.isRequired = value === true || value === 'true';
          scope.$applyAsync();        
        });
        
        scope.$watch('ngDisabled', function(value){
          scope.isDisabled = value === true || value === 'true';
          scope.$applyAsync();        
        });
      },
    };
  }
]);

}());