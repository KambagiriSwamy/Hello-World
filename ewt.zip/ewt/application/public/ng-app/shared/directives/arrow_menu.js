'use strict';

/**
 * @ngdoc directive
 * @name ewtApp.directive:arrowMenu
 * @description
 * # arrowMenu
 */
angular.module('ewtApp')
  .directive('arrowMenu', function () {
    return {
      restrict: 'A',
      templateUrl:'ng-app/partials/directives/arrow-tabs.html',
      link: function postLink(scope, element, attrs) {
        element.addClass('arrow-menu-container');

        scope.clearTabs=function(){
          scope.tabs.forEach(function(tab){
            tab.active= false;
          });
        };
        scope.showAllTabs=function(){
          scope.tabs.forEach(function(tab){
            tab.active=true;
          });
        };

        scope.selectTab=function(idx){
          scope.clearTabs();
          scope.tabs[idx].active=true;
        };
      }
    };
  });
