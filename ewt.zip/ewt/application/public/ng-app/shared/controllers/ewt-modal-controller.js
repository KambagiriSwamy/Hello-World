'use strict';

/**
 * @ngdoc function
 * @name ewtApp.controller:ewtModalController
 * @description
 * # ewtModalController
 * Controller of the ewtApp
 */
angular.module('ewtApp')
  .controller('ewtModalController', ['$scope', '$filter', '$modalInstance', 'resolved', 'exportFields', 'ewtUtils', '$state', 'ewtCampaign',
    function($scope, $filter, $modalInstance, resolved, exportFields, utilities, $state, ewtCampaign) {
      $scope.resolved = angular.copy(resolved);
      $scope.utilities = utilities;

      /**
       * @ Donot pollute scope for every pop up
       */

      $scope.recepeints = [{
        code: 'MM',
        name: 'Marketing Manager'
      }, {
        code: 'PMM',
        name: 'Primary Marketing Manager'
      }, {
        code: 'SMM',
        name: 'Secondary Marketing Manager'
      }];
      $scope.noRecepeint = {
        code: 'none',
        name: 'None'
      };
      /**
       * If the campaign does not have Secondary Marketing Manager then from
       * the recepeints array remove Secondary Marketing Manager
       * @param  {Object} resolved                            [campaign Object]
       * @param  {Object} !resolved.secondaryMarketingManager [Secondary Marketing Manager Object]
       */
      if (resolved && !resolved.secondaryMarketingManager) {
        $scope.recepeints.pop();
      }

      $scope.uncheckOthers = function() {
        if ($scope.noRecepeint.checked) {
          angular.forEach($scope.recepeints, function(recepeint) {
            recepeint.checked = false;
          });
        }
      };

      $scope.validateForm = function(message) {
        if (message) {
          return !(message.length > 0 && ($filter('filter')($scope.recepeints, {
            checked: true
          }).length > 0));
        } else {
          return true;
        }
      };

      $scope.validateRecepients = function() {
        var sendTo = $filter('filter')($scope.recepeints, {
          checked: true
        }).length > 0 ? true : false;
        return sendTo || $scope.noRecepeint.checked;
      };

      $scope.campaignCheck = function(action) {
        $scope.sendTo = '';
        if ($scope.recepeints[0].checked) {
          $scope.sendTo = $scope.sendTo + $scope.resolved.requestor.email + ',';
        }
        if ($scope.recepeints[1].checked) {
          $scope.sendTo = $scope.sendTo + $scope.resolved.primaryMarketingManager.email + ',';
        }
        if ($scope.resolved.secondaryMarketingManager && $scope.recepeints[2].checked) {
          $scope.sendTo = $scope.sendTo + $scope.resolved.secondaryMarketingManager.email + ',';
        }

        if ($scope.sendTo === '') {
          $scope.sendTo = $scope.noRecepeint.code;
        } else {
          $scope.sendTo = $scope.sendTo.slice(0, -1);
        }

        if (action === 'revision') {
          $scope.resolved.revisionRequired($scope.sendTo, $scope.revisionReason);
        }
        if (action === 'decline') {
          $scope.resolved.deny($scope.sendTo, $scope.declineReason);
        }
        if (action === 'rollBack2Manager') {
          $scope.resolved.rollBack($scope.sendTo, $scope.rollBackReason);
        }
      };

      $scope.dismiss = function(options) {
        $modalInstance.dismiss(options);
      };

      $scope.close = function(options) {
        $modalInstance.close(options);
      };

      /**
       * Cancel campaign logic only available to scope if the purpose of modal pop-up is to 
       * cancel cells . This cancellation is of two type 
       * 1) cancel whole campaign before it is submitted to esp 
       *   - This will move the campaign to CANCELLED state directly 
       *   - There will no reponse pop-up box, page will navigate to campaigns list tab
       * 2) cancel only few / all cells with a list of check boxes after campaign submitted to ESP
       * This cancellation function 
       *   - User can select cancell all drops 
       *   - User can select one whole drop with all cells or only few cells
       *   - User will see a respose pop-up with all the cells cancelled 
       *   - No cells with past dates are show in the pop-up or say not allowed to cancell
       */

      if (resolved && resolved.purpose === 'cancelCampaign') {
        /**
         * showConfirmation is a boolean variable which is toggle the visibilty of cancel cells confirmatio pop-up
         * true  -- after selected cells are cancelled
         * false -- by default / when pop-up opens
         */
        $scope.showConfirmation = false;
        // boolean variable to check if the campaign type is MA so that campaign pop-up is shown accordingly (US428996)
        $scope.isMA = resolved.campaign.emailType.codeName === 'ET_MA' ? true : false;

        /**
         * allCellsMarked variable : It is boolean flag to validate whether all the cells for all the deployments 
         * true  -- By default / when modal pop-up loads as 'CANCEL ALL DROPS' is selected by default
         * false -- when user selects 'CANCEL FEW DROPS' with altleast one cell is unchecked
         */
        var allCellsMarked = true;

        /**
         * cancelCampaignSubmission function : This is called when user click on canel submission button
         * for both before and after the Submission to ESP. 
         * 
         */

        $scope.cancelCampaignSubmission = function() {
          if (!resolved.campaign.isSubmittedToESP) {
            /**
             * If the Campain is not submitted to ESP (Known using ESP flag) the cancelCampaign 
             * function is called and campaign is set to CANCELLED state and in the success callback
             * the Cancel Pop-up is closed and User is navigted to Campaign History page
             */
            $scope.resolved.campaign.cancelCampaign().then(function(response) {
              $scope.dismiss('cancel');
              $state.go('app.auth.campaigns.list');
            });
          } else {
            /**
             * Here we will check whether all possible cells on the campaign cancel pop-up 
             * is selected or not and set allCellsMarked to false if all cells are not checked
             */
            var tempCriticalData = $scope.resolved.campaign.criticalDataSubmittedCopy
            for (var index = 0; index < tempCriticalData.length; index++) {
              if (tempCriticalData[index].checked) {
                for (var innerIndex = 0; innerIndex < tempCriticalData[index].keys.length; innerIndex++) {
                  if (!tempCriticalData[index].keys[innerIndex].checked) {
                    allCellsMarked = false;
                  }
                }
              } else {
                allCellsMarked = false;
              }
            }
            /**
             * Here we will call cancelCampaign function which will cancel all the selected cells
             * and in success callback we will get all the cancell cell in response. This response
             * is again grouped in deployment dates order.
             */
            $scope.resolved.campaign.cancelCampaign().then(function(response) {
              $scope.showConfirmation = true;
              var criticalDataSubmitted = angular.copy(response);
              var formattedObj = {},
                criticalDataArray = [];
              for (var cnt = 0; cnt < criticalDataSubmitted.length; cnt++) {
                var rowObj = criticalDataSubmitted[cnt].keys;
                if (formattedObj[rowObj.CMPGN_DEPLOY_DATE]) {
                  var arr = formattedObj[rowObj.CMPGN_DEPLOY_DATE].keys;
                  arr.push(rowObj);
                  formattedObj[rowObj.CMPGN_DEPLOY_DATE].keys = arr;
                } else {
                  var arr = [];
                  arr.push(rowObj);
                  formattedObj[rowObj.CMPGN_DEPLOY_DATE] = {
                    'keys': arr
                  };
                }
              }
              for (var key in formattedObj) {
                var dtObj = {};
                dtObj = formattedObj[key];
                dtObj.date = key;
                dtObj.formattedDate = key.stringToDate();
                criticalDataArray.push(dtObj);
              }
              $scope.cancelledCells = criticalDataArray;
              /**
               * If the User selecte all possible cells to cancel / User selects cancel all 
               * drops option we will set campaign to CANCELLED state and update the campign
               */
              if (allCellsMarked || $scope.resolved.campaign.cancelAllDrops === 'true') {
                $scope.resolved.campaign.cancelledAllCells();
              }
            });
          }
        }

        /**
         * closeCancelledCells function : this function is called when user clicks close button
         * on cancel confrimation pop-up will close the pop-up and also checks
         * if the campaign state is CANCELLED, then navigate to ERA's list state 
         */
        $scope.closeCancelledCells = function() {
          $scope.dismiss('cancel');
          /**
           * if the campaign state is CANCELLED, then navigate to ERA's list state 
           * else reload the state to update the UI with cancelled cells status in Mailplan tab
           * @param  {String} $scope.resolved.campaign.state.codeName [campaig state's codeName]
           */
          if ($scope.resolved.campaign.state.codeName === 'cancelled') {
            $state.go('app.auth.campaigns.list');
          } else {
            $state.go($state.current, {}, {
              reload: true
            });

          }
        }

        /**
         * isCancelSubmissionInvalid function: This function will enable/disable the cancel
         * submission button on the cancel pop-up
         * return false -- if User selects 
         * @return {Boolean} [Tells whether cancel campaign Form is valid or not ]
         */
        $scope.isCancelSumbissionInValid = function() {
          if ($scope.resolved.campaign.cancelAllDrops === 'true') {
            return false;
          } else {
            /**
             * This conditon initially checks for all the cells of the selected deployment dates
             * and set the validCancelCells to false for every valid deployment date
             * after looping through all valid deployments if the validCancelCells is still false 
             * then we can say that cancelCampaign met the requiremts
             * Return false -- if there are none of the dates selected
             * Return true  -- if any deployment date is checked without atleast one cell checked 
             *                 for cancellation
             */
            var cancelDates = $filter('filter')($scope.resolved.campaign.criticalDataSubmittedCopy, {
              checked: true
            });
            if (cancelDates.length > 0) {
              var validCancelCells = true;
              angular.forEach(cancelDates, function(cancelDate) {
                var cancelCells = $filter('filter')(cancelDate.keys, {
                  checked: true
                });
                if (cancelCells.length === 0) {
                  validCancelCells = false;
                }
              });
              if (!validCancelCells) {
                return true;
              }
            } else {
              return true;
            }
            return false;
          }
        }

        /**
         * unCheckAllCells function : this function will un-check all the cells on cancellation
         * modal pop-up - first we will loop through all deployment dates and inner loop will
         * loop through all the cells in each deployment -- now set checked to flase for
         * every deployment date : cell
         */
        $scope.unCheckAllCells = function() {
          var checkedFlag = false;
          angular.forEach($scope.resolved.campaign.criticalDataSubmittedCopy, function(date) {
            date.checked = checkedFlag;
            angular.forEach(date.keys, function(key) {
              key.checked = checkedFlag;
            })
          });
        };
        /**
         * dateChecked : This function is called when a user click on deplyement date of canel
         * modal pop-up, it takes deployment date object and set checked to true for all cells
         * under that deployment date
         * @param  {object} date [deployment date object with number of cells]
         */
        $scope.dateChecked = function(date) {
          angular.forEach(date.keys, function(key) {
            key.checked = date.checked;
          });
        };

        /**
         * allCellsAreChecked: This function is called when user click on each cell it takes the 
         * deployment date object as an input, It will make sure deployment date object is checked
         * true for valid conditions
         * date.checked = true   -- if all the cells of the given deployment is checked 
         * date.checked = flase  -- if all the cells of the given deployment is unchecked 
         * date.checked = true   -- if there is one/ more cells in checked and unchecked state 
         * @param  {object} date [deployment date object with number of cells]
         */
        $scope.allCellsAreChecked = function(date) {
          if ($filter('filter')(date.keys, {
              checked: "false"
            }).length === 0) {
            date.checked = true;
          } else if ($filter('filter')(date.keys, {
              checked: "true"
            }).length === 0) {
            date.checked = false;
          } else {
            date.checked = true;
          }
        };
      };


      /**
       * This block is rendered only if purpose of opening the modal is to export campaign details.
       * @param  {String} resolved.purpose Differentiator text that is used to initiate scope and its variables for modal
       */
      if (resolved && resolved.purpose === 'exportCampaigns') {

        /**
         * ewtCampaign is the instance of campaigns object.
         * Used to make api call on clicking export button.
         * @type {ewtCampaign}
         */
        var ewtCampaign = new ewtCampaign();
        /**
         * $scope.fields has labels and their checked statuses
         * @type {[Object]}
         */
        $scope.fields = angular.copy(exportFields.campaign);
        /**
         * previousState stores the previous state of fields to reset on unchecking selet/unselect all.
         * @type {[Object]}
         */
        var previousState = angular.copy(exportFields.campaign);
        /**
         * selection - Method used to check and uncheck all the checkboxed based on parameter passed
         * @param  {String} params   - decides whether to check or uncheck all the labels
         */
        $scope.selection = function(params) {
          /**
           * Iterate through all the fields and set status to checked if check all checkbox is checked
           */
          if (params === 'all') {
            /**
             * Checks if check all check box is checkd
             * If yes then, stores the states of all fields and then changes all fields to checked.
             * Else, resets all the fields to previous states.
             */
            if ($scope.selectAll) {
              previousState = angular.copy($scope.fields);
              $scope.unselectAll = false;
              angular.forEach($scope.fields, function(field) {
                field.checked = true;
              });
            } else {
              $scope.fields = angular.copy(previousState);
            }
          }
          /**
           * if uncheck all checkbox is changed
           */
          if (params === 'none') {
            /**
             * Checks if uncheck all check box is checkd
             * If yes then, stores the states of all fields and then changes all fields to unchecked.
             * Else, resets all the fields to previous states.
             */
            if ($scope.unselectAll) {
              previousState = angular.copy($scope.fields);
              $scope.selectAll = false;
              angular.forEach($scope.fields, function(field) {
                field.checked = false;
              });
            } else {
              $scope.fields = angular.copy(previousState);
            }
          }
        };

        /**
         * filterLabels - triggered on clicking any check box.
         * unchecks checkAll and uncheckAll checkoxes and checks any of them later based on conditions.
         */
        $scope.filterLabels = function() {
          /**
           * If none of the checkboxes are selected then uncheck all checkbox is checked
           * If all the check boxes are checked then check all checkbox is checked.
           * else bothe check boxes are unchecked
           */
          if ($filter('filter')($scope.fields, {
              'checked': true
            }, true).length === 0) {
            $scope.unselectAll = true;
          } else if ($filter('filter')($scope.fields, {
              'checked': true
            }, true).length === $scope.fields.length) {
            $scope.selectAll = true;
          } else {
            $scope.unselectAll = false;
            $scope.selectAll = false;
          }
        };

        /**
         * atALableIsChecked is used to enable or disable export button based on number of fields checked.
         * @return {boolean} True if atleast one checkbox is checked else false.
         */
        $scope.atALableIsChecked = function() {
          return $filter('filter')($scope.fields, {
            'checked': true
          }, true).length > 0 ? true : false;
        };

        /**
         * setCampaignsForExport - Formats all the campaigns provided to modal controller to desired format
         *                         for exporting into a csv file.
         * @return {[Object]}    - Array of objects after formating campaigns.
         */
        $scope.setCampaignsForExport = function() {
          return formatCampaignData(utilities.arrayToExport);
        };

        /**
         * formatCampaignData accepts call back to be called after the Api is called
         * @param  {function} callBack   - call back to be called after getting the response
         */
        var formatCampaignData = function(callBack) {
          var serachObjectCopy = resolved.serachObjectCopy;
          var checkedFields = $filter('filter')($scope.fields, {
            checked: true
          }, true);
          serachObjectCopy.columns = [];
          serachObjectCopy.heading = [];
          angular.forEach(checkedFields, function(field) {
            serachObjectCopy.columns.push(field.campaignField);
            serachObjectCopy.heading.push(field.label);
          });
          serachObjectCopy.action = 'export';

          var filteredCampaigns = [];
          return ewtCampaign.searchCampaigns(serachObjectCopy).then(function(response) {
            $scope.close();
            return callBack(angular.copy(response));
          });
        };

        /**
         * setHeaders - this method is used to set headers on checking/unchecking any field
         *              This method has to be called onloading this controller to set defauilt headers
         */
        $scope.setHeaders = function() {
          /**
           * headers - maintains the headers to be exported in csv file.
           * @type {Array}
           */
          $scope.headers = [];
          /**
           * Setting headers to be exported on clicking check and uncheck all check boxes
           */
          $filter('filter')($scope.fields, {
            'checked': true
          }, true).forEach(function(field) {
            $scope.headers.push(field.label);
          });
        };
        $scope.setHeaders();
      }
    }
  ]);
