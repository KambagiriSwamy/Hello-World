'use strict';

/**
 * @ngdoc service
 * @name ewtApp.DynamicCampaignType
 * @description
 * # DynamicCampaignType
 * Value in the ewtApp.
 */
angular.module('ewtApp')
  .value('dynamicCampaignTypes', [
    {code: 'D', name: 'Dynamic Email'},
    {code: 'L', name: 'Lending Awareness'},
    {code: 'N', name: 'Not Applicable'},
    {code: 'P', name: 'Pre-Sync'},
    {code: '1', name: 'Recommender All'},
    {code: '2', name: 'Recommender Spend Only'},
    {code: '3', name: 'Recommender New Merchant'},
    {code: 'A', name: 'AOR'},
    {code: 'E', name: 'AED'},
  ]);