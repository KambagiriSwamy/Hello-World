'use strict';

/**
 * @ngdoc service
 * @name ewtApp.emailTypes
 * @description
 * # emailTypes
 * Value in the ewtApp.
 */

/**
 * exportFields holds configuration objects for the fields to be exported.
 * for Campaign :-
 *     campaignFiled will have the reference where the labeled value can be found for a campaign.
 *     We can have any number of references based on the campaign type.
 *     Ex : Mail history will reside in campaign.mailHistory for servicing and oneoff
 *          where as it will be present in campaign.ma.mailHistory for marketing automation.
 *
 * for Users :-
 *     There are three different ways in which required details are extracted from a User
 *       1. String => this is the key that holds required value directly
 *       2. String with special character as '->'
 *           '->'  => desired value is in a embedded oject 
 *                    Ex: parent->child
 *       3. 'date' => The value to be exported is a Date Object. We need to create a Date instance and 
 *                    format that properly before exporting to CSV. 
 */


angular.module('ewtApp')
  .value('exportFields', {
    'campaign': [{
        'label': 'Mail History ID',
        'checked': true,
        'campaignField': 'mailHistory,ma.mailHistory'
    }, {
        'label': 'Request ID',
        'checked': true,
        'campaignField': 'requestID'
    }, {
        'label': 'Campaign Name',
        'checked': true,
        'campaignField': 'name'
    }, {
        'label': 'Campaign Status Description',
        'checked': true,
        'campaignField': 'state.name'
    }, {
        'label': 'Execution Dates',
        'checked': true,
        'campaignField': 'deploymentDates'
    }, {
        'label': 'Marketing Manager Name (Requestor)',
        'checked': true,
        'campaignField': 'requestor.name'
    }, {
        'label': 'Requestor Email Address',
        'checked': true,
        'campaignField': 'requestor.email'
    }, {
        'label': 'Leader Name',
        'checked': true,
        'campaignField': 'requestor.leader.name'
    }, {
        'label': 'Leader Email Address',
        'checked': true,
        'campaignField': 'requestor.leader.email'
    }, {
        'label': 'Primary Marketing Manager Name',
        'checked': true,
        'campaignField': 'primaryMarketingManager.name'
    }, {
        'label': 'PMM Email Address',
        'checked': true,
        'campaignField': 'primaryMarketingManager.email'
    }, {
        'label': 'Secondary Marketing Manager Name',
        'checked': true,
        'campaignField': 'secondaryMarketingManager.name'
    }, {
        'label': 'SMM Email Address',
        'checked': true,
        'campaignField': 'secondaryMarketingManager.email'
    }, {
        'label': 'Email Type',
        'checked': true,
        'campaignField': 'emailType.name'
    }, {
        'label': 'Campaign Business Unit',
        'checked': true,
        'campaignField': 'businessUnit.name'
    }, {
        'label': 'Campaign Type',
        'checked': false,
        'campaignField': 'FUTURE' // Will be added later releases
    }, {
        'label': 'Campaign Subtype',
        'checked': false,
        'campaignField': 'FUTURE' // Will be added later releases
    }, {
        'label': 'Campaign Objective',
        'checked': false,
        'campaignField': 'description'
    }, {
        'label': 'Estimated File Count',
        'checked': false,
        'campaignField': 'FUTURE' // Will be added later releases
    }, {
        'label': 'Volume Cap',
        'checked': true,
        'campaignField': 'volumeCap'
    }, {
        'label': 'Trigger Resting Week',
        'checked': true,
        'campaignField': 'FUTURE' // Will be added later releases
    }, {
        'label': 'Version Number',
        'checked': true,
        'campaignField': 'versions,ma.maVersions'
    }, {
        'label': 'Cell Number',
        'checked': true,
        'campaignField': 'versions,ma.maCells'
    }, {
        'label': 'Special Campaign Type',
        'checked': true,
        'campaignField': 'dynamicCampaigns' // Dynamic campains
    }, {
        'label': 'CPS Target Population',
        'checked': false,
        'campaignField': 'cardProducts'
    }, {
        'label': 'OPEN Target Population',
        'checked': false,
        'campaignField': 'cardProducts'
    }, {
        'label': 'Email Preview Addresses',
        'checked': true,
        'campaignField': 'previewEmailList'
    }, {
        'label': 'Email Seed Addresses',
        'checked': true,
        'campaignField': 'deployEmailList'
    }, {
        'label': 'Trigger Type',
        'checked': false,
        'campaignField': 'FUTURE' // Will be added later releases
    }, {
        'label': 'CM Need Category',
        'checked': true,
        'campaignField': 'cmNeedCategories'
    }, {
        'label': 'No Arbitration Campaign',
        'checked': true,
        'campaignField': 'FUTURE' // Will be added later releases
    }, {
        'label': 'BU Deployment Slot',
        'checked': false,
        'campaignField': 'buDeployment'
    }, {
        'label': 'Budget Line',
        'checked': true,
        'campaignField': 'budgetLine'
    }, {
        'label': 'Responsibility Center',
        'checked': true,
        'campaignField': 'responsbilityCenter'
    }, {
        'label': 'Rollback Reason',
        'checked': false,
        'campaignField': 'rollBackComments'
    }, {
        'label': 'Personalized Fields',
        'checked': true,
        'campaignField': 'pznFields' //pzn
    }, {
        'label': 'ESP Vendor',
        'checked': true,
        'campaignField': 'esp.name'
    }, {
        'label': 'Notes to ESP',
        'checked': true,
        'campaignField': 'espInstructions'
    }, {
        'label': 'Notes to Admin',
        'checked': true,
        'campaignField': 'comments'
    }
  ],
    'users': [{
        'label': 'First Name',
        'selector': 'firstName'
    }, {
        'label': 'Last Name',
        'selector': 'lastName'
    }, {
        'label': 'Email Address',
        'selector': 'email'
    }, {
        'label': 'ADS ID',
        'selector': 'uid'
    }, {
        'label': 'Business Unit',
        'selector': 'businessUnit->name'
    }, {
        'label': 'User Type',
        'selector': 'role->name'
    }, {
        'label': 'Status',
        'selector': 'status->name'
    }, {
        'label': 'User Added On',
        'selector': 'createdOn',
        'type': 'date'
    }, {
        'label': 'Last Updated On',
        'selector': 'lastUpdatedOn',
        'type': 'date'
    }]
  });

