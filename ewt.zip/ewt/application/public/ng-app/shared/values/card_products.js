'use strict';

/**
 * @ngdoc service
 * @name ewtApp.cardProducts
 * @description
 * # cardProducts
 * Value in the ewtApp.
 */
angular.module('ewtApp')
  .value('cardProducts', [
    {code: 'x001', name: 'Consumer Premium'},
    {code: 'x002', name: 'Consumer CoBrand'},
    {code: 'x003', name: 'Consumer Lending'},
    {code: 'x004', name: 'Consumer Charge'},
    {code: 'x005', name: 'OPEN Premium'},
    {code: 'x006', name: 'OPEN CoBrand'},
    {code: 'x007', name: 'OPEN Lending'},
    {code: 'x008', name: 'OPEN Charge'},
  ]);