'use strict';

/**
 * @ngdoc service
 * @name ewtApp.emailVendors
 * @description
 * # emailVendors
 * Value in the ewtApp.
 */
angular.module('ewtApp')
  .value('emailVendors', [
    {code: 'E', codeName: 'exactTarget', name: 'Exact Target'},
    {code: 'C', codeName: 'cheetahMail', name: 'Cheetah Mail'}
  ]);