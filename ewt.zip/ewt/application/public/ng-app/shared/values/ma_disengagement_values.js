'use strict';

/**
 * @ngdoc service
 * @name ewtApp.emailTypes
 * @description
 * # emailTypes
 * Value in the ewtApp.
 */
angular.module('ewtApp')
  .value('maDisengamentNos', [{
      value: 1,
      name: '1 week'
    }, {
      value: 2,
      name: '2 weeks'
    }, {
      value: 3,
      name: '3 weeks'
    }, {
      value: 4,
      name: '4 weeks'
    }, {
      value: 5,
      name: '5 weeks'
    }, {
      value: 6,
      name: '6 weeks'
    }, {
      value: 7,
      name: '7 weeks'
    }, {
      value: 8,
      name: '8 weeks'
    }, {
      value: 9,
      name: '9 weeks'
    }, {
      value: 10,
      name: '10 weeks'
    },
    {
      value: 11,
      name: '11 weeks'
    }, {
      value: 12,
      name: '12 weeks'
    }
  ]);
