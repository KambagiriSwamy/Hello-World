'use strict';

/**
 * @ngdoc service
 * @name ewtApp.campaignDurationWeeks
 * @description
 * # Camapign Duration In Weeks
 * Value in the ewtApp.
 */
angular.module('ewtApp')
  .value('campaignDurationWeeks', {
    'ET_SERVICING': [],
    'ET_ONEOFF': [{
      value: 0,
      name: 'Single Day'
    }, {
      value: 1,
      name: '1 week'
    }, {
      value: 2,
      name: '2 weeks'
    }, {
      value: 3,
      name: '3 weeks'
    }, {
      value: 4,
      name: '4 weeks'
    }, {
      value: 5,
      name: '5 weeks'
    }, {
      value: 6,
      name: '6 weeks'
    }],
    'ET_MA': [{
      value: 1,
      name: '1 week'
    }, {
      value: 2,
      name: '2 weeks'
    }, {
      value: 3,
      name: '3 weeks'
    }, {
      value: 4,
      name: '4 weeks'
    }, {
      value: 5,
      name: '5 weeks'
    }, {
      value: 6,
      name: '6 weeks'
    }, {
      value: 7,
      name: '7 weeks'
    }, {
      value: 8,
      name: '8 weeks'
    }, {
      value: 9,
      name: '9 weeks'
    }, {
      value: 10,
      name: '10 weeks'
    }, {
      value: 11,
      name: '11 weeks'
    }, {
      value: 12,
      name: '12 weeks'
    }, {
      value: 13,
      name: '13 weeks'
    }, {
      value: 14,
      name: '14 weeks'
    }, {
      value: 15,
      name: '15 weeks'
    }, {
      value: 16,
      name: '16 weeks'
    }, {
      value: 17,
      name: '17 weeks'
    }, {
      value: 18,
      name: '18 weeks'
    }, {
      value: 19,
      name: '19 weeks'
    }, {
      value: 20,
      name: '20 weeks'
    }, {
      value: 21,
      name: '21 weeks'
    }, {
      value: 22,
      name: '22 weeks'
    }, {
      value: 23,
      name: '23 weeks'
    }, {
      value: 24,
      name: '24 weeks'
    }, {
      value: 25,
      name: '25 weeks'
    }, {
      value: 26,
      name: '26 weeks'
    }, {
      value: 27,
      name: '27 weeks'
    }, {
      value: 28,
      name: '28 weeks'
    }, {
      value: 29,
      name: '29 weeks'
    }, {
      value: 30,
      name: '30 weeks'
    }, {
      value: 31,
      name: '41 weeks'
    }, {
      value: 32,
      name: '42 weeks'
    }, {
      value: 33,
      name: '43 weeks'
    }, {
      value: 34,
      name: '44 weeks'
    }, {
      value: 35,
      name: '45 weeks'
    }, {
      value: 36,
      name: '46 weeks'
    }, {
      value: 37,
      name: '47 weeks'
    }, {
      value: 38,
      name: '48 weeks'
    }, {
      value: 39,
      name: '49 weeks'
    }, {
      value: 40,
      name: '40 weeks'
    }, {
      value: 41,
      name: '41 weeks'
    }, {
      value: 42,
      name: '42 weeks'
    }, {
      value: 43,
      name: '43 weeks'
    }, {
      value: 44,
      name: '44 weeks'
    }, {
      value: 45,
      name: '45 weeks'
    }, {
      value: 46,
      name: '46 weeks'
    }, {
      value: 47,
      name: '47 weeks'
    }, {
      value: 48,
      name: '48 weeks'
    }, {
      value: 49,
      name: '49 weeks'
    }, {
      value: 50,
      name: '50 weeks'
    }, {
      value: 51,
      name: '51 weeks'
    }, {
      value: 52,
      name: '52 weeks'
    }],
    'ET_PNL': []
  });
