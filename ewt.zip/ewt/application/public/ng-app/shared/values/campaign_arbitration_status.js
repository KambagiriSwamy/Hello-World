'use strict';

/**
 * @ngdoc service
 * @name ewtApp.arbitrationStatus
 * @description
 * # arbitrationStatus
 * Value in the ewtApp.
 */
angular.module('ewtApp')
  .value('arbitrationStatus', {
    'ET_SERVICING': [{
      code: 'Y',
      codeName: 'arbitrated',
      name: 'Arbitrated'
    }, {
      code: 'N',
      codeName: 'nonArbitrated',
      name: 'Non Arbitrated'
    }, {
      code: 'P',
      codeName: 'highPriority',
      name: 'High Priority'
    }, {
      code: '3',
      codeName: 'lowPriority',
      name: 'Low Priority'
    }],
    'ET_MA': [{
      code: 'N',
      codeName: 'nonArbitrated',
      name: 'Non Arbitrated'
    }],
    'ET_ONEOFF': [{
      code: 'Y',
      codeName: 'arbitrated',
      name: 'Arbitrated'
    }, {
      code: 'N',
      codeName: 'nonArbitrated',
      name: 'Non Arbitrated'
    }, {
      code: 'P',
      codeName: 'highPriority',
      name: 'High Priority'
    }, {
      code: '3',
      codeName: 'lowPriority',
      name: 'Low Priority'
    }],
    'ET_PNL': [{
      code: 'Y',
      codeName: 'arbitrated',
      name: 'Arbitrated'
    }, {
      code: 'N',
      codeName: 'nonArbitrated',
      name: 'Non Arbitrated'
    }, {
      code: 'P',
      codeName: 'highPriority',
      name: 'High Priority'
    }, {
      code: '3',
      codeName: 'lowPriority',
      name: 'Low Priority'
    }]
  });
