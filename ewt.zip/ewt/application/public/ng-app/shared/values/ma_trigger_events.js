'use strict';

/**
 * @ngdoc service
 * @name ewtApp.triggerEvents
 * @description
 * # triggerEvents
 * Value in the ewtApp.
 */
angular.module('ewtApp')
  .value('triggerEvents', [{
    'name': 'Email Driven',
    'codeName': 'EMAIL_DRIVEN'
  }, {
    'name': 'Integration Driven',
    'codeName': 'INTEGRATION_DRIVEN'
  }]);
