"use strict";

/**
 * @ngdoc Value
 * @name partialPaths
 * @description
 * # partialPaths
 * Value in the ewtApp.
 *
 * partialPaths is a object that has reference
 * keys as the email type code name
 * and the value is an object that has paths for respective tabs.
 *
 * Tab name should be same ad the ID given in $scope.tabs of campaign controller
 */

angular.module("ewtApp")
  .value("partialPaths", {
    "ET_SERVICING": {
      "descriptionTab": "ng-app/partials/campaign/servicing/description-tab.html",
      "deploymentTab": "ng-app/partials/campaign/servicing/schedule-tab.html",
      "marketingAutomationTab": "ng-app/partials/campaign/servicing/marketing-automation-tab.html",
      "mailPlanTab": "ng-app/partials/campaign/servicing/mailplan-tab.html",
      "personalizationTab": "ng-app/partials/campaign/servicing/personalization-tab.html",
      "attachmentsTab": "ng-app/partials/campaign/servicing/attachment-tab.html"
    },
    "ET_MA": {
      "descriptionTab": "ng-app/partials/campaign/marketing-automation/description-tab.html",
      "deploymentTab": "ng-app/partials/campaign/marketing-automation/schedule-tab.html",
      "marketingAutomationTab": "ng-app/partials/campaign/marketing-automation/marketing-automation-tab.html",
      "mailPlanTab": "ng-app/partials/campaign/marketing-automation/mailplan-tab.html",
      "personalizationTab": "ng-app/partials/campaign/marketing-automation/personalization-tab.html",
      "attachmentsTab": "ng-app/partials/campaign/marketing-automation/attachment-tab.html"
    },
    "ET_ONEOFF": {
      "descriptionTab": "ng-app/partials/campaign/one-off/description-tab.html",
      "deploymentTab": "ng-app/partials/campaign/one-off/schedule-tab.html",
      "marketingAutomationTab": "ng-app/partials/campaign/one-off/marketing-automation-tab.html",
      "mailPlanTab": "ng-app/partials/campaign/one-off/mailplan-tab.html",
      "personalizationTab": "ng-app/partials/campaign/one-off/personalization-tab.html",
      "attachmentsTab": "ng-app/partials/campaign/one-off/attachment-tab.html"
    },
    "ET_PNL": {
      "descriptionTab": "ng-app/partials/campaign/product-news-letter/description-tab.html",
      "deploymentTab": "ng-app/partials/campaign/product-news-letter/schedule-tab.html",
      "marketingAutomationTab": "ng-app/partials/campaign/product-news-letter/marketing-automation-tab.html",
      "mailPlanTab": "ng-app/partials/campaign/product-news-letter/mailplan-tab.html",
      "personalizationTab": "ng-app/partials/campaign/product-news-letter/personalization-tab.html",
      "attachmentsTab": "ng-app/partials/campaign/product-news-letter/attachment-tab.html"
    }
  });