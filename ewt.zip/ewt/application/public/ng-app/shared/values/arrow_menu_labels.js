'use strict';

/**
 * @ngdoc value
 * @name ewtApp.filter:unique
 * @function
 * @description
 * # unique
 * Value in the ewtApp.
 */
angular.module('ewtApp')
  .value('arrowMenuLables', [{
    label: 'Campaign Description'
  }, {
    label: 'Scheduling'
  }, {
    label: 'Marketing Automation'
  }, {
    label: 'Mail Plan'
  }, {
    label: 'Personalization'
  }, {
    label: 'Attachments'
  }]);
