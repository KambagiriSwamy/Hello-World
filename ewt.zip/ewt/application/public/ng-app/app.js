'use strict';

/**
 * @ngdoc overview
 * @name appNameApp
 * @description
 * # appNameApp
 *
 * Main module of the application.
 */
angular
  .module('ewtApp', [
    'ui.router',
    'ngSanitize',
    'ngCsv',
    'ewtDashboardModule',
    'static-include',
    'ui.bootstrap',
    'ngFileUpload',
    // 'ui.grid',
    'ngResource',
    //do not delete new modules insertion mark
    'ewtEditCampaignModule',
    'ewtUserManagementModule'

  ])
  .config(function($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.otherwise('/campaigns/');

    $stateProvider
      .state('app', {
        abstract: true,
        template: '<div ui-view></div>',
      })
      .state('app.auth', {
        abstract: true,
        templateUrl: 'ng-app/partials/index.html',
        resolve: {
          initLoadData: function(initialData) {
            var data = initialData.split('&quot;').join('"');
            data = data.split('&amp;').join('&');
            data = JSON.parse(data);
            // storing the logged-in user object for later client-side checks
            window.sessionStorage.setItem('loggedInUser', JSON.stringify(data.loggedInUser));
            return data;
          }
        },
        controller: function($scope) {

        }
      });
  });
