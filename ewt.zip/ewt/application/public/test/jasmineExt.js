'use strict';

function JasmineExtn() {

  var vm = this;
}

JasmineExtn.prototype.readJSON = function(path) {

  var vm = this;
  var xhttp;

  if (window.jasmineRunner === true) {
    if (path.indexOf('base') >= 0) {
      path = path.replace('base/', '../');
    }
  }


  if (window.XMLHttpRequest) {

    xhttp = new XMLHttpRequest();
  } else {
    // code for IE6, IE5
    xhttp = new ActiveXObject("Microsoft.XMLHTTP");
  }

  xhttp.onreadystatechange = function() {

    if (xhttp.readyState === 4 && xhttp.status === 200) {
      vm.data = JSON.parse(xhttp.responseText);
    }
  };
  xhttp.open('GET', path, false);
  xhttp.send();
  return vm.data;
};
