/**
 * Module: generator-jumpstart
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: Yeoman generator for JumpStart - lets you quickly set up a project with defaults and best practices.
 */

'use strict';

// Karma configuration
// http://karma-runner.github.io/0.12/config/configuration-file.html
// Generated on 2015-05-25 using
// generator-karma 1.0.0

module.exports = function(config) {

  config.set({
    // enable / disable watching file and executing tests whenever any file changes
    autoWatch: true,

    // base path, that will be used to resolve files and exclude
    basePath: '../',

    // testing framework to use (jasmine/mocha/qunit/...)
    // as well as any additional frameworks (requirejs/chai/sinon/...)
    frameworks: [
      'jasmine'
    ],

    // list of files / patterns to load in the browser
    files: [{
        pattern: './test/jasmineExt.js',
        included: true
      },
      // bower:js
      './bower_components/angular/angular.js',
      './bower_components/angular-translate/angular-translate.js',
      './bower_components/angular-translate-loader-static-files/angular-translate-loader-static-files.js',
      './bower_components/angular-cookies/angular-cookies.js',
      './bower_components/angular-resource/angular-resource.js',
      './bower_components/angular-sanitize/angular-sanitize.js',
      './bower_components/angular-aria/angular-aria.js',
      './bower_components/ui-router/release/angular-ui-router.js',
      './bower_components/ng-file-upload/ng-file-upload-all.js',
      './bower_components/angular-file-upload/angular-file-upload.js',
      './bower_components/angular-bootstrap/ui-bootstrap-tpls.js',
      './bower_components/angular-ui-grid/ui-grid.js',
      './bower_components/jquery/dist/jquery.min.js',
      './bower_components/angular-bootstrap/ui-bootstrap.js',
      './bower_components/angular-mocks/angular-mocks.js',
      './bower_components/angular-route/angular-route.js',
      './bower_components/ng-csv/src/ng-csv/ng-csv.js',
      // endbower
      //features:js
      {
        pattern: '**/*.json',
        served: true,
        included: false
      },

      './ng-app/app.js',
      './ng-app/components/campaign/list/list-campaigns-module.js',
      './ng-app/components/campaign/edit/edit-campaign-module.js',
      './ng-app/components/campaign/new/new-campaign-module.js',
      './ng-app/components/campaign/list/list-campaigns-controller.js',
      './ng-app/components/campaign/campaign-controller.js',
      './ng-app/components/dashboard/dashboard-module.js',
      './ng-app/components/dashboard/dashboard-controller.js',
      './ng-app/core/classes/campaign.js',
      './ng-app/core/classes/user.js',
      './ng-app/core/lib/utils.js',
      './ng-app/core/classes/ui-state.js',
      './ng-app/master-data-service.js',
      './ng-app/shared/directives/static_include.js',
      './ng-app/shared/values/arrow_menu_labels.js',
      './ng-app/shared/values/dynamic_campaings.js',
      './ng-app/shared/values/version-no.js',
      './ng-app/shared/values/ma_disengagement_values.js',
      './ng-app/shared/values/card_products.js',
      './ng-app/shared/values/email_deployment_vendor.js',
      './ng-app/shared/values/ma_trigger_events.js',
      './ng-app/shared/values/campaign_arbitration_status.js',
      './ng-app/shared/values/campaign_duration_weeks.js',
      './ng-app/shared/values/campaign-fields-to-export.js',
      './ng-app/shared/controllers/ewt-modal-controller.js',
      './ng-app/components/user/user-management-module.js',
      './ng-app/components/user/user-controller.js',
      './ng-app/components/user/new/new-user-module.js',
      './ng-app/components/user/edit/edit-user-module.js',
      './ng-app/components/user/search/search-users-module.js',
      './ng-app/components/user/search/search-users-controller.js',



      // yet to load shared files
      //endfeatures

      //loading tests
      './spec/ng-app/app.spec.js',
      './spec/ng-app/master-data-service.spec.js',
      './test/spec/ng-app/components/campaign/campaign-controller.spec.js',
      './test/spec/ng-app/components/campaign/list/list-campaigns-controller.spec.js',
      './test/spec/ng-app/core/classes/campaign.spec.js',
      './test/spec/ng-app/components/user/user-controller.spec.js',
      './test/spec/ng-app/components/user/user-management-module.spec.js',
      './test/spec/ng-app/components/user/search/search-users-module.spec.js',
      './test/spec/ng-app/components/user/edit/edit-user-module.spec.js',
      './test/spec/ng-app/core/classes/user.spec.js',
      './test/spec/ng-app/core/lib/utils.spec.js',
      './test/spec/ng-app/shared/controllers/ewt-modal-controller.spec.js',

      //loading html files
      './views/**/*.html',
    ],

    // list of files / patterns to exclude
    exclude: [],

    // web server port
    port: 9876,

    // Start these browsers, currently available:
    // - Chrome
    browsers: [
      'Chrome'
    ],

    // reporters
    reporters: ['progress', 'coverage'],
    coverageReporter: {
      type: 'html',
      dir: '../../application/public/reports/'
    },


    // Which plugins to enable
    plugins: [
      'karma-chrome-launcher',
      'karma-jasmine',
      'karma-ng-html2js-preprocessor',
      'karma-coverage'
    ],

    preprocessors: {
      './ng-app/**/*.js': ['coverage'],
      './**/*.html': ['ng-html2js']
    },
    ngHtml2JsPreprocessor: {
      stripPrefix: 'application/public/',
      moduleName: 'templates'
    },


    // Continuous Integration mode
    // if true, it capture browsers, run tests and exit

    colors: true,

    // level of logging
    // possible values: LOG_DISABLE || LOG_ERROR || LOG_WARN || LOG_INFO || LOG_DEBUG
    logLevel: config.LOG_INFO

    // Uncomment the following lines if you are using grunt's server to run the tests
    // proxies: {
    //   '/': 'http://localhost:9000/'
    // },
    // URL root prevent conflicts with the site root
    // urlRoot: '_karma_'
  });
};
