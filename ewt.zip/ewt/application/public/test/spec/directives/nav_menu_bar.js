'use strict';

describe('Navigation Menu bar', function() {
  var element, scope;
  var $compile, $rootScope, $location, template, $location;
  var fakedTemplate = '<nav><ul class="navigation"><li ng-repeat="route in routes" ui-sref-active="active"><a ui-sref="{{route.state}}">{{route.label}}</a></li></ul><nav>';

  beforeEach(module('ewtApp'));
  beforeEach(module('templates'));
  beforeEach(function() {
    var navLabelsMock = [
        {label : "My Dashboard"},
        {label : "Submit a New Campaign"},
        {label : "Campaign History"},
        {label : "Logout"},
      ];

    module(function($provide) {
      $provide.value ('navLabels', navLabelsMock);
    })
  });
  
  beforeEach(inject(function($templateCache, _$compile_, _$rootScope_,_$location_){
    $templateCache.put('ng-app/partials/directives/navigation.html', fakedTemplate);
    $compile = _$compile_;
    $rootScope = _$rootScope_;
    $location = _$location_;
    scope = $rootScope.$new();
    element = angular.element('<div nav-menu-bar></div>');
    $compile(element)(scope);
    scope.$digest();
  }));

  it('routes need to be defined', function() {
    expect(scope.routes).toBeDefined();
    expect(scope.routes).not.toBeNull();
  });

  it('it should create a 4 clikable navigation menu bar', function() {
    var tabs = element.find('a');
    expect(tabs.length).toBe(4);
    expect(tabs.eq(0).text()).toBe('My Dashboard');
    expect(tabs.eq(1).text()).toBe('Submit a New Campaign');
    expect(tabs.eq(2).text()).toBe('Campaign History');
    expect(tabs.eq(3).text()).toBe('Logout');
  });
});