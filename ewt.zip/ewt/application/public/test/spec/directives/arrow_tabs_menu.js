'use strict';

describe('Directive: arrowMenu', function () {

  // load the directive's module
  beforeEach(module('templates'));
  beforeEach(module('ewtApp'));

  var element, $scope, $rootScope, $compile;
  var fakedTemplate = '<nav><ul class="navigation"><li ng-repeat="tab in tabs" ng-class="{active:tab.active, disabled:tab.disabled}" ng-style="{zIndex:(tabs.length-$index)}"><button ng-click="clearTabs();tab.active=true; $event.preventDefault(); $event.stopPropagation();" ng-disabled="tab.disabled">{{tab.label}}</button></li></ul></nav>';
  var tabs = [
      {
        label: 'General',
        id: 'general'
      },
      {
        label: 'Deplyoment',
        id: 'deployment'
      },
      {
        label: 'Personalization',
        id: 'personalization',
        disabled: true
      },
      {
        label: 'Creative',
        id: 'creative',
        disabled: true
      },
      {
        label: 'Attachments',
        id: 'attachments'
      }
    ];

  beforeEach(inject(function ($templateCache ,_$rootScope_, _$compile_) {
    $rootScope = _$rootScope_;
    $compile = _$compile_;
    $scope = $rootScope.$new();
    $templateCache.put('ng-app/partials/directives/arrow-tabs.html',fakedTemplate);
    $scope.tabs = tabs;
    element = angular.element('<div arrow-menu ng-hide="allActive"></div>');
    element = $compile(element)($scope);
    $scope.$digest();
  }));



  it('should generate 5 tabs with buttons', function () {
    var tabs = element.find('button');
    expect(tabs.length).toBe(5);
  });


  it('it should create a 5 clikable arrow menu bar with labels', function() {
    var tabs = element.find('button');
    expect(tabs.eq(0).text()).toBe('General');
    expect(tabs.eq(1).text()).toBe('Deplyoment');
    expect(tabs.eq(2).text()).toBe('Personalization');
    expect(tabs.eq(3).text()).toBe('Creative');
    expect(tabs.eq(4).text()).toBe('Attachments');
  });

  it('should disable 2 tabs with if it is a new campaign and user is not admin', function () {
    expect(angular.element(element.find('li')[2]).hasClass('disabled')).toBeTruthy();    
    expect(angular.element(element.find('li')[3]).hasClass('disabled')).toBeTruthy();    
  });

  it('should disable 2 tabs with if it is a submitted campaign and require admin approval', function () {
    $scope.tabs[2].disabled = $scope.tabs[3].disabled = true;
    expect(angular.element(element.find('li')[2]).hasClass('disabled')).toBeTruthy();    
    expect(angular.element(element.find('li')[3]).hasClass('disabled')).toBeTruthy();    
  });

  it('should enable 5 tabs  if it is a admin and got the campaign for final approval', function () {
    $scope.tabs[2].disabled = $scope.tabs[3].disabled = false;
    $compile(element)($scope);
    expect(angular.element(element.find('li')[2]).hasClass('disabled')).toBeFalsy();    
    expect(angular.element(element.find('li')[3]).hasClass('disabled')).toBeFalsy();  
  });

  it('Directive: clearTabs()', function() {
    $scope.tabs[0].active = true;
    $scope.tabs[1].active = true;
    $scope.tabs[2].active = true;
    $scope.tabs[3].active = true;
    $scope.tabs[4].active = true;
    $scope.clearTabs();
    expect($scope.tabs[0].active).toBeFalsy();
    expect($scope.tabs[1].active).toBeFalsy();
    expect($scope.tabs[2].active).toBeFalsy();
    expect($scope.tabs[3].active).toBeFalsy();
    expect($scope.tabs[4].active).toBeFalsy();
  });

  it('Directive: showAllTabs()', function() {
    $scope.tabs[0].active = false;
    $scope.tabs[1].active = false;
    $scope.tabs[2].active = false;
    $scope.tabs[3].active = false;
    $scope.tabs[4].active = false;
    $scope.showAllTabs();
    expect($scope.tabs[0].active).toBeTruthy();
    expect($scope.tabs[1].active).toBeTruthy();
    expect($scope.tabs[2].active).toBeTruthy();
    expect($scope.tabs[3].active).toBeTruthy();
    expect($scope.tabs[4].active).toBeTruthy();
  });

  it('Directive: selectTab()', function() {
    $scope.tabs[0].active = false;
    $scope.tabs[1].active = false;
    $scope.tabs[2].active = false;
    $scope.tabs[3].active = false;
    $scope.tabs[4].active = false;
    $scope.selectTab(0);
    expect($scope.tabs[0].active).toBeTruthy();
    expect($scope.tabs[1].active).toBeFalsy();
    expect($scope.tabs[2].active).toBeFalsy();
    expect($scope.tabs[3].active).toBeFalsy();
    expect($scope.tabs[4].active).toBeFalsy();
  });

  it('to have class arrow-menu-container', function() {
    expect(angular.element(element).hasClass('arrow-menu-container')).toBeTruthy();
  });
});
