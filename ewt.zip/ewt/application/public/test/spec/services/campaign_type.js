'use strict';

describe('Service: campaignType', function () {

  // load the service's module
  beforeEach(module('ewtApp'));

  // instantiate service
  var campaignType;
  beforeEach(inject(function (_campaignType_) {
    campaignType = _campaignType_;
  }));

  it('should do something', function () {
    expect(!!campaignType).toBe(true);
  });

});
