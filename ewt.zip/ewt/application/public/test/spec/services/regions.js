'use strict';

describe('Service: regions', function () {

  // load the service's module
  beforeEach(module('ewtApp'));

  // instantiate service
  var regions;
  beforeEach(inject(function (_regions_) {
    regions = _regions_;
  }));

  it('should do something', function () {
    expect(!!regions).toBe(true);
  });

});
