'use strict';

describe('Service: emailTypes', function () {

  // load the service's module
  beforeEach(module('ewtApp'));

  // instantiate service
  var emailTypes;
  beforeEach(inject(function (_emailTypes_) {
    emailTypes = _emailTypes_;
  }));

  it('should do something', function () {
    expect(!!emailTypes).toBe(true);
  });

});
