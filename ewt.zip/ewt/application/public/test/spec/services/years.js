'use strict';

describe('Service: years', function () {

  // load the service's module
  beforeEach(module('ewtApp'));

  // instantiate service
  var years;
  beforeEach(inject(function (_years_) {
    years = _years_;
  }));

  it('should do something', function () {
    expect(!!years).toBe(true);
  });

});
