'use strict';

describe('Service: marketingManagerSimpleValue', function () {

  // load the service's module
  beforeEach(module('ewtApp'));

  // instantiate service
  var marketingManagerSimpleValue;
  beforeEach(inject(function (_marketingManagerSimpleValue_) {
    marketingManagerSimpleValue = _marketingManagerSimpleValue_;
  }));

  it('should do something', function () {
    expect(!!marketingManagerSimpleValue).toBe(true);
  });

});
