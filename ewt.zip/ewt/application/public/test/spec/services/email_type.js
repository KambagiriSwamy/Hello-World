'use strict';

describe('Service: emailType', function () {

  // load the service's module
  beforeEach(module('ewtApp'));

  // instantiate service
  var emailType;
  beforeEach(inject(function (_emailType_) {
    emailType = _emailType_;
  }));

  it('should do something', function () {
    expect(!!emailType).toBe(true);
  });

});
