'use strict';

describe('Service: level1Descriptions', function () {

  // load the service's module
  beforeEach(module('ewtApp'));

  // instantiate service
  var level1Descriptions;
  beforeEach(inject(function (_level1Descriptions_) {
    level1Descriptions = _level1Descriptions_;
  }));

  it('should do something', function () {
    expect(!!level1Descriptions).toBe(true);
  });

});
