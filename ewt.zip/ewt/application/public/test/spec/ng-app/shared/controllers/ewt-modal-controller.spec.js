'use strict';

describe('Campaign modal controller :', function() {
  var rootScope, scope, ewtModalController, state, modalInstance,
    filter, resolved, exportFields, ewtUtils;

  var jasmineExt = new JasmineExtn();
  var mockData = jasmineExt.readJSON('base/test/spec/ng-app/components/campaign/list/JSON/mockData.json');

  var mockModalInstance  = {
    close: function (options) {
      return 'called close method with arguments - ' + options;
    },
    dismiss: function (options) {
      return 'called dismiss method with arguments - ' + options;
    },
    opened : {},
    rendered : {},
    result : {}
  };

  var loadewtModalController = function(resoloveObj) {
    return function ($rootScope, $controller, _$state_, _$filter_, _ewtUtils_, _exportFields_) {
      scope = $rootScope.$new();
      ewtUtils = _ewtUtils_;
      state = _$state_;
      modalInstance = mockModalInstance;
      filter = _$filter_;
      resolved = resoloveObj;
      exportFields = _exportFields_;

      var ewtModalController = $controller('ewtModalController', {
        $scope: scope,
        ewtUtils: ewtUtils,
        $state: state,
        $filter: filter,
        resolved: resolved,
        exportFields: exportFields,
        $modalInstance: modalInstance
      });
    }
  }

  // beforeEach(module('ewtApp'));

  describe('Specific to Export modal window', function() {
    // beforeEach(module('ewtApp', function($provide) {
    //   $provide.value('$modalInstance', mockModalInstance);
    // }));
    // 
    var mockResolve = jasmineExt.readJSON('base/test/spec/ng-app/shared/controllers/JSON/mock-export-resolve.json');
    beforeEach(module('ewtApp'));
    beforeEach(module(function($provide) {
      $provide.value('APIServer', mockData.mockApiServer.APIServer);
      $provide.value('initialData', mockData.mockInitLoadString);
      $provide.value('initLoadData', mockData.mockInitLoadData);
    }));
    beforeEach(function(){
      mockResolve.resolve.campaigns.forEach(function (campaign) {
        if (campaign.buDeployment) {
          campaign.buDeployment = new Date(campaign.buDeployment);
        }
        if(campaign.deploymentDates.length>0) {
          campaign.deploymentDates[0] = new Date (campaign.deploymentDates[0]);
        }
      });
    });
    beforeEach(inject(loadewtModalController(mockResolve.resolve)));

    it('should populate scope with appropriate variables and methods for exporting', function () {
      expect(scope.fields).toBeDefined()
    });

    it('Export buttons should be disabled if no field is selected, else enabled', function () {
      expect(scope.atALableIsChecked()).toBeTruthy();
      scope.fields.forEach(function (field) {
        field.checked = false;
      });
      expect(scope.atALableIsChecked()).toBeFalsy();
    });

    it('should check check all checkbox if all the fields are selected', function () {
      scope.fields.forEach(function (field) {
        field.checked = true;
      });
      scope.filterLabels();
      expect(scope.unselectAll).toBeFalsy();
      expect(scope.selectAll).toBeTruthy();
    });

    it('should check uncheck all checkbox if all the fields are unselected', function () {
      scope.fields.forEach(function (field) {
        field.checked = false;
      });
      scope.filterLabels();
      expect(scope.unselectAll).toBeTruthy();
      expect(scope.selectAll).toBeFalsy();
    });

    it('should uncheck check all and uncheck all checkbox if few of the fields are selected', function () {
      scope.filterLabels();
      expect(scope.unselectAll).toBeFalsy();
      expect(scope.selectAll).toBeFalsy();
    });

    it('should check all the fields if check all checkbox is checked', function () {
      var allCheckedState = JSON.parse(JSON.stringify(scope.fields));
      allCheckedState.forEach(function (field) {
        field.checked = true;
      });

      scope.selectAll = true;

      scope.selection('all');
      expect(scope.fields).toEqual(allCheckedState);
    });

    it('should restore back all the fields if check all checkbox is unchecked', function () {
      var length = scope.fields.length, iteration = 0;
      while(iteration < 15) {
        var index = Math.floor((Math.random() * length) + 1);
        scope.fields[index-1].checked = !scope.fields[index-1].checked;
        iteration++;
      }
      var randomFields = JSON.parse(JSON.stringify(scope.fields));

      scope.selectAll = true;
      scope.selection('all');
      scope.selectAll = false;
      scope.selection('all');
      expect(scope.fields).toEqual(randomFields);
    });

    it('should uncheck all the fields if uncheck all checkbox is checked', function () {
      var allUnCheckedState = JSON.parse(JSON.stringify(scope.fields));
      allUnCheckedState.forEach(function (field) {
        field.checked = false;
      });

      scope.unselectAll = true;

      scope.selection('none');
      expect(scope.fields).toEqual(allUnCheckedState);
    });

    it('should restore back all the fields if uncheck all checkbox is unchecked', function () {
      var length = scope.fields.length, iteration = 0;
      while(iteration < 15) {
        var index = Math.floor((Math.random() * length) + 1);
        scope.fields[index-1].checked = !scope.fields[index-1].checked;
        iteration++;
      }
      var randomFields = JSON.parse(JSON.stringify(scope.fields));

      scope.unselectAll = true;
      scope.selection('none');
      scope.unselectAll = false;
      scope.selection('none');
      expect(scope.fields).toEqual(randomFields);
    });


    describe('Exporting the campaign functionailty', function () {
      var exportObj = mockResolve.exported;
      it ('should check if only checked fields are exported', function () {
        /**
         * Iterate through all the fields present and check few of them.
         * Maintain them in temperory stack to check on them later in expect method
         */
        var length = scope.fields.length, iteration = 0, noOfFields = 20, selectedFields = [], expectedExport = [];
        while (iteration < 20) {
          var index = Math.floor((Math.random() * length));
          scope.fields[index].checked = true;
          selectedFields.push(scope.fields[index]);
          iteration++;
        }

        exportObj.forEach(function (campaign) {
          var tempCamp = {};
          console.clear();
          selectedFields.forEach(function(field) {
            tempCamp[field.label] = campaign[field.label];
            console.log(field.label);
          });
          console.log(tempCamp);
          expectedExport.push(tempCamp);
        });

        // console.log(scope.formatCampaignData());
        // console.log(expectedExport);
        // console.log(selectedFields);
        expect(scope.formatCampaignData()).toEqual(expectedExport);
      });
      
      
      
      it('should export all fields', function () {
        scope.fields.forEach(function (field) {
          field.checked = true;
        });

        expect(scope.formatCampaignData()).toEqual(exportObj);
      });

    });
  });


});
