'use strict';

describe(' Test on Search User Management Module ', function() {
  var $rootScope, $state, $location, $httpBackend;
  var jasmineExt = new JasmineExtn();
  var mockData = jasmineExt.readJSON('base/test/spec/ng-app/components/user/JSON/mockData.json');


  beforeEach(module('ewtApp'));
  beforeEach(module(function($provide) {
    $provide.value('APIServer', mockData.mockApiServer);
    $provide.value('initialData', mockData.mockInitLoadString);
    $provide.value('initLoadData', mockData.mockInitLoadData);
  }));
  beforeEach(inject(function(_$rootScope_, _$state_, _$httpBackend_, $templateCache, _$location_) {
    $rootScope = _$rootScope_;
    $state = _$state_;
    $location = _$location_;
    $httpBackend = _$httpBackend_;
  }));
  it(' resolve object should define ewtUsers', function() {
    $state.go('app.auth.users.search');
    $rootScope.$digest();
    expect($state.current.name).toBe('app.auth.users.search');
  });
});
