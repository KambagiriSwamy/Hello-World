'use strict';

describe(' Test on Edit User Management Module ', function() {
  var $state, ewtUsers;
  var jasmineExt = new JasmineExtn();
  var mockData = jasmineExt.readJSON('base/test/spec/ng-app/components/user/JSON/mockData.json');


  beforeEach(module('ewtApp'));
  beforeEach(module(function($provide) {
    $provide.value('APIServer', mockData.mockApiServer);
    $provide.value('initialData', mockData.mockInitLoadString);
    $provide.value('initLoadData', mockData.mockInitLoadData);
  }));
  beforeEach(inject(function(_$state_, _ewtUsers_) {
    $state = _$state_;
    ewtUsers = _ewtUsers_;
  }));
  it(' resolve object should define ewtUsers', function() {
    $state.go('app.auth.users.edit');
    var resolve = $state.get('app.auth.users.edit', {
      'id': '56826365b0af623e0f2e95f4'
    }).resolve.ewtUsers(ewtUsers);
    expect($state.get('app.auth.users.edit', {
      'id': '56826365b0af623e0f2e95f4'
    }).resolve.ewtUsers).toBeDefined();
  });
});
