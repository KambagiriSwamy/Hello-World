'use strict';

describe('Campaign controller which performs operatins for both new and existing campaign', function() {
  var rootScope, scope, ewtMasterDataService, ewtCampaignController, state, ewtUIState,
    arrowMenuLables, dynamicCampaignTypes, versionNos, maDisengamentNos, cardProducts, emailVendors,
    triggerEvents, arbitrationStatus, ewtCampaign;
  var mockApiServer = {
    'APIServer': 'api/v1/'
  };

  var mockAttachmentTypes = {};
  var mockInitLoadData = {
    businessUnits: [{
      '_id': '56137304f23bae527e374ce3',
      'name': 'Global Merchant Services (GMS)',
      'code': 'U007',
      'codeName': 'BU_GMS'
    }, {
      '_id': '56137304f23bae527e374ce4',
      'name': 'GCC',
      'code': 'U006',
      'codeName': 'BU_GCC'
    }, {
      '_id': '56137304f23bae527e374ce5',
      'name': 'OPEN',
      'code': 'U005',
      'codeName': 'BU_OPEN'
    }, {
      '_id': '56137304f23bae527e374ce6',
      'name': 'CCSG',
      'code': 'U004',
      'codeName': 'BU_CCSG'
    }, {
      '_id': '56137304f23bae527e374ce7',
      'name': 'Publishing',
      'code': 'U003',
      'codeName': 'BU_PUBLISHING'
    }, {
      '_id': '56137304f23bae527e374ce8',
      'name': 'GMPI',
      'code': 'U002',
      'codeName': 'BU_GMPI'
    }, {
      "_id": "56137304f23bae527e374ce9",
      "name": "Global Prepaid",
      "code": "U019",
      "codeName": "BU_GLOBAL_PREPAID"
    }, {
      "_id": "56137304f23bae527e374cea",
      "name": "Consumer Travel",
      "code": "U018",
      "codeName": "BU_CONSUMER_TRAVEL"
    }, {
      "_id": "56137304f23bae527e374ceb",
      "name": "AXPi",
      "code": "U017",
      "codeName": "BU_AXPI"
    }, {
      "_id": "56137304f23bae527e374cec",
      "name": "MR",
      "code": "U020",
      "codeName": "BU_MR"
    }, {
      "_id": "56137305f23bae527e374ced",
      "name": "Card Services",
      "code": "U021",
      "codeName": "BU_CARD_SERVICES"
    }, {
      "_id": "56137305f23bae527e374cee",
      "name": "Direct Deposits",
      "code": "U022",
      "codeName": "BU_DIRECT_DEPOSITS"
    }, {
      "_id": "56137305f23bae527e374cef",
      "name": "Enterprise Growth Group (EGG)",
      "code": "U023",
      "codeName": "BU_EGG"
    }, {
      "_id": "56137305f23bae527e374cf0",
      "name": "Digital Partnerships & Development (DPD)",
      "code": "U024",
      "codeName": "BU_DPD"
    }],
    "campaignTypes": [{
      "_id": "56137305f23bae527e374cf1",
      "name": "Card Acquisition",
      "code": "008",
      "codeName": "CT_CARD_ACQUISITION"
    }, {
      "_id": "56137305f23bae527e374cf2",
      "name": "Balance Transfer",
      "code": "024",
      "codeName": "CT_BALANCE_TRANSFER"
    }, {
      "_id": "56137305f23bae527e374cf3",
      "name": "Card Services",
      "code": "026",
      "codeName": "CT_CARD_SERVICES"
    }, {
      "_id": "56137305f23bae527e374cf4",
      "name": "CTN",
      "code": "038",
      "codeName": "CT_CTN"
    }, {
      "_id": "56137305f23bae527e374cf5",
      "name": "LOC",
      "code": "041",
      "codeName": "CT_LOC"
    }, {
      "_id": "56137305f23bae527e374cf6",
      "name": "Loyalty",
      "code": "043",
      "codeName": "CT_LOYALTY"
    }, {
      "_id": "56137305f23bae527e374cf7",
      "name": "Self Servicing",
      "code": "048",
      "codeName": "CT_SELF_SERVICING"
    }, {
      "_id": "56137305f23bae527e374cf8",
      "name": "Spend",
      "code": "057",
      "codeName": "CT_SPEND"
    }, {
      "_id": "56137305f23bae527e374cf9",
      "name": "Publishing",
      "code": "060",
      "codeName": "CT_PUBLISHING"
    }, {
      "_id": "56137305f23bae527e374cfa",
      "name": "Market Research",
      "code": "062",
      "codeName": "CT_MARKET_RESEARCH"
    }],
    "cellTypes": [{
      "_id": "56137306f23bae527e374d68",
      "code": "T",
      "codeName": "test",
      "name": "Mailable (Test)"
    }, {
      "_id": "56137306f23bae527e374d69",
      "code": "C",
      "codeName": "control",
      "name": "Holdout (Control)"
    }],
    "marketingManagers": [{
      "_id": "56137306f23bae527e374d58",
      "value": "cseba1",
      "phone": "212-640-5091",
      "email": "Cassandra.J.SebastianPernia@aexp.com",
      "name": "Cassandra J SebastianPernia",
      "role": {
        "name": "manager",
        "codeName": "mm",
        "code": "001"
      }
    }, {
      "_id": "56137306f23bae527e374d59",
      "value": "avargh3",
      "phone": "212-624-9842",
      "email": "alfred.t.varghese@aexp.com",
      "name": "Alfred T arghese",
      "role": {
        "name": "manager",
        "codeName": "mm",
        "code": "001"
      }
    }, {
      "_id": "56137306f23bae527e374d5a",
      "value": "jaortiz",
      "phone": "212-640-7898",
      "email": "Jessica.A.Ortiz@aexp.com",
      "name": "Jessica A Ortiz",
      "role": {
        "name": "manager",
        "codeName": "mm",
        "code": "001"
      }
    }, {
      "_id": "56137306f23bae527e374d5b",
      "value": "knapoli",
      "phone": "212-640-5004",
      "email": "Kayla.Napoli@aexp.com",
      "name": "Kayla Napoli",
      "role": {
        "name": "manager",
        "codeName": "mm",
        "code": "001"
      }
    }, {
      "_id": "56137306f23bae527e374d5c",
      "value": "azelenet",
      "phone": "212-640-3301",
      "email": "Andrea.L.Zelenetz1@aexp.com",
      "name": "Andrea L Zelenetz",
      "role": {
        "name": "manager",
        "codeName": "mm",
        "code": "001"
      }
    }, {
      "_id": "56137306f23bae527e374d5d",
      "value": "sguggino",
      "phone": "505-239-6368",
      "email": "Sarah.E.Guggino@aexp.com",
      "name": "Sarah E Guggino@aexp.com",
      "role": {
        "name": "manager",
        "codeName": "mm",
        "code": "001"
      }
    }, {
      "_id": "56137306f23bae527e374d5e",
      "value": "mjones32",
      "phone": "602-537-8954",
      "email": "matthew.r.jones@aexp.com",
      "name": "Matthew R Jones",
      "role": {
        "name": "manager",
        "codeName": "mm",
        "code": "001"
      }
    }, {
      "_id": "56137306f23bae527e374d5f",
      "value": "cblan3",
      "phone": "602-537-8954",
      "email": "CLARISSA.BLANCO@aexp.com",
      "name": "CLARISSA BLANCO",
      "role": {
        "name": "manager",
        "codeName": "mm",
        "code": "001"
      }
    }, {
      "_id": "56137306f23bae527e374d63",
      "value": "nvishw",
      "phone": "312-624-9864",
      "email": "Nagabhushan.a.andrew1@aexp.com",
      "name": "Nagabhushan B Vishwanath",
      "role": {
        "name": "manager",
        "codeName": "mm",
        "code": "001"
      }
    }, {
      "_id": "56137306f23bae527e374d64",
      "value": "nvishw",
      "phone": "312-624-9864",
      "email": "Nagabhushan.a.andrew1@aexp.com",
      "name": "Nagabhushan B Vishwanath",
      "role": {
        "name": "manager",
        "codeName": "mm",
        "code": "001"
      }
    }, {
      "_id": "56137306f23bae527e374d65",
      "value": "nvishw",
      "phone": "312-624-9864",
      "email": "Nagabhushan.a.andrew1@aexp.com",
      "name": "Nagabhushan B Vishwanath",
      "role": {
        "name": "manager",
        "codeName": "mm",
        "code": "001"
      }
    }, {
      "_id": "56137306f23bae527e374d66",
      "uid": "randrew",
      "value": "randrew",
      "phone": "212-624-9822",
      "email": "roopa.a.andrew1@aexp.com",
      "name": "Roopa Andrew",
      "role": {
        "name": "manager",
        "codeName": "mm",
        "code": "001"
      }
    }],
    "emailTypes": [{
      "_id": "56137304f23bae527e374ce1",
      "code": "012",
      "name": "Servicing",
      "codeName": "ET_SERVICING"
    }, {
      "_id": "56137304f23bae527e374ce2",
      "code": "008",
      "name": "Marketing Automation",
      "codeName": "ET_MA"
    }],
    "loggedInUser": {
      "_id": "56137306f23bae527e374d66",
      "uid": "randrew",
      "value": "randrew",
      "phone": "212-624-9822",
      "email": "roopa.a.andrew1@aexp.com",
      "name": " Roopa Andrew",
      "role": {
        "name": "manager",
        "codeName": "mm",
        "code": "001"
      },
      "leader": {
        "firstName": "Dummy",
        "lastName": "leader",
        "email": "leader@aexp.com"
      }
    }
  };


  var campaignMockData = {
    newMockCampaign: {
      "state": {
        "codeName": "draft"
      },
      "requestor": {
        "_id": "56137306f23bae527e374d66",
        "uid": "randrew",
        "value": "randrew",
        "phone": "212-624-9822",
        "email": "roopa.a.andrew1@aexp.com",
        "name": " Roopa Andrew",
        "role": {
          "name": "manager",
          "codeName": "mm",
          "code": "001"
        },
        "leader": {
          "firstName": "Dummy",
          "lastName": "leader",
          "email": "leader@aexp.com"
        }
      },
      "requestorPrimary": {
        "_id": "56137306f23bae527e374d66",
        "uid": "randrew",
        "value": "randrew",
        "phone": "212-624-9822",
        "email": "roopa.a.andrew1@aexp.com",
        "name": " Roopa Andrew",
        "role": {
          "name": "manager",
          "codeName": "mm",
          "code": "001"
        },
        "leader": {
          "firstName": "Dummy",
          "lastName": "leader",
          "email": "leader@aexp.com"
        }
      },
      "isSTO": "true",
      "isMultiCMNeedCategory": "false",
      "mhids": [],
      'arbitrationStatus': {},
      "pznVariables": [],
      "dynamicCampaigns": [],
      "requestID": "Pending",
      "creativeMockup": {},
      "businessUnit": {},
      "emailType": {},
      "type": {},
      "isDynamicCampaign": "false",
      "cmNeedCategories": [],
      "primaryMarketingManager": {
        "_id": "56137306f23bae527e374d66",
        "uid": "randrew",
        "value": "randrew",
        "phone": "212-624-9822",
        "email": "roopa.a.andrew1@aexp.com",
        "name": " Roopa Andrew",
        "role": {
          "name": "manager",
          "codeName": "mm",
          "code": "001"
        },
        "leader": {
          "firstName": "Dummy",
          "lastName": "leader",
          "email": "leader@aexp.com"
        }
      },
      "secondaryMarketingManager": {},
      "subType": {},
      "comments": [],
      "cardProducts": [{
        "code": "x001",
        "name": "Consumer Premium"
      }, {
        "code": "x002",
        "name": "Consumer CoBrand"
      }, {
        "code": "x003",
        "name": "Consumer Lending"
      }, {
        "code": "x004",
        "name": "Consumer Charge"
      }, {
        "code": "x005",
        "name": "OPEN Premium"
      }, {
        "code": "x006",
        "name": "OPEN CoBrand"
      }, {
        "code": "x007",
        "name": "OPEN Lending"
      }, {
        "code": "x008",
        "name": "OPEN Charge"
      }],
      "deploymentDates": [],
      "cmNeed": {
        "selected": [],
        "available": []
      },
      "durationInWeeks": 1
    },
    approvedMockCampaign: {
      "_id": "5629e638efc1e6e81f2e17e1",
      "requestID": 282,
      "durationInWeeks": 1,
      "ma": {
        "approvalDocuments": [],
        "instructionDocuments": [],
        "maVersions": []
      },
      "espInstructions": "",
      "triggerRest": 12,
      "volumeCap": 0,
      "conversionData": "sd fasdfsdfas",
      "description": "sadf asdfas dfffffffffffffffffffffffffffffffffffffffffffffffffff",
      "budgetLine": "sdf asd",
      "isDynamicCampaign": false,
      "isMultiCMNeedCategory": false,
      "businessUnit": {
        "_id": "56137304f23bae527e374ce4",
        "name": "GCC",
        "code": "U006",
        "codeName": "BU_GCC"
      },
      "emailType": {
        "_id": "56137304f23bae527e374ce1",
        "code": "012",
        "name": "Servicing",
        "codeName": "ET_SERVICING"
      },
      "primaryMarketingManager": {
        "_id": "56137306f23bae527e374d66",
        "uid": "randrew",
        "value": "randrew",
        "phone": "212-624-9822",
        "email": "roopa.a.andrew1@aexp.com",
        "name": " Roopa Andrew",
        "role": {
          "name": "manager",
          "codeName": "mm",
          "code": "001"
        }
      },
      "requestor": {
        "_id": "56137306f23bae527e374d66",
        "uid": "randrew",
        "value": "randrew",
        "phone": "212-624-9822",
        "email": "roopa.a.andrew1@aexp.com",
        "name": " Roopa Andrew",
        "role": {
          "name": "manager",
          "codeName": "mm",
          "code": "001"
        },
        "leader": {
          "firstName": "Dummy",
          "lastName": "leader",
          "email": "leader@aexp.com"
        }
      },
      "name": "sa f",
      "state": {
        "logDisplayName": "Request Approved",
        "name": "Request Approved",
        "codeName": "approved",
        "code": "RIA",
        "_id": "56137305f23bae527e374d32"
      },
      "__v": 1,
      "creativeMockup": {
        "_id": "5629e638efc1e6e81f2e17e5",
        "size": "13874",
        "extension": ".xlsx",
        "fileName": "EWT_mappings.xlsx",
        "creativeVersion": 0,
        "gfsID": "5629e638efc1e6e81f2e17e3",
        "type": {
          "emailTypeCodes": ["012", "008"],
          "name": "Initial Draft",
          "codeName": "attachment_mock",
          "code": "001",
          "_id": "560b7e6a7981e574e17b3aa6"
        }
      },
      "arbitration": {
        "code": "Y",
        "codeName": "nonArbitrated",
        "name": "Non Arbitrated"
      },
      "esp": {
        "code": "E"
      },
      "criticalDataUpdates": {
        "DEPLOYMENTDATES": false,
        "CELLS": false,
        "VERSIONS": false,
        "MHID": false
      },
      "isSubmittedToESP": false,
      "espLoadDetails": [],
      "attachments": [],
      "subjectLines": [],
      "versions": [],
      "pznFields": [],
      "deployEmailList": [],
      "previewEmailList": [],
      "mailHistory": [],
      "comments": [],
      "deploymentDates": ["2025-10-29T18:30:00.000Z"],
      "log": [{
        "_id": "5629e638efc1e6e81f2e17e2",
        "timestamp": "2025-10-23T07:48:08.532Z",
        "content": "Pending Initial Approval"
      }, {
        "_id": "5629fc8a2d207d482053cdb7",
        "timestamp": "2025-10-23T09:23:22.471Z",
        "content": "Request Approved"
      }],
      "cardProducts": [{
        "code": "x001",
        "name": "Consumer Premium"
      }, {
        "code": "x005",
        "name": "OPEN Premium"
      }],
      "dynamicCampaigns": [],
      "cmNeedCategories": []
    },
    approvedMockServicingCampaign: {
      "_id": "5629e638efc1e6e81f2e17e1",
      "requestID": 282,
      "durationInWeeks": 1,
      "ma": {
        "approvalDocuments": [],
        "instructionDocuments": [],
        "maVersions": []
      },
      "espInstructions": "",
      "triggerRest": 12,
      "volumeCap": 0,
      "conversionData": "sd fasdfsdfas",
      "description": "sadf asdfas dfffffffffffffffffffffffffffffffffffffffffffffffffff",
      "budgetLine": "sdf asd",
      "isDynamicCampaign": false,
      "isMultiCMNeedCategory": false,
      "businessUnit": {
        "_id": "56137304f23bae527e374ce4",
        "name": "GCC",
        "code": "U006",
        "codeName": "BU_GCC"
      },
      "emailType": {
        "_id": "56137304f23bae527e374ce1",
        "code": "012",
        "name": "Servicing",
        "codeName": "ET_SERVICING"
      },
      "primaryMarketingManager": {
        "_id": "56137306f23bae527e374d66",
        "uid": "randrew",
        "value": "randrew",
        "phone": "212-624-9822",
        "email": "roopa.a.andrew1@aexp.com",
        "name": " Roopa Andrew",
        "role": {
          "name": "manager",
          "codeName": "mm",
          "code": "001"
        }
      },
      "requestor": {
        "_id": "56137306f23bae527e374d66",
        "uid": "randrew",
        "value": "randrew",
        "phone": "212-624-9822",
        "email": "roopa.a.andrew1@aexp.com",
        "name": " Roopa Andrew",
        "role": {
          "name": "manager",
          "codeName": "mm",
          "code": "001"
        },
        "leader": {
          "firstName": "Dummy",
          "lastName": "leader",
          "email": "leader@aexp.com"
        }
      },
      "name": "sa f",
      "state": {
        "logDisplayName": "Request Approved",
        "name": "Request Approved",
        "codeName": "approved",
        "code": "RIA",
        "_id": "56137305f23bae527e374d32"
      },
      "__v": 1,
      "creativeMockup": {
        "_id": "5629e638efc1e6e81f2e17e5",
        "size": "13874",
        "extension": ".xlsx",
        "fileName": "EWT_mappings.xlsx",
        "creativeVersion": 0,
        "gfsID": "5629e638efc1e6e81f2e17e3",
        "type": {
          "emailTypeCodes": ["012", "008"],
          "name": "Initial Draft",
          "codeName": "attachment_mock",
          "code": "001",
          "_id": "560b7e6a7981e574e17b3aa6"
        }
      },
      "arbitration": {
        "code": "Y",
        "codeName": "nonArbitrated",
        "name": "Non Arbitrated"
      },
      "esp": {
        "code": "E"
      },
      "criticalDataUpdates": {
        "DEPLOYMENTDATES": false,
        "CELLS": false,
        "VERSIONS": false,
        "MHID": false
      },
      "isSubmittedToESP": false,
      "espLoadDetails": [],
      "attachments": [],
      "subjectLines": [],
      "versions": [],
      "pznFields": [],
      "deployEmailList": [],
      "previewEmailList": [],
      "mailHistory": [],
      "comments": [],
      "deploymentDates": ["2025-10-29T18:30:00.000Z"],
      "log": [{
        "_id": "5629e638efc1e6e81f2e17e2",
        "timestamp": "2025-10-23T07:48:08.532Z",
        "content": "Pending Initial Approval"
      }, {
        "_id": "5629fc8a2d207d482053cdb7",
        "timestamp": "2025-10-23T09:23:22.471Z",
        "content": "Request Approved"
      }],
      "cardProducts": [{
        "code": "x001",
        "name": "Consumer Premium"
      }, {
        "code": "x005",
        "name": "OPEN Premium"
      }],
      "dynamicCampaigns": [],
      "cmNeedCategories": []
    },
    approvedMockMACampaign: {
      "_id": "5629dde6cf3ab2941dcc6d29",
      "requestID": 278,
      "durationInWeeks": 1,
      "ma": {
        "approvalDocuments": [],
        "instructionDocuments": [],
        "maVersions": [],
        "maCells": []
      },
      "espInstructions": "",
      "triggerRest": 12,
      "volumeCap": 0,
      "conversionData": "sdf asdfsd",
      "description": "sdf asdfsdsdf asdfsdsdf asdfsdsdf asdfsdsdf asdfsdsdf asdfsdsdf asdfsdsdf asdfsdsdf asdfsdsdf asdfsdsdf asdfsdsdf asdfsdsdf asdfsd",
      "budgetLine": "fasdddddddddddd",
      "isDynamicCampaign": false,
      "isMultiCMNeedCategory": false,
      "primaryMarketingManager": {
        "_id": "56137306f23bae527e374d66",
        "uid": "randrew",
        "value": "randrew",
        "phone": "212-624-9822",
        "email": "roopa.a.andrew1@aexp.com",
        "name": " Roopa Andrew",
        "role": {
          "name": "manager",
          "codeName": "mm",
          "code": "001"
        }
      },
      "requestor": {
        "_id": "56137306f23bae527e374d66",
        "uid": "randrew",
        "value": "randrew",
        "phone": "212-624-9822",
        "email": "roopa.a.andrew1@aexp.com",
        "name": " Roopa Andrew",
        "role": {
          "name": "manager",
          "codeName": "mm",
          "code": "001"
        },
        "leader": {
          "firstName": "Dummy",
          "lastName": "leader",
          "email": "leader@aexp.com"
        }
      },
      "name": "sdf asdfsd",
      "state": {
        "logDisplayName": "Request Approved",
        "name": "Request Approved",
        "codeName": "approved",
        "code": "RIA",
        "_id": "56137305f23bae527e374d32"
      },
      "__v": 4,
      "creativeMockup": {
        "_id": "5629fcd771098e781e5793a4",
        "size": "81430",
        "extension": ".pdf",
        "fileName": "Payslip.pdf",
        "creativeVersion": 0,
        "gfsID": "5629fcd771098e781e5793a2",
        "type": {
          "emailTypeCodes": ["012", "008"],
          "name": "Initial Draft",
          "codeName": "attachment_mock",
          "code": "001",
          "_id": "560b7e6a7981e574e17b3aa6"
        }
      },
      "arbitration": {
        "code": "N",
        "codeName": "nonArbitrated",
        "name": "Non Arbitrated"
      },
      "businessUnit": {
        "_id": "56137305f23bae527e374cee",
        "name": "Direct Deposits",
        "code": "U022",
        "codeName": "BU_DIRECT_DEPOSITS"
      },
      "emailType": {
        "_id": "56137304f23bae527e374ce2",
        "code": "008",
        "name": "Marketing Automation",
        "codeName": "ET_MA"
      },
      "esp": {
        "code": "E"
      },
      "criticalDataUpdates": {
        "DEPLOYMENTDATES": false,
        "CELLS": false,
        "VERSIONS": false,
        "MHID": false
      },
      "isSubmittedToESP": false,
      "espLoadDetails": [],
      "attachments": [],
      "subjectLines": [],
      "versions": [],
      "pznFields": [],
      "deployEmailList": [],
      "previewEmailList": [],
      "mailHistory": [{
        "startDate": "2025-11-18T18:30:00.000Z",
        "mhid": "dsfafasd"
      }, {
        "startDate": "2025-11-05T18:30:00.000Z",
        "mhid": "sadfasdf"
      }],
      "comments": [],
      "deploymentDates": ["2025-11-05T18:30:00.000Z"],
      "log": [{
        "_id": "5629dde6cf3ab2941dcc6d2a",
        "timestamp": "2025-10-23T07:12:38.702Z",
        "content": "Initiated"
      }, {
        "_id": "5629fce171098e781e5793a5",
        "timestamp": "2025-10-23T09:24:49.415Z",
        "content": "Pending Initial Approval"
      }, {
        "_id": "5629fcfcdbc196cc21c1d469",
        "timestamp": "2025-10-23T09:25:16.515Z",
        "content": "Request Approved"
      }],
      "cardProducts": [{
        "name": "Consumer Premium",
        "code": "x001"
      }, {
        "name": "OPEN Premium",
        "code": "x005"
      }],
      "dynamicCampaigns": [],
      "cmNeedCategories": [{
        "name": "Other banking products",
        "businessUnitCode": "U022",
        "granularOptOutCode": "MKFINS",
        "code": "CMNC07",
        "_id": "56137307f23bae527e374d8d"
      }]
    },
  }

  /**
   * @ Spy Functions 
   */

  var mock_campaignForm = {
    personalizationSection: {
      newMHIDForm: {
        $setUntouched: function() {
          return true;
        }

      }
    },
    creativeSection: {
      $setUntouched: function() {
        return true;
      }
    },
    $ditry: false
  }
  var mock_mhid_with_less_than_StartDate = {
    'mhid': 'SFDSADFA',
    'startDate': '2000-01-02T13:46:05.365Z',
    'incomplete': false,
    'cell': {
      'srcCode': 'CELL1',
      'description': 'test',
      'type': {
        'code': 'T',
        'codeName': 'test',
        'name': 'Mailable (Test)'
      },
      'isLinkedToMHID': true,
      'removeAlternative': 'Cannot remove as linked to a MHID',
      'editAleternative': 'Cannot edit as linked to a MHID'
    },
  };
  var loadewtCampaignController = function(campaignData) {
    return function($rootScope, $controller, _ewtMasterDataService_, _ewtUIState_, _$state_,
      _arrowMenuLables_, _dynamicCampaignTypes_, _versionNos_, _maDisengamentNos_, _cardProducts_,
      _emailVendors_, _triggerEvents_, _arbitrationStatus_, _ewtCampaign_) {
      rootScope = $rootScope;
      ewtCampaign = new _ewtCampaign_(campaignData);
      scope = $rootScope.$new();
      ewtMasterDataService = _ewtMasterDataService_;
      ewtUIState = _ewtUIState_;
      state = _$state_;
      dynamicCampaignTypes = _dynamicCampaignTypes_;
      arrowMenuLables = _arrowMenuLables_;
      versionNos = _versionNos_;
      maDisengamentNos = _maDisengamentNos_;
      cardProducts = _cardProducts_;
      emailVendors = _emailVendors_;
      triggerEvents = _triggerEvents_;
      arbitrationStatus = _arbitrationStatus_;
      ewtCampaignController = $controller('ewtCampaignController', {
        $scope: scope,
        $rootScope: rootScope,
        ewtMasterDataService: ewtMasterDataService,
        ewtUIState: ewtUIState,
        dynamicCampaignTypes: dynamicCampaignTypes,
        versionNos: versionNos,
        maDisengamentNos: maDisengamentNos,
        campaign: ewtCampaign,
        cardProducts: cardProducts,
        emailVendors: emailVendors,
        triggerEvents: triggerEvents,
        arbitrationStatus: arbitrationStatus,
        attachmentTypes: mockAttachmentTypes,
        $state: state
      });
    }
  }
  var mock_valid_mhid = {
    mhid: 'test1234'
  };
  var mock_invalid_mhid = {
    mhid: 'test'
  };
  var mock_creative_file = {
    "type": {
      "_id": "560b7e6a7981e574e17b3aa6",
      "code": "001",
      "codeName": "attachment_mock",
      "name": "Initial Draft",
      "emailTypeCodes": ["012", "008"]
    },
    "gfsID": "5661a47e8bc69e40214a7184",
    "creativeVersion": 0,
    "name": "test.png",
    "extension": ".png",
    "size": "0",
    "_id": "5661a47e8bc69e40214a7186"
  };
  var mock_mhid_differntFromParent = {
    'mhid': '63477777',
    'startDate': '2025-11-19T18:30:00.000Z',
    'cell': {
      'editAleternative': 'Cannot edit as linked to a MHID',
      'removeAlternative': 'Cannot remove as linked to a MHID',
      'isLinkedToMHID': true,
      'type': {
        'name': 'Holdout (Control)',
        'codeName': 'control',
        'code': 'C',
      },
      'description': 'sdf',
      'srcCode': '23'
    },
    'editing': true,
    'edit': {
      'mhid': '63478888',
      'startDate': '2025-11-19T18:30:00.000Z',
      'cell': {
        'editAleternative': 'Cannot edit as linked to a MHID',
        'removeAlternative': 'Cannot remove as linked to a MHID',
        'isLinkedToMHID': true,
        'type': {
          'name': 'Holdout (Control)',
          'codeName': 'control',
          'code': 'C',
        },
        'description': 'sdf',
        'srcCode': '23'
      },
      'cellError': true,
      'isnewMHIDValid': {
        'status': false,
        'message': 'New MHID'
      }
    }
  };
  var mock_mhid_SameAsParent = {
    'mhid': '63477777',
    'startDate': '2025-11-19T18:30:00.000Z',
    'cell': {
      'editAleternative': 'Cannot edit as linked to a MHID',
      'removeAlternative': 'Cannot remove as linked to a MHID',
      'isLinkedToMHID': true,
      'type': {
        'name': 'Holdout (Control)',
        'codeName': 'control',
        'code': 'C',
      },
      'description': 'sdf',
      'srcCode': '23'
    },
    'editing': true,
    'edit': {
      'mhid': '63477777',
      'startDate': '2025-11-19T18:30:00.000Z',
      'cell': {
        'editAleternative': 'Cannot edit as linked to a MHID',
        'removeAlternative': 'Cannot remove as linked to a MHID',
        'isLinkedToMHID': true,
        'type': {
          'name': 'Holdout (Control)',
          'codeName': 'control',
          'code': 'C',
        },
        'description': 'sdf',
        'srcCode': '23'
      },
      'cellError': true,
      'isnewMHIDValid': {
        'status': false,
        'message': 'New MHID'
      }
    }
  };
  var mock_trigger_events = [{
    'name': 'Email Driven',
    'codeName': 'EMAIL_DRIVEN'
  }, {
    'name': 'Integration Driven',
    'codeName': 'INTEGRATION_DRIVEN'
  }];
  var mock_pzn_reserved = {
    "code": "CMCardProduct",
    "codeName": "cmCardProd",
    "name": "CM Card Product",
    "description": "CM Card Product",
    "reserved": true,
  };
  var mock_pzn_unreserved = {
    "code": "pzn11",
    "codeName": "pzn11",
    "name": "PZN 11",
    "reserved": false,
  };
  var mock_pzn_selected = [{
    'code': 'CMFirstName',
    'codeName': 'cmFirst',
    'name': 'CM First Name',
    'description': 'CM First Name',
    'reserved': true
  }, {
    'code': 'CMMemberSinceDate',
    'codeName': 'cmMember',
    'name': 'CM Member Since Date',
    'description': 'CM Member Since Date',
    'reserved': true
  }, {
    'code': 'CMCardProduct',
    'codeName': 'cmCardProd',
    'name': 'CM Card Product',
    'description': 'CM Card Product',
    'reserved': true
  }, {
    'code': 'DCEReserved1',
    'codeName': 'dceRese1',
    'name': 'DCE Reserved 1',
    'description': 'DCE Reserved',
    'reserved': true
  }, {
    'code': 'DCEReserved2',
    'codeName': 'dceRese2',
    'name': 'DCE Reserved 2',
    'description': 'DCE Reserved',
    'reserved': true
  }, {
    'code': 'pzn1',
    'codeName': 'pzn1',
    'name': 'PZN 1',
    'description': 'Test',
    'reserved': false
  }, {
    'code': 'pzn2',
    'codeName': 'pzn2',
    'name': 'PZN 2',
    'description': 'Test 2',
    'reserved': false
  }];
  var mock_mailHistory = [{
    'mhid': 'SFDSADFA',
    'startDate': '2026-01-02T13:46:05.365Z',
    'cell': {
      'srcCode': 'CELL1',
      'description': 'test',
      'type': {
        'code': 'T',
        'codeName': 'test',
        'name': 'Mailable (Test)'
      },
      'isLinkedToMHID': true,
      'removeAlternative': 'Cannot remove as linked to a MHID',
      'editAleternative': 'Cannot edit as linked to a MHID'
    },
  }, {
    'mhid': 'SFDSADFA',
    'startDate': '2026-01-02T13:46:05.365Z',
    'cell': {
      'srcCode': 'CELL3',
      'description': 'test',
      'type': {
        'code': 'C',
        'codeName': 'control',
        'name': 'Holdout (Control)'
      }
    },
  }, {
    'mhid': 'SDFSAAAA',
    'startDate': '2025-12-16T11:20:28.122Z',
    'cell': {
      'srcCode': 'CELL1',
      'description': 'test',
      'type': {
        'code': 'T',
        'codeName': 'test',
        'name': 'Mailable (Test)'
      },
      'isLinkedToMHID': true,
      'removeAlternative': 'Cannot remove as linked to a MHID',
      'editAleternative': 'Cannot edit as linked to a MHID'
    },
  }, {
    'mhid': 'SDFSAAAA',
    'startDate': '2025-12-16T11:20:28.122Z',
    'cell': {
      'srcCode': 'CELL2',
      'description': 'test',
      'type': {
        'code': 'C',
        'codeName': 'control',
        'name': 'Holdout (Control)'
      }
    },
  }, {
    'mhid': 'SDFSAAAA',
    'startDate': '2025-12-16T11:20:28.122Z',
    'cell': {
      'srcCode': 'CELL3',
      'description': 'test',
      'type': {
        'code': 'C',
        'codeName': 'control',
        'name': 'Holdout (Control)'
      },
      'isLinkedToMHID': true,
      'removeAlternative': 'Cannot remove as linked to a MHID',
      'editAleternative': 'Cannot edit as linked to a MHID'
    },
  }, {
    'mhid': 'YYYYYYYY',
    'startDate': '2025-12-17T11:22:53.373Z',
    'cell': {
      'srcCode': 'CELL1',
      'description': 'test',
      'type': {
        'code': 'T',
        'codeName': 'test',
        'name': 'Mailable (Test)'
      },
      'isLinkedToMHID': true,
      'removeAlternative': 'Cannot remove as linked to a MHID',
      'editAleternative': 'Cannot edit as linked to a MHID'
    },
  }, {
    'mhid': 'YYYYYYYY',
    'startDate': '2025-12-17T11:22:53.373Z',
    'cell': {
      'srcCode': 'CELL2',
      'description': 'test',
      'type': {
        'code': 'C',
        'codeName': 'control',
        'name': 'Holdout (Control)'
      },
      'isLinkedToMHID': true,
      'removeAlternative': 'Cannot remove as linked to a MHID',
      'editAleternative': 'Cannot edit as linked to a MHID'
    },
  }, {
    'mhid': 'YYYYYYYY',
    'startDate': '2025-12-17T11:22:53.373Z',
    'cell': {
      'editAleternative': 'Cannot edit as linked to a MHID',
      'removeAlternative': 'Cannot remove as linked to a MHID',
      'isLinkedToMHID': true,
      'type': {
        'name': 'Holdout (Control)',
        'codeName': 'control',
        'code': 'C',
      },
      'description': 'test',
      'srcCode': 'CELL3'
    },
  }, {
    'mhid': 'YYYYYYYY',
    'startDate': '2025-12-17T11:22:53.373Z',
    'cell': {
      'editAleternative': 'Cannot edit as linked to a MHID',
      'removeAlternative': 'Cannot remove as linked to a MHID',
      'isLinkedToMHID': true,
      'type': {
        'name': 'Holdout (Control)',
        'codeName': 'control',
        'code': 'C',
      },
      'description': 'test',
      'srcCode': 'CELL3'
    },
  }, {
    'mhid': 'SDFAAAAA',
    'startDate': '2025-12-12T13:46:43.133Z',
    'cell': {
      'editAleternative': 'Cannot edit as linked to a MHID',
      'removeAlternative': 'Cannot remove as linked to a MHID',
      'isLinkedToMHID': true,
      'type': {
        'name': 'Mailable (Test)',
        'codeName': 'test',
        'code': 'T',
      },
      'description': 'test',
      'srcCode': 'CELL1'
    },
  }, {
    'mhid': 'SDFAAAAA',
    'startDate': '2025-12-12T13:46:43.133Z',
    'cell': {
      'editAleternative': 'Cannot edit as linked to a MHID',
      'removeAlternative': 'Cannot remove as linked to a MHID',
      'isLinkedToMHID': true,
      'type': {
        'name': 'Holdout (Control)',
        'codeName': 'control',
        'code': 'C',
      },
      'description': 'test',
      'srcCode': 'CELL2'
    },
  }, {
    'mhid': 'SDFAAAAA',
    'startDate': '2025-12-12T13:46:43.133Z',
    'cell': {
      'srcCode': 'CELL3',
      'description': 'test',
      'type': {
        'code': 'C',
        'codeName': 'control',
        'name': 'Holdout (Control)'
      },
      'isLinkedToMHID': true,
      'removeAlternative': 'Cannot remove as linked to a MHID',
      'editAleternative': 'Cannot edit as linked to a MHID'
    },
  }]
  var mock_event = jasmine.createSpyObj('event', ['preventDefault', 'stopPropagation']);
  var getToday = function() {
    return new Date((new Date()).getTime() + (24 * 60 * 60 * 1000));
  }

  beforeEach(module('ewtApp'));
  beforeEach(module('ewtApp', function($provide) {
    $provide.value('APIServer', mockApiServer);
    $provide.value('initLoadData', mockInitLoadData);
    $provide.value('initialData', "{&quot;campaignTypes&quot;:[{&quot;_id&quot;:&quot;5677cfa3ef05740bc688015b&quot;,&quot;name&quot;:&quot;Card Acquisition&quot;,&quot;code&quot;:&quot;008&quot;,&quot;codeName&quot;:&quot;CT_CARD_ACQUISITION&quot;},{&quot;_id&quot;:&quot;5677cfa3ef05740bc688015c&quot;,&quot;name&quot;:&quot;Balance Transfer&quot;,&quot;code&quot;:&quot;024&quot;,&quot;codeName&quot;:&quot;CT_BALANCE_TRANSFER&quot;},{&quot;_id&quot;:&quot;5677cfa3ef05740bc688015d&quot;,&quot;name&quot;:&quot;Card Services&quot;,&quot;code&quot;:&quot;026&quot;,&quot;codeName&quot;:&quot;CT_CARD_SERVICES&quot;},{&quot;_id&quot;:&quot;5677cfa3ef05740bc688015e&quot;,&quot;name&quot;:&quot;CTN&quot;,&quot;code&quot;:&quot;038&quot;,&quot;codeName&quot;:&quot;CT_CTN&quot;},{&quot;_id&quot;:&quot;5677cfa3ef05740bc688015f&quot;,&quot;name&quot;:&quot;LOC&quot;,&quot;code&quot;:&quot;041&quot;,&quot;codeName&quot;:&quot;CT_LOC&quot;},{&quot;_id&quot;:&quot;5677cfa3ef05740bc6880160&quot;,&quot;name&quot;:&quot;Loyalty&quot;,&quot;code&quot;:&quot;043&quot;,&quot;codeName&quot;:&quot;CT_LOYALTY&quot;},{&quot;_id&quot;:&quot;5677cfa3ef05740bc6880161&quot;,&quot;name&quot;:&quot;Self Servicing&quot;,&quot;code&quot;:&quot;048&quot;,&quot;codeName&quot;:&quot;CT_SELF_SERVICING&quot;},{&quot;_id&quot;:&quot;5677cfa3ef05740bc6880162&quot;,&quot;name&quot;:&quot;Spend&quot;,&quot;code&quot;:&quot;057&quot;,&quot;codeName&quot;:&quot;CT_SPEND&quot;},{&quot;_id&quot;:&quot;5677cfa3ef05740bc6880163&quot;,&quot;name&quot;:&quot;Publishing&quot;,&quot;code&quot;:&quot;060&quot;,&quot;codeName&quot;:&quot;CT_PUBLISHING&quot;},{&quot;_id&quot;:&quot;5677cfa3ef05740bc6880164&quot;,&quot;name&quot;:&quot;Market Research&quot;,&quot;code&quot;:&quot;062&quot;,&quot;codeName&quot;:&quot;CT_MARKET_RESEARCH&quot;}],&quot;marketingManagers&quot;:[{&quot;_id&quot;:&quot;5677cfa4ef05740bc68801c8&quot;,&quot;uid&quot;:&quot;avargh3&quot;,&quot;value&quot;:&quot;avargh3&quot;,&quot;phone&quot;:&quot;212-624-9842&quot;,&quot;email&quot;:&quot;alfred.t.varghese@aexp.com&quot;,&quot;name&quot;:&quot;Alfred T arghese&quot;,&quot;role&quot;:{&quot;_id&quot;:&quot;5677cfa4ef05740bc68801c3&quot;,&quot;code&quot;:&quot;001&quot;,&quot;codeName&quot;:&quot;mm&quot;,&quot;name&quot;:&quot;Marketing Manager&quot;},&quot;businessUnit&quot;:{&quot;_id&quot;:&quot;5677cfa3ef05740bc688014d&quot;,&quot;name&quot;:&quot;Global Merchant Services (GMS)&quot;,&quot;code&quot;:&quot;U007&quot;,&quot;codeName&quot;:&quot;BU_GMS&quot;},&quot;lastUpdatedOn&quot;:&quot;2015-12-21T13:01:39.394Z&quot;,&quot;status&quot;:{&quot;_id&quot;:&quot;5677cfa4ef05740bc68801c5&quot;,&quot;code&quot;:&quot;001&quot;,&quot;codeName&quot;:&quot;active&quot;,&quot;name&quot;:&quot;Active&quot;}},{&quot;_id&quot;:&quot;5677cfa4ef05740bc68801cb&quot;,&quot;uid&quot;:&quot;azelenet&quot;,&quot;value&quot;:&quot;azelenet&quot;,&quot;phone&quot;:&quot;212-640-3301&quot;,&quot;email&quot;:&quot;Andrea.L.Zelenetz1@aexp.com&quot;,&quot;name&quot;:&quot;Andrea L Zelenetz&quot;,&quot;role&quot;:{&quot;_id&quot;:&quot;5677cfa4ef05740bc68801c3&quot;,&quot;code&quot;:&quot;001&quot;,&quot;codeName&quot;:&quot;mm&quot;,&quot;name&quot;:&quot;Marketing Manager&quot;},&quot;businessUnit&quot;:{&quot;_id&quot;:&quot;5677cfa3ef05740bc688014d&quot;,&quot;name&quot;:&quot;Global Merchant Services (GMS)&quot;,&quot;code&quot;:&quot;U007&quot;,&quot;codeName&quot;:&quot;BU_GMS&quot;},&quot;lastUpdatedOn&quot;:&quot;2015-12-21T10:15:59.952Z&quot;,&quot;status&quot;:{&quot;_id&quot;:&quot;5677cfa4ef05740bc68801c5&quot;,&quot;code&quot;:&quot;001&quot;,&quot;codeName&quot;:&quot;active&quot;,&quot;name&quot;:&quot;Active&quot;}},{&quot;_id&quot;:&quot;5677cfa4ef05740bc68801ce&quot;,&quot;uid&quot;:&quot;cblan3&quot;,&quot;value&quot;:&quot;cblan3&quot;,&quot;phone&quot;:&quot;602-537-8954&quot;,&quot;email&quot;:&quot;CLARISSA.BLANCO@aexp.com&quot;,&quot;name&quot;:&quot;CLARISSA BLANCO&quot;,&quot;role&quot;:{&quot;_id&quot;:&quot;5677cfa4ef05740bc68801c3&quot;,&quot;code&quot;:&quot;001&quot;,&quot;codeName&quot;:&quot;mm&quot;,&quot;name&quot;:&quot;Marketing Manager&quot;},&quot;businessUnit&quot;:{&quot;_id&quot;:&quot;5677cfa3ef05740bc688014e&quot;,&quot;name&quot;:&quot;GCC&quot;,&quot;code&quot;:&quot;U006&quot;,&quot;codeName&quot;:&quot;BU_GCC&quot;},&quot;lastUpdatedOn&quot;:&quot;2015-12-21T12:24:41.379Z&quot;,&quot;status&quot;:{&quot;_id&quot;:&quot;5677cfa4ef05740bc68801c5&quot;,&quot;code&quot;:&quot;001&quot;,&quot;codeName&quot;:&quot;active&quot;,&quot;name&quot;:&quot;Active&quot;}},{&quot;_id&quot;:&quot;5677cfa4ef05740bc68801c7&quot;,&quot;uid&quot;:&quot;cseba1&quot;,&quot;value&quot;:&quot;cseba1&quot;,&quot;phone&quot;:&quot;212-640-5091&quot;,&quot;email&quot;:&quot;Cassandra.J.SebastianPernia@aexp.com&quot;,&quot;name&quot;:&quot;Cassandra J SebastianPernia&quot;,&quot;role&quot;:{&quot;_id&quot;:&quot;5677cfa4ef05740bc68801c3&quot;,&quot;code&quot;:&quot;001&quot;,&quot;codeName&quot;:&quot;mm&quot;,&quot;name&quot;:&quot;Marketing Manager&quot;},&quot;businessUnit&quot;:{&quot;_id&quot;:&quot;5677cfa3ef05740bc688014e&quot;,&quot;name&quot;:&quot;GCC&quot;,&quot;code&quot;:&quot;U006&quot;,&quot;codeName&quot;:&quot;BU_GCC&quot;},&quot;lastUpdatedOn&quot;:&quot;2015-12-21T10:12:24.364Z&quot;,&quot;status&quot;:{&quot;_id&quot;:&quot;5677cfa4ef05740bc68801c5&quot;,&quot;code&quot;:&quot;001&quot;,&quot;codeName&quot;:&quot;active&quot;,&quot;name&quot;:&quot;Active&quot;}},{&quot;_id&quot;:&quot;5677cfa4ef05740bc68801ca&quot;,&quot;uid&quot;:&quot;knapoli&quot;,&quot;value&quot;:&quot;knapoli&quot;,&quot;phone&quot;:&quot;212-640-5004&quot;,&quot;email&quot;:&quot;Kayla.Napoli@aexp.com&quot;,&quot;name&quot;:&quot;Kayla Napoli&quot;,&quot;role&quot;:{&quot;_id&quot;:&quot;5677cfa4ef05740bc68801c3&quot;,&quot;code&quot;:&quot;001&quot;,&quot;codeName&quot;:&quot;mm&quot;,&quot;name&quot;:&quot;Marketing Manager&quot;},&quot;businessUnit&quot;:{&quot;_id&quot;:&quot;5677cfa3ef05740bc688014d&quot;,&quot;name&quot;:&quot;Global Merchant Services (GMS)&quot;,&quot;code&quot;:&quot;U007&quot;,&quot;codeName&quot;:&quot;BU_GMS&quot;},&quot;lastUpdatedOn&quot;:&quot;2015-12-21T11:47:04.506Z&quot;,&quot;status&quot;:{&quot;_id&quot;:&quot;5677cfa4ef05740bc68801c5&quot;,&quot;code&quot;:&quot;001&quot;,&quot;codeName&quot;:&quot;active&quot;,&quot;name&quot;:&quot;Active&quot;}}],&quot;businessUnits&quot;:[{&quot;_id&quot;:&quot;5677cfa3ef05740bc688014d&quot;,&quot;name&quot;:&quot;Global Merchant Services (GMS)&quot;,&quot;code&quot;:&quot;U007&quot;,&quot;codeName&quot;:&quot;BU_GMS&quot;},{&quot;_id&quot;:&quot;5677cfa3ef05740bc688014e&quot;,&quot;name&quot;:&quot;GCC&quot;,&quot;code&quot;:&quot;U006&quot;,&quot;codeName&quot;:&quot;BU_GCC&quot;},{&quot;_id&quot;:&quot;5677cfa3ef05740bc688014f&quot;,&quot;name&quot;:&quot;OPEN&quot;,&quot;code&quot;:&quot;U005&quot;,&quot;codeName&quot;:&quot;BU_OPEN&quot;},{&quot;_id&quot;:&quot;5677cfa3ef05740bc6880150&quot;,&quot;name&quot;:&quot;CCSG&quot;,&quot;code&quot;:&quot;U004&quot;,&quot;codeName&quot;:&quot;BU_CCSG&quot;},{&quot;_id&quot;:&quot;5677cfa3ef05740bc6880151&quot;,&quot;name&quot;:&quot;Publishing&quot;,&quot;code&quot;:&quot;U003&quot;,&quot;codeName&quot;:&quot;BU_PUBLISHING&quot;},{&quot;_id&quot;:&quot;5677cfa3ef05740bc6880152&quot;,&quot;name&quot;:&quot;GMPI&quot;,&quot;code&quot;:&quot;U002&quot;,&quot;codeName&quot;:&quot;BU_GMPI&quot;},{&quot;_id&quot;:&quot;5677cfa3ef05740bc6880153&quot;,&quot;name&quot;:&quot;Global Prepaid&quot;,&quot;code&quot;:&quot;U019&quot;,&quot;codeName&quot;:&quot;BU_GLOBAL_PREPAID&quot;},{&quot;_id&quot;:&quot;5677cfa3ef05740bc6880154&quot;,&quot;name&quot;:&quot;Consumer Travel&quot;,&quot;code&quot;:&quot;U018&quot;,&quot;codeName&quot;:&quot;BU_CONSUMER_TRAVEL&quot;},{&quot;_id&quot;:&quot;5677cfa3ef05740bc6880155&quot;,&quot;name&quot;:&quot;AXPi&quot;,&quot;code&quot;:&quot;U017&quot;,&quot;codeName&quot;:&quot;BU_AXPI&quot;},{&quot;_id&quot;:&quot;5677cfa3ef05740bc6880156&quot;,&quot;name&quot;:&quot;MR&quot;,&quot;code&quot;:&quot;U020&quot;,&quot;codeName&quot;:&quot;BU_MR&quot;},{&quot;_id&quot;:&quot;5677cfa3ef05740bc6880157&quot;,&quot;name&quot;:&quot;Card Services&quot;,&quot;code&quot;:&quot;U021&quot;,&quot;codeName&quot;:&quot;BU_CARD_SERVICES&quot;},{&quot;_id&quot;:&quot;5677cfa3ef05740bc6880158&quot;,&quot;name&quot;:&quot;Direct Deposits&quot;,&quot;code&quot;:&quot;U022&quot;,&quot;codeName&quot;:&quot;BU_DIRECT_DEPOSITS&quot;},{&quot;_id&quot;:&quot;5677cfa3ef05740bc6880159&quot;,&quot;name&quot;:&quot;Enterprise Growth Group (EGG)&quot;,&quot;code&quot;:&quot;U023&quot;,&quot;codeName&quot;:&quot;BU_EGG&quot;},{&quot;_id&quot;:&quot;5677cfa3ef05740bc688015a&quot;,&quot;name&quot;:&quot;Digital Partnerships &amp; Development (DPD)&quot;,&quot;code&quot;:&quot;U024&quot;,&quot;codeName&quot;:&quot;BU_DPD&quot;}],&quot;cellTypes&quot;:[{&quot;_id&quot;:&quot;5677cfa4ef05740bc68801d5&quot;,&quot;code&quot;:&quot;T&quot;,&quot;codeName&quot;:&quot;test&quot;,&quot;name&quot;:&quot;Mailable (Test)&quot;},{&quot;_id&quot;:&quot;5677cfa4ef05740bc68801d6&quot;,&quot;code&quot;:&quot;C&quot;,&quot;codeName&quot;:&quot;control&quot;,&quot;name&quot;:&quot;Holdout (Control)&quot;}],&quot;emailTypes&quot;:[{&quot;_id&quot;:&quot;5677cfa3ef05740bc688014b&quot;,&quot;code&quot;:&quot;012&quot;,&quot;name&quot;:&quot;Servicing&quot;,&quot;codeName&quot;:&quot;ET_SERVICING&quot;},{&quot;_id&quot;:&quot;5677cfa3ef05740bc688014c&quot;,&quot;code&quot;:&quot;008&quot;,&quot;name&quot;:&quot;Marketing Automation&quot;,&quot;codeName&quot;:&quot;ET_MA&quot;}],&quot;userRoles&quot;:[{&quot;_id&quot;:&quot;5677cfa4ef05740bc68801c4&quot;,&quot;code&quot;:&quot;002&quot;,&quot;codeName&quot;:&quot;axpi&quot;,&quot;name&quot;:&quot;Admin&quot;},{&quot;_id&quot;:&quot;5677cfa4ef05740bc68801c3&quot;,&quot;code&quot;:&quot;001&quot;,&quot;codeName&quot;:&quot;mm&quot;,&quot;name&quot;:&quot;Marketing Manager&quot;}],&quot;userStatus&quot;:[{&quot;_id&quot;:&quot;5677cfa4ef05740bc68801c5&quot;,&quot;code&quot;:&quot;001&quot;,&quot;codeName&quot;:&quot;active&quot;,&quot;name&quot;:&quot;Active&quot;},{&quot;_id&quot;:&quot;5677cfa4ef05740bc68801c6&quot;,&quot;code&quot;:&quot;002&quot;,&quot;codeName&quot;:&quot;inactive&quot;,&quot;name&quot;:&quot;Inactive&quot;}],&quot;loggedInUser&quot;:{&quot;_id&quot;:&quot;5677cfa4ef05740bc68801d4&quot;,&quot;uid&quot;:&quot;avarghes&quot;,&quot;value&quot;:&quot;avarghes&quot;,&quot;phone&quot;:&quot;212-624-9842&quot;,&quot;email&quot;:&quot;alfred.t.varghese@aexp.com&quot;,&quot;name&quot;:&quot;Alfred T arghese&quot;,&quot;role&quot;:{&quot;_id&quot;:&quot;5677cfa4ef05740bc68801c4&quot;,&quot;code&quot;:&quot;002&quot;,&quot;codeName&quot;:&quot;axpi&quot;,&quot;name&quot;:&quot;Admin&quot;},&quot;businessUnit&quot;:{&quot;_id&quot;:&quot;5677cfa3ef05740bc688014e&quot;,&quot;name&quot;:&quot;GCC&quot;,&quot;code&quot;:&quot;U006&quot;,&quot;codeName&quot;:&quot;BU_GCC&quot;},&quot;lastUpdatedOn&quot;:&quot;2015-12-21T12:05:18.660Z&quot;,&quot;status&quot;:{&quot;_id&quot;:&quot;5677cfa4ef05740bc68801c5&quot;,&quot;code&quot;:&quot;001&quot;,&quot;codeName&quot;:&quot;active&quot;,&quot;name&quot;:&quot;Active&quot;},&quot;leader&quot;:{&quot;firstName&quot;:&quot;Dummy&quot;,&quot;lastName&quot;:&quot;leader&quot;,&quot;email&quot;:&quot;leader@aexp.com&quot;}}}");
    $provide.value('attachments', mockAttachmentTypes);
  }));

  /**
   * @Featured: New Campaign Test Cases. 
   */
  describe('Tests for only new Campaign', function() {
    beforeEach(module('ewtNewCampaignModule'));
    beforeEach(inject(loadewtCampaignController(campaignMockData.newMockCampaign)));

    it('Initially the new campaign from resolve function should be equal to $scope.campaign', function() {
      expect(scope.campaign).toEqual(ewtCampaign);
    });

    it('When new campaign is requested creative to be empty object', function() {
      expect(scope.campaign.creativeMockup).toEqual({});
    });

    describe('Testing Email Type change function', function() {
      var emailTypeServicingMock = {
        "_id": "56137304f23bae527e374ce1",
        "code": "012",
        "name": "Servicing",
        "codeName": "ET_SERVICING"
      };
      var emailTypeMAMock = {
        "_id": "56137304f23bae527e374ce2",
        "code": "008",
        "name": "Marketing Automation",
        "codeName": "ET_MA"
      };
      it('Default Test on Eamil Type', function() {
        expect(scope.campaign.emailType).toBeDefined();
        expect(scope.campaign.emailType.codeName).toBeUndefined();
      });

      it('Test on Email Type change to any one of the emailType', function() {
        scope.campaign.emailType.codeName = 'ET_SERVICING';
        scope.emailTypeChange();
        expect(scope.campaign.emailType).toEqual(emailTypeServicingMock);
      });


      it('Test on New MA tabs visibility when email type changes', function() {
        scope.campaign.emailType.codeName = 'ET_MA';
        scope.emailTypeChange();
        expect(scope.tabs[2].emailTypeVisibility).toBeTruthy();
        scope.campaign.emailType.codeName = 'ET_SERVICING';
        scope.emailTypeChange();
        expect(scope.tabs[2].emailTypeVisibility).toBeFalsy();
      });

      it('Test on Email Type change to MA Eamil Type', function() {
        scope.campaign.emailType.codeName = 'ET_MA';
        scope.emailTypeChange();
        expect(scope.campaign.emailType).toEqual(emailTypeMAMock);
      });

      it('Email type change should cahng the value of arbitrationStatus as for MA it is non arbs and for servicing should be null', function() {
        scope.campaign.emailType.codeName = 'ET_MA';
        scope.emailTypeChange();
        expect(scope.campaign.arbitrationStatus.code).toBe('N');
        scope.campaign.emailType.codeName = 'ET_SERVICING';
        scope.emailTypeChange();
        expect(scope.campaign.arbitrationStatus).toEqual({});
      });
      it('Reset the deplyoment date if email type is not MA else deploymentDates remain same', function() {
        scope.campaign.emailType.codeName = 'ET_MA';
        scope.campaign.deploymentDates[0] = new Date('2020-12-20T18:30:00.000Z');
        scope.emailTypeChange();
        expect(scope.campaign.deploymentDates).not.toBe([]);
        scope.campaign.emailType.codeName = 'ET_SERVICING';
        scope.campaign.deploymentDates[0] = new Date('2020-12-19T18:30:00.000Z');
        scope.emailTypeChange();
        expect(scope.campaign.deploymentDates).toEqual([]);
      });
    });
  });

  /**
   * @Featured: Common Tests for all kinds of campaign. 
   */
  describe('All Common tests for a Campaign', function() {
    beforeEach(module('ewtNewCampaignModule'));
    beforeEach(inject(loadewtCampaignController(campaignMockData.newMockCampaign)));
    describe('calculateEndMinDate', function() {
      it('Test that will check for invalid start dates of the MA mhids when start date is changed', function() {
        var outputDate = new Date('2025-11-25T00:00:00.000Z');
        scope.campaign.emailType.codeName = 'ET_SERVICING';
        scope.campaign.deploymentDates[0] = outputDate;
        scope.calculateEndMinDate();
        expect(scope.campaign.deploymentDates[0]).toEqual(scope.campaign.deploymentDates[0]);
        scope.campaign.mailHistory = mock_mailHistory;
        scope.campaign.emailType.codeName = 'ET_MA';
        scope.calculateEndMinDate();
        expect(scope.campaign.atleastOneDateEqual).toBeFalsy();
      });
    });
    it('Test and return true if the user is admin else return false', function() {
      expect(scope.isAdmin).toBeDefined();
      expect(typeof scope.isAdmin).toBe('function');
      expect(scope.isAdmin()).toBe(false);
      scope.user.role.codeName = 'axpi';
      expect(scope.isAdmin()).toBe(true);
      scope.user.role.codeName = 'axpiAdmin';
      expect(scope.isAdmin()).toBe(true);
    });
    it('Test and return true if the user is manager else return false', function() {
      expect(scope.isManager).toBeDefined();
      scope.user.role.codeName = 'mm';
      expect(scope.isManager()).toBe(true);
      scope.user.role.codeName = 'axpi';
      expect(scope.isManager()).toBe(false);
      scope.user.role.codeName = 'axpiAdmin';
      expect(scope.isManager()).toBe(false);
    });
    describe('Test on isSameAsParent function', function() {
      var parent, child;
      child = {
        mockDataObj: 'test'
      };
      parent = {
        mockDataObj: 'test',
        edit: true,
        editing: false,
        $$hashKey: 325
      };
      it('Test isSameAsParent function to be defined', function() {
        expect(scope.isSameAsParent).toBeDefined();
        expect(typeof scope.isSameAsParent).toBe('function');
      });
      it('Test return true if parent and child object are same else return false', function() {
        expect(scope.isSameAsParent(child, parent)).toBeTruthy();
        parent.newProp = 'test5';
        expect(scope.isSameAsParent(child, parent)).toBeFalsy();
        delete parent.newProp;
      });
      it('Test to compare child and parent object excluding parent had edit, editing and $$hashKey properties ', function() {
        expect(scope.isSameAsParent(child, parent)).toBeTruthy();
      })
    });

    describe('Test on replicateObj function', function() {
      var mockObject;
      mockObject = {
        mockDataObj: 'test'
      };
      var mockObject1, mockObject2;
      it('Test replicateObj function to be defined', function() {
        expect(scope.replicateObj).toBeDefined();
        expect(typeof scope.replicateObj).toBe('function');
      })
      it('Test return object same as the object passed as the parameter', function() {
        mockObject1 = scope.replicateObj(mockObject);
        expect(mockObject1).toEqual(mockObject);
      });
      it('Test to return object by removing edit, editin, incomplete and cells properties', function() {
        mockObject.edit = true;
        mockObject.editing = false;
        mockObject.incomplete = true;
        mockObject.cells = {};
        mockObject2 = scope.replicateObj(mockObject);
        expect(mockObject2.edit).toBeUndefined();
        expect(mockObject2.editing).toBeUndefined();
        expect(mockObject2.incomplete).toBeUndefined();
        expect(mockObject2.cells).toBeUndefined();
      });
    });

    describe('Test on Set Email of Primary Marketing Manager and Secondary Marketing Manager', function() {
      var setEmailOutputMock = {
        "_id": "56137306f23bae527e374d66",
        "uid": "randrew",
        "value": "randrew",
        "phone": "212-624-9822",
        "email": "roopa.a.andrew1@aexp.com",
        "name": "Roopa Andrew",
        "role": {
          "name": "manager",
          "codeName": "mm",
          "code": "001"
        }
      };
      var secondaryMMSetEmailOutputMock = {
        "_id": "56137306f23bae527e374d58",
        "value": "cseba1",
        "phone": "212-640-5091",
        "email": "Cassandra.J.SebastianPernia@aexp.com",
        "name": "Cassandra J SebastianPernia",
        "role": {
          "name": "manager",
          "codeName": "mm",
          "code": "001"
        }
      };
      it('Test on setEmail function to be defined function', function() {
        expect(scope.setEmail).toBeDefined();
        expect(typeof scope.setEmail).toBe('function');
      });

      it('Testing setEmail function sets primary Marketing Mangers', function() {
        scope.setEmail('primary');
        expect(scope.campaign.primaryMarketingManager.email).toBe(setEmailOutputMock.email);
      });

      it('Testing setEmail function sets secondary Marketing Mangers', function() {
        scope.setEmail('secondary');
        expect(scope.campaign.secondaryMarketingManager.email).toBe(secondaryMMSetEmailOutputMock.email);
      });
    });
    it('Default tests on Bussiness unit change function', function() {
      expect(scope.bussinessUnitChange).toBeDefined();
      expect(typeof scope.bussinessUnitChange).toBe('function');
    });

    describe('Tests on business unit change function', function() {
      it('Testing business unit change for Servicing campaign should reset cm nedd cmNeedCategories', function() {
        scope.campaign.emailType.codeName = 'ET_SERVICING';
        scope.bussinessUnitChange();
        expect(scope.campaign.isMultiCMNeedCategory).toBe('false');
        expect(scope.campaign.cmNeed.selected).toEqual([]);
      });
      it('Testing bussinessUnitChange function for other campaign except Servicing', function() {
        spyOn(ewtMasterDataService, 'getCMNeedCategory').and.callFake(function() {
          return;
        })
        scope.campaign.emailType.codeName = 'ET_MA';
        scope.bussinessUnitChange();
        expect(ewtMasterDataService.getCMNeedCategory).toHaveBeenCalled();
      });
    });

    describe('Test to check if the start date get gets disabled ie. return true for MA campaign if the user is Marketing manager', function() {
      it('Should get false if emailType is not defined', function() {
        delete scope.campaign.emailType;
        expect(scope.campaign.emailType).not.toBeDefined();
        expect(scope.isStartDateEnabled()).toBeFalsy();
      });

      it('Should get false if emailType is not MA', function() {
        scope.campaign.emailType.codeName = 'ET_SERVICING';
        expect(scope.isStartDateEnabled()).toBeFalsy();
      });

      it('Should get false if state is not draft and email type is MA', function() {
        scope.campaign.emailType.codeName = 'ET_MA';
        scope.campaign.state.codeName = 'draft';
        expect(scope.isStartDateEnabled()).toBeFalsy();
      });

      it('Should get false if user is Manager and state is draft and email type is MA', function() {
        scope.campaign.emailType.codeName = 'ET_MA';
        scope.campaign.state.codeName = 'draft';
        expect(scope.isStartDateEnabled()).toBeFalsy();
      });

      it('Should return ture if user is Manger and state is not draft and email type is MA else return', function() {
        scope.campaign.emailType.codeName = 'ET_MA';
        scope.campaign.state.codeName = 'approved';
        scope.user.role.codeName = 'axpi';
        expect(scope.isStartDateEnabled()).toBeFalsy();
        scope.user.role.codeName = 'mm';
        expect(scope.isStartDateEnabled()).toBeTruthy();
      });
    });

    it('Test the it should be a defined function', function() {
      expect(scope.checkPersonalizantionTab).toBeDefined();
      expect(typeof scope.checkPersonalizantionTab).toBe('function');
    });

    describe('Test on open new mhid date picker function', function() {
      it('Default value tests on function', function() {
        expect(scope.openNewMHIDDatePicker).toBeDefined();
        expect(typeof scope.openNewMHIDDatePicker).toBe('function');
      });

      it('Test whether the new date picker is opening and closing for the MHID start date on clicking on calender', function() {
        var mock_mhidObject = {
          mhidDateOpened: false,
          cellError: true
        };

        scope.openNewMHIDDatePicker(mock_event, mock_mhidObject);
        expect(mock_mhidObject.mhidDateOpened).toBeTruthy();
      });
    });

    describe('Test on validateDeploymentSection function', function() {
      it('that it is function by default', function() {
        expect(scope.validateDeploymentSection).toBeDefined();
        expect(typeof scope.validateDeploymentSection).toBe('function');
      });
      it('that it should return true if the section is invalid', function() {
        expect(scope.validateDeploymentSection()).toBeFalsy();
        delete scope.campaign.deploymentDates[0];
        expect(scope.validateDeploymentSection()).toBeTruthy();
      });
    });



    describe('Notes Section', function() {
      describe('Test on close notes function', function() {
        beforeEach(function() {
          spyOn(scope.campaign.modal, 'open').and.callFake(function(options) {
            return true;
          });
        });
        it('that it is a function by default', function() {
          expect(scope.campaign.closeNotes).toBeDefined();
          expect(typeof scope.campaign.closeNotes).toBe('function');
        });
        it('that it close the notes section on close button click', function() {
          scope.campaign.showNotes = true;
          scope.campaign.closeNotes('');
          expect(scope.campaign.showNotes).toBeFalsy();
          scope.campaign.closeNotes('Test Comment');
          expect(scope.campaign.model.open).toHaveBeenCalled();
        });
      });
    });

    it('disbale dates function return true if it is a sunday for emailType Servicing', function() {
      var mock_for_disableDates = new Date('2025-11-22T18:30:00.000Z');
      scope.campaign.emailType.codeName = 'ET_MA';
      expect(scope.disabledDates(mock_for_disableDates, 'day')).toBeFalsy();
      scope.campaign.emailType.codeName = 'ET_SERVICING';
      expect(scope.disabledDates(mock_for_disableDates, 'day')).toBeTruthy();
    });

    it('openDatePicker function', function() {
      scope.opened = false;
      var outputOpened = !scope.opened;
      scope.openDatePicker(mock_event);
      expect(scope.opened).toBe(outputOpened);
    });

    describe('preview file function', function() {
      it('is a default function', function() {
        expect(scope.previewFile).toBeDefined();
        expect(typeof scope.previewFile).toBe('function');
      });
      it('preiew a file if files is valid', function() {
        spyOn(ewtMasterDataService, 'viewMockUp').and.callFake(function() {
          return true;
        });
        var mock_file = {
          'name': 'test',
          'size': 2020,
          'type': 'application/pdf'
        };
        scope.mockFile = {};
        scope.previewFile();
        expect(ewtMasterDataService.viewMockUp).not.toHaveBeenCalled();
        scope.mockFile.file = mock_file;
        scope.previewFile();
        expect(ewtMasterDataService.viewMockUp).toHaveBeenCalled();
      });
    });
    describe('remove mock file function', function() {
      it('is a default function', function() {
        expect(scope.removeMock).toBeDefined();
        expect(typeof scope.removeMock).toBe('function');
      });
      it('preiew a file if files is valid', function() {
        // spyOn(ewtMasterDataService, 'sdfas').and.callFake(function() {
        //   return true;
        // });

        var mock_cbRemoveMock = function() {};
        scope.campaign.creativeMockup = {
          'test': 'invalid file'
        };
        scope.removeMock('');
        expect(scope.campaign.creativeMockup).toEqual(scope.campaign.creativeMockup)
        scope.campaign.creativeMockup = mock_creative_file;
        scope.removeMock('560b7e6a7981e574e17b3aa6');
        expect(scope.campaign.creativeMockup).toBe({})
      });
    });

    describe('upload mock function', function() {
      var $files = [];
      beforeEach(function() {
        $files[0] = mock_creative_file;
      });
      it(' uploads the mock file when the files is valid', function() {
        scope.uploadMock($files);
        expect(scope.mockFile.file).toEqual($files[0]);
      });
      it(' alerts if the file uploaded is exe type', function() {
        $files[0].name = 'test.exe';
        scope.uploadMock($files);
        expect(scope.campaign.showAlert).toHaveBeenCalledWith('Cannot upload .exe files');
      });
      it(' alerts if the file uploaded exceeds 10MB size limit', function() {
        $files[0].name = 'test.png';
        $files[0].size = 10485761;
        scope.uploadMock($files);
        expect(scope.campaign.showAlert).toHaveBeenCalledWith('Cannot upload file greater than 10MB in size');
      });
      it(' file is not upload if the campaign is not having requestID', function() {
        scope.campaign.requestID = '';
        $files[0].size = 1485761;
        scope.uploadMock($files);
        expect(scope.campaign.uploadMockFile).not.toHaveBeenCalled();
      });
      it(' files length is empty then the upload mock should be empty object', function() {
        $files = [];
        scope.uploadMock($files);
        expect(scope.mockFile).toEqual({});
      })
    });

    describe('Draft campaign function', function() {
      beforeEach(function() {
        scope.campaignForm = mock_campaignForm;
        spyOn(scope.campaign, 'saveAsDraft').and.callFake(function(param1) {
          return;
        });
      });
      it('should reset form dirty when this function is called', function() {
        scope.campaignForm.$dirty = true;
        scope.draftCampaign();
        expect(scope.campaignForm.$dirty).toBeFalsy();
      });
      it(' should call save as draft with null parameter when no mock upload file', function() {
        scope.cMockuploadedFile = {};
        scope.draftCampaign();
        expect(scope.campaign.saveAsDraft).toHaveBeenCalledWith(null);
      });
      it(' should call save as draft with creative mock file as parameter', function() {
        scope.cMockuploadedFile = mock_creative_file;
        scope.draftCampaign();
        expect(scope.campaign.saveAsDraft).toHaveBeenCalledWith(scope.cMockuploadedFile);
      });
    });

    it('updateAttachmentsInScope function should push a attachment to scope attachment array', function() {
      scope.campaign.attachments = [];
      var arrayLength = scope.campaign.attachments.length || 0;
      scope.updateAttachmentsInScope(mock_creative_file);
      expect(scope.campaign.attachments.length).toBe(arrayLength + 1);
    });
    it('remove file function', function() {

    });
  });

  /**
   * @Featured: Existing campaign Test common for all Email types
   */

  describe('Tests for Existing Approved Campaign', function() {
    beforeEach(function() {
      campaignMockData.approvedMockCampaign.deploymentDates[0] = new Date(campaignMockData.approvedMockCampaign.deploymentDates[0]);
    });
    beforeEach(inject(loadewtCampaignController(campaignMockData.approvedMockCampaign)));
    it('Initially the existing campaign from resolve function should be equal to $scope.campaign', function() {
      expect(scope.campaign).toEqual(ewtCampaign);
    });

    it('When Approved campaign is requested creative should not be empty object and should have _id and gridFs id and', function() {
      expect(scope.campaign.creativeMockup).toBeDefined();
      expect(scope.campaign.creativeMockup).not.toEqual({});
      expect(scope.campaign.creativeMockup.gfsID).not.toBe('');
      expect(scope.campaign.creativeMockup._id).not.toBe('');
    });

    describe('Testing checkMhid function', function() {
      it('Test the checkMhid is default defined function', function() {
        expect(scope.checkMhid).toBeDefined();
        expect(typeof scope.checkMhid).toBe('function');
      });
      it('Test the single mhid is undefined then mhidWarning should be set to false', function() {
        expect(scope.campaign.mailHistory[0]).toBeUndefined();
        scope.checkMhid();
        expect(scope.mhidWarning).toBeFalsy();
      });
      it('Test the single mhid is having length not equal to 8 then mhidWarning should be set to false', function() {

        scope.campaign.mailHistory[0] = mock_invalid_mhid;
        scope.checkMhid();
        expect(scope.mhidWarning).toBeFalsy();
      });
      it('Test that if valid mhid is given for servicing campaign it should check in db', function() {
        scope.campaign.mailHistory[0] = mock_valid_mhid;
        scope.checkMhid();
        expect(true).toBeTruthy();
      });
      it('Test that if valid mhid is given for MA Campaign it should check in db', function() {
        scope.campaign.emailType.codeName = 'ET_MA';
        scope.campaign.mailHistory[0] = mock_valid_mhid;
        scope.checkMhid();
        expect(true).toBeTruthy();
      });
    });

    describe('Test on checkPersonalizantionTab function', function() {
      it('Test the checkPersonalizantionTab is default defined function', function() {
        expect(scope.checkPersonalizantionTab).toBeDefined();
        expect(typeof scope.checkPersonalizantionTab).toBe('function');
      });

      it('Test that it should return false if the there is an error in seed and preview list elements', function() {
        expect(scope.campaign.seedPreviewText).toBeDefined();
        expect(scope.campaign.seedPreviewText).toBe('');
        expect(scope.campaign.seedPreviewErrorMessage).toBeDefined();
        expect(scope.campaign.seedPreviewErrorMessage).toBe('');
        expect(scope.campaign.seedDeployText).toBeDefined();
        expect(scope.campaign.seedDeployText).toBe('');
        expect(scope.campaign.seedDeployErrorMessage).toBeDefined();
        expect(scope.campaign.seedDeployErrorMessage).toBe('');
        expect(scope.checkPersonalizantionTab()).toBeFalsy();

        scope.campaign.seedPreviewText = 'test@aexp.com;test@aexp.com';
        scope.campaign.seedPreviewErrorMessage = '';
        scope.campaign.seedDeployText = 'test@aexp.com;test@aexp.com';
        scope.campaign.seedDeployErrorMessage = '';
        expect(scope.checkPersonalizantionTab()).toBeFalsy();
      });
    });

    describe('Test on Verify PZN Fields', function() {
      it('check verifyPzn function to find uniqueness in the pzn selected list', function() {
        scope.pznAlreadyExists = false;
        scope.campaign.pznFields = mock_pzn_selected;
        scope.campaign.pznSelected = mock_pzn_reserved;
        scope.verifyPzn();
        expect(scope.pznAlreadyExists).toBeTruthy();
        scope.campaign.pznSelected = mock_pzn_unreserved;
        scope.verifyPzn();
        expect(scope.pznAlreadyExists).toBeFalsy();
      });
    });

    it('Test on pznDescriptionEnabled function that will disabled pzn description text box if pzn is not selected or pzn is already exists', function() {
      expect(scope.pznDescriptionEnabled).toBeDefined();
      expect(typeof scope.pznDescriptionEnabled).toBe('function');
      scope.campaign.pznSelected = {};
      expect(scope.pznDescriptionEnabled()).toBeFalsy();
      scope.campaign.pznSelected = mock_pzn_unreserved;
      expect(scope.pznDescriptionEnabled()).toBeFalsy();
      scope.pznAlreadyExists = true;
      expect(scope.pznDescriptionEnabled()).toBeTruthy();
    });
    it('Test on hidePznError function that it should set pznAlreadyExists to false', function() {
      scope.pznAlreadyExists = true;
      scope.hidePznError();
      expect(scope.pznAlreadyExists).toBeFalsy();
    });
    describe('Test on disableADDPzn function', function() {
      it('that it is a function by default', function() {
        expect(scope.disableADDPzn).toBeDefined();
        expect(typeof scope.disableADDPzn).toBe('function');
      });
      it('that it should return true if the pzn is invalid else return false', function() {
        expect(scope.disableADDPzn()).toBeTruthy();
        scope.campaign.pznSelected = mock_pzn_reserved;
        expect(scope.disableADDPzn()).toBeFalsy();
      });
    });

    describe('Test on addPznVariable function', function() {
      it('that it is a function by default', function() {
        expect(scope.addPznVariable).toBeDefined();
        expect(typeof scope.addPznVariable).toBe('function');
      });
      it('that any invalid pzn fields selected will not be add to pzn fields list', function() {
        scope.campaign.pznSelected = {};
        var existingPznFiledsLength = scope.campaign.pznFields.length;
        scope.addPznVariable();
        expect(scope.campaign.pznFields.length).toBe(existingPznFiledsLength);
      });
      it('that it should add pznSelected into campaign pznFields taking pznDescription for unreserved pznFields', function() {
        scope.campaign.pznFields = mock_pzn_selected;
        scope.campaign.pznDescription = 'Test Description';
        var existingPznFiledsLength = scope.campaign.pznFields.length;
        scope.campaign.pznSelected = mock_pzn_unreserved;
        scope.addPznVariable();
        expect(scope.campaign.pznFields.length).toBe(existingPznFiledsLength + 1);
      });
      it('that it should add pznSelected into campaign pznFields taking default description for reserved pznFields', function() {
        scope.campaign.pznSelected = mock_pzn_reserved;
        var existingPznFiledsLength = scope.campaign.pznFields.length;
        scope.addPznVariable();
        expect(scope.campaign.pznFields.length).toBe(existingPznFiledsLength + 1);
      });
    });

    describe('seedPreviewListUpdated', function() {
      it('is a function by default', function() {
        expect(scope.seedPreviewListUpdated).toBeDefined();
        expect(typeof scope.seedPreviewListUpdated).toBe('function');
      });
      it('sets the error message according the previewListStatus', function() {
        scope.campaign.seedPreviewText = 'test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;';
        scope.seedPreviewListUpdated();
        expect(scope.campaign.isPreviewErrorVisible).toBeFalsy();
        scope.campaign.seedPreviewText = '';
        scope.seedPreviewListUpdated();
        expect(scope.campaign.seedPreviewErrorMessage).toBe('This is a required field; at least one valid email must be included.');
        scope.campaign.seedPreviewText = 'testInvalidEmail';
        scope.seedPreviewListUpdated();
        expect(scope.campaign.seedPreviewErrorMessage).toBe('Please enter at least one valid email address in the format of EWT-DCE@aexp.com');
        scope.campaign.seedPreviewText = 'test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com';
        scope.seedPreviewListUpdated();
        expect(scope.campaign.seedPreviewErrorMessage).toBe('There is a maximum of 15 emails.');
      });
    });

    describe('seedDeployListUpdated', function() {
      it('is a function by default', function() {
        expect(scope.seedDeployListUpdated).toBeDefined();
        expect(typeof scope.seedDeployListUpdated).toBe('function');
      });
      it('sets the error message according the previewListStatus', function() {
        scope.campaign.seedDeployText = 'test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;';
        scope.seedDeployListUpdated();
        expect(scope.campaign.isDeployErrorVisible).toBeFalsy();
        scope.campaign.seedDeployText = '';
        scope.seedDeployListUpdated();
        expect(scope.campaign.seedDeployErrorMessage).toBe('This is a required field; at least one valid email must be included.');
        scope.campaign.seedDeployText = 'testInvalidEmail';
        scope.seedDeployListUpdated();
        expect(scope.campaign.seedDeployErrorMessage).toBe('Please enter at least one valid email address in the format of EWT-DCE@aexp.com');
        scope.campaign.seedDeployText = 'test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com;test@aexp.com';
        scope.seedDeployListUpdated();
        expect(scope.campaign.seedDeployErrorMessage).toBe('There is a maximum of 15 emails.');
      });
    });
  });

  /**
   * @Featured: Existing Other campaign Test 
   */
  describe('Test for Other NON Existing Approved Campaign', function() {
    beforeEach(function() {
      campaignMockData.approvedMockCampaign.emailType.codeName = 'ET_OTHER';
    });
    beforeEach(inject(loadewtCampaignController(campaignMockData.approvedMockCampaign)));
    it('Test that if the email type is ET_OTHER then verifyMhid should not be called', function() {
      spyOn(ewtMasterDataService, 'verifyMhid').and.callFake(function() {
        return true;
      });
      scope.campaign.emailType.codeName = 'ET_OTHER';
      scope.campaign.mailHistory[0] = mock_valid_mhid;
      scope.checkMhid();
      expect(ewtMasterDataService.verifyMhid).not.toHaveBeenCalled();
    });
  });
  /**
   * @Featured: Existing MA campaign Test 
   */
  describe('Tests for Existing MA Approved Campaign', function() {
    var mhid_mock = {
      'mhid': 'dsgdfgsd',
      'incomplete': true,
      'startDate': '2025-11-25T18:30:00.000Z'
    };
    beforeEach(function() {
      campaignMockData.approvedMockMACampaign.deploymentDates[0] = new Date(campaignMockData.approvedMockMACampaign.deploymentDates[0]);
    });
    /**
     * @Describe: MA Approved campaign with no incomplete fields
     */
    describe('Test for Approved MA Campaign with no incomplete mhid fields', function() {
      var mock_MA_new_mhid = {
        "mhid": "SFDSADFA",
        "startDate": "2025-12-02T18:30:00.000Z",
        'newSrcCodes': ['CELL2']
      };
      var oldMHID = 'SFDSADFA';
      var mock_MA_invalid_mhid = {
        "mhid": "SFDSadfa",
        "startDate": "2025-12-02T18:30:00.000Z",
        'newSrcCodes': ['CELL1', 'CELL3']
      };
      var mock_MA_invalid_new_mhid = {
        "mhid": "SFDSADFA",
        "startDate": "2025-12-02T18:30:00.000Z",
        'newSrcCodes': ['CELL1', 'CELL3']
      };
      var mock_MA_valid_existingMHID = {
        "mhid": "SFDSADFA",
        "startDate": "2025-12-02T18:30:00.000Z",
        "cell": {
          "srcCode": "CELL3",
          "description": "test",
          "type": {
            "code": "T",
            "codeName": "test",
            "name": "Mailable (Test)"
          },
          "isLinkedToMHID": true,
          "removeAlternative": "Cannot remove as linked to a MHID",
          "editAleternative": "Cannot edit as linked to a MHID"
        },
        "cellError": true
      };
      beforeEach(function() {
        campaignMockData.approvedMockMACampaign.previewEmailList = ['test@aexp.com', 'test@aexp.com'];
        campaignMockData.approvedMockMACampaign.deployEmailList = ['test@aexp.com', 'test@aexp.com'];
        campaignMockData.approvedMockMACampaign.mailHistory = [{
          "mhid": "SFDSADFA",
          "startDate": "2025-12-02T18:30:00.000Z",
          "cell": {
            "srcCode": "CELL1",
            "description": "test",
            "type": {
              "_id": "56137306f23bae527e374d68",
              "code": "T",
              "codeName": "test",
              "name": "Mailable (Test)"
            },
            "isLinkedToMHID": true,
            "removeAlternative": "Cannot remove as linked to a MHID",
            "editAleternative": "Cannot edit as linked to a MHID"
          },
        }, {
          "mhid": "SFDSADFA",
          "startDate": "2025-12-02T18:30:00.000Z",
          "cell": {
            "type": {
              "name": "Holdout (Control)",
              "codeName": "control",
              "code": "C",
              "_id": "56137306f23bae527e374d69"
            },
            "description": "test",
            "srcCode": "CELL3"
          },
        }];
      });
      beforeEach(inject(loadewtCampaignController(campaignMockData.approvedMockMACampaign)));

      it('Campaign should be an Marketing Automation', function() {
        expect(scope.campaign.emailType.codeName).toBe('ET_MA');
      });

      it('For MA Campaign the arbitration status defaul should be Non-Arbitration', function() {
        expect(scope.campaign.arbitration.code).toBe('N');
      });
      describe('Test on add new mhid function for approved campaigns', function() {
        it('Test on addNewMHID that it should be a defined function', function() {
          expect(scope.addNewMHID).toBeDefined();
          expect(typeof scope.addNewMHID).toBe('function');
        });


        it('Test on addNewMHID that it should check for uniqueness and reset newMhidObj', function() {
          scope.campaign.newMhidObj = mhid_mock;
          scope.addNewMHID(mhid_mock, 'add', 2);
          scope.campaign.mailHistory.push(mhid_mock);
          expect(scope.campaign.newMhidObj).toEqual({});
          expect(scope.campaign.mailHistoryValid).toBeFalsy();
          var mhid_mock1 = {
            'mhid': 'dsgdfgsd',
            'incomplete': true,
            'startDate': '2025-11-25T18:30:00.000Z'
          };
          scope.addNewMHID(mhid_mock1, 'add', 3);
          expect(scope.campaign.mailHistoryValid).toBeTruthy();
          scope.campaign.mailHistory.pop();
          scope.addNewMHID(mhid_mock1, 'add', 3);
          expect(scope.campaign.mailHistoryValid).toBeFalsy();
        });
        it('Test to check when the action is add then addMHID function need to be invoked', function() {
          scope.addNewMHID(mhid_mock, 'add', 2);
          expect(scope.campaign.addMHID).toHaveBeenCalled();
        });

        it('Test on addNewMHID that it should call updateMHID method on update action', function() {
          scope.addNewMHID(mock_MA_valid_existingMHID, 'update', 2);
          expect(scope.campaign.updateMHID).toHaveBeenCalled();
        });
        it('Test on addNewMHID that addMHID and updateMHID function should be called if action is not "add" and "update"', function() {
          scope.addNewMHID(mhid_mock, 'test', 2);
          expect(scope.campaign.addMHID).not.toHaveBeenCalled();
          expect(scope.campaign.updateMHID).not.toHaveBeenCalled();
        });
        it('Test that there is no incomplete date in multiple mhids when the campaign is loaded when campaign is MA and there is atleast one mhid', function() {
          expect(scope.campaign.mailHistoryValid).toBeFalsy();
        });
      });

      describe('Test on edit mhid function which update the existing mhid', function() {
        it('Edit mhid should be a defined function', function() {
          expect(scope.editMHIDClick).toBeDefined();
          expect(typeof scope.editMHIDClick).toBe('function');
        });

        it('Test that when editMHIDClick is cliked it should reset newMhidObj', function() {
          scope.campaignForm = mock_campaignForm;
          scope.campaign.newMhidObj = {
            test: 'test'
          };
          expect(scope.campaign.newMhidObj).not.toEqual({});
          scope.editMHIDClick(mhid_mock);
          expect(scope.campaign.newMhidObj).toEqual({});
        });
      });

      describe('Test that when removeMHID function is cliked then it should remove one mhid at that index', function() {
        it('Test that removeMHID should be not be undefined and should be a function', function() {
          expect(scope.removeMHID).not.toBeUndefined();
          expect(typeof scope.removeMHID).toBe('function');
        });

        it('Test that it removes mhid at specific index provided', function() {
          var mailHistory_length = scope.campaign.mailHistory.length;
          scope.removeMHID(1);
          expect(scope.campaign.mailHistory.length).toBeLessThan(mailHistory_length);
        });

      });
      describe('Test on validateMHID function that it should validate the provided mhdidobj', function() {
        it('Test that validateMHID function to call campaign.validateMHID function if the length is equal to 8', function() {
          scope.validateNewMHID(mhid_mock);
          expect(scope.campaign.validateMHID).toHaveBeenCalled();
        });

        it('Test that validateMHID function not to call campaign.validateMHID function if the length is equal not equal to 8', function() {
          var invalid_mhid_mock = {
            mhid: '12478',
            startDate: '2025-11-25T18:30:00.000Z'
          };
          scope.validateNewMHID(invalid_mhid_mock);
          expect(scope.campaign.validateMHID).not.toHaveBeenCalled();
        });
      });

      it('Test to check checkPersonalizantionTab function return true if there is valid MHID to the campaign', function() {
        spyOn(scope.campaign, 'checkForStartDate').and.callFake(function() {
          return true;
        });
        scope.campaign.mailHistoryValid = false;
        expect(scope.checkPersonalizantionTab()).toBeTruthy();
        expect(scope.campaign.mailHistoryValid).toBeFalsy();
      });

      describe('Test on isUniqueCombination function', function() {
        it('isUniqueCombination should be a function by default', function() {
          expect(scope.isUniqueCombination).toBeDefined();
          expect(typeof scope.isUniqueCombination).toBe('function');
        });
        it('that mhid cell error will be false if the combination exits for new cells combination', function() {
          expect(scope.isUniqueCombination(mock_MA_new_mhid, null, null)).toBeTruthy();
          expect(scope.isUniqueCombination(mock_MA_invalid_new_mhid, null, null)).toBeFalsy();
        });
        it('that mhid cell error will be false if the combination exist for an updating mhid-cellid combination', function() {
          expect(scope.isUniqueCombination(mock_MA_valid_existingMHID, 0, oldMHID)).toBeFalsy();
        });
      });

      describe('Test on validateNewMHID  function', function() {
        it('that it should be a function by default', function() {
          expect(scope.validateNewMHID).toBeDefined();
          expect(typeof scope.validateNewMHID).toBe('function');
        });
        it('that it should convert lowerCase mhid to uppercase', function() {
          expect(mock_MA_invalid_mhid.mhid === mock_MA_invalid_mhid.mhid.toUpperCase()).toBeFalsy();
          scope.validateNewMHID(mock_MA_invalid_mhid, null, null);
          expect(mock_MA_invalid_mhid.mhid === mock_MA_invalid_mhid.mhid.toUpperCase()).toBeTruthy();
        });
      });
      it('that isMhidUnchanged return true if mhid is unchanged else return false', function() {
        expect(scope.isMhidUnchanged).toBeDefined();
        expect(typeof scope.isMhidUnchanged).toBe('function');
        scope.mhid = mock_mhid_SameAsParent;
        expect(scope.isMhidUnchanged(scope.mhid.edit, scope.mhid)).toBeTruthy();
        scope.mhid = mock_mhid_differntFromParent;
        expect(scope.isMhidUnchanged(scope.mhid.edit, scope.mhid)).toBeFalsy();
      });
      it('Trigger Evnets change function select the object from the dropdown selected', function() {
        scope.campaign.current.triggerEvent = {
          'codeName': 'EMAIL_DRIVEN'
        };
        scope.triggerEventChange();
        expect(scope.campaign.current.triggerEvent).toEqual(mock_trigger_events[0]);
        scope.campaign.current.triggerEvent = {
          'codeName': 'INTEGRATION_DRIVEN'
        };
        scope.triggerEventChange();
        expect(scope.campaign.current.triggerEvent).toEqual(mock_trigger_events[1]);
      });
      it('test calculateEndMinDate set mhid start date is less that deploymentDates to incomplete', function() {
        scope.campaign.mailHistory = [];
        scope.campaign.mailHistory.push(mock_mhid_with_less_than_StartDate);
        expect(scope.campaign.mailHistory[0].incomplete).toBeFalsy();
        scope.calculateEndMinDate();
        expect(scope.campaign.mailHistory[0].incomplete).toBeTruthy();
      });
    });
    /**
     * @Describe: MA Approved campaign with incomplete fields
     */
    describe('Test for Approved MA Campaign with incomplete mhid fields', function() {
      var mhid_mock = {
        'mhid': 'dsgdfgsd',
        'incomplete': true,
        'startDate': '2025-11-25T18:30:00.000Z',
        'cell': {
          "srcCode": "src01",
          "description": "test",
          "type": {
            "code": "C",
            "codeName": "control",
            "name": "Holdout (Control)"
          }
        }
      };
      beforeEach(function() {
        campaignMockData.approvedMockMACampaign.mailHistory.push(mhid_mock);
        campaignMockData.approvedMockMACampaign.previewEmailList = ['test@aexp.com', 'test@aexp.com'];
        campaignMockData.approvedMockMACampaign.deployEmailList = ['test@aexp.com', 'test@aexp.com'];
      });
      beforeEach(inject(loadewtCampaignController(campaignMockData.approvedMockMACampaign)));
      it('Test that there is wrong date in multiple mhids when the campaign is loaded when campaign is MA and there is atleast one mhid', function() {
        expect(scope.campaign.mailHistoryValid).toBeTruthy();
      });

      it('Test that when removeMHID is clicked and there are incomplete mhids sets then mailHistoryValid value will be true', function() {
        scope.removeMHID(1);
        expect(scope.campaign.mailHistoryValid).toBeTruthy();
      });

      it('Test that when validateNewMHID is called and there are incomplete mhids sets then mailHistoryValid value will be true', function() {
        scope.validateNewMHID(mhid_mock, 1);
        expect(scope.campaign.mailHistoryValid).toBeTruthy();
      });
      it('Test to check checkPersonalizantionTab when the mailHistory is empty', function() {
        scope.campaign.mailHistory = [];
        expect(scope.checkPersonalizantionTab()).toBeFalsy();
      });
      it('Test to check checkPersonalizantionTab function return false if there are checkForStartDate validateion error', function() {
        expect(scope.checkPersonalizantionTab()).toBeFalsy();
      });
      it('Test to check checkPersonalizantionTab function return false if there are incomplete fields', function() {
        scope.campaign.mailHistoryValid = false;
        expect(scope.checkPersonalizantionTab()).toBeFalsy();
        expect(scope.campaign.mailHistoryValid).toBeTruthy();
      });
      // it('Test that there is incomplete date in multiple mhids that it sets mailHistoryValid to true', function() {
      //   console.log(scope.campaign.mailHistory);
      //   expect(scope.campaign.mailHistoryValid).toBeTruthy();
      //   scope.campaign.mailHistory.push(mock_mhid_with_less_than_StartDate);
      //   console.log(scope.campaign.mailHistory);
      //   scope.addNewMHID(mock_mhid_with_less_than_StartDate, 'update', 10);
      //   expect(scope.campaign.mailHistoryValid).toBeFalsy();
      // });
    });
  });

  /**
   * @Featured: Existing Campaign Test Cases. 
   */
  describe('Tests for Existing Approved Servicing Campaign', function() {
    beforeEach(function() {
      campaignMockData.approvedMockServicingCampaign.previewEmailList = ['test@aexp.com', 'test@aexp.com'];
      campaignMockData.approvedMockServicingCampaign.deployEmailList = ['test@aexp.com', 'test@aexp.com'];
    });
    describe('Existing Servicing campaign with no mhid', function() {
      beforeEach(inject(loadewtCampaignController(campaignMockData.approvedMockServicingCampaign)));
      it('Test to checkPersonalizantionTab return true if there is no mhid', function() {
        expect(scope.checkPersonalizantionTab()).toBeTruthy();
      });
    });

    describe('Existing Servicing campaign with mhid already entered and saved', function() {
      beforeEach(function() {
        campaignMockData.approvedMockServicingCampaign.mailHistory = [{
          mhid: 'test1234'
        }];
      });
      beforeEach(inject(loadewtCampaignController(campaignMockData.approvedMockServicingCampaign)));

      it('Test that when mhid is updated then check that db call is done to check uniqueness of mhid over all campaigns', function() {
        spyOn(ewtMasterDataService, 'verifyMhid').and.callFake(function() {
          return true;
        });
        scope.checkMhid();
        expect(ewtMasterDataService.verifyMhid).not.toHaveBeenCalled();
      });
      it('Test to checkPersonalizantionTab return false if there is no valid mhid', function() {
        expect(scope.checkPersonalizantionTab()).toBeTruthy();
        scope.campaign.mailHistory[0] = mock_invalid_mhid;
        scope.mailHistory = true;
        expect(scope.checkPersonalizantionTab()).toBeFalsy();
      });
    });
  });

  describe('Tests for one offs', function() {
    beforeEach(inject(loadewtCampaignController(campaignMockData.newMockCampaign)));
    beforeEach(function() {

    });

    describe('Campaign end date should be :', function() {
      // check feb 28
      var startDateMock = {
        'sameMonth': {
          'duration': 1,
          'startDates': [new Date('01/07/2016'), new Date('01/08/2016'), new Date('01/09/2016'), new Date('01/10/2016'), new Date('01/11/2016'), new Date('01/12/2016'), new Date('01/13/2016')],
          'endDate': new Date('01/20/2016')
        },
        'nextMonth': {
          'duration': 3,
          'startDates': [new Date('01/07/2016'), new Date('01/08/2016'), new Date('01/09/2016'), new Date('01/10/2016'), new Date('01/11/2016'), new Date('01/12/2016'), new Date('01/13/2016')],
          'endDate': new Date('02/03/2016')
        },
        'nextYear': {
          'duration': 5,
          'startDates': [new Date('12/03/2015'), new Date('12/04/2015'), new Date('12/05/2015'), new Date('12/06/2015'), new Date('12/07/2015'), new Date('12/08/2015'), new Date('12/09/2015')],
          'endDate': new Date('01/13/2016')
        }
      };

      it('appropriate if it falls in same month', function() {
        // Set Campaign Duration
        scope.campaign.durationInWeeks = startDateMock.sameMonth.duration;
        startDateMock.sameMonth.startDates.forEach(function(mockStartDate) {
          scope.campaign.deploymentDates[0] = mockStartDate;
          scope.setEndDate();
          expect(scope.campaign.deploymentDates[1]).toEqual(startDateMock.sameMonth.endDate);
        });
      });

      it('appropriate if it falls in next month', function() {
        // Set Campaign Duration
        scope.campaign.durationInWeeks = startDateMock.nextMonth.duration;
        startDateMock.nextMonth.startDates.forEach(function(mockStartDate) {
          scope.campaign.deploymentDates[0] = mockStartDate;
          scope.setEndDate();
          expect(scope.campaign.deploymentDates[1]).toEqual(startDateMock.nextMonth.endDate);
        });
      });

      it('appropriate if it falls in same year', function() {
        // Set Campaign Duration
        scope.campaign.durationInWeeks = startDateMock.nextYear.duration;
        startDateMock.nextYear.startDates.forEach(function(mockStartDate) {
          scope.campaign.deploymentDates[0] = mockStartDate;
          scope.setEndDate();
          expect(scope.campaign.deploymentDates[1]).toEqual(startDateMock.nextYear.endDate);
        });
      });

      it('hidden/not shown if either of campaign start date or campaign duration is not selected', function() {
        // Set Campaign Duration
        delete scope.campaign.durationInWeeks;
        scope.campaign.deploymentDates = [];
        scope.setEndDate();
        expect(scope.campaign.deploymentDates.length).toBe(0);
      });
    });

  });

});
