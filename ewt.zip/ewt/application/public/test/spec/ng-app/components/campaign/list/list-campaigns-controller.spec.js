  'use strict';

  describe('Campaigns list controller', function() {

    var jasmineExt = new JasmineExtn();
    var mockData = jasmineExt.readJSON('base/test/spec/ng-app/components/campaign/list/JSON/mockData.json');
    var $rootScope,
      $scope,
      ewtCampaignsListController,
      initLoadData,
      campaigns,
      ewtCampaign,
      ewtUIState,
      $httpBackend,
      $q;

    var mockEvent = {
      preventDefault: function() {
        return true;
      },
      stopPropagation: function() {
        return true;
      }
    };
    var dateToString = function() {
      return true;
    }
    var promiseSuccessCallback = function(response) {
      var defer = $q.defer();
      defer.resolve(response);
      return defer.promise;
    };

    beforeEach(module('ewtApp'));
    beforeEach(module(function($provide) {
      $provide.value('APIServer', mockData.mockApiServer.APIServer);
      $provide.value('initialData', mockData.mockInitLoadString);
      $provide.value('initLoadData', mockData.mockInitLoadData);
      campaigns = mockData.mockCampaigns;
      campaigns.initLoadData = mockData.mockInitLoadData;
    }));
    /*
     * Loding the List Campaign Controller
     */
    beforeEach(inject(function(_$rootScope_, $controller, _initLoadData_, _ewtCampaign_, _ewtUIState_, _$httpBackend_, _$q_) {
      $rootScope = _$rootScope_;
      $q = _$q_;
      $scope = $rootScope.$new();
      initLoadData = _initLoadData_;
      $httpBackend = _$httpBackend_;
      ewtUIState = _ewtUIState_;
      ewtCampaign = new _ewtCampaign_();
      ewtCampaignsListController = $controller('ewtCampaignsListController', {
        $scope: $scope,
        campaigns: campaigns,
        ewtCampaign: ewtCampaign,
        ewtUIState: ewtUIState
      });
      $httpBackend.whenGET('ng-app/partials/index.html').respond(200, '');
      $httpBackend.whenGET('ng-app/partials/campaign/list.html').respond(200, '');
      $httpBackend.whenGET('ng-app/partials/user/sections/list.html').respond(200, '');
      $httpBackend.whenGET('api/v1/campaigns?columns=name,requestor.name,requestID,emailType,deploymentDates,state.name,state.codeName,lock.isLocked,lock.key,lock.owner.uid').respond(200, []);

    }));

    /*
     * Unit Test Cases starts here 
     */
    // @fucntion: toggleDatePicker
    it('Toggle datePicker function will toggle date piceker open or closed state', function() {
      var datePicker = {
          open: true
        },
        $event = mockEvent,
        expectOutput = !datePicker.open;
      $scope.toggleDatePicker($event, datePicker);
      expect(datePicker.open).toBe(expectOutput);
    });

    it('Toggle datePicker function will close datePicker for undefined value', function() {
      var datePicker = {
          open: undefined
        },
        $event = mockEvent;
      $scope.toggleDatePicker($event, datePicker);
      expect(datePicker.open).toBeFalsy();
    });
    // @fucntion: checkEndDate
    it('check endDate function will set endDate to null if endDate is less or equal to start date', function() {
      var startDate = {
          date: new Date()
        },
        endDate = {
          date: new Date()
        };
      expect(endDate.date).not.toBe(null);
      endDate.date = new Date(endDate.date.setDate(endDate.date.getDate() - 1));
      $scope.checkEndDate(startDate, endDate);
      expect(endDate.date).toBe(null);
    });
    it('check endDate function will remain same if endDate is greater than start date', function() {
      var startDate = {
          date: new Date()
        },
        endDate = {
          date: new Date()
        };
      endDate.date = new Date(endDate.date.setDate(endDate.date.getDate() + 2));
      expect(endDate.date).toBe(endDate.date);
      $scope.checkEndDate(startDate, endDate);
      expect(endDate.date).toBe(endDate.date);
    });

    // @function: changeSort
    it('Change sort function will set the sort type and order is ascending for the first time sorting on each header', function() {
      var type = 'requestID';
      $scope.sortType = null;
      $scope.changeSort(type);
      expect($scope.sortType).toBe(type);
      expect($scope.sortOrderReverse).toBeFalsy();
    });

    it('Change sort function will toggle the sort order if the sorting is already applied', function() {
      $scope.sortType = 'requestID';
      $scope.sortOrderReverse = false;
      var type = 'requestID';
      $scope.changeSort(type);
      expect($scope.sortOrderReverse).toBeTruthy();
      $scope.changeSort(type);
      expect($scope.sortOrderReverse).toBeFalsy();
    });

    //@function: search Campaigns

    it('search campaigns function will make the api call and get the promise', function() {
      var searchObject = {
        "uid": 'all',
        "mhid": 'testMHID',
        "deployStartDatePicker": {
          "open": false
        },
        "deployEndDatePicker": {
          "open": false
        },
        "requestedStartDatePicker": {
          "open": false
        },
        "requestedEndDatePicker": {
          "open": false
        },
        "businessUnit": "all",
        "emailType": "all",
        "campaignStatus": "all",
        "edis": "all"
      };
      $httpBackend.whenPOST('api/v1/filter/campaigns').respond(200, mockData.mockCampaigns.campaignsList);
      $scope.searchCampaigns(searchObject);
      $httpBackend.flush();
      expect($scope.campaigns).toBe(mockData.mockCampaigns);
    });

    it('transform searchObject function will update the searchObject', function() {
      var searchObject = {
        "deployStartDatePicker": {
          "date": "2016-01-11T18:30:00.000Z"
        },
        "deployEndDatePicker": {
          "date": "2016-02-02T18:30:00.000Z"
        },
        "requestedStartDatePicker": {
          "date": "2016-01-18T18:30:00.000Z"
        },
        "requestedEndDatePicker": {
          "date": "2016-01-24T18:30:00.000Z"
        },
        "uid": "testUser",
        "businessUnit": "TESTBU",
        "emailType": "TESTEMAIL",
        "campaignStatus": "testState",
        "requestID": "32423",
        "mhid": "23423423",
        "edis": "true"
      };
      $scope.campaigns.searchObject = searchObject;

      var date = new Date();
      searchObject.deployStartDatePicker.date = new Date(searchObject.deployStartDatePicker.date);
      searchObject.deployEndDatePicker.date = new Date(searchObject.deployEndDatePicker.date);
      searchObject.requestedStartDatePicker.date = new Date(searchObject.requestedStartDatePicker.date);
      searchObject.requestedEndDatePicker.date = new Date(searchObject.requestedEndDatePicker.date);
      $httpBackend.whenPOST('api/v1/filter/campaigns').respond(200, mockData.mockCampaigns.campaignsList);
      $scope.searchCampaigns(searchObject);
      $httpBackend.flush();
      expect($scope.campaigns).toBe(mockData.mockCampaigns);
    });

    it('transform searchObject function will set edis to boolen true and false from "true" and "false" ', function() {
      var searchObject = {
        "deployStartDatePicker": {
          "date": "2016-01-11T18:30:00.000Z"
        },
        "deployEndDatePicker": {
          "date": "2016-02-02T18:30:00.000Z"
        },
        "requestedStartDatePicker": {
          "date": "2016-01-18T18:30:00.000Z"
        },
        "requestedEndDatePicker": {
          "date": "2016-01-24T18:30:00.000Z"
        },
        "uid": "testUser",
        "businessUnit": "TESTBU",
        "emailType": "TESTEMAIL",
        "campaignStatus": "testState",
        "requestID": "32423",
        "mhid": "23423423",
        "edis": "true"
      };
      var date = new Date();
      $scope.campaigns.searchObject = searchObject;
      searchObject.deployStartDatePicker.date = new Date(searchObject.deployStartDatePicker.date);
      searchObject.deployEndDatePicker.date = new Date(searchObject.deployEndDatePicker.date);
      searchObject.requestedStartDatePicker.date = new Date(searchObject.requestedStartDatePicker.date);
      searchObject.requestedEndDatePicker.date = new Date(searchObject.requestedEndDatePicker.date);
      $httpBackend.whenPOST('api/v1/filter/campaigns').respond(200, mockData.mockCampaigns.campaignsList);
      $scope.searchCampaigns(searchObject);
      $httpBackend.flush();
      expect($scope.campaigns.searchObject.edis).toBeTruthy();

      $scope.campaigns.searchObject.edis = "false";
      $scope.searchCampaigns(searchObject);
      $httpBackend.flush();
      expect(searchObject.edis).toBeFalsy();
    });

    it('should open export campaign pop up window', function() {
      $scope.openExportFilterScreen();
      expect($scope.listModal.open).toHaveBeenCalledWith({
        'url': 'ng-app/partials/directives/modals/campaign-export.html',
        'resolve': {
          'purpose': 'exportCampaigns',
          'campaigns': $scope.campaignsList
        }
      })
    });

    describe('UI state function', function() {

      it('isVisible function will return boolean value', function() {
        var fieldName = 'test';
        var campaign = mockData.mockCampaigns.campaignsList[0];
        var user = "mm";
        var loggedInUser = 'mm';

        var output = $scope.uiState.isVisible(fieldName, campaign, user);
        expect(ewtUIState.isVisible).toHaveBeenCalled();
        expect(typeof output).toEqual('boolean');
      });

    });
  });
