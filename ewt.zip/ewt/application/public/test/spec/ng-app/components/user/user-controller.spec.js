'use strict';
describe('Tests on User Management Controller', function() {

  var jasmineExt = new JasmineExtn();
  var mockData = jasmineExt.readJSON('base/test/spec/ng-app/components/user/JSON/mockData.json');
  var $rootScope, $scope, ewtUserManagementController, initLoadData, ewtUsers, $state, ewtUtils, $q;


  var $httpBackend;
  var promiseSuccessCallback = function(response) {
    var defer = $q.defer();
    defer.resolve(response);
    return defer.promise;
  };

  var promiseFailureCallback = function(response) {
    var defer = $q.defer();
    defer.reject(response);
    return defer.promise;
  };
  var actionButtonOnModal = '';

  function createMockSection(section) {
    mockData.mockUsersData[section] = {
      $setPristine: function() {
        return true;
      },
      $setUntouched: function() {
        return true;
      },
      $invalid: false
    };
  }

  /* Loading Module here */
  beforeEach(module('ewtApp'));
  beforeEach(module(function($provide) {
    $provide.value('APIServer', mockData.mockApiServer);
    $provide.value('initialData', mockData.mockInitLoadString);
    $provide.value('initLoadData', mockData.mockInitLoadData);
  }));
  beforeEach(inject(function(_$rootScope_, $controller, _initLoadData_, _ewtUsers_, _$state_, _ewtUtils_, _$httpBackend_, _$q_) {
    $rootScope = _$rootScope_;
    $q = _$q_;
    $scope = $rootScope.$new();
    initLoadData = _initLoadData_;
    $state = _$state_;
    ewtUtils = _ewtUtils_;
    $httpBackend = _$httpBackend_;
    ewtUsers = new _ewtUsers_({
      initLoadData: mockData.mockInitLoadData
    });
    ewtUserManagementController = $controller('ewtUserManagementController', {
      $scope: $scope,
      ewtUsers: ewtUsers,
      $state: $state,
      utilities: ewtUtils
    });
  }));

  beforeEach(function() {
    ewtUsers.userList = mockData.mockNewAdminUser;
    ewtUsers.modal = {
      open: function(options) {
        options.actionButtons[actionButtonOnModal].callBack;
      }
    };
  });
  describe('Test that all default values are set to scope', function() {
    it('ewtUsers initLoadData is equal to scope default data', function() {
      expect(ewtUsers.initLoadData.businessUnits).toEqual($scope.businessUnits);
    });
    it(' Reactive Flag should be false by default', function() {
      expect($scope.reactiveStatusFlag).toBeFalsy();
    });
  });


  describe('Test on Find User function', function() {
    it(' that getUsers function get all user details of ewtUsers is to call from scope getUsers is called with success callback', function() {
      var response = mockData.mockUsersData.allUsers;
      spyOn(ewtUsers, 'getUsers').and.callFake(function() {
        return promiseSuccessCallback(response);
      });
      $scope.findUser();
      $scope.$digest();
      expect(ewtUsers.getUsers).toHaveBeenCalledWith($scope.search);
    });
    it(' that getUsers function of ewtUsers is to call from scope getUsers is called with failure callBack', function() {
      spyOn(ewtUsers, 'getUsers').and.callFake(function() {
        return promiseFailureCallback();
      });
      $scope.findUser();
      $scope.$digest();
      expect(ewtUsers.getUsers).toHaveBeenCalledWith($scope.search);
    });
  });
  it('Test on uidChange ', function() {
    $scope.addUserError = 'dummyTestMessage';
    $scope.uidChange();
    expect($scope.addUserError).toBe('');
  });
  describe('Test on add New User function', function() {
    beforeEach(function() {
      createMockSection('addUserSectionMock');
      $scope.addUserSection = mockData.mockUsersData.addUserSectionMock;
      $scope.newUser = mockData.mockUsersData.newUserObjMock;
    });
    it(' success callBack', function() {
      var response = mockData.mockUsersData.addUserMockSuccess;
      actionButtonOnModal = 0;
      spyOn(ewtUsers, 'addUser').and.callFake(function() {
        return promiseSuccessCallback(response);
      });
      $scope.addNewUser();
      $scope.$digest();
      expect(ewtUsers.addUser).toHaveBeenCalled();
    });
    it(' failure callBack with data object', function() {
      var response = mockData.mockUsersData.addUserMockFailure.alreadyExists;
      spyOn(ewtUsers, 'addUser').and.callFake(function() {
        return promiseFailureCallback(response);
      });
      $scope.addNewUser();
      $scope.$digest();
      expect(ewtUsers.addUser).toHaveBeenCalled();
    });
    it(' failure callBack without data object', function() {
      var response = mockData.mockUsersData.addUserMockFailure.withoutData;
      spyOn(ewtUsers, 'addUser').and.callFake(function() {
        return promiseFailureCallback(response);
      });
      $scope.addNewUser();
      $scope.$digest();
      expect(ewtUsers.addUser).toHaveBeenCalled();
    });
  });
  describe('Test on update user function', function() {
    it(' have to call ewtUsers update user function', function() {
      var editUserObj = mockData.mockUsersData.editUserObjMock;
      spyOn(ewtUsers, 'updateUser');
      $scope.updateUser(editUserObj);
      expect(ewtUsers.updateUser).toHaveBeenCalled();
    });
  });
  describe('Test on delete user function', function() {
    // var deleteUserSuccessHandlerMock = jasmine.createSpy('deleteUserSuccessHandler');
    var deleteUserSuccessHandler = function() {};

    it(' have to call ewtUsers delete user function ', function() {
      var deleteUserObject = mockData.mockUsersData.editUserObjMock;
      actionButtonOnModal = 0;
      spyOn(ewtUsers, 'deleteUser');
      $scope.deleteUser(deleteUserObject);
      expect(ewtUsers.deleteUser).toHaveBeenCalled();
    });

    it(' have to call ewtUsers delete user function with differnt message ', function() {
      var deleteUserObject = mockData.mockUsersData.editUserObjMock;
      $scope.ewtUsers.initLoadData.loggedInUser.uid = mockData.mockUsersData.editUserObjMock.uid;
      actionButtonOnModal = 0;
      spyOn(ewtUsers, 'deleteUser');
      $scope.deleteUser(deleteUserObject);
      expect(ewtUsers.deleteUser).toHaveBeenCalled();
    });
  });
  describe('Test on toggle selectedRow function', function() {
    var selectedUserObj, index;
    it(' selects the current row on click when no row is selected', function() {
      selectedUserObj = mockData.mockUsersData.allUsers[1];
      index = 1;
      $scope.toggleSelectUserRow(index, selectedUserObj);
      expect($scope.selectedRow).toBe(index);
      expect($scope.selectedUserObj).toEqual(selectedUserObj);
    });
    it(' toggle the current row selection on click when same row is already selected', function() {
      selectedUserObj = mockData.mockUsersData.allUsers[1];
      index = 1;
      $scope.selectedUserObj = mockData.mockUsersData.allUsers[1];
      $scope.toggleSelectUserRow(index, selectedUserObj);
      expect($scope.selectedRow).toBeNull();
      expect($scope.selectedUserObj).toBeUndefined();
    });
  });
  describe('Test on isUserActive  function', function() {
    var userObject;
    it(' should return false if there is the status is active', function() {
      userObject = mockData.mockUsersData.activeUserObjectMock;
      expect($scope.isUserActive(userObject)).toBeFalsy();
    });
    it(' should return false if there is no status delfined', function() {
      userObject = mockData.mockUsersData.activeUserObjectMock;
      delete userObject.status;
      expect($scope.isUserActive(userObject)).toBeFalsy();
    });
    it(' should return true if there is the status is inactive', function() {
      userObject = mockData.mockUsersData.inActiveUserObjectMock;
      expect($scope.isUserActive(userObject)).toBeTruthy();
    });
  });

  it('Test on clear search user form should clear the search form', function() {
    createMockSection('searchUserSecitonMock');
    $scope.searchUserSection = mockData.mockUsersData.searchUserSecitonMock;
    $scope.search = {
      'businessUnit': 'Gms'
    };
    $scope.clearSearchForm($scope.search, $scope.searchUserSecitonMock);
    expect($scope.search.businessUnit).toBe('');
  });
  it('Test on clear search user form without sending object', function() {
    createMockSection('searchUserSecitonMock');
    $scope.searchUserSection = mockData.mockUsersData.searchUserSecitonMock;
    $scope.search = null;
    $scope.clearSearchForm($scope.search, $scope.searchUserSecitonMock);
    expect($scope.searchUserSection.$invalid).toBeFalsy();
  });

});


describe('Tests on User Management Controller with inactive user object', function() {

  var jasmineExt = new JasmineExtn();
  var $rootScope, $scope, ewtUserManagementController, initLoadData, ewtUsers, $state, ewtUtils, $q;

  var mockData = jasmineExt.readJSON('base/test/spec/ng-app/components/user/JSON/mockData.json');



  /* Loading Module here */
  beforeEach(module('ewtApp'));
  beforeEach(module(function($provide) {
    $provide.value('APIServer', mockData.mockApiServer);
    $provide.value('initialData', mockData.mockInitLoadString);
    $provide.value('initLoadData', mockData.mockInitLoadData);
  }));
  beforeEach(inject(function(_$rootScope_, $controller, _initLoadData_, _ewtUsers_, _$state_, _ewtUtils_, _$httpBackend_, _$q_) {
    $rootScope = _$rootScope_;
    $q = _$q_;
    $scope = $rootScope.$new();
    initLoadData = _initLoadData_;
    $state = _$state_;
    ewtUtils = _ewtUtils_;
    ewtUsers = new _ewtUsers_(mockData.mockInactiveUsersData);
    ewtUserManagementController = $controller('ewtUserManagementController', {
      $scope: $scope,
      ewtUsers: ewtUsers,
      $state: $state,
      utilities: ewtUtils
    });
  }));

  describe('Test that  Reactive Flag should be true if the status is reactive or inactive', function() {
    it(' Inactive User', function() {
      $scope.edit = mockData.mockUsersData.editUserInactiveObjMock;
      expect($scope.reactiveStatusFlag).toBeTruthy();
    });
  });
});
