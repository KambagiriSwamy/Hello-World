'use strict';

describe('Campaign service', function() {

  /**
   * @Setting default MOCK values.
   */
  var ewtCampaign, resource, Upload, Filter, Q, State, $httpBackend, Window, ApiServer, ewtMasterDataService, cardProducts;
  var MockCardProducts = [{
    code: 'x001',
    name: 'Consumer Premium'
  }, {
    code: 'x002',
    name: 'Consumer CoBrand'
  }, {
    code: 'x003',
    name: 'Consumer Lending'
  }, {
    code: 'x004',
    name: 'Consumer Charge'
  }, {
    code: 'x005',
    name: 'OPEN Premium'
  }, {
    code: 'x006',
    name: 'OPEN CoBrand'
  }, {
    code: 'x007',
    name: 'OPEN Lending'
  }, {
    code: 'x008',
    name: 'OPEN Charge'
  }, ];
  var initLoadData = {
    'marketingManagers': [{
      '_id': '55f66cfaa80c0d427b4187d8',
      'value': 'avargh3',
      'phone': '212-624-9842',
      'email': 'alfred.t.varghese@aexp.com',
      'name': 'Alfred T arghese',
      'role': {
        'name': 'manager',
        'codeName': 'mm',
        'code': '001'
      }
    }, {
      '_id': '55f66cfaa80c0d427b4187d9',
      'value': 'nvishw',
      'phone': '312-624-9864',
      'email': 'Nagabhushan.a.andrew1@aexp.com',
      'name': 'Nagabhushan B Vishwanath',
      'role': {
        'name': 'manager',
        'codeName': 'mm',
        'code': '001'
      }
    }, {
      '_id': '55f66cfaa80c0d427b4187da',
      'value': 'nvishw',
      'phone': '312-624-9864',
      'email': 'Nagabhushan.a.andrew1@aexp.com',
      'name': 'Nagabhushan B Vishwanath',
      'role': {
        'name': 'manager',
        'codeName': 'mm',
        'code': '001'
      }
    }, {
      '_id': '55f66cfaa80c0d427b4187db',
      'value': 'nvishw',
      'phone': '312-624-9864',
      'email': 'Nagabhushan.a.andrew1@aexp.com',
      'name': 'Nagabhushan B Vishwanath',
      'role': {
        'name': 'manager',
        'codeName': 'mm',
        'code': '001'
      }
    }, {
      '_id': '55f66cfaa80c0d427b4187dc',
      'uid': 'randrew',
      'value': 'randrew',
      'phone': '212-624-9822',
      'email': 'roopa.a.andrew1@aexp.com',
      'name': ' Roopa Andrew',
      'role': {
        'name': 'manager',
        'codeName': 'mm',
        'code': '001'
      }
    }],
    'emailTypes': [{
      '_id': '55f66cf8a80c0d427b418765',
      'code': '012',
      'name': 'Servicing',
      'codeName': 'ET_SERVICING'
    }, {
      '_id': '55f66cf8a80c0d427b418766',
      'code': '013',
      'name': 'Marketing Automation',
      'codeName': 'ET_MA'
    }],
    'businessUnits': [{
      '_id': '55f66cf8a80c0d427b418767',
      'name': 'Global Merchant Services (GMS)',
      'code': 'U007',
      'codeName': 'BU_GMS'
    }, {
      '_id': '55f66cf8a80c0d427b418768',
      'name': 'GCC',
      'code': 'U006',
      'codeName': 'BU_GCC'
    }, {
      '_id': '55f66cf8a80c0d427b418769',
      'name': 'OPEN',
      'code': 'U005',
      'codeName': 'BU_OPEN'
    }, {
      '_id': '55f66cf8a80c0d427b41876a',
      'name': 'CCSG',
      'code': 'U004',
      'codeName': 'BU_CCSG'
    }, {
      '_id': '55f66cf8a80c0d427b41876b',
      'name': 'Publishing',
      'code': 'U003',
      'codeName': 'BU_PUBLISHING'
    }, {
      '_id': '55f66cf8a80c0d427b41876c',
      'name': 'GMPI',
      'code': 'U002',
      'codeName': 'BU_GMPI'
    }, {
      '_id': '55f66cf8a80c0d427b41876d',
      'name': 'Global Prepaid',
      'code': 'U019',
      'codeName': 'BU_GLOBAL_PREPAID'
    }, {
      '_id': '55f66cf8a80c0d427b41876e',
      'name': 'Consumer Travel',
      'code': 'U018',
      'codeName': 'BU_CONSUMER_TRAVEL'
    }, {
      '_id': '55f66cf9a80c0d427b41876f',
      'name': 'AXPi',
      'code': 'U017',
      'codeName': 'BU_AXPI'
    }, {
      '_id': '55f66cf9a80c0d427b418770',
      'name': 'MR',
      'code': 'U020',
      'codeName': 'BU_MR'
    }, {
      '_id': '55f66cf9a80c0d427b418771',
      'name': 'Card Services',
      'code': 'U021',
      'codeName': 'BU_CARD_SERVICES'
    }, {
      '_id': '55f66cf9a80c0d427b418772',
      'name': 'Direct Deposits',
      'code': 'U022',
      'codeName': 'BU_DIRECT_DEPOSITS'
    }, {
      '_id': '55f66cf9a80c0d427b418773',
      'name': 'Enterprise Growth Group (EGG)',
      'code': 'U023',
      'codeName': 'BU_EGG'
    }, {
      '_id': '55f66cf9a80c0d427b418774',
      'name': 'Digital Partnerships & Development (DPD)',
      'code': 'U024',
      'codeName': 'BU_DPD'
    }],
    'campaignTypes': [{
      '_id': '55f66cf9a80c0d427b418775',
      'name': 'Card Acquisition',
      'code': '008',
      'codeName': 'CT_CARD_ACQUISITION'
    }, {
      '_id': '55f66cf9a80c0d427b418776',
      'name': 'Balance Transfer',
      'code': '024',
      'codeName': 'CT_BALANCE_TRANSFER'
    }, {
      '_id': '55f66cf9a80c0d427b418777',
      'name': 'Card Services',
      'code': '026',
      'codeName': 'CT_CARD_SERVICES'
    }, {
      '_id': '55f66cf9a80c0d427b418778',
      'name': 'CTN',
      'code': '038',
      'codeName': 'CT_CTN'
    }, {
      '_id': '55f66cf9a80c0d427b418779',
      'name': 'LOC',
      'code': '041',
      'codeName': 'CT_LOC'
    }, {
      '_id': '55f66cf9a80c0d427b41877a',
      'name': 'Loyalty',
      'code': '043',
      'codeName': 'CT_LOYALTY'
    }, {
      '_id': '55f66cf9a80c0d427b41877b',
      'name': 'Self Servicing',
      'code': '048',
      'codeName': 'CT_SELF_SERVICING'
    }, {
      '_id': '55f66cf9a80c0d427b41877c',
      'name': 'Spend',
      'code': '057',
      'codeName': 'CT_SPEND'
    }, {
      '_id': '55f66cf9a80c0d427b41877d',
      'name': 'Publishing',
      'code': '060',
      'codeName': 'CT_PUBLISHING'
    }, {
      '_id': '55f66cf9a80c0d427b41877e',
      'name': 'Market Research',
      'code': '062',
      'codeName': 'CT_MARKET_RESEARCH'
    }],
    'cellTypes': [{
      '_id': '55f66cfaa80c0d427b4187de',
      'code': 'T',
      'codeName': 'test',
      'name': 'Mailable (Test)'
    }, {
      '_id': '55f66cfaa80c0d427b4187df',
      'code': 'C',
      'codeName': 'control',
      'name': 'Holdout (Control)'
    }],
    'loggedInUser': {
      '_id': '55f66cfaa80c0d427b4187dc',
      'uid': 'randrew',
      'value': 'randrew',
      'phone': '212-624-9822',
      'email': 'roopa.a.andrew1@aexp.com',
      'name': ' Roopa Andrew',
      'role': {
        'name': 'manager',
        'codeName': 'mm',
        'code': '001'
      },
      'leader': {
        'firstName': 'Dummy',
        'lastName': 'leader',
        'email': 'leader@aexp.com'
      }
    }
  };

  var dbMailHistory = [{
    mhid: 'updated3',
    startDate: new Date()
  }];

  /**
   * @Declaring and injecting values into module before running each test
   */
  beforeEach(module('ewtApp', function($provide) {
    $provide.value('APIServer', 'api/v1/');
    $provide.value('_cardProducts_', MockCardProducts);
    $provide.value('ewtMasterDataService', {
      MhidService: function(mhid, action) {
        if (action === 'add') {
          return {
            then: function(resolve, reject) {
              if (typeof resolve === 'function') {
                return resolve({
                  data: {
                    newMhid: mhid
                  }
                });
              }
            }
          };
        } else if (action === 'remove') {
          return {
            then: function(success) {
              return success();
            }
          };
        }
      },
      verifyMhid: function(mhid) {
        var present = false;
        dbMailHistory.forEach(function(value) {
          if (value.mhid === mhid) {
            present = true;
          }
        });
        if (present) {
          return {
            then: function(resolve, reject) {
              if (typeof resolve === 'function') {
                return resolve({
                  data: {
                    errorMessage: true
                  }
                });
              }
            }
          };
        } else {
          return {
            then: function(resolve, reject) {
              if (typeof resolve === 'function') {
                return resolve({
                  data: {
                    errorMessage: false
                  }
                });
              }
            }
          };
        }
      }
    });
  }));


  /**
   * @Mocking all promisses required
   */


  /**
   * @Injecting dependecies and instantiating EwtCampaign service before each test
   */


  // beforeEach(inject(function (_Upload_, _$filter_, $q, $state, $, _$httpBackend_, APIServer, _cardProducts_, _ewtCampaign_) {
  //   var EwtCampaign = _ewtCampaign_;
  //   ewtCampaign = new EwtCampaign();
  //   Upload = _Upload_;
  //   Filter = _$filter_;
  //   Q = $q;
  //   State = $state;
  //   $httpBackend = _$httpBackend_;
  //   ApiServer = APIServer;
  //   cardProducts = _cardProducts_;
  // }));

  beforeEach(inject(function($injector) {
    var EwtCampaign = $injector.get('ewtCampaign');
    ewtCampaign = new EwtCampaign();
    Filter = $injector.get('$filter');
  }));

  /**
   * @Test for: File actions in Campaign.
   */

  // describe('File operations: ', function () {
  //   var mockFile = {};
  //   var optionsPassed = {};
  //   var successResponse = {
  //     creativeVersion: 0,
  //     extension: '.jpg',
  //     fileName: 'Chris.jpg',
  //     gfsID: '563890cf4cb3a1684a26fca1',
  //     size: '79299'
  //   };
  //   var httpResponse;
  //   var httpCallBack = function (response) {
  //     httpResponse = response;
  //   };

  //   beforeEach(inject(function ($injector) {
  //     Upload = $injector.get('Upload');
  //     $httpBackend = $injector.get('$httpBackend');

  //     mockFile = {
  //       extension: '.jpg',
  //       fileName: 'Dummy.jpg',
  //       gfsID: '563738d31c8g92ec3a4b4e83',
  //       size: '79289'
  //     };
  //     spyOn(Upload, 'upload').and.callFake(function (options) {

  //       return {
  //         success : function (callBack) {
  //           callBack(successResponse);
  //         }
  //       };
  //     });

  //     /**
  //      * @MA tab, on deleting a version -
  //      *  api/v1/campaigns/delete/version/229/1
  //      *  
  //      *  URL      - api/v1/campaigns/delete/version/ requestID / VersionNo
  //      *  Response - {status: "success"}
  //      */

  //     $httpBackend.when('GET', 'api/v1/campaigns/delete/22222').respond(200, {'status': 'success'});

  //     // $httpBackend.when('GET', '/api/v1/campaigns/delete/version/229/1').respond(200, {'status': 'success'});
  //   }));

  //   // afterEach(function () {
  //   //   $httpBackend.verifyNoOutstandingExpectation();
  //   //   $httpBackend.verifyNoOutstandingRequest();

  //   //   // $httpBackend.flush();
  //   // });
  //   // afterEach(function() {
  //   //   $httpBackend.verifyNoOutstandingExpectation();
  //   //   $httpBackend.verifyNoOutstandingRequest();
  //   // });

  //   it('should Upload mock file', function () {
  //     var test = '';
  //     ewtCampaign.uploadMockFile(mockFile, 1);
  //     expect(ewtCampaign.creativeMockup).toEqual(successResponse);
  //     ewtCampaign.attachFileToCampaign('api/v1/creatives/uploadMock/1', mockFile, function () {
  //       test = 'attachFileToCampaign - Success';
  //     }, function () {
  //       test = 'attachFileToCampaign - Failure';
  //     });

  //     expect(test).toBe('attachFileToCampaign - Success');
  //   });


  //   it('should remove file for a version in MA tab', function () {

  //     $httpBackend.expectGET('api/v1/campaigns/delete/22222');
  //     ewtCampaign.removeFile('api/v1/campaigns/delete/22222', function (response) {
  //       console.log(response);
  //       httpResponse = response;
  //     });

  //     $httpBackend.flush();

  //     expect(httpResponse).toEqual({'status': 'success'});

  //     $httpBackend.verifyNoOutstandingExpectation();
  //     $httpBackend.verifyNoOutstandingRequest();
  //   });


  //   /*Work floe for remove file and remove mock functions

  //   removeFile:

  //   MA tab, on deleting a version -

  //     api/v1/campaigns/delete/version/229/1

  //     URL      = api/v1/campaigns/delete/version/ requestID / VersionNo
  //     Response = {status: "success"}


  //   MA tab, on deleting approval Document - 

  //     api/v1/ma/attachment/remove/229/56382671285a96a81613f7cc/approvalDocument

  //     URL      = api/v1/ma/attachment/remove/ requestID / file.gfsID / docType (instructionDocuments / approvalDocument)
  //     Response = []

  //   Attachment Tab, on deleting a attachment - 

  //     api/v1/creatives/229/5639dc275720ddf07ac5d5a9

  //     URL       = api/v1/creatives/ requestID / file.gfsID
  //     Response = [files] - Rest of the attachment objects


  //   removeMock:

  //   Description tab ,

  //     api/v1/creatives/removeMock/229/5636fbc32961963408015206

  //     URL      = api/v1/creatives/ requestID / file.gfsID
  //     Response = {status: "success"}*/


  // });

  /**
   * @Test for: creating, updating, validating, deleting cells from/to a Campaign.
   */

  describe('Campaign CELL should:', function() {
    var mockCell = {},
      actionButtonOnModal = '';

    beforeEach(inject(function() {
      actionButtonOnModal = '';
      ewtCampaign.emailType = {
        codeName: 'ET_SERVICING'
      };
      mockCell = {
        description: 'This is mock Cell',
        srcCode: '12341234',
        type: 'Test',
        versionNo: 50
      };
      ewtCampaign.cells = [];
      ewtCampaign.initLoadData = initLoadData;

      ewtCampaign.versions = [{
        number: 1,
        cells: [],
        subjects: []
      }, {
        number: 4,
        cells: [],
        subjects: []
      }, {
        number: 5,
        cells: [],
        subjects: []
      }, {
        number: 10,
        cells: [],
        subjects: []
      }, {
        number: 17,
        cells: [],
        subjects: []
      }];

      ewtCampaign.subjectLinesArr = [{
        number: 4,
        subjectLine: 'Dummy Subject Line - 1',
        espInstructions: 'Dummy description - 1'
      }, {
        number: 4,
        subjectLine: 'Dummy Subject Line - 2',
        espInstructions: 'Dummy description - 2'
      }, {
        number: 5,
        subjectLine: 'Dummy Subject Line - 3',
        espInstructions: 'Dummy description - 3'
      }, {
        number: 17,
        subjectLine: 'Dummy Subject Line - 4',
        espInstructions: 'Dummy description - 4'
      }];

      ewtCampaign.cells = [{
        description: 'This is mock Cell - 1',
        srcCode: '1',
        type: 'Test',
        versionNo: 10
      }, {
        description: 'This is mock Cell - 2',
        srcCode: '2',
        type: 'Test',
        versionNo: 1
      }, {
        description: 'This is mock Cell - 3',
        srcCode: '3',
        type: 'Test',
        versionNo: 1
      }, {
        description: 'This is mock Cell - 4',
        srcCode: '4',
        type: 'Test',
        versionNo: 4
      }, {
        description: 'This is mock Cell - 5',
        srcCode: '5',
        type: 'Test',
        versionNo: 5
      }, {
        description: 'This is mock Cell - 6',
        srcCode: '6',
        type: 'Test',
        versionNo: 17
      }, {
        description: 'This is mock Cell - 7',
        srcCode: '7',
        type: 'Test',
        versionNo: 17
      }];

      ewtCampaign.attachments = [{
        gfsID: 'Sample',
        type: {},
        creativeVersion: 1,
        fileName: 'Sample%20File.txt',
        extension: 'txt',
        size: 1024
      }, {
        gfsID: 'Sample',
        type: {},
        creativeVersion: 4,
        fileName: 'Sample%20File.txt',
        extension: 'txt',
        size: 1024
      }, {
        gfsID: 'Sample',
        type: {},
        creativeVersion: 10,
        fileName: 'Sample%20File.txt',
        extension: 'txt',
        size: 1024
      }, ];

      ewtCampaign.modal = {
        open: function(options) {
          options.actionButtons[actionButtonOnModal].callBack();
        }
      };
    }));

    it('be in valid if Cell is \'null\'', function() {
      expect(ewtCampaign.isCellProper({})).toBeFalsy();
    });

    it('skip version if it is MA Campaign', function() {
      ewtCampaign.emailType.codeName = 'ET_MA';
      expect(ewtCampaign.isCellProper(mockCell)).toBeTruthy();
    });

    it('consider version if it is Servicing Campaign', function() {
      expect(ewtCampaign.isCellProper(mockCell)).toBeTruthy();
      delete mockCell.versionNo;
      expect(ewtCampaign.isCellProper(mockCell)).toBeFalsy();
      ewtCampaign.emailType.codeName = 'trigger';
      expect(ewtCampaign.isCellProper(mockCell)).toBeUndefined();
    });

    it('check and add CELL', function() {
      var initialLength = ewtCampaign.cells.length;
      ewtCampaign.emailType = {
        codeName: 'ET_MA'
      };
      ewtCampaign.addCell(mockCell);
      expect(ewtCampaign.cells.length).toBe(initialLength + 1);
    });

    it('add Cell - Servicing Campaign', function() {
      var typeToTest = mockCell.type;
      ewtCampaign.cellAddUpdate(mockCell, 'add');
      expect(mockCell.type).not.toBe(typeToTest);
    });

    describe('removal in relation to subject lines for Servicing Campaign :', function() {

      beforeEach(inject(function() {

      }));

      it('Remove Cell if it is not the Last cell associated to version', function() {
        var initialLength = ewtCampaign.cells.length;
        ewtCampaign.removeCell(0);
        expect(ewtCampaign.cells.length).toBe(initialLength - 1);
      });

      it('Remove Cell if it is last cell to version and has no subjectlines to it', function() {
        var initialLength = ewtCampaign.cells.length;
        ewtCampaign.removeCell(1);
        ewtCampaign.removeCell(1);
        expect(ewtCampaign.cells.length).toBe(initialLength - 2);
      });

      it('prompt user on removing last cell associated to version having subjctLines and remove cell on clicking yes', function() {
        var initialLength = ewtCampaign.cells.length;
        actionButtonOnModal = 0;
        ewtCampaign.removeCell(3);
        expect(ewtCampaign.attachments[1].creativeVersion).toBe('');
        delete ewtCampaign.attachments;
        ewtCampaign.removeCell(3);
        expect(ewtCampaign.cells.length).toBe(initialLength - 2);
      });

      it('prompt user on removing last cell associated to version having subjctLines and persist cell on clicking no', function() {
        var initialLength = ewtCampaign.cells.length;
        actionButtonOnModal = 1;
        ewtCampaign.removeCell(3);
        expect(ewtCampaign.cells.length).toBe(initialLength);
      });
    });

    describe('Updating a Cell :', function() {

      beforeEach(inject(function() {


      }));

      it('update Cell (not linked to any subject) - Servicing Campaign', function() {
        ewtCampaign.cellAddUpdate(mockCell, 'update', 0);
        expect(ewtCampaign.cells[0]).toEqual(mockCell);
      });

      it('update cell which has multiple cells for a version', function() {
        ewtCampaign.cellAddUpdate(mockCell, 'update', 2);
        expect(ewtCampaign.cells[2]).toEqual(mockCell);
      });

      it('update cell if it has no subjectlines associated to it, even though it is last cell to that version', function() {
        ewtCampaign.cellAddUpdate(mockCell, 'update', 0);
        expect(ewtCampaign.cells[0]).toEqual(mockCell);
      });

      it('prompt user on updating last cell linked to a version, and remove corresponding subject lines if any if yes', function() {
        actionButtonOnModal = 0;
        ewtCampaign.cellAddUpdate(mockCell, 'update', 3);
        delete ewtCampaign.cells[3].editing;
        expect(ewtCampaign.cells[3]).toEqual(mockCell);
        delete ewtCampaign.attachments;
        ewtCampaign.cellAddUpdate(mockCell, 'update', 4);
        delete ewtCampaign.cells[4].editing;
        expect(ewtCampaign.cells[4]).toEqual(mockCell);
        ewtCampaign.cellAddUpdate(mockCell, 'update', 6);
        delete ewtCampaign.cells[6].editing;
        expect(ewtCampaign.cells[6]).toEqual(mockCell);
      });

      it('prompt user on updating last cell linked to a version, and retain corresponding subject lines if any if no', function() {
        actionButtonOnModal = 1;
        ewtCampaign.cellAddUpdate(mockCell, 'update', 3);
        expect(ewtCampaign.cells[3]).not.toEqual(mockCell);
      });
    });

    describe('Check for Unique cell:', function() {

      it('check if sorce code is unique and cases sensitive', function() {
        mockCell.srcCode = '1234asd';
        expect(ewtCampaign.isUniqueCell(mockCell)).toBeTruthy();
        mockCell.srcCode = '1234ASD';
        ewtCampaign.addCell(mockCell);
        expect(ewtCampaign.isUniqueCell(mockCell)).toBeFalsy();
      });

      it('check if sorce code is unique and cases sensitive while editing', function() {
        ewtCampaign.cells[3].srcCode = '4asd';
        var cellToUpdate = JSON.parse(JSON.stringify(ewtCampaign.cells[3]));
        cellToUpdate.srcCode = cellToUpdate.srcCode.toUpperCase();
        expect(ewtCampaign.isUniqueCell(cellToUpdate, 'editing', ewtCampaign.cells[3])).toBeFalsy();
        cellToUpdate.srcCode = '4asd';
        expect(ewtCampaign.isUniqueCell(cellToUpdate, 'editing', ewtCampaign.cells[3])).toBeTruthy();
        delete cellToUpdate.srcCode;
        expect(ewtCampaign.isUniqueCell(cellToUpdate, 'editing', ewtCampaign.cells[3])).toBeTruthy();
      });
    });

    describe('Operations on subjectLines', function() {
      it('add subjectline in to versions', function() {
        var newSubjectLine = {
          number: 14,
          subjectLine: 'Dummy Subject Line - 1',
          espInstructions: 'Dummy description - 1',
        };
        var initialLength = ewtCampaign.subjectLinesArr.length;
        ewtCampaign.addSubjectLine(newSubjectLine);
        expect(ewtCampaign.subjectLinesArr.length).toBe(initialLength + 1);
      });

      it('update subjectline of a version', function() {
        var newSubjectLine = {
          number: 1,
          subjectLine: 'Updated Dummy Subject Line - 1',
          espInstructions: 'Dummy description - 1',
        };
        ewtCampaign.updateSubjectLine(newSubjectLine, 0);
        expect(ewtCampaign.subjectLinesArr[0]).toEqual(newSubjectLine);
      });

      it('remove subjectline associated to a version number', function() {
        var initialLength = ewtCampaign.subjectLinesArr.length;
        ewtCampaign.removeSubjectLine(0);
        expect(ewtCampaign.subjectLinesArr.length).toBe(initialLength - 1);
        ewtCampaign.removeSubjectLine(-1);
        expect(ewtCampaign.subjectLinesArr.length).toBe(initialLength - 1);
      });
    });


    it('add Cell - MA Campaign', function() {
      ewtCampaign.emailType.codeName = 'ET_MA';
      ewtCampaign.initLoadData = initLoadData;
      var typeToTest = mockCell.type;
      ewtCampaign.cellAddUpdate(mockCell, 'add');
      expect(mockCell.type).not.toBe(typeToTest);
    });

    it('update Cell (not linked to any version) - MA Campaign', function() {
      ewtCampaign.emailType.codeName = 'ET_MA';
      ewtCampaign.initLoadData = initLoadData;
      ewtCampaign.versions = [];
      ewtCampaign.subjectLinesArr = [];
      var typeToTest = mockCell.type;
      ewtCampaign.cellAddUpdate(mockCell, 'add');
      mockCell.description = 'Changed description';
      delete mockCell.type;
      ewtCampaign.cellAddUpdate(mockCell, 'update', 0);
      expect(ewtCampaign.cells[0].description).toBe('Changed description');
    });

    it('determine if version is required based on email type and also its validation', function() {

      expect(ewtCampaign.isVersionRequired(mockCell)).toBeFalsy();
      delete mockCell.versionNo;
      expect(ewtCampaign.isVersionRequired(mockCell)).toBeTruthy();
      ewtCampaign.emailType.codeName = 'ET_MA';
      expect(ewtCampaign.isVersionRequired(mockCell)).toBeFalsy();
    });
  });

  /**
   * @Test for: creating, updating, validating, deleting subject lines from/to a Campaign.
   */

  /**
   * @Test for: creating, updating, validating, deleting MHID from/to a Campaign.
   */

  // describe('Operations on MHIDs: ', function () {
  //   var mockMHID, spyVariable;

  //   beforeEach(inject(function () {
  //     mockMHID = {
  //       mhid: '12312312',
  //       startDate: new Date()
  //     };
  //   }));


  //   describe('MA campaign', function () {
  //     beforeEach(inject(function () {
  //       ewtCampaign.mailHistory = [];
  //       ewtCampaign.emailType = {
  //         codeName: 'ET_MA'
  //       };
  //     }));

  //     it('Should add MHID to mail history of campaign', function () {
  //       var initialLength = ewtCampaign.mailHistory.length;
  //       ewtCampaign.requestID = 1;
  //       // ewtCampaign.newMhidObj = mockMHID;
  //       ewtCampaign.deploymentDates = [new Date()];
  //       ewtCampaign.addMHID(mockMHID);
  //       expect(ewtCampaign.mailHistory.length).toBe(initialLength + 1);
  //     });

  //     it('Should update MHID to mail history of campaign', function () {
  //       var initialLength = ewtCampaign.mailHistory.length;
  //       ewtCampaign.requestID = 1;
  //       ewtCampaign.newMhidObj = mockMHID;
  //       ewtCampaign.deploymentDates = [new Date()];
  //       ewtCampaign.addMHID();
  //       mockMHID.mhid = 'updated2';
  //       ewtCampaign.updateMHID(mockMHID, 0);
  //       expect(ewtCampaign.mailHistory.length).toBe(initialLength + 1);
  //     });

  //     it('Should remove MHID to mail history of campaign', function () {
  //       var initialLength = ewtCampaign.mailHistory.length;
  //       ewtCampaign.requestID = 1;
  //       ewtCampaign.newMhidObj = mockMHID;
  //       ewtCampaign.deploymentDates = [new Date()];
  //       ewtCampaign.addMHID();
  //       ewtCampaign.removeMHID(mockMHID);
  //       ewtCampaign.mailHistory.splice(0, 1); // Should be cleaned after reorganizing code
  //       expect(ewtCampaign.mailHistory.length).toBe(initialLength);
  //     });


  //     describe('validating MHIDs : ', function () {
  //       var initialLength;
  //       beforeEach(inject(function () {
  //         ewtCampaign.mailHistory =[
  //           {
  //             mhid: '12312311',
  //             startDate: new Date('Sat Oct 27 2015 15:29:54 GMT+0530 (India Standard Time)')
  //           },
  //           {
  //             mhid: '12312312',
  //             startDate: new Date()
  //           },
  //           {
  //             mhid: '12312313',
  //             startDate: new Date()
  //           },
  //           {
  //             mhid: '12312314',
  //             startDate: new Date()
  //           },
  //           {
  //             mhid: '12312315',
  //             startDate: new Date()
  //           },
  //           {
  //             mhid: '12312316',
  //             startDate: new Date()
  //           }
  //         ];
  //         initialLength = ewtCampaign.mailHistory.length;
  //         ewtCampaign.requestID = 1;
  //         ewtCampaign.deploymentDates = [new Date()];
  //       }));

  //       it ('should validate MHID that Exists locally', function () {
  //         ewtCampaign.validateMHID(mockMHID);
  //         expect(mockMHID.isnewMHIDValid).toEqual({
  //           status: true,
  //           message: 'MHID Exists locally'
  //         });
  //       });

  //       it ('should validate for new MHID', function () {
  //         mockMHID.mhid = 'updated2';
  //         ewtCampaign.validateMHID(mockMHID);
  //         expect(mockMHID.isnewMHIDValid).toEqual({
  //           status: false,
  //           message: 'New MHID'
  //         });
  //       });

  //       it ('should check if MHID exosts in DB for servicing campaign', function () {
  //         ewtCampaign.emailType.codeName = 'ET_SERVICING';
  //         mockMHID.mhid = 'updated3';
  //         ewtCampaign.validateMHID(mockMHID);
  //         expect(mockMHID.isnewMHIDValid).toEqual({
  //           status: true,
  //           message: 'MHID already Exists in DB'
  //         });
  //         ewtCampaign.emailType.codeName = 'ET_ONEOFF';
  //         ewtCampaign.validateMHID(mockMHID);
  //       });

  //       it ('should validate MHID if it is same as parent', function () {
  //         ewtCampaign.validateMHID(mockMHID, 1);
  //         expect(mockMHID.isnewMHIDValid).toEqual({
  //           status: false,
  //           message: 'Same as parent'
  //         });
  //       });
  //     });
  //   });
  // });

  /**
   * @Test for: Date operations in Campaign.
   */

  /**
   * @Test for: MA version operations in Campaign.
   */
  describe('Operations on MA tab', function() {

    var mockMaVersion;
    beforeEach(inject(function(_Upload_) {
      Upload = _Upload_;
      ewtCampaign.ma = {
        approvalDocuments: [{
          extension: '.xlsx',
          fileName: 'SampleCells.xlsx',
          gfsID: '56382673285a96a81613f7d0',
          size: '11452'
        }],
        disengagementValue: 4,
        instructionDocuments: [{
          extension: '.xlsx',
          fileName: 'SampleCells.xlsx',
          gfsID: '56382673285a96a81613f7d0',
          size: '11452'
        }],
        maCells: [],
        maVersions: [{
          creativeDocument: [{
            extension: '.jpg',
            fileName: 'Chris.jpg',
            gfsID: '563738d31c8f92ec3a4b4e83',
            size: '79299'
          }],
          poid: 'aass:1231',
          subjectLine: 'asdasd',
          triggerEvent: {
            codeName: 'INTEGRATION_DRIVEN',
            name: 'Integration Driven'
          },
          versionId: 1,
          versionName: 'dddd'
        }, {
          creativeDocument: [{
            extension: '.xlsx',
            fileName: 'export2.xlsx',
            gfsID: '56382667285a96a81613f7c2',
            size: '132061'
          }, {
            extension: '.jpg',
            fileName: 'Chris.jpg',
            gfsID: '563738d31c8f92ec3a4b4e83',
            size: '79299'
          }, {
            extension: '.xlsx',
            fileName: 'export1.xlsx',
            gfsID: '56382667285a96a81613f7c1',
            size: '132061'
          }, {
            extension: '.xlsx',
            fileName: 'EWT_Fields_v12.xlsx',
            gfsID: '56382667285a96a81613f7c0',
            size: '132061'
          }],
          subjectLine: 'asdasdasda',
          triggerEvent: {
            codeName: 'EMAIL_DRIVEN',
            name: 'Email Driven'
          },
          versionId: 2,
          versionName: 'dasdee'
        }]
      };
      mockMaVersion = {
        creativeDocument: [{
          extension: '.jpg',
          fileName: 'Dummy.jpg',
          gfsID: '563738d31c8g92ec3a4b4e83',
          size: '79289'
        }],
        poid: 'face:luck',
        subjectLine: 'test dubject line',
        triggerEvent: {
          codeName: 'INTEGRATION_DRIVEN',
          name: 'Integration Driven'
        },
        versionId: 1,
        versionName: 'Test version name'
      };

      spyOn(Upload, 'upload').and.callFake(function(options) {
        return {
          success: function(callBack) {
            callBack('Upload Called');
          }
        };
      });

    }));

    it('Shouild generate version ID', function() {
      ewtCampaign.versionIdGenerator();
      expect(ewtCampaign.currentMAVersionId).toBe(1);
      ewtCampaign.versionIdGenerator('12sfasd');
      expect(ewtCampaign.currentMAVersionId).toBe(13);
    });

    it('should update a MA version', function() {
      var initialLength = ewtCampaign.ma.maVersions.length;
      ewtCampaign.updateMAVersion(mockMaVersion);
      expect(ewtCampaign.ma.maVersions.length).toBe(initialLength);
    });

    it('should not update if version id is not present', function() {
      var initialLength = ewtCampaign.ma.maVersions.length;
      mockMaVersion.versionId = 4;
      ewtCampaign.updateMAVersion(mockMaVersion);
      expect(ewtCampaign.ma.maVersions.length).toBe(initialLength);
    });

    it('should upload files on saving', function() {
      var response = '';
      ewtCampaign.attachVersionFileToCampaign('api/v1/campaigns/version/229/versionAttachment/2', mockMaVersion.creativeDocument, mockMaVersion, function(testResponse) {
        response = testResponse;
      });
      expect(response).toBe('Upload Called');
    });

    it('should remove uploaded file', function() {
      var uploadedFile = {
        fileName: 'export1.xlsx',
        lastModified: 1445229850000,
        name: 'export1.xlsx',
        size: 11817,
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        webkitRelativePath: '',
        gfsID: '12131465664gev934123n41234'
      };
      ewtCampaign.current = {
        deletedFile: []
      };
      ewtCampaign.removeVersionFile(uploadedFile);
      expect(ewtCampaign.current.deletedFile.length).toBe(1);
      expect(ewtCampaign.current.deletedFile[0]._id).toBe(uploadedFile.gfsID);

      delete ewtCampaign.current.deletedFile;
      delete uploadedFile.gfsID;
      ewtCampaign.removeVersionFile(uploadedFile);
      expect(ewtCampaign.current.deletedFile.length).toBe(0);
    });
  });
  /**
   * @Test for: Other operations - Notes slide Out and so on.
   */
  it('Should add comments', function() {
    ewtCampaign.initLoadData = initLoadData;
    ewtCampaign.comments = [];
    ewtCampaign.addComment('Sample Test');
    expect(ewtCampaign.comments.length).toBe(1);
    ewtCampaign.addComment();
    expect(ewtCampaign.comments.length).toBe(1);
  });

  /**
   * @Test for: Operations to save, update, create campaign
   */

  /**
   * @Test for: Seed List validation
   */
  describe('Operations on Seed List :', function() {

    it('should validate strings in seedlists', function() {
      var validSeeds = 'asd@aas.com;asd@sa.com; sdfsd23@asda.com';
      var invalidSeeds = 'asd@aas.com;asd@sa.com sdfsd23@asda.com';

      expect(ewtCampaign.validateSeedEmailList(invalidSeeds, [], 15)).toBe('invalid');
      expect(ewtCampaign.validateSeedEmailList(validSeeds, [], 15)).toBeTruthy();
    });

    it('should handle errors in seed validations', function() {
      var seeds = 'ase@dfas.com;ase@dfas.com;ase@dfas.com;ase@dfas.com;ase@dfas.com;ase@dfas.com;ase@dfas.com;ase@dfas.com;ase@dfas.com;ase@dfas.com;ase@dfas.com;ase@dfas.com;ase@dfas.com;ase@dfas.com;ase@dfas.com;ase@dfas.com;ase@dfas.com;ase@dfas.com;ase@dfas.com;ase@dfas.com;ase@dfas.com;ase@dfas.com;ase@dfas.com;ase@dfas.com;ase@dfas.com;ase@dfas.com;';
      expect(ewtCampaign.validateSeedEmailList('', [], 15)).toBe('stringEmpty');
      expect(ewtCampaign.validateSeedEmailList(seeds, [], 15)).toBe('errMAxEmails');
      seeds = '; ;';
      expect(ewtCampaign.validateSeedEmailList(seeds, [], 15)).toBe('invalid');
    });
  });

  /**
   * @Test for: 
   */

  /**
   * @Test for: 
   */

  /**
   * @Test for: 
   */

  /**
   * @Test for: 
   */

  /**
   * @Test for: 
   */
});
