'use strict';

describe('Test User Core Functions ', function() {
  var jasmineExt = new JasmineExtn();
  var mockData = jasmineExt.readJSON('base/test/spec/ng-app/components/user/JSON/mockData.json');
  var mockUserData = jasmineExt.readJSON('base/test/spec/ng-app/core/classes/JSON/user.json');

  var ewtUsers, $state, $rootScope, $httpBackend, $q;
  var promiseSuccessCallback = function(response) {
    var defer = $q.defer();
    defer.resolve(response);
    return defer.promise;
  };

  var promiseFailureCallback = function(response) {
    var defer = $q.defer();
    defer.reject(response);
    return defer.promise;
  };
  var actionButtonOnModal;
  beforeEach(module('ewtApp', function($provide) {
    $provide.value('APIServer', 'api/v1/');
    $provide.value('initialData', mockData.mockInitLoadString);
  }));

  beforeEach(inject(function($injector, _$state_, _$rootScope_, _$httpBackend_, _$q_) {
    var EwtUsers = $injector.get('ewtUsers');
    $rootScope = _$rootScope_;
    $httpBackend = _$httpBackend_;
    ewtUsers = new EwtUsers();
    $state = _$state_;
    $q = _$q_;
    $httpBackend.whenGET('ng-app/partials/index.html').respond(200, '');
    $httpBackend.whenGET('ng-app/partials/campaign/list.html').respond(200, '');
    $httpBackend.whenGET('ng-app/partials/user/sections/list.html').respond(200, '');
    $httpBackend.whenGET('api/v1/campaigns?columns=name,requestor.name,requestID,emailType,deploymentDates,state.name,state.codeName,lock.isLocked,lock.key,lock.owner._id').respond(200, []);
  }));

  describe(' find user function', function() {
    beforeEach(function() {});
    it(' switches the state', function() {
      spyOn($state, 'go');
      var searchObj = {};
      ewtUsers.findUser(searchObj);
      expect($state.go).toHaveBeenCalledWith('app.auth.users.list', {
        search: searchObj
      });
    });
  });

  describe(' get users function', function() {
    it(' get specific user if _id is specified', function() {
      var response = {
        'Test': 'TestUser'
      };
      $httpBackend.whenGET('api/v1/user/12342342353').respond(200, response);
      var searchObj = {
        '_id': '12342342353',
        'businessUnit': 'TestBU'
      };
      var output = ewtUsers.getUsers(searchObj);
      $httpBackend.flush();
      expect(output.$$state).toBeDefined();
    });

    it(' get all user if no search._id is specified', function() {
      var response = {
        'Test': 'TestUser'
      };
      $httpBackend.whenPOST('api/v1/users/search').respond(200, []);
      var searchObj = {
        'businessUnit': 'TestBU'
      };
      var output = ewtUsers.getUsers(searchObj);
      $httpBackend.flush();
      expect(output.$$state.value.$resolved).toBeTruthy();
    });
  });

  describe(' add users function ', function() {
    var response, result, newUser;
    it(' return a resolved promise on adding user', function() {
      newUser = mockUserData.newUserMock;
      response = mockUserData.mockResponse.addUser;
      $httpBackend.whenPOST('api/v1/users').respond(200, response);
      result = ewtUsers.addUser(newUser);
      $httpBackend.flush();
      expect(result.$$state.value.$resolved).toBeTruthy();
    });
    it(' negative Scenario when no new user object return nothing', function() {
      newUser = null;
      response = ewtUsers.addUser(newUser);
      expect(response).toBeUndefined();
    });
  });

  describe(' update users function ', function() {

    var response, result, updateUserObj;
    beforeEach(function() {

      $httpBackend.whenPOST('api/v1/users/search').respond(200, response);
      spyOn($state, 'go');
    });

    it(' Update the user and swithches to list state', function() {
      updateUserObj = mockUserData.updateUserMockObj;
      updateUserObj.initLoadData = mockData.mockInitLoadData;
      response = mockUserData.mockResponse.updateUser;
      $httpBackend.whenPOST('api/v1/users/1231231231123').respond(200, response);
      result = ewtUsers.updateUser(updateUserObj);
      $httpBackend.flush();
      expect($state.go).toHaveBeenCalledWith('app.auth.users.list');
    });
    it(' negative Scenario when no user object then return nothing', function() {
      updateUserObj = null;
      response = ewtUsers.updateUser(updateUserObj);
      expect(response).toBeUndefined();
    });
  });

  describe(' delete user', function() {
    beforeEach(function() {
      ewtUsers.modal = {
        open: function(options) {
          options.actionButtons[actionButtonOnModal].callBack();
        }
      };
      spyOn($state, 'go');
    });
    it(' deletes user select yes when popup comes and current state is not edit', function() {
      var deleteUser = mockUserData.deleteUserMock;
      var response = mockUserData.mockResponse.deleteUser;
      $httpBackend.whenGET('api/v1/users/delete/12345645641123').respond(200, response);
      actionButtonOnModal = 0;
      var deleteUserSuccessHandlerMock = jasmine.createSpy('deleteUserSuccessHandler');
      ewtUsers.deleteUser(deleteUser, deleteUserSuccessHandlerMock, 'test');
      $httpBackend.flush();
      expect($state.go).not.toHaveBeenCalled();
    });

    it(' deletes user select yes when popup comes and current state is edit', function() {
      var deleteUser = mockUserData.deleteUserMock;
      var response = mockUserData.mockResponse.deleteUser;
      $httpBackend.whenGET('api/v1/users/delete/12345645641123').respond(200, response);
      actionButtonOnModal = 0;
      $state.current.name = 'app.auth.users.edit';
      var deleteUserSuccessHandlerMock = jasmine.createSpy('deleteUserSuccessHandler');
      ewtUsers.deleteUser(deleteUser, deleteUserSuccessHandlerMock, 'test');
      $httpBackend.flush();
      expect($state.go).toHaveBeenCalledWith('app.auth.users.list');
    });

    it(' deletes user select yes when popup comes and response has no message', function() {
      var deleteUser = mockUserData.deleteUserMock;
      var response = mockUserData.mockResponse.deleteUser;
      $httpBackend.whenGET('api/v1/users/delete/12345645641123').respond(200, response);
      actionButtonOnModal = 0;
      delete response.msg;
      $state.current.name = 'app.auth.users.edit';
      var deleteUserSuccessHandlerMock = jasmine.createSpy('deleteUserSuccessHandler');
      ewtUsers.deleteUser(deleteUser, deleteUserSuccessHandlerMock, 'test');
      $httpBackend.flush();
      expect($state.go).not.toHaveBeenCalledWith('app.auth.users.list');
    });

    it(' deletes user select No when popup comes', function() {
      var deleteUser = mockUserData.deleteUserMock;
      var response = mockUserData.mockResponse.deleteUser;
      $httpBackend.whenGET('api/v1/users/delete/12345645641123').respond(200, response);
      actionButtonOnModal = 1;
      var deleteUserSuccessHandlerMock = jasmine.createSpy('deleteUserSuccessHandler');
      ewtUsers.deleteUser(deleteUser, deleteUserSuccessHandlerMock, 'test');
      $httpBackend.flush();
      expect($state.go).not.toHaveBeenCalled();
    });

    it(' negative Scenario when no delete object then return nothing', function() {
      var deleteUser = null;
      var response = ewtUsers.deleteUser(deleteUser);
      expect(response).toBeUndefined();
    });
  });
});
