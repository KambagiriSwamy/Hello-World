'use strict';

describe('Service: campaignManagementSrv', function () {

  // load the service's module
  beforeEach(module('ewtApp'));

  // instantiate service
  var campaignManagementSrv;
  beforeEach(inject(function (_campaignManagementSrv_) {
    campaignManagementSrv = _campaignManagementSrv_;
  }));

  it('should do something', function () {
    expect(!!campaignManagementSrv).toBe(true);
  });

});
