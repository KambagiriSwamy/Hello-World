'use strict';
describe('New Campaign Management and New Campaign Service', function() {
  var rootScope, scope, ewtCampaignController, ewtMasterDataService, state, url, Campaign,
mockDynamicCampaignTypes = {},
  mockCardProducts = {},
  mockInitData = { 
    businessUnits: [
     { 
       value: 'U100',
       foreignKey: 'R100',
       name: 'Global Business Services' },
     { 
       value: 'U003',
       foreignKey: 'R003',
       name: 'Global Merchant Services' },
     { 
       value: 'U002',
       foreignKey: 'R002',
       name: 'Consumer Products and Services' },
     { 
       value: 'U001',
       foreignKey: 'R001',
       name: 'Technology' },
     { 
       value: 'U200',
       foreignKey: 'R100',
       name: 'Digital Partnerships & Development(DPD)'},
     { 
       value: 'U201',
       foreignKey: 'R100',
       name: 'GCC' 
      }
    ],
    emailTypes:[ 
      {
       value: '006',
       name: 'U S STANDARD' },
     { 
       value: '010',
       name: 'U S HOURLY TRIGGER' },
     { 
       value: '011',
       name: 'U S BATCH TRIGGER' },
     { 
       value: '012',
       name: 'BROADCAST' 
      } 
    ],
    loggedInUser: {
      email: "roopa.a.andrew1@aexp.com",
      firstName: "Roopa",
      lastName: "Renjit",
      leader: {
        email: "manjunath.a.arakere@aexp.com",
        firstName: "Manjunath",
        lastName: "Arakere",
        uid: "marakere"
      },
      name: " Roopa A Andrew",
      phone: "212-624-9845",
      role: "manager",
      uid: "randrew"
    },
    marketingManagers : {
      email: "roopa.a.andrew1@aexp.com",
      firstName: "Roopa",
      lastName: "Renjit",
      leader: {
        email: "manjunath.a.arakere@aexp.com",
        firstName: "Manjunath",
        lastName: "Arakere",
        uid: "marakere"
      },
      name: " Roopa A Andrew",
      phone: "212-624-9845",
      role: "manager",
      uid: "randrew"
    }
  },
  mockArrowMenuLables = [
    {label: 'General'},
    {label: 'Deplyoment'},
    {label: 'Personalization'},
    {label: 'Creative'},
    {label: 'Attachments'}
  ], 
  mockUserData={
    "role": "manager",
    "value": "rramamoh",
    "phone": "212-645-9872",
    "email": "Rashmi.a.andrew1@aexp.com",
    "name": "Rashmi Ramamohan",
    "leaderName": "Manjunath Arakere",
    "leaderEmail": "manjunath.a.arakere@aexp.com"    
  }, 
  mockCampaign={
    "state": "draft",
    "requestor": {
      "role": "manager",
      "value": "rramamoh",
      "phone": "212-645-9872",
      "email": "Rashmi.a.andrew1@aexp.com",
      "name": " Rashmi Ramamohan",
      "leaderName": "Manjunath Arakere",
      "leaderEmail": "manjunath.a.arakere@aexp.com"
    },
    "requestorPrimary": {
      "role": "manager",
      "value": "rramamoh",
      "phone": "212-645-9872",
      "email": "Rashmi.a.andrew1@aexp.com",
      "name": " Rashmi Ramamohan",
      "leaderName": "Manjunath Arakere",
      "leaderEmail": "manjunath.a.arakere@aexp.com"
    }
  };

  mockCampaign.saveAsDraft = function() {};
  mockCampaign.saveAsIs = function() {};
  mockCampaign.validateStatesTrue = function() {};
  mockCampaign.getSelectedObject = function() {};
  mockCampaign.$uploadAttachment = function() {};
  
  var mockMangersData = [];
  // loading the modules
  beforeEach(module('ui.router'));
  beforeEach(module('ewtNewCampaignModule'));
  beforeEach(
    inject(function ($rootScope, $controller, _masterDataService_, _$state_) {
      rootScope = $rootScope;
      scope = $rootScope.$new();
      ewtMasterDataService = _ewtMasterDataService_;
      state = _$state_;
      ewtCampaignController = $controller('ewtCampaignController', {
        $scope: scope,
        ewtMasterDataService: ewtMasterDataService,
        arrowMenuLables: mockArrowMenuLables,
        campaign: mockCampaign,
        initLoadData: mockInitData,
        dynamicCampaignTypes: mockDynamicCampaignTypes,
        cardProducts: mockCardProducts
      });
      spyOn(scope.campaign, "validateStatesTrue").and.callFake(function() {
        return true;
      });
    })
  );

  it('Test tabs data of default inputs', function() {
    expect(scope.tabs).toBeDefined();
    expect(scope.tabs.length).toBe(5);
  });



  it('Changes on BU change when BROADCAST', function() {
    scope.campaign.businessUnit = {"value":"U100","foreignKey":"R100","name":"Global Business Services"};
    scope.campaign.emailType = {'value': '012','name': 'BROADCAST' };
    scope.campaign.isCmNeedCategoryMultiple = "yes";
    scope.bussinessUnitChange();
    expect(scope.campaign.isCmNeedCategoryMultiple).toBe('no');
    expect(scope.campaign.cmNeedCategoryMultiSelectedList).toEqual([]);
  });

  it(' Business unit changes when not BROADCAST', function() {
    scope.campaign.emailType = {'value': '006','name': 'U S STANDARD' };
    ewtMasterDataService.getCMNeedCategory = function() {};
    spyOn(ewtMasterDataService, "getCMNeedCategory").and.callFake(function() {
        return true;
      });
    scope.bussinessUnitChange();
    expect(ewtMasterDataService.getCMNeedCategory).toHaveBeenCalled();
  });

  it(' Campaign Type changes', function() {
    scope.campaign.campaignType = {"value":"008","name":"Card Acquisition"};
    ewtMasterDataService.getCampaignSubTypes = function() {};
    spyOn(ewtMasterDataService, "getCampaignSubTypes").and.callFake(function() {
        return true;
      });
    scope.campaignTypeChange();
    expect(ewtMasterDataService.getCampaignSubTypes).toHaveBeenCalled();
  })



  it('should set weeks array depending on emailType', function() {
    scope.campaign.emailType = mockInitData.emailTypes[0];
    scope.emailTypeChange();
    expect(scope.weeksArray).toEqual([1,2,3,4,5,6]);

    scope.campaign.emailType = mockInitData.emailTypes[3];
    scope.emailTypeChange();
    expect(scope.weeksArray).toEqual([1]);

    scope.campaign.emailType = mockInitData.emailTypes[2];
    scope.emailTypeChange();
    expect(scope.weeksArray).toEqual([1,2,3,4,5,6,7,8,9,10,11,12]);
  });

  it('should change on STO change', function() {
    scope.campaignSTO = "no";
    scope.campaignSTOChange();
    expect(scope.weeksArray).toContain(0);

    scope.campaignSTO = "yes";
    scope.campaignSTOChange();
    expect(scope.weeksArray).not.toContain(0);
  });

  it('should change state to submitted4approval on submitting', function() {
    spyOn(scope.campaign, "saveAsIs").and.callFake(function() {
      return true;
    });
    scope.campaign.deploymentDate = new Date();
    scope.campaign.state = "draft";
    scope.submitCampaign();
    expect(scope.campaign.state).toBe("submitted4approval");
  });

  

  it('should return true if user is manager and state is valid', function() {
    expect(scope.managerCheckState("draft")).toBeTruthy();
    expect(scope.adminCheckState("draft")).not.toBeTruthy();
  });

  it('should return true if user is admin and state is valid', function() {
    scope.user.role = "admin";
    expect(scope.managerCheckState("draft")).not.toBeTruthy();
    expect(scope.adminCheckState("draft")).toBeTruthy();
  });

  it('should set Default values', function() {
    //scope.campaign.requestor = undefined;
    expect(scope.campaign.isCmNeedCategoryMultiple).toBe("no");
    expect(scope.campaign.mhids).toEqual([]);
    expect(scope.campaign.pznVariables).toEqual([]);
  });

  it('should disable tabs depending on user', function () {
    scope.user.role = "manager";
    expect(scope.managerTabsEnable("draft,submitted4approval")).toBeTruthy();
    scope.user.role = "admin";
    expect(scope.adminTabsEnable("draft,submitted4approval")).toBeTruthy();
    scope.user.role = "manager";
  });

  
  it('checking addCMCategory() function : cmNeedCategoryMultiSelectedList ', function() {
    var initArrayLen = scope.campaign.cmNeedCategoryMultiSelectedList.length;
    scope.campaign.cmNeedCategoryMultiListAvaialble = {
      "value" : "cm100",
      "foreignKey" : "U200",
      "name" : "Cards & Gifts"
    };
    scope.addcmCategory();
    expect(scope.campaign.cmNeedCategoryMultiSelectedList.length).toBeGreaterThan(initArrayLen);
    scope.campaign.cmNeedCategoryMultiListAvaialble = null;
    initArrayLen = scope.campaign.cmNeedCategoryMultiSelectedList.length;
    scope.addcmCategory();
    expect(scope.campaign.cmNeedCategoryMultiSelectedList.length).toBe(initArrayLen);
  });
  it('checking removecmCategory() function : cmNeedCategoryMultiListAvaialble ', function() {
    var initArrayLen = scope.data.cmNeedCategorysMultiSelect.length;
    scope.campaign.readyForcmListRemoval = {
      "value" : "cm100",
      "foreignKey" : "U200",
      "name" : "Cards & Gifts"
    };
    scope.removecmCategory();
    expect(scope.data.cmNeedCategorysMultiSelect.length).toBeGreaterThan(initArrayLen);
    scope.campaign.readyForcmListRemoval = null;
    initArrayLen = scope.data.cmNeedCategorysMultiSelect.length;
    scope.removecmCategory();
    expect(scope.data.cmNeedCategorysMultiSelect.length).toBe(initArrayLen);
  });
    
  // it('should resolve initial values for my Controller',function() {
  //   console.log(state.current);
  //   state.go('app.auth.campaigns.new');
  //   rootScope.$apply();
  //   console.log(state.current);
  // });


  it('testing the select Card Products with the check boxes ', function() {
    var noOfCardProducts = scope.campaign.cardProducts.length;
    var selectCard = {value: "x001", name: "Consumer Premium"},
        mockCardProducts = [];

    scope.campaign.cardProducts = mockCardProducts;
    spyOn(scope.campaign, "getSelectedObject").and.callFake(function() {
      return null;
    });
    scope.selectCardProduct(selectCard);
    expect(scope.campaign.cardProducts.length).toBe(noOfCardProducts+1);
  });

  it('testing the select Card Products with the check boxes ', function() {
    var noOfCardProducts = scope.campaign.cardProducts.length;
    var selectCard = {value: "x001", name: "Consumer Premium"};
        mockCardProducts = [
        {value: "x001", name: "Consumer Premium"}
      ];
    scope.campaign.cardProducts = mockCardProducts;
    spyOn(scope.campaign, "getSelectedObject").and.callFake(function() {
      return true;
    });

    scope.selectCardProduct(selectCard);
    expect(scope.campaign.cardProducts.length).toBe(noOfCardProducts-1);
  });

    it('should restore cmNeedCategory multi select options', function () {
    scope.campaign.cmNeedCategoryMultiSelectedList = [{
      "_id": "55b7a144f781120908687861",
      "value": "cm100",
      "foreignKey": "U200",
      "name": "Cards & Gifts"
    }, {
      "_id": "55b7a157f781120908687862",
      "value": "cm101",
      "foreignKey": "U200",
      "name": "Benifits and Rewards"
    }, {
      "_id": "55b7a19bf781120908687863",
      "value": "cm102",
      "foreignKey": "U201",
      "name": "Corporate Offers"
    }];
    scope.setDefaultCMneeds();
    expect(scope.campaign.cmNeedCategoryMultiSelectedList).toEqual([]);
  });

  it('should diable depending on date and mode', function () {
    var validDate = new Date();
    var InvalidDate = new Date("Sun Oct 25 2015 12:00:00 GMT+0530 (India Standard Time)");

    expect(scope.disabledDates(validDate,'day')).not.toBeTruthy();
    expect(scope.disabledDates(validDate,'month')).not.toBeTruthy();

    expect(scope.disabledDates(InvalidDate,'day')).toBeTruthy();
    expect(scope.disabledDates(InvalidDate,'month')).not.toBeTruthy();
  });

  it('should formate date', function () {
    var date = new Date();
    console.log(date.getMonth());
    var formated = (date.getMonth()+1) +'/'+date.getDate() +'/'+date.getFullYear();

    scope.campaign.deploymentDate = new Date();
    scope.submitCampaign();
    expect(scope.campaign.deploymentDate).toBe(formated);
  });

  it('should open date picker', function () {
    var event = {
      preventDefault: function () {},
      stopPropagation: function () {}
    };

    spyOn(event, "preventDefault").and.callFake(function() {
      return true;
    });
    spyOn(event, "stopPropagation").and.callFake(function() {
      return true;
    });

    scope.openDatePicker(event);
    expect(scope.opened).toBeTruthy();
  });

  it('should define mockFile', function () {
    var file = [
      {
        lastModified: 1440409054947,
        lastModifiedDate: new Date(),
        name: "EWT_Fields_v7.xlsx",
        size: 29446,
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        webkitRelativePath: ""
      }
    ];
    scope.mockFile = {};
    scope.uploadedFile = {};
    scope.uploadMock(file);
    expect(scope.mockFile).toEqual([file[0]]);
    expect(scope.uploadedFile).not.toEqual({});
  });

  it('view uploded creative', function () {
    delete scope.mockFile;
    expect(scope.viewMockUp()).not.toBeTruthy();

    scope.mockFile = {
      lastModified: 1440409054947,
      lastModifiedDate: new Date(),
      name: "EWT_Fields_v7.xlsx",
      size: 29446,
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      webkitRelativePath: ""
    };

    scope.viewMockUp();
  });
});


