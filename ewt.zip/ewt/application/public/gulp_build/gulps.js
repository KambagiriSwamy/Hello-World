/**
 * Created by dmore14 on 6/15/2015.
 */
var ngHtml2Js = require("gulp-ng-html2js");
var minifyHtml = require("gulp-minify-html");
var concat = require("gulp-concat");
var uglify = require("gulp-uglify");
var karma = require('karma').server;
var rename = require('gulp-rename');
var ngAnnotate = require('gulp-ng-annotate');
var runsequence = require('run-sequence');
var usemin = require('gulp-usemin');
var fs = require('fs-extra');
var usemin = require('gulp-usemin');
var minifyCss = require('gulp-minify-css');
var cdn = require('gulp-cdnizer');
var uncache = require('gulp-uncache');
var path = require('path');
var livereload = require('gulp-livereload');
var nodemon = require('gulp-nodemon');

var clean = require('./gulp_clean');
var replace = require('./gulp_replace');


var path_build = [
  '**/*',
  '!qa',
  '!test',
  '!reports',
  '!gulpfile.js',
  '!.*'
];

var post_build_clean = [
  'dist/application/public/scripts',
  'dist/application/public/gulp_build',
  'dist/application/public/test'
];



module.exports = function (gulp, config) {


  config.jumpstart.duster.destDirPath='/dist/application/public/js/dust-tpls';
  config.jumpstart.duster.srcDirPath= '/dist/application/public/views/common';
  config.jumpstart.duster.skipPathFromTemplateId= '/dist/application/public/views/';
  config.jumpstart.spud.destDirPath='/dist/application/public/locales/json';
  config.jumpstart.spud.srcDirPath= '/dist/application/public/locales';

  path_usemin = {
  
    src: config.root + '/dist/application/public/**/*.dust',
  
    output: config.root + '/',
    dest: config.root + '/dist/application/public',
    CDNSrcFiles: config.jumpstart.contentManagement.cdn.CDNSrcFiles,
    CDNBaseURL: config.jumpstart.contentManagement.cdn.CDNBaseURL
  };

  gulp.task('angular-tests','executes the frontend tests', function (done) {
    karma.start({
      configFile: config.root + '/application/public/test/karma.conf.js',
      singleRun: true
    }, done);
  });

  gulp.task('angular-dev-templates','Compiles .html angular partials and sets them into the $templateCache service in the development code',function () {
    var srcPath = config.root + '/application/public';
    var dstPath = config.root + '/application/public/scripts';
    return cacheTemplates(srcPath, dstPath);
  })


  gulp.task('angular-dev-annotate','angular application annotation in the develop folder', function () {
    var srcPath = config.root + '/application/public';
    var dstPath = config.root + '/application/public';
    return annotate(srcPath, dstPath);
  });

  gulp.task('angular-dev-insert-templates','Inserts the reference to the generated develop templates file', ['angular-dev-templates'], function () {

  
    var referenceFile='views/common/includes/js.dust';
    var dstPath='views/common/includes';
  


    referenceFile = config.root + '/application/public/'+referenceFile;
    dstPath = config.root + '/application/public/'+dstPath;
    var reference = 'scripts/built_partials.min.js';
    return insertTemplatesReference(referenceFile, reference,dstPath);
  });

  gulp.task('angular-dist-insert-templates','Inserts the reference to the generated production templates file', ['angular-dist-templates'], function () {

  
    var referenceFile='views/common/includes/js.dust';
    var dstPath='views/common/includes';
  


    referenceFile = config.root + '/application/public/'+referenceFile;
    dstPath = config.root + '/dist/application/public/'+dstPath;
    var reference = 'scripts/built_partials.min.js';
    return insertTemplatesReference(referenceFile, reference,dstPath);
  });

  gulp.task('angular-dist-templates','Compiles .html angular partials and sets them into the $templateCache service', function () {
    var srcPath = config.root + '/application/public';
    var dstPath = config.root + '/dist/application/public/scripts';
    return cacheTemplates(srcPath, dstPath);
  })


  gulp.task('angular-dist-annotate','angular application annotation in build context', function () {
    var srcPath = config.root + '/application/public';
    var dstPath = config.root + '/dist/application/public';
    return annotate(srcPath, dstPath);
  });

  gulp.task('build','builds your application and sets it ready for production',function () {
    var confs={
      duster:{},
      spud:{}
    };

  
    for(var conf in confs){
      for(var prop in config.jumpstart[conf]){
        confs[conf][prop]=config.jumpstart[conf][prop]
      }
    }

    config.jumpstart.duster.destDirPath='/dist/application/public/js/dust-tpls';
    config.jumpstart.duster.srcDirPath= '/dist/application/public/views/common';
    config.jumpstart.duster.skipPathFromTemplateId= '/dist/application/public/views/';
    config.jumpstart.spud.destDirPath='/dist/application/public/json';
    config.jumpstart.spud.srcDirPath= '/dist/application/public/locales';
  
    runsequence(
      'build-copy-folders',
      'angular-dist-annotate',
      'angular-dist-insert-templates',
    
      'convert-props-to-json',
    
      'usemin',
      'build-clean'
    );

  
    for(var conf in confs){
      for(var prop in confs[conf]){
        config.jumpstart[conf][prop]=confs[conf][prop];
      }
    }
  

  });

  gulp.task('build-copy-folders','Copies akk needed files from the develop location to the build location',function(){
    return gulp.src(path_build)
      .pipe(gulp.dest('dist/'))
  })

  gulp.task('build-clean','Deletes the unnecesary files from build folder',function(){

    post_build_clean.forEach(function(toRemove){
      toRemove=path.normalize(config.root+'/'+toRemove)
      fs.removeSync(toRemove);
    })


    return gulp.src(post_build_clean,{read:false})
      .pipe(clean())

  })

  function annotate(srcPath, dstPath) {
    var paths = [
      (srcPath + '/**/*.js'),
      ('!' + srcPath + '/node_modules/**/*'),
      ('!' + srcPath + '/bower_components/**/*')
    ]
    return gulp.src(paths)
      .pipe(ngAnnotate())
      .pipe(gulp.dest(dstPath));
  }

  function cacheTemplates(srcPath, cacheFile) {
    var paths = [
        (srcPath + '/**/*.html'),
        ('!' + srcPath + '/node_modules/**/*'),
        ('!' + srcPath + '/bower_components/**/*'),
    
    ]
    return gulp.src(paths)
      .pipe(minifyHtml({
        empty: true,
        spare: true,
        quotes: true
      }))
      .pipe(ngHtml2Js({
        moduleName: 'ewtApp',
        stripPrefix: (srcPath)
      }))
      .pipe(concat('built_partials.min.js'))
      .pipe(uglify())
      .pipe(gulp.dest(cacheFile));
  }

  function insertTemplatesReference(referenceFile, reference, newReferenceFile) {
    newReferenceFile = newReferenceFile===undefined ? referenceFile : newReferenceFile;
    gulp.src(referenceFile)
      .pipe(replace('<!-- ng-html2js placeholder -->', ('<script src="' + reference + '"></script>')))
      .pipe(gulp.dest(newReferenceFile));
  }

  gulp.task('usemin', 'Compresses and concats all JS and CSS that are inside the build tags', function() {
    return gulp.src(path_usemin.src)
      .pipe(usemin({
        outputRelativePath: path_usemin.output,
        css: [minifyCss(), 'concat'],
        js: [uglify({
          mangle: false
        })],
        jsTemplate: [uglify({
          mangle: false
        })]
      }))
      .pipe(cdn({
        files: path_usemin.CDNSrcFiles,
        defaultCDNBase: path_usemin.CDNBaseURL
      }))
      .pipe(uncache())
      .pipe(gulp.dest(path_usemin.dest));
  });


  gulp.task('serve:livereload','Allows server restart and browser autoreresh while modifying your app', function() {
    livereload.listen();

    nodemon({
      script: 'app.js',
      ext:'dust',
      delay: 10,
    }).on('restart', function() {
      gulp.src(['application/public/**/*'])
      .pipe(livereload())

    });
  })
  
}
