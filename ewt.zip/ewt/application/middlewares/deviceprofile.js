 /**
 * Module: 
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description:  - <DESC_HERE>
 */

'use strict';

var config = require('config');
var deviceProfileSVC = require('jumpstart-device-profile')(config.jumpstart.deviceProfile);

/*
 *  Sample URL filter to log all the incoming requests to console
 *  For more information on Middleware visit: http://expressjs.com/api.html#middleware
 */
module.exports = function (req, res, next) {

  if(config.jumpstart.deviceProfile.active){
    //getting device profile
    deviceProfileSVC.fetch(req, res, function(err){
      if(err !== null) {
        logger.internal('deviceProfile: ERROR occurred fetching device details' + err);
      }
    });
  }
  next();
};