 /**
  * Module: 
  *
  * --------------------------------------------------------------------------
  *
  * (C) Copyright 2014 American Express, Inc. All rights reserved.
  * The contents of this file represent American Express trade secrets and
  * are confidential. Use outside of American Express is prohibited and in
  * violation of copyright law.  Licence information of all dependent modules
  * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
  *
  *
  * Description:  - <DESC_HERE>
  */
 'use strict';

 module.exports = function(req, res, next) {
   logger.info('middleware.auth :: method entry');
   /*
   As in development env we have disabled sessions (no redis in local), so here we will mock the session.
   This manual setting of session is only for dev env, till we do not have redis in local setup and enable the redis session config.
   Below is the MM user, if you move the user to admin user in 'aplication/controllers/app.js' the also make the required change here.
    */
   if (!(req.session.loggedInUser) && (process.env.NODE_ENV === 'development')) {
     req.session.loggedInUser = {
       "_id": "5631cbdd84e82c38c507bd92",
       "uid": "knapoli",
       "value": "knapoli",
       "phone": "212-624-9822",
       "email": "kayla.poli@aexp.com",
       "name": "kayla poli",
       "role": {
         "name": "manager",
         "codeName": "mm",
         "code": "001"
       },
       "leader": {
         "firstName": "Dummy",
         "lastName": "leader",
         "email": "leader@aexp.com"
       }
     };
   }


   // check for valid user session. If 'loggedInUser' is set in session we are good to go, else return eror.
   if ((process.env.NODE_ENV !== 'development') && !req.session.loggedInUser) {
     return res.status(412).send({
       status: 'failure',
       code: 'SESSION_EXPIRED',
       showOnUI: true,
       reason: 'Your session has expired, kindly refresh the page.'
     });
   }
   next();
 };
