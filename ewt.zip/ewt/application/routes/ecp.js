/**
 * Created by smurugad on 10/5/2015.
 */
'use strict';

var logMiddleware = require('../middlewares/log'),
    cors = require('cors'),
    config = require('config'),
    validDomains = config.application.logging.validDomains,
    validDomainsRegex = [];
for (var i in validDomains) {
    validDomainsRegex.push(new RegExp(validDomains[i]));
}

var v1 = {
    ecpservice: require('../controllers/api/v1/ecp-service')
};

/*
 *  Router to handle all the requests starting with /demo
 *  For more information using router, visit: http://expressjs.com/api.html#router
 */
module.exports = function(router) {
    router.route('/ecp/campaign/:offerMailID').get(logMiddleware, v1.ecpservice.getCampaign); 
};
