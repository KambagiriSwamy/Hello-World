/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT 2.0 - <DESC_HERE>
 */

'use strict';

var logMiddleware = require('../middlewares/log'),
  multipart = require('connect-multiparty'),
  multipartMiddleware = multipart(),
  util = require('util'),
  bodyParser = require('body-parser'),
  jsonParser = bodyParser.json({
    type: 'application/*+json'
  }),
  userAuth = require('../middlewares/auth.js'),
  adminAuth = require('../middlewares/adminauth.js');


var cors = require('cors'),
  config = require('config'),
  validDomains = config.application.logging.validDomains,
  validDomainsRegex = [];

for (var i in validDomains) {
  validDomainsRegex.push(new RegExp(validDomains[i]));
}


var v1 = {
  //documentation: require('../controllers/api/v1/documentation'),

  // attachment: require('../controllers/api/v1/attachment'),
  campaign: require('../controllers/api/v1/campaign'),
  maVersion: require('../controllers/api/v1/maVersion'),
  // creative: require('../controllers/api/v1/creative'),
  file: require('../controllers/api/v1/file'),
  excel: require('../controllers/api/v1/excel'),
  // emailType: require('../controllers/api/v1/email-type'),
  user: require('../controllers/api/v1/user'),
  campaignSubTypes: require('../controllers/api/v1/campaign-sub-type'),
  cmNeedCategory: require('../controllers/api/v1/cm-need-category'),
  attachmentType: require('../controllers/api/v1/attachment-type'),
  mhidValidator: require('../controllers/api/v1/mhid-validator'),
  pznVariable: require('../controllers/api/v1/pznVariable'),
  revertCampaignState: require('../controllers/api/v1/revert-cmp-state'),
  cancelCampaignDrops: require('../controllers/api/v1/cancel-esp-drops'),
  runDbPatch: require('../controllers/api/v1/run-db-patch'),
  verifyRollback: require('../controllers/api/v1/rollback-verification'),
  pullDeployedCreative: require('../controllers/api/v1/pull-deployed-creative')
};

/*
 *  Router to handle all the requests starting with /demo
 *  For more information using router, visit: http://expressjs.com/api.html#router
 */
module.exports = function(router) {
  router.use(cors({
    origin: validDomainsRegex,
    ExposedHeaders: 'Content-Disposition'
  }));

  router.route('/v1/campaigns').get(logMiddleware, jsonParser, userAuth, v1.campaign.index);
  router.route('/v1/filter/campaigns').post(logMiddleware, jsonParser, userAuth, v1.campaign.index);
  router.route('/v1/campaigns').post(logMiddleware, userAuth, v1.campaign.create);
  router.route('/v1/campaigns/:campaign_id').get(logMiddleware, userAuth, v1.campaign.show);
  router.route('/v1/campaigns/:campaign_id').post(logMiddleware, userAuth, v1.campaign.update);
  router.route('/v1/campaigns/delete/version/:campaign_id/:version_id').get(logMiddleware, jsonParser, userAuth, v1.maVersion.destroy);
  // API to save MA version details, including form data and MA version creatives - MA tab
  router.route('/v1/campaigns/version/:campaign_id/:attachment_type/:version_id').post(logMiddleware, jsonParser, userAuth, multipartMiddleware, v1.maVersion.saveMAVersion);

  // API to view an attachment, called when download button for attachment is clicked
  router.route('/v1/files/:file_id/name/:file_name').get(logMiddleware, userAuth, v1.file.show);
  // Below two APIs are to preview (quick uploak and download in one go) an attachment
  router.route('/v1/files/tempSave').post(logMiddleware, multipartMiddleware, userAuth, v1.file.tempSave);
  router.route('/v1/files/preview/:encpath/:encname').get(logMiddleware, multipartMiddleware, userAuth, v1.file.preview);
  // API to attach any creative attachment - Attachment tab
  router.route('/v1/files/:campaign_id').post(logMiddleware, multipartMiddleware, userAuth, v1.file.saveFilesToGridFs);
  // API to save creative mockup - Description tab
  router.route('/v1/files/:campaign_id/:attachment_type').post(logMiddleware, multipartMiddleware, userAuth, v1.file.saveFilesToGridFs);

  // API to to upload approval and instruction docs for MA campaigns - MA tab
  router.route('/v1/ma/attachment/:campaign_id/:attachment_type').post(logMiddleware, multipartMiddleware, userAuth, v1.file.saveMAFilesToGridFs);
  // API to delete any attachment (creative mock and attachment tab and even campaign level attachments on MA tab)
  router.route('/v1/files/:campaign_id/:file_id/:attachment_type').get(logMiddleware, userAuth, v1.file.destroy);
  router.route('/v1/files/:campaign_id/:file_id').get(logMiddleware, userAuth, v1.file.destroy);

  router.route('/v1/excel/import/:excel_for').post(logMiddleware, multipartMiddleware, userAuth, v1.excel.excelReader);

  router.route('/v1/users/search').post(logMiddleware, jsonParser, userAuth, adminAuth, v1.user.index);
  router.route('/v1/users/search').get(logMiddleware, jsonParser, userAuth, adminAuth, v1.user.index);
  router.route('/v1/users').post(logMiddleware, jsonParser, userAuth, adminAuth, v1.user.create);
  router.route('/v1/users/:user_id').post(logMiddleware, jsonParser, userAuth, adminAuth, v1.user.update);
  router.route('/v1/user/:user_id').get(logMiddleware, jsonParser, userAuth, adminAuth, v1.user.show);
  // router.route('/v1/users/role/:role_name').get(logMiddleware, v1.user.showByRoleName);
  router.route('/v1/users/delete/:user_id').get(logMiddleware, jsonParser, userAuth, adminAuth, v1.user.destroy);

  // router.route('/v1/email-types').get(logMiddleware, v1.emailType.index);

  //campaign sub types
  router.route('/v1/campaign-sub-types/campaign-types/:campaign_types_id').get(logMiddleware, v1.campaignSubTypes.showByCampaignTypeId);

  // for CM need category
  // router.route('/v1/cmNeedCategory').get(logMiddleware, v1.cmNeedCategory.index);
  router.route('/v1/cmNeedCategory/business-unit/:business_unit_code').get(logMiddleware, v1.cmNeedCategory.showByBusinessUnitCode);

  //to validate presence (absence) of MHID
  router.route('/v1/verify-mhid/:mhid').get(logMiddleware, v1.mhidValidator.validate);
  router.route('/v1/mhid/add').post(logMiddleware, v1.mhidValidator.create);
  router.route('/v1/mhid/remove').post(logMiddleware, v1.mhidValidator.destroy);

  //pzn variables
  router.route('/v1/pznVariables').get(logMiddleware, v1.pznVariable.index);

  //for attachmentTypes
  router.route('/v1/attachment-types/:campaign_email_type_code').get(logMiddleware, v1.attachmentType.showByEmailTypeCode);

  // to revert campaign status
  router.route('/v1/revert-campaign-state/:requestId').get(logMiddleware, v1.revertCampaignState.revert);
  router.route('/v1/campaigns/:campaignId/lock/:tabId').get(logMiddleware, userAuth, v1.campaign.lock);
  router.route('/v1/campaigns/:campaignId/unlock/:tabId').get(logMiddleware, userAuth, v1.campaign.unlock);
  router.route('/v1/campaigns/:campaignId/extend-lock/:tabId').get(logMiddleware, userAuth, v1.campaign.extendLockTimer);

  //to cancel campaign drops
  router.route('/v1/cancelCampaignDrops').post(logMiddleware, v1.cancelCampaignDrops.cancelCampaignDrops);

  //to request Acces to ERA
  router.route('/v1/requestAccess').post(logMiddleware, v1.user.requestAccess);

  /**
   * patch apis - to make sure old campaigns work properly
   */
  router.route('/v1/run-db-patch/:patch_name').get(logMiddleware, jsonParser, v1.runDbPatch.run);

  //to verify whether a campaign can be rolledback to edit
  router.route('/v1/verifyRollback/:requestID').get(logMiddleware, v1.verifyRollback.verify);
  router.route('/v1/deployed-creatives').get(logMiddleware, v1.pullDeployedCreative.getFromET);
  
};
