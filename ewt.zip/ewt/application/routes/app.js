/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-POC - <DESC_HERE>
 */

'use strict';

var app = require('../controllers/app');

/*
 *  Router to handle all the requests starting with /demo
 *  For more information using router, visit: http://expressjs.com/api.html#router
 */
module.exports = function (router) {

	// Request handling the request on /
	// Adding middleware to all requests for this route
	router.route('/').get(app.get);

};
