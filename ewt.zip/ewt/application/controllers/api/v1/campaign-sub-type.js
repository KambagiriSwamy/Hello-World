/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 (ERA) - This file defines the controller for campaign-sub-type at Node end. It has all action methods related to campaign-sub-type.
 */

'use strict';

var db = require('../../../lib/db.js'),
  errUtils = require('../../../lib/err-utils');

module.exports = {
  /**
   * Name: showByCampaignTypeId
   * Description: This action method retuns all the campaign-sub-types for given campaign type.
   * @param  {Object} req Request object received from client
   * @param  {Object} res Response object that will be returned to client
   * @return {Void}     This function returns JSON data to client
   */
  showByCampaignTypeId: function(req, res) {
    logger.info('api.campaign-sub-type.showByCampaignTypeId :: method entry');
    var CampaignSubType = db.campaignSubTypeClass();

    // Query DB to find all related campaign-sub-types for given campaign-type
    CampaignSubType.find({
      campaignTypeCode: req.params.campaign_types_id
    }, function(err, campaignSubTypes) {
      if (err) {
        return errUtils.handleError(res, err);
      }
      logger.info('api.campaign-sub-type.showByCampaignTypeId :: Returning campaign-sub-types for campaign type code: ' + req.params.campaign_types_id);
      // Return the queried data as JSON to client
      return res.status(200).json(campaignSubTypes);
    });
  }
};
