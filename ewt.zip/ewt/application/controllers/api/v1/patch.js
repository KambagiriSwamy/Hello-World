/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md 
 *
 *
 * Description: EWT-2.0 (ERA) - This file defined the updating the mongodb for model changes at Node end.
 */

'use strict';

var db = require('../../../lib/db.js'),
  utils = require('../../../lib/utils.js'),
  errUtils = require('../../../lib/err-utils.js'),
  asyncEach = require('async-each');
/*
 * Controller which handles api requests related to updating the exsisting campaigns, coming from client through router.
 */
module.exports = {
  /*
   * Name: creationDate
   * Description: This action method updates all the campaigns with their creation date and returns a json holding that status for each campaign.
   * @param {Object} req Request object received from client
   * @param {Object} res Response object send back to client
   */

  creationDate: function(req, res) {
    logger.info('Method Entry :: creationDate');
    var Campaign = db.campaignClass();
    var results = [];
    /**
     * Fetching all campaigns from data base
     */
    Campaign.find({}, function (err, campaigns){

      /**
       * If error is encountered then the data base is down or we were unble to connect to data base of some reason
       * Returning a repose for the same
       */
      if (err) {
        errUtils.handleError(res, {'reason': 'Unable to fetch data from database'});
      }

      /**
       * All the campaings are deep copied into allCampaigns variable
       * All manipulations can be done on allCampaigns variable where as campaigns will remain unchanged.
       * This is just to have a reference and stop a DB call in case required
       * 
       * @type {[Objects]}
       */
      asyncEach(campaigns, function (singleCampaign , cb) {

        Campaign.findById(singleCampaign._id, function (err, campaignObject) {
          if (err) {
            results.push({
                id : singleCampaign.requestID,
                'status' : 'Failed to add create date as this campaign was not found in database'
              });
            errUtils.handleCustomError(res, 500, results);
          }

          /**
           * not adding creation date if already present
           */
          if (!campaignObject.createdOn) {
            var creationDate = new Date(campaignObject._id.getTimestamp());
            campaignObject.createdOn = utils.formatDate( (creationDate.getMonth() + 1)+ '/' + creationDate.getDate() + '/' + creationDate.getFullYear());
            campaignObject.save(function (err, savedCampaign) {
              if (err) {
                results.push({
                  id : campaignObject.requestID,
                  'status' : 'Failed to add create date (unnable to save campaign check database connection)'
                });
                errUtils.handleCustomError(res, 500, results);
              }
              results.push({
                id : savedCampaign.requestID,
                'status' : 'Updated with creation date ('+(savedCampaign.createdOn.getMonth() + 1)+ '/' + savedCampaign.createdOn.getDate() + '/' + savedCampaign.createdOn.getFullYear()+')'
              });
              return cb();
            });
          } else {
            return cb();
          }
        });
        
      }, function(err) {
        logger.info('Script Executed Successfully::: All campaigns now have creation date');
        if (results.length) {
          return res.status(200).jsonp({'status': 'Updated campaigns with creation date', 'result' : results});
        } else {
          return res.status(200).jsonp({'stauts' : 'All campaigns already have creation date'});
        }
      });

      
    });
  }
};
