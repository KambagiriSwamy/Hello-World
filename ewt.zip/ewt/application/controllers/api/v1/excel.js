/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 (ERA) - This file defines the controller for doing all excel related operations at Node end.
 */

'use strict';

var fs = require('fs'),
  errUtils = require('../../../lib/err-utils'),
  utils = require('../../../lib/utils'),
  excelExtractor = require('../../../lib/excel-reader'),
  csvReader = require('json-2-csv');

module.exports = {
  /**
   * Name: excelReader
   * Description: This action method receives the file. If its Excel or CVS file, it reads it and return backs the sctream to client.
   * @param  {Object}   req  This is a request object received from client.
   * @param  {Object}   res  This is a response object returned to client.
   * @param  {Function} next This is the function that express passes us to give it back the control, so that it can execute the next function in middleware chain.
   * @return {Void}        It returns the file contents as stream.
   */
  excelReader: function(req, res) {
    logger.info('api.excel.excelReader :: method entry');
    var fileData,
      fileName = (req.files.file.originalFilename && req.files.file.originalFilename.toLowerCase()) || '';
    if (fileName.search('.csv') !== -1) { // Received file is a CSV file
      fs.readFile(req.files.file.path, 'utf8', function(err, stream) {
        if (err) { // Faced some issue in reading CSV file, so return an error to client.
          return errUtils.handleError(res, {
            'status': 'failure',
            'reason': 'Error while reading file ' + req.files.file.originalFilename
          });
        }
        csvReader.csv2json(stream, function(err, json) {
          if (err) { // Faced an issue in converting CSV to JSON, so return an error to client.
            return errUtils.handleError(res, {
              'status': 'failure',
              'reason': 'Error while converting file "' + req.files.file.originalFilename + '" to JSON.'
            });
          }
          fileData = {
            'workSheet1': json
          };
          if (req.params.excel_for === 'cells') {
            // The file has been loaded as DART file, so validate to ensue that the data of DART file is fine.
            utils.cellDartValidator(fileData, function(err, cellDartData) {
              if (err) { // Some issue is there with the file data, so return an error to client.
                return errUtils.handleCustomError(res, 412, err);
              }
              // All looks good, so return the file contents / data (as JSON) back to client.
              return res.status(200).json(cellDartData);
            });
          }
        });
      });
    } else if ((fileName.search('.xls') !== -1) || (fileName.search('.ods') !== -1)) {
      // File is either an excel or open-office spreadsheet file
      // Read the Excel file and get its contents as JSON
      fileData = excelExtractor.getJson(req.files.file.path);
      if (req.params.excel_for === 'cells') {
        // The file has been loaded as DART file, so validate to ensue that the data of DART file is fine.
        utils.cellDartValidator(fileData, function(err, cellDartData) {
          if (err) { // Some issue is there with the file data, so return an error to client.
            return errUtils.handleCustomError(res, 412, err);
          }
          // All looks good, so return the file contents / data (as JSON) back to client.
          return res.status(200).json(cellDartData);
        });
      }
    } else {
      // The file is not in expected format, so return error to client.
      return errUtils.handleCustomError(res, 412, {
        status: 'failure',
        reason: 'Only files with xlsx, csv, xls, xlsb, xlsm and ods formats can be accepted.'
      });
    }
  }
};
