/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-POC - <DESC_HERE>
 */

'use strict';

var db = require('../../../lib/db.js'),
  _ = require('lodash'),
  EventEmitter = require('events').EventEmitter,
  ee = new EventEmitter(),
  utils = require('../../../lib/utils.js'),
  file = require('./file.js');
var asyncEach = require('async-each');


function handleError(res, err) {
  logger.error(err);
  return res.status(500).send(err);
}

function handleCustomError(res, errCode, errMessage) {
  logger.error(errMessage);
  return res.status(errCode).send(errMessage);
}
module.exports = {
  saveMAVersion: function(req, res) {
    logger.info('saveMAVersion::Method called');
    utils.setupValidator(req, res);
    var requestData = JSON.parse(req.body.data),
      MAVersion, maVersionObj, campaign, attachmentSize = 0;
    campaign = db.campaignClass();
    campaign.findOne({
      'requestID': req.params.campaign_id
    }, function(err, campaignToUpdate) {
      if (err) {
        logger.error('saveMAVersion::Failed to load Campaign');
        return handleError(res, err);
      }
      if (!campaignToUpdate) {
        logger.error('saveMAVersion::Campaign Not Found');
        return handleCustomError(res, 204, {
          'status': 'failure',
          'reason': 'Campaign Not Found'
        });
      }
      campaignToUpdate.ma = campaignToUpdate.ma || {};
      campaignToUpdate.ma.approvalDocuments = campaignToUpdate.ma.approvalDocuments || [];
      campaignToUpdate.ma.instructionDocuments = campaignToUpdate.ma.instructionDocuments || [];
      campaignToUpdate.ma.disengagementValue = (campaignToUpdate.ma.disengagementValue * 1) || 0;
      campaignToUpdate.ma.maCells = campaignToUpdate.ma.maCells || [];
      campaignToUpdate.ma.maVersions = campaignToUpdate.ma.maVersions || [];
      campaignToUpdate.ma.mailHistory = campaignToUpdate.ma.mailHistory || [];
      campaignToUpdate.ma.filesSentToET = campaignToUpdate.ma.filesSentToET || []

      var MA = db.marketingAutomationClass(),
        maObj = new MA({
          'approvalDocuments': campaignToUpdate.ma.approvalDocuments,
          'instructionDocuments': campaignToUpdate.ma.instructionDocuments,
          'disengagementValue': campaignToUpdate.ma.disengagementValue,
          'maCells': campaignToUpdate.ma.maCells,
          'mailHistory': campaignToUpdate.ma.mailHistory,
          'filesSentToET': campaignToUpdate.ma.filesSentToET,
          'maVersions': campaignToUpdate.ma.maVersions
        });
      campaignToUpdate.ma = maObj;

      var versionIndex = -1;
      if (campaignToUpdate.ma.maVersions.length > 0) {
        versionIndex = _.findIndex(campaignToUpdate.ma.maVersions, {
          'versionId': parseInt(requestData.versionId)
        });
      }
      if (versionIndex !== -1) {
        logger.info('Version ID found');
        maVersionObj = campaignToUpdate.ma.maVersions[versionIndex];
        maVersionObj.versionName = requestData.versionName;
        maVersionObj.subjectLine = requestData.subjectLine;
        maVersionObj.poid = requestData.poid;
        maVersionObj.complianceCode = requestData.complianceCode;
        maVersionObj.triggerEvent = requestData.triggerEvent;
        campaignToUpdate.ma.maVersions[versionIndex] = maVersionObj;
        var deletedFiles = requestData.deletedFile;
        if (deletedFiles) {
          logger.info('Deleteing the files for the version');
          deletedFiles.forEach(function(file, index) {
            var deleteIndex = _.findIndex(campaignToUpdate.ma.maVersions[versionIndex].creativeDocument, {
              'gfsID': file._id
            });
            if (deleteIndex >= 0) {
              campaignToUpdate.ma.maVersions[versionIndex].creativeDocument.splice(deleteIndex, 1);
            }
          });

          attachmentSize = utils.calculateAttachmentSize(campaignToUpdate.ma.maVersions[versionIndex].creativeDocument, 'size');
          campaignToUpdate.save(function(err) {
            if (err) {
              return handleError(res, err);
            }

            module.exports.unlinkFiles(requestData.deletedFile, function(err) {
              if (req.files.file) {
                logger.info('Upload creativeDocument file upload started');
                var filesArr = [];
                if (!Array.isArray(req.files.file)) {
                  filesArr[0] = req.files.file;
                } else {
                  filesArr = req.files.file;
                }
                return file.saveMAAttachment(filesArr, req.params.attachment_type, req.params.campaign_id, requestData.versionId, res, attachmentSize);
              } else {
                //version update triggerd and no files to update
                return res.status(200).jsonp(campaignToUpdate.ma.maVersions);
              }
            });
            //module.exports.unlinkFiles(requestData.deletedFile);

          });

        } else {
          attachmentSize = utils.calculateAttachmentSize(campaignToUpdate.ma.maVersions[versionIndex].creativeDocument, 'size');
          campaignToUpdate.save(function(err) {
            if (err) {
              return handleError(res, err);
            }
            if (req.files.file) {
              logger.info('Upload creativeDocument file upload started');
              var filesArr = [];
              if (!Array.isArray(req.files.file)) {
                filesArr[0] = req.files.file;
              } else {
                filesArr = req.files.file;
              }
              return file.saveMAAttachment(filesArr, req.params.attachment_type, req.params.campaign_id, requestData.versionId, res, attachmentSize);
            } else {
              //version update triggerd and no files to update
              return res.status(200).jsonp(campaignToUpdate.ma.maVersions);
            }
          });
        }
      } else {
        logger.info('Create New Version initiated');
        MAVersion = db.marketingAutomationVersionsClass();
        maVersionObj = new MAVersion();
        maVersionObj.versionId = requestData.versionId;
        maVersionObj.versionName = requestData.versionName;
        maVersionObj.subjectLine = requestData.subjectLine;
        maVersionObj.poid = requestData.poid;
        maVersionObj.complianceCode = requestData.complianceCode;
        maVersionObj.triggerEvent = requestData.triggerEvent;
        campaignToUpdate.ma.maVersions.push(maVersionObj);

        if (!utils.isValidVersion(req)) {
          logger.error('saveMAVersion::Invalid MA Version Object received');
          var error = {
            'status': 'error',
            'message': 'Mandatory Fields are missing',
            'errorList': req.validationErrors()
          };
          return res.status(500).jsonp(error);
        }
        campaignToUpdate.save(function(err) {
          if (err) {
            return handleError(res, err);
          }
          if (req.files.file) {
            logger.info('Upload creativeDocument file upload started');
            var filesArr = [];
            if (!Array.isArray(req.files.file)) {
              filesArr[0] = req.files.file;
            } else {
              filesArr = req.files.file;
            }
            return file.saveMAAttachment(filesArr, req.params.attachment_type, req.params.campaign_id, requestData.versionId, res, attachmentSize);
          } else {
            //version update triggerd and no files to update
            return res.status(200).jsonp(campaignToUpdate.ma.maVersions);
          }
        });
      }

    });
  },
  destroy: function(req, res) {
    var Campaign = db.campaignClass();
    var versionIndex,
      gfsIDArr = [];
    Campaign.findOne({
      'requestID': req.params.campaign_id
    }, function(err, campaign) {
      if (err) {
        return handleError(res, err);
      }
      if (!campaign) {
        return handleCustomError(res, 204, {
          'status': 'failure',
          'reason': 'Campaign Not Found'
        });
      }

      var MA = db.marketingAutomationClass();
      var maObj = new MA({
        'approvalDocuments': campaign.ma.approvalDocuments,
        'instructionDocuments': campaign.ma.instructionDocuments,
        'disengagementValue': campaign.ma.disengagementValue,
        'maCells': campaign.ma.maCells,
        'mailHistory': campaign.ma.mailHistory,
        'filesSentToET': campaign.ma.filesSentToET,
        'maVersions': campaign.ma.maVersions
      });
      campaign.ma = maObj;
      versionIndex = _.findIndex(campaign.ma.maVersions, {
        'versionId': parseInt(req.params.version_id)
      });
      if (versionIndex !== -1) {
        var creativeDocuments = campaign.ma.maVersions[versionIndex].creativeDocument;
        for (var cnt = 0; cnt < creativeDocuments.length; cnt++) {
          var obj = {};
          obj._id = creativeDocuments[cnt].gfsID;
          gfsIDArr.push(obj);
        }
        campaign.ma.maVersions.splice(versionIndex, 1);
        campaign.save(function(err) {
          if (err) {
            return handleError(res, err);
          }
          if (gfsIDArr.length > 0) {
            module.exports.unlinkFiles(gfsIDArr, function(err) {
              return res.status(200).jsonp({
                'status': 'success'
              });
            });
          } else {
            return res.status(200);
          }
        });
      } else {
        return handleError(res, err);
      }
    });
  },
  unlinkFiles: function(fileToRemoveArr, callBack) {
    var gridfs = db.gridfs();

    asyncEach(fileToRemoveArr, function(file, cb) {
      gridfs.remove(file, function(err) {
        return cb(err);
      });
    }, function(err) {
      return callBack(err);
    });
  }
};
