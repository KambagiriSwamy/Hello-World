/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-POC - <DESC_HERE>
 */

'use strict';

var db = require('../../../lib/db.js');

module.exports = {

  revert: function(req, res) {
    var campaignRequestId = req.params.requestId;
    var Campaign = db.campaignClass();
    Campaign.findOne({
      'requestID': campaignRequestId
    }, function(err, campaign) {
      if (err) {
        return res.status(500).jsonp('{Status : Error retrieving the campaign from Database. }');
      }
      if (!campaign.state.codeName === 'queued2esp') {
        return res.status(500).jsonp('{Status : Campaign is not yet Queued for ESP submission. }');
      } else {
        var CampaignStatus = db.campaignStateClass();
        CampaignStatus.findOne({
          'codeName': 'submitted2admin'
        }, function(err, go2state) {
          if (err) {
            return res.status(500).jsonp('{Status : Error retrieving the campaign status from Database. }');
          }
          campaign.state = go2state;
          campaign.save(function(err) {
            if (err) {
              return res.status(500).jsonp('{Status : Error saving the campaign to Database. }');
            } else {
              return res.status(200).jsonp('{Status : Campaign Status successfuly reverted. }');
            }
          });
        });
      }
    });
  }
};
