/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 (ERA) - This file defines the controller for offer-details API called from ECP at regular intervals. This is the integration point between ECP and ERA.
 */
'use strict';
var db = require ('../../../lib/db'),
  ecpUtils = require ('../../../lib/ecp-utils'),
  errUtils = require ('../../../lib/err-utils'),
  response = new Object (ecpUtils.getCampaignObject ());

module.exports = {
  getCampaign: function (req, res) {
    var campaign = db.campaignClass ();
    var query = campaign.findOne ({
      $or: [{
        'mailHistory.mhid': req.params.offerMailID
      }, {
        'ma.mailHistory.mhid': req.params.offerMailID
      }]
    });
    query.exec (function (err, campaignObj) {
      if (err) {
        return errUtils.handleError (res, err);
      }
      if (! campaignObj) {
        res.status (404);
        var jsonText = '{ "Code":"404","App Internal Code":"200","Message":"Invalid MHID"}';
        var obj = JSON.parse (jsonText);
        return res.json (obj);
      }
      // Call this service to build Response
      ecpUtils.buildReponse (campaignObj, req.params.offerMailID, response);
      return res.json (response);
    });
  }
}