/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 (ERA) - This file implements the user controller at node end. It has all the action methods related to user controller
 */

'use strict';

// var cancelCampaignPatch = require('../../../../db/Release_2/cancel-campaigns-patch');
// var creationDatePatch = require('../../../../db/Release_2/creation-date-patch');
// var primaryCmNeedCategoryPatch = require('../../../../db/Release_2/primaryCmNeedCategory-patch');
var errUtils = require('../../../lib/err-utils');
module.exports = {
  run: function(req, res) {
    logger.info('api.v1.run-db-patch.run :: method entry');
    var requestedPatch = req.params.patch_name;
    var patch;
    switch (requestedPatch) {
      case 'cancelCampaign':
        patch = cancelCampaignPatch;
        break;
      case 'creationDate' : 
        patch = creationDatePatch;
      case 'primaryCmNeedCategory' :
        patch = primaryCmNeedCategoryPatch;
      default:
        logger.error('unrecognized patch name supplied');
        break;
    }
    if (patch) {
      patch.runPatch(function(err) {
        if (err) {
          logger.error('error running db patch ' + JSON.stringify(err));
          return errUtils.handleCustomError(res, 500, 'error running db patch' + JSON.stringify(err));
        } else {
          return res.status(200).json('success');
        }
      });
    }
  }

};
