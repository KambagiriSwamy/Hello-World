/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md 
 *
 *
 * Description: EWT-2.0 (ERA) - Controller to expose rollback as service to web client. It has all methods
 * necessary to validate and perform rollback.
 */

'use strict';

var db = require('../../../lib/db.js'),
  _ = require('lodash'),
  email = require('../../email'),
  esp = require('../../../lib/esp.js'),
  utils = require('../../../lib/utils.js'),
  stateValidator = require('../../../lib/state-validator.js'),
  campaignLibrary = require('../../../lib/campaign.js'),
  errUtils = require('../../../lib/err-utils.js');

module.exports = {
  verify: function(req, res) {
    logger.info('api.Controllers.rollback-verification.verify : method entry');
    var requestID = req.params.requestID;
    var Campaign = db.campaignClass();
    Campaign.findOne({
      'requestID': requestID
    }, function(err, cmp) {
      if (err) {
        logger.error('api.Controllers.rollback-verification.verify : error finding campaign with id: ' + requestID);
        return errUtils.handleCustomError(res, 500, {
          status: 'failure',
          code: 'SYSTEM_FAILURE',
          reason: 'ET Service - retrieve status call failure'
        });
      } else if (cmp) {
        esp.getCampaignDeploymentDetails(cmp, function(err, campaign) {
          if (err) {
            logger.error('api.Controllers.rollback-verification.verify : error finding campaign status from ET with id: ' + requestID);
            return errUtils.handleCustomError(res, 500, {
              status: 'failure',
              code: 'SYSTEM_FAILURE',
              reason: 'Cannot verify status of campaign at ESP due to Technical Error'
            });
          } else {
            var today = new Date();
            var hasFutureDeployments = false;
            var validForRollback = false;
            campaign.criticalDataSubmitted.forEach(function(drop) {
              var loadStatus;
              if (campaign.espLoadDetails && campaign.espLoadDetails.length > 0) {
                loadStatus = _.find(campaign.espLoadDetails, {
                  'mhid': drop.keys.CMPGN_MAIL_ID,
                  'cellID': drop.keys.CMPGN_VER_CELL_ID,
                  'deploymentDate': drop.keys.CMPGN_DEPLOY_DATE
                });
              }
              if (!loadStatus) {
                var depDate = new Date(drop.keys.CMPGN_DEPLOY_DATE);
                if (depDate > today) {
                  hasFutureDeployments = true;
                }
              }
            });
            if (hasFutureDeployments) {
              return res.status(200).json({
                'status': 'OK'
              });
            }
            return errUtils.handleCustomError(res, 412, {
              status: 'failure',
              code: 'VALIDATION_FAILED',
              reason: 'Campaign cannot be rolled back since all deployments are in the past.'
            });
          }
        });
      } else {
        return errUtils.handleCustomError(res, 500, {
          status: 'failure',
          code: 'VALIDATION_FAILED',
          reason: 'Cannot Fetch campaign due to Technical error'
        });
      }
    });
  }
};
