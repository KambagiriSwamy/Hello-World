/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 (ERA) - This file implements the user controller at node end. It has all the action methods related to user controller
 */

'use strict';

var db = require('../../../lib/db.js'),
  errUtils = require('../../../lib/err-utils.js'),
  _ = require('lodash'),
  EventEmitter = require('events').EventEmitter,
  ldap = require('../../../lib/ldap'),
  userUtils = require('../../../lib/user.js'),
  utils = require('../../../lib/utils.js'),
  email = require('../../email.js'),
  ee = new EventEmitter();

/*
 *  Controller which handles api requests user, coming from client through router.
 */

module.exports = {
  /*
   * Name: index
   * Description: This action method returns all the fields/attributes of all the users in DB.
   * @param  {Object} req Request object received from client
   * @param  {Object} res Response object returned to client
   * @return {Void}
   */
  index: function(req, res) {
    logger.info('api.user.index :: method entry');
    var User = db.userClass(),
      columns = req.query.columns || 'uid,firstName,lastName,businessUnit,role,createdOn,lastUpdatedOn,status,email',
      queryObject = {};

    // TODO: TA815680 - Not sure why we are using POST to get users. We should have used GET. Need to make this change.
    if (req.body) {
      if (req.body.uid && req.body.uid.trim().length > 0) {
        queryObject.uid = new RegExp(req.body.uid.trim(), 'i');
      }
      if (req.body.name && req.body.name.trim().length > 0) {
        queryObject.name = new RegExp(req.body.name.trim(), 'i');
      }
      if (req.body.lastName && req.body.lastName.trim().length > 0) {
        queryObject.lastName = req.body.lastName.trim();
      }
      if (req.body.businessUnit && req.body.businessUnit.toLowerCase() !== 'all' && req.body.businessUnit.trim().length > 0) {
        queryObject['businessUnit.codeName'] = req.body.businessUnit.trim();
      }
      if (req.body.role && req.body.role.toLowerCase() !== 'all' && req.body.role.trim().length > 0) {
        queryObject['role.codeName'] = req.body.role.trim();
      }
      if (req.body.status && req.body.status.toLowerCase() !== 'all' && req.body.status.trim().length > 0) {
        if (req.body.status.toLowerCase().trim() == 'active') { // reactive is same as active from app prespective.
          queryObject['$or'] = [{
            'status.codeName': 'active'
          }, {
            'status.codeName': 'reactive'
          }];
        } else {
          queryObject['status.codeName'] = req.body.status.toLowerCase().trim();
        }
        // queryObject['status.codeName'] = req.body.status.trim();
      }
    }
    // Do not return the users which are deleted. Deleted user records remain in DB as dorment, they do not get physically deleted from DB
    queryObject.markAsDeleted = false;

    // Find users and return requested columns/attributed based on received filter params
    columns = columns.split(',').join(' ');
    User.find(queryObject, columns, {
      sort: {
        uid: 1
      }
    }, function(err, users) {
      if (err) {
        return errUtils.handleError(res, err);
      }
      return res.status(200).json(users);
    });
  },

  /**
   * Name: create
   * Description: This action method creates/adds a new user record in DB.
   * @param  {Object} req Request object received from client
   * @param  {Object} res Response object returned to client
   * @return {Void}
   */
  create: function(req, res) {
    logger.info('api.user.create :: method entry');
    utils.setupValidator(req, res);
    var User = db.userClass(),
      UserStatus = db.userStatusClass(),
      ldapFilter;
    // Validate the req object to ensure we have all required fieds to add new user 
    if (!userUtils.isUserValid(req)) {
      return errUtils.handleCustomError(res, 412, {
        'status': 'failure',
        'reason': 'Mandatory fields are missing'
      });
    }
    // Check if we have any already, with given uid ?
    User.findOne({
      'uid': req.body.uid
    }, function(err, dbUser) {
      if (err) {
        return errUtils.handleError(res, err);
      }
      if (dbUser && dbUser.markAsDeleted === false) {
        // We already have an active user with given uid, so doesn't make sense to create same user again.
        return errUtils.handleCustomError(res, 422, {
          'status': 'failure',
          'reason': 'User Already Exists'
        });
      }

      dbUser = dbUser || null;
      if (process && (process.env.NODE_ENV !== 'development')) { // Non-development environment
        // Check if the user exists in ADS / LDAP or not. We search using ADS ID
        ldapFilter = '(samaccountname=' + req.body.uid + ')';
        ldap.getUserDetails(ldapFilter, null, function(err, ldapUser) {
          if (err) {
            return errUtils.handleError(res, err);
          }
          if (!ldapUser) { // User does not exist in ADS, return error
            return errUtils.handleCustomError(res, 412, {
              'status': 'failure',
              'reason': 'User does not exist in ADS.'
            });
          }
          if (ldapUser.userAccountControl === '514') { // User is disabled in ADS, so we should not add this to ERA DB
            return errUtils.handleCustomError(res, 412, {
              'status': 'failure',
              'reason': 'User is not active / enabled in ADS.'
            });
          }
          // User exists and is also enabled in ADS, so lets create the corresponding user in ERA DB.
          // If user already exists in ERA DB, it will be re-activate.
          userUtils.addUser2DB(req, ldapUser, dbUser, function(err, user) {
            if (err) {
              return errUtils.handleError(res, err);
            } else {
              return res.status(200).json(user);
            }
          });
        });
      } else { // Development environment. Skip LDAP / ADS check as we may not have ADS access in dev env.
        // Add the user to ERA DB. If user already exists in ERA DB, it will be re-activate.
        var ldapUser = {};
        userUtils.addUser2DB(req, ldapUser, dbUser, function(err, user) {
          if (err) {
            return errUtils.handleError(res, err);
          } else {
            return res.status(200).json(user);
          }
        });
      }
    });
  },
  /**
   * Name: show
   * Description: This action method return the requested user to client
   * @param  {Object} req Request object received from client
   * @param  {Object} res Response object returned to client
   * @return {Void}
   */
  show: function(req, res) {
    logger.info('api.user.show :: method entry');
    var User = db.userClass();

    // Find user record in DB for given user id
    User.findById(req.params.user_id, function(err, user) {
      if (err) {
        return errUtils.handleError(res, err);
      }
      if (user && user.markAsDeleted && user.markAsDeleted === true) {
        // User has been deleted. We keep the deleted users, but mark them as deleted and do not allow login for them.
        return errUtils.handleCustomError(res, 412, {
          'status': 'failure',
          'reason': 'User marked as deleted'
        });
      }
      // Return response client
      return res.status(200).json(user);
    });
  },
  /**
   * Name: update
   * Description: This action method updates the existing user record
   * @param  {Object} req Request object received from client
   * @param  {Object} res Response object returned to client
   * @return {Void}
   */
  update: function(req, res) {
    logger.info('api.user.update :: method entry');
    utils.setupValidator(req, res);
    if (!userUtils.isUserValid(req)) {
      // The user details that we received are not complete
      return errUtils.handleCustomError(res, 412, {
        'status': 'failure',
        'reason': 'Mandatory fields are missing'
      });
    }
    var User = db.userClass();
    // Find the user with given ID
    User.findById(req.params.user_id, function(err, user) {
      if (err) {
        return errUtils.handleError(res, err);
      }

      if (!user) { // User not found in DB
        return res.status(204).send('User not found');
      }

      // Update the user attributes
      user.role = req.body.role;
      user.businessUnit = req.body.businessUnit;
      user.status = req.body.status;
      user.lastUpdatedOn = new Date();
      // Save the updated user to DB
      user.save(function(err) {
        if (err) {
          return errUtils.handleError(res, err);
        }
        logger.info('Updated the user with ADS ID: ' + user.uid)
        return res.status(200).json(user);
      });
    });
  },

  /**
   * Name: destroy
   * Description: This action method marks the user as deleted. It actually does not delete the user record from DB.
   * @param  {Object} req Request object received from client
   * @param  {Object} res Response object returned to client
   * @return {Void}
   */
  destroy: function(req, res) {
    logger.info('api.user.destroy :: method entry');
    var User = db.userClass();

    // Get the user record from DB based on given ID
    User.findById(req.params.user_id, function(err, user) {
      if (err) {
        return errUtils.handleError(res, err);
      }

      if (!user) { // Not able to find user in DB
        return res.status(204).send('User not found');
      }
      // Do not actually delete the user record, but mark it as deleted so that we make it virtually non-existant in system. 
      user.markAsDeleted = true;
      // Update the user record in DB
      user.save(function(err) {
        if (err) {
          return errUtils.handleError(res, err);
        }
        // Return back to client with success status.
        res.status(200).json({
          msg: 'success'
        });
      });
    });
  },

  requestAccess: function(req, res) {
    logger.info('api.v1.user.requestAccess :: method entry');
    if (req.body && req.body.uid && req.body.name && req.body.email) {
      var userDetails = {
          uid: req.body.uid,
          name: req.body.name,
          email: req.body.email
        },
        User = db.userClass(),
        toList = [],
        ccList = [];

      ccList = [req.body.email];
      User.find({
        $or: [{
          'role.codeName': 'axpi'
        }, {
          'role.codeName': 'axpiAdmin'
        }]
      }, function(err, users) {
        logger.info('Retrieved Admin User email list' + JSON.stringify(users));
        if (err) {
          logger.error(err);
          return errUtils.handleError(res, err);
        }
        for (var indx in users) {
          toList.push(users[indx].email);
        }
        email.notifyRequestAccess(userDetails, toList, ccList, null, function(err) {
          if (err) {
            logger.error('Failed to send Request Access Email for user with email-id: ' + userDetails.email);
            return errUtils.handleCustomError(res, 500, {
              'status': 'failure',
              'message': 'Failed to send email, may be beacuse of non-availability of email server.'
            });
          }
          logger.info('Successfully sent Request Access Email for user with email-id: ' + userDetails.email);
          return res.status(200).jsonp({
            'status': 'success',
            'message': 'Email sent successfully'
          });
        });
      }).select('email');
    } else {
      logger.error('Query string is invalid in controllers/api/v1/user/requestAccess.');
      return errUtils.handleCustomError(res, 412, {
        'status': 'failure',
        'message': 'Mandatory fields are missing in query String'
      });
    }
  }
};