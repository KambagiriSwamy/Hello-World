/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 (ERA) - This file defines the controller for attachment-type at Node end. It has all action methods related to attachement-type.
 */

'use strict';

var db = require('../../../lib/db'),
  errUtils = require('../../../lib/err-utils'),
  _ = require('lodash');

module.exports = {
  /**
   * Name: showByEmailTypeCode
   * Description: This action method is responsible to return all attachment types that are related to given campaign email type
   * @param  {Object} req Request object received from client
   * @param  {Object} res Response data returned to client
   * @return {Void}     This function returns JSON data to client
   */
  showByEmailTypeCode: function(req, res) {
    logger.info('api.attachment-type.showByEmailTypeCode :: method entry');
    var AttachmentType = db.attachmentTypeClass();

    // Query DB to find all the attachment types that are related to given campaign email type
    AttachmentType.find({
      'emailTypeCodes': req.params.campaign_email_type_code
    }, function(err, attachmentType) {
      if (err) {
        return errUtils.handleError(res, err);
      }
      logger.info('api.attachment-type.showByEmailTypeCode :: Returning attachment-types for email type code: ' + req.params.campaign_email_type_code);
      // Return the queried data as JSON to client
      return res.status(200).json(attachmentType);
    });
  }
};
