/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 (ERA) - This file defines the controller for doing all file and attachment related operations at Node end.
 */

'use strict';

var db = require('../../../lib/db.js'),
  Campaign = require('./campaign.js'),
  utils = require('../../../lib/utils.js'),
  errUtils = require('../../../lib/err-utils.js'),
  fileUtils = require('../../../lib/file-utils.js'),
  gridFS = require('../../../lib/grid-fs'),
  asyncEach = require('async-each'),
  _ = require('lodash'),
  fs = require('fs'),
  shortId = require('shortid'),
  EventEmitter = require('events').EventEmitter,
  ee = new EventEmitter(),
  mime = require('mime'),
  path = require('path'),
  mongoose = require('mongoose'),
  crypto = require('crypto'),
  algorithm = 'aes256',
  key = 'emailworkflowtoolversiontwo',
  fileSizeLimit = 10485780, // No file attached should be greater than 10 MB - Business requirement
  versionAttachmentLimit = 4194304; // For MA campaigns, the attachments for each versions should not be more than 4 MB

module.exports = {
  /**
   * Name: tempSave
   * Description: This action method saves the given file temparorily.
   * @param  {Onject} req This is the request object received from client.
   * @param  {Object} res This is the response object that will be returned to client.
   * @return {Void}     This function retuns the JSON (file name and its encrypted path on server) back to client, using response object.
   */
  tempSave: function(req, res) {
    logger.info('api.file.tempSave :: method entry');
    // We need not to save the file explicily. Its already done, body-parser saves it on filesystem and gives us the path to it.
    var filename = req.files.file.name.replace(/\s+/g, '_');
    var filepath = req.files.file.path;
    var cipher = crypto.createCipher(algorithm, key);
    // Encrypt the file path before returning it back to client
    var encrypted = cipher.update(filepath, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    var response = {
      path: encrypted,
      name: filename
    };
    return res.status(200).jsonp(response);
  },

  /**
   * Name: preview
   * Description: This action method returns the content of file whose path is given by client as encrypted path.
   * @param  {Object} req This is the request object received from client
   * @param  {Object} res This is the response object that will be returned to client
   * @return {Void}     This is action methos returns the file contents to client
   */
  preview: function(req, res) {
    logger.info('api.file.preview :: method entry');
    var is;
    var filepath = req.params.encpath;
    var fileName = req.params.encname;

    var decipher = crypto.createDecipher(algorithm, key);
    // Unencript the file path that we received from client
    var decrypted = decipher.update(filepath, 'hex', 'utf8') + decipher.final('utf8');

    // Read the file as stream
    is = fs.createReadStream(decrypted);
    res.setHeader('Content-Disposition', 'inline; filename =' + fileName);
    res.setHeader('Content-Type', mime.lookup(fileName));

    req.on('error', function(err) {
      res.send(500, err);
    });

    is.on('error', function(err) {
      res.status(500).send(err);
    });

    is.on('end', function() {
      // Once file reading is done, delete the file and return back to client with file contents.
      fs.unlink(decrypted, function() {
        return res.status(200);
      });
    });
    // Set the file content as response
    is.pipe(res);
  },

  /**
   * Name: saveFilesToGridFs
   * Dscription: This action method saved the given file in GridFS and its reference in campaign. This is
   * called whenever a file is attached from attachment tab in front-end or when creative mock is attached
   * from description tab in front-end.
   * @param  {Object}   req  This is request object received from client.
   * @param  {Object}   res  This is response object that will be returned to client.
   * @return {Void}        This method does not return anything.
   */
  saveFilesToGridFs: function(req, res) {
    logger.info('api.file.saveFilesToGridFs :: method entry');
    var fileName = req.files.file.name.replace(/\s+/g, '_'),
      campaignId = req.params.campaign_id,
      stats = fs.statSync(req.files.file.path),
      fileSizeInBytes = stats['size'],
      attachmentType = req.params.attachment_type,
      filePath = req.files.file.path,
      fileExtension = path.extname(req.files.file.path);

    // No file uploaded should not be more than set limit of 10 MB
    if (fileSizeInBytes > fileSizeLimit) {
      var error = {
        'status': 'error',
        'message': 'File size exceeds file size limitation'
      };
      return errUtils.handleCustomError(res, 412, error);
    }

    var Campaign = db.campaignClass();
    Campaign.findOne({
      '_id': campaignId
    }, function(err, campaignToUpdate) {
      if (campaignToUpdate) {
        if (!fileUtils.isSizeWithinUploadLimits(campaignToUpdate.attachments, fileSizeInBytes)) {
          // After adding this file, the overall size of campaign attachments will exceed the set limit of 10 MB, so we should not save this file
          var response = {
            'status': 'failure',
            'reason': 'File size exceeds overall file size limitation'
          };
          return errUtils.handleCustomError(res, 412, response);
        }

        gridFS.saveFile(filePath, fileName, function(err, gridFsId) {
          var attachmentObj = db.attachmentClass();
          attachmentObj = new attachmentObj({
            'gfsID': gridFsId,
            'fileName': fileName,
            'extension': fileExtension,
            'size': fileSizeInBytes
          });

          if (attachmentType === 'creative-mock') {
            var attachmentTypeModel = db.attachmentTypeClass();
            attachmentTypeModel.findOne({
              'codeName': 'attachment_mock'
            }, function(err, attachmentTypeObj) {
              if (err) {
                logger.error('Error occured while fetching attachment type (attachment_mock) from DB. Error: ' + err);
                return errUtils.handleError(res, err);
              }
              if (attachmentTypeObj) {
                attachmentObj.type = attachmentTypeObj;
                attachmentObj.creativeVersion = 0;

                campaignToUpdate.creativeMockup = attachmentObj;
                campaignToUpdate.save(function(err, camp) {
                  if (err) {
                    return errUtils.handleError(res, err);
                  }
                  return res.status(200).jsonp(attachmentObj);
                });
              } else {
                logger.error('Attachment type (attachment_mock) is not present in mongo collection : ' + attachmentType);
                return errUtils.handleError(res, 'Attachment type (attachment_mock) is not present in mongo collection : ' + attachmentType);
              }
            }); //end of attachmentTypeModel.findOne
          } else {
            // Add the gridfs reference in Campaign 
            campaignToUpdate.attachments.push(attachmentObj);
            // Save the campaign to DB
            campaignToUpdate.save(function(err, camp) {
              if (err) {
                return errUtils.handleError(res, err);
              }
              return res.status(200).jsonp(attachmentObj);
            });
          }
        });
      }
    });
  },
  // removeCreativeMock: function(req, res, next) {
  //   //to remove the creative mock from campaign and gridfs.
  //   logger.info('removeCreativeMock::method called');
  //   var gridfs = db.gridfs();
  //   var campaign = db.campaignClass();
  //   gridfs.remove({
  //     _id: req.params.file_id
  //   }, function(err) {
  //     if (err) {
  //       logger.error('removeCreativeMock::Failed to remove file from gridfs');
  //       return errUtils.handleError(res, err);
  //     }
  //     campaign.findOne({
  //       'requestID': req.params.campaign_id
  //     }, function(err, campaign_to_update) {
  //       if (err) {
  //         logger.error('removeCreativeMock::Failed to load campaign');
  //         return errUtils.handleError(res, err);
  //       }
  //       campaign_to_update.creativeMockup = {};
  //       campaign_to_update.save();
  //       return res.status(200).jsonp({
  //         'status': 'success'
  //       });
  //     });
  //   });
  // },
  // uploadCreatives: function(req, res, next) {
  //   logger.info('uploadCreatives::Method called');
  //   var gridfs = db.gridfs();
  //   var is, os;
  //   var fileName = req.files.file.name.replace(/\s+/g, '_');
  //   var campaignId = req.params.campaign_id;
  //   var version = req.params.version;
  //   var stats = fs.statSync(req.files.file.path);
  //   var fileSizeInBytes = stats['size'];
  //   var fileExtension = path.extname(req.files.file.path);
  //   var attachmentType = req.params.attachment_type;
  //   is = fs.createReadStream(req.files.file.path);
  //   os = gridfs.createWriteStream({
  //     filename: fileName
  //   });

  //   is.pipe(os);
  //   //unlink the file from temp location after successful upload
  //   os.on('close', function(file) {
  //     fs.unlink(req.files.file.path, function() {
  //       var gridfs_id = file._id;
  //       var campaign = db.campaignClass();
  //       if (attachmentType === 'attachment_mock') {
  //         campaign.findOneAndUpdate({
  //           'requestID': campaignId,
  //           'attachments.type.codeName': 'attachment_mock'
  //         }, {
  //           '$set': {
  //             'attachments.$.gfsID': gridfs_id,
  //             'attachments.$.fileName': fileName,
  //             'attachments.$.extension': fileExtension,
  //             'attachments.$.size': fileSizeInBytes
  //           }
  //         }, function(err, campaign_with_mock) {
  //           if (err) {
  //             logger.error('mock file update to campaign failed for camapign : ' + campaignId);
  //             return res.status(500).jsonp(err);
  //           } else {
  //             if (campaign_with_mock) {
  //               //remove old attachment from fs
  //               return res.status(200).jsonp(campaign_with_mock);
  //             } else {
  //               campaign.findOne({
  //                 'requestID': campaignId
  //               }, function(err, campaign_without_mock) {
  //                 var attachmentTypeModel = db.attachmentTypeClass();
  //                 attachmentTypeModel.findOne({
  //                   'codeName': 'attachment_mock'
  //                 }, function(err, attachmentTypeObj) {
  //                   if (attachmentTypeObj) {
  //                     var attachmentObj = db.attachmentClass();
  //                     attachmentObj = new attachmentObj({
  //                       'type': attachmentTypeObj,
  //                       'gfsID': gridfs_id,
  //                       'creativeVersion': version,
  //                       'fileName': fileName,
  //                       'extension': fileExtension,
  //                       'size': fileSizeInBytes
  //                     });
  //                     campaign_without_mock.attachments.push(attachmentObj);
  //                     campaign_without_mock.save();
  //                     return res.status(200).jsonp(attachmentObj);
  //                   } else {
  //                     logger
  //                       .error('Attachemnt Type is not present in mongo collection : ' + attachmentType);
  //                     return res.status(500);
  //                   }
  //                 });
  //               });
  //             }
  //           }
  //         });
  //       } else {
  //         //not a mock file
  //         campaign.findOne({
  //           'requestID': campaignId
  //         }, function(err, campaign_to_update) {
  //           var attachmentTypeModel = db.attachmentTypeClass();
  //           attachmentTypeModel.find({
  //             'codeName': attachmentType
  //           }, function(err, attachmentTypeObj) {
  //             if (attachmentTypeObj) {
  //               var attachmentObj = db.attachmentClass();
  //               attachmentObj = new attachmentObj({
  //                 'type': attachmentTypeObj,
  //                 'gfsID': gridfs_id,
  //                 'creativeVersion': version,
  //                 'fileName': fileName,
  //                 'extension': fileExtension,
  //                 'size': fileSizeInBytes
  //               });
  //               campaign_to_update.attachments.push(attachmentObj);
  //               campaign_to_update.save();
  //               return res.status(200).jsonp(attachmentObj);
  //             } else {
  //               logger.error('Attachemnt Type is not present in mongo collection : ' + attachmentType);
  //               return res.status(500);
  //             }
  //           });

  //         });
  //       }
  //     }); //end of fs.unlink
  //   }); // end of is.on
  // },
  show: function(req, res, next) {
    var gridfs = db.gridfs();
    var readstream = gridfs.createReadStream({
      _id: req.params.file_id
    });
    var fileName = req.params.file_name;
    res.setHeader('Content-Disposition', 'inline; filename =' + fileName);
    res.setHeader('Content-Type', mime.lookup(fileName));

    req.on('error', function(err) {
      res.status(500).jsonp(err);
    });
    readstream.on('error', function(err) {
      res.status(500).jsonp(err);
    });

    readstream.on('end', function() {
      return res.status(200);
    });
    readstream.pipe(res);

  },
  saveMAAttachment: function(files, attachmentType, campaignId, versionID, res, attachmentSize) {
    logger.info('saveMAAttachment::Method called');
    var CampaignClass = db.campaignClass();
    var count = 0,
      responseData;
    CampaignClass.findOne({
      'requestID': campaignId
    }, function(err, campaignToUpdate) {
      if (err) {
        return errUtils.handleError(res, err);
      }
      if (!campaignToUpdate) {
        logger.error('saveMAAttachment::Failed to load Campaign');
        return errUtils.handleCustomError(res, 204, {
          'status': 'failure',
          'reason': 'Campaign Not Found'
        });
      }

      campaignToUpdate.ma = campaignToUpdate.ma || {};
      campaignToUpdate.ma.approvalDocuments = campaignToUpdate.ma.approvalDocuments || [];
      campaignToUpdate.ma.instructionDocuments = campaignToUpdate.ma.instructionDocuments || [];
      campaignToUpdate.ma.disengagementValue = (campaignToUpdate.ma.disengagementValue * 1) || 0;
      campaignToUpdate.ma.maCells = campaignToUpdate.ma.maCells || [];
      campaignToUpdate.ma.maVersions = campaignToUpdate.ma.maVersions || [];
      campaignToUpdate.ma.mailHistory = campaignToUpdate.ma.mailHistory || [];
      campaignToUpdate.ma.filesSentToET = campaignToUpdate.ma.filesSentToET || []

      var MA = db.marketingAutomationClass(),
        maObj = new MA({
          'approvalDocuments': campaignToUpdate.ma.approvalDocuments,
          'instructionDocuments': campaignToUpdate.ma.instructionDocuments,
          'disengagementValue': campaignToUpdate.ma.disengagementValue,
          'maCells': campaignToUpdate.ma.maCells,
          'mailHistory': campaignToUpdate.ma.mailHistory,
          'filesSentToET': campaignToUpdate.ma.filesSentToET,
          'maVersions': campaignToUpdate.ma.maVersions
        });
      campaignToUpdate.ma = maObj;
      var fileSizeInBytes = 0;
      asyncEach(files, function(file, fileCallback) {
        logger.info('File upload started');
        var fileName = file.name.replace(/\s+/g, '_');
        var stats = fs.statSync(file.path);
        fileSizeInBytes += stats.size;
        var fileExtension = path.extname(file.path);

        var gridfs = db.gridfs(),
          is, os;
        is = fs.createReadStream(file.path);
        os = gridfs.createWriteStream({
          filename: fileName
        });
        is.pipe(os);
        //unlink the file from temp location after successful upload
        os.on('close', function(fileObj) {
          logger.info('File uploaded to gridfs');
          var gridfsId = fileObj._id;
          fs.unlink(file.path, function() {

            var ATTACHMENTOBJ = db.attachmentClass();
            var attachmentObj = new ATTACHMENTOBJ({
              'gfsID': gridfsId,
              'fileName': fileName,
              'extension': fileExtension,
              'size': fileSizeInBytes
            });
            if (attachmentType && attachmentType === 'approvalDocument') {
              campaignToUpdate.ma.approvalDocuments.push(attachmentObj);
              campaignToUpdate.markModified('ma.approvalDocuments');
              responseData = 'approvalDocument';
            } else if (attachmentType && attachmentType === 'instructionDocuments') {
              campaignToUpdate.ma.instructionDocuments.push(attachmentObj);
              campaignToUpdate.markModified('ma.instructionDocuments');
              responseData = 'instructionDocuments';
            } else
            if (attachmentType && attachmentType === 'versionAttachment' && utils.validateAttachmentObject(attachmentObj)) {
              var versionIndex = utils.findObjectIndex(campaignToUpdate.ma.maVersions, 'versionId', versionID);
              if (versionIndex !== -1) {
                var maVersionObj = campaignToUpdate.ma.maVersions[versionIndex];
                maVersionObj.creativeDocument.push(attachmentObj);
                campaignToUpdate.ma.maVersions[versionIndex] = maVersionObj;
                responseData = 'versionAttachment' + versionIndex;
              }
            }
            //responseData = attachmentObj;
            var sizeLimit = 0;
            //Check the attachemnt type for approval and instruction documents 10mb and 4mb per version size.
            if (attachmentType === 'approvalDocument' || attachmentType === 'instructionDocuments') {
              sizeLimit = fileSizeLimit;
            } else {
              sizeLimit = versionAttachmentLimit;
            }
            //adding the exsisitng file size and new file size if there are any
            if ((attachmentSize + fileSizeInBytes) > fileSizeLimit) {
              var error = {
                'status': 'error',
                'message': 'File size exceeds file size limitation'
              };
              logger.error('File size exceeds file size limitation');
              return fileCallback(error, null);
            }
            return fileCallback(null, responseData);
          }); //end of fs.unlink
        });
      }, function(err, responseData) {
        if (err) {
          logger.error('error uploading files for MA campaign ' + campaignToUpdate.requestID);
          return res.status(500).jsonp(err);
        } else {
          campaignToUpdate.save(function(err) {
            if (err) {
              return res.status(500).jsonp(err);
            }
            logger.info('File upload completed and updated gridfs object to campaign');
          });
          if (responseData && responseData[0]) {
            if (responseData[0] === 'approvalDocument') {
              return res.status(200).jsonp(campaignToUpdate.ma.approvalDocuments);
            } else if (responseData[0] === 'instructionDocuments') {
              return res.status(200).jsonp(campaignToUpdate.ma.instructionDocuments);
            } else if (responseData[0].indexOf('versionAttachment') > -1) {
              return res.status(200).jsonp(campaignToUpdate.ma.maVersions);
            }
          } else {
            return res.status(200).jsonp(campaignToUpdate.ma.maVersions);
          }
        }
      });
    });
  },
  saveMAFilesToGridFs: function(req, res, next) {
    var campaignId = req.params.campaign_id,
      CampaignClass = db.campaignClass();
    CampaignClass.findOne({
      'requestID': campaignId
    }, function(err, campaignToUpdate) {
      campaignToUpdate.ma = campaignToUpdate.ma || {};
      campaignToUpdate.ma.approvalDocuments = campaignToUpdate.ma.approvalDocuments || [];
      campaignToUpdate.ma.instructionDocuments = campaignToUpdate.ma.instructionDocuments || [];
      campaignToUpdate.ma.maVersions = campaignToUpdate.ma.maVersions || [];
      if (!campaignToUpdate) {
        logger.error('Invalid campaign request id is sent in the request' + campaignId);
        return res.status(500);
      }
      var filesArr = [],
        attachmentSize = 0;
      if (!Array.isArray(req.files.file)) {
        filesArr[0] = req.files.file;
      } else {
        filesArr = req.files.file;
      }
      if (req.params.attachment_type === 'instructionDocuments') {
        attachmentSize = utils.calculateAttachmentSize(campaignToUpdate.ma.instructionDocuments, 'size');
      } else if (req.params.attachment_type === 'approvalDocument') {
        attachmentSize = utils.calculateAttachmentSize(campaignToUpdate.ma.approvalDocuments, 'size');
      }
      module.exports.saveMAAttachment(filesArr, req.params.attachment_type, campaignId, null, res, attachmentSize);
    });
  },
  destroy: function(req, res) {
    logger.info('api.file.destroy :: method entry');
    var gridfs = db.gridfs();
    var campaignId = req.params.campaign_id;
    gridFS.exists(req.params.file_id, function(err, found) {
      if (err) {
        return errUtils.handleError(res, err);
      }

      if (!found) {
        return res.status(412).send('File not found in GridFS.');
      }

      var Campaign = db.campaignClass(),
        query;

      switch (req.params.attachment_type) {
        case 'approvalDocument':
          query = {
            $pull: {
              'ma.approvalDocuments': {
                'gfsID': req.params.file_id
              }
            }
          };
          break;
        case 'instructionDocuments':
          query = {
            $pull: {
              'ma.instructionDocuments': {
                'gfsID': req.params.file_id
              }
            }
          };
          break;
        case 'creative-mock':
          query = {
            $set: {
              'creativeMockup': {}
            }
          };
          break;
        default:
          query = {
            $pull: {
              'attachments': {
                'gfsID': req.params.file_id
              }
            }
          };
          break;
      }

      Campaign.findOneAndUpdate({
        '_id': campaignId
      }, query, {
        'new': 'true'
      }, function(err, campaign) {
        if (err) {
          return errUtils.handleError(res, err);
        }
        gridFS.deleteFile(req.params.file_id, function(err) {
          if (err) {
            return errUtils.handleError(res, err);
          }
          return res.status(200).jsonp({
            status: 'success'
          });
        });
      });

    });
  }
};
