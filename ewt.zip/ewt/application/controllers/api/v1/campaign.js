/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md 
 *
 *
 * Description: EWT-2.0 (ERA) - This file defined the campaign controller at Node end. It has all action methods related to campaign.
 */

'use strict';

var db = require('../../../lib/db.js'),
  esp = require('../../../lib/esp.js'),
  assert = require('assert-plus'),
  _ = require('lodash'),
  EventEmitter = require('events').EventEmitter,
  ee = new EventEmitter(),
  email = require('../../email'),
  utils = require('../../../lib/utils.js'),
  stateValidator = require('../../../lib/state-validator.js'),
  mhidValidator = require('./mhid-validator.js'),
  campaignLibrary = require('../../../lib/campaign.js'),
  errUtils = require('../../../lib/err-utils.js'),
  formatForExport = require('../../../lib/export-formater.js'),
  campaignLockMaxTimeout = 1800000; // by default, campaign lock should expire in 30 mins (1800000 milli seconds).
/*
 * Controller which handles api requests related to campaign, coming from client through router.
 */
module.exports = {
  /*
   * Name: index
   * Description: This action method returns all the campaigns in DB with out any filters. It returns only those campaign fields/attributes which are requested by client.
   * @param {Object} req Request object received from client
   * @param {Object} res Response object send back to client
   */

  index: function(req, res) {
    logger.info('api.campaign.index :: method entry');
    var Campaign = db.campaignClass(),
      sortOptions = {},
      filterObj = {},
      orFilter = [],
      deployDate = {},
      maDate = {},
      datesObj = {},
      mhidObj = {},
      startDepDatePresent = false,
      endDepDatePresent = false;
    // get the requested fields of all the campaigns in DB
    // default view for mm is to show the records of there uid in requestor,primary marketing manager and secondary marketing manager
    if ((utils.isMMUser(req.session.loggedInUser) && !req.body.action) || (req.body.action && req.body.uid && req.body.uid.trim().length > 0)) {
      //filterobje to apply the or logic
      var uid,
        deploymet;
      if (req.body.uid) {
        uid = req.body.uid;
      } else {
        uid = req.session.loggedInUser.uid;
      }
      orFilter.push({
        'requestor.uid': uid
      });
      orFilter.push({
        'primaryMarketingManager.uid': uid
      });
      orFilter.push({
        'secondaryMarketingManager.uid': uid
      });
    }
    if (orFilter.length > 0) {
      filterObj.$or = orFilter;
    }
    if (!_.isEmpty(req.body)) {
      if (req.body.requestID && req.body.requestID.trim().length >= 5) {
        filterObj.requestID = req.body.requestID;
      }
      if (req.body.mhid && req.body.mhid.trim().length > 0) {
        req.body.mhid = req.body.mhid.toUpperCase();
        var maMhidObj = {
          'ma.mailHistory.mhid': {
            "$regex": "^" + req.body.mhid
          }
        };
        var mhidValueObj = {
          'mailHistory.mhid': {
            "$regex": "^" + req.body.mhid
          }
        };
        mhidObj.$or = [maMhidObj, mhidValueObj];
      }
      if (req.body.emailType && req.body.emailType.trim().length > 0) {
        filterObj['emailType.codeName'] = req.body.emailType;
      }
      if (req.body.businessUnit && req.body.businessUnit.trim().length > 0) {
        filterObj['businessUnit.codeName'] = req.body.businessUnit;
      }
      if (req.body.campaignStatus && req.body.campaignStatus.trim().length > 0) {
        filterObj['state.codeName'] = req.body.campaignStatus;
      }
      if (req.body.edis) {
        filterObj['isDynamicCampaign'] = req.body.edis;
      }
      if (req.body.deploymentStartDate && req.body.deploymentStartDate.trim().length > 0) {
        startDepDatePresent = true;
        var depStartDate = new Date(req.body.deploymentStartDate);
      }
      if (req.body.deploymentEndDate && req.body.deploymentEndDate.trim().length > 0) {
        endDepDatePresent = true;
        var depEndDate = new Date(req.body.deploymentEndDate);
        // Increment the given end date by 1 as we take the time as midnight 12, so one day should be incremented to include the last/end date
        depEndDate.setDate(depEndDate.getDate() + 1);
      }

      if (startDepDatePresent && endDepDatePresent) { // Both Start and End Dates are given in filter criteria
        // Show all campaigns, except the campaigns that have start date as well as end date outside the given start / end date range.
        deployDate = {
          "$and": [{
            "deploymentDates.0": {
              "$lte": depEndDate
            }
          }, {
            "$or": [{
              "endDate": {
                "$gte": depStartDate
              }
            }, {
              "endDate": null
            }]
          }]
        };

        maDate = {
          "$and": [{
            "ma.mailHistory.startDate": {
              "$lte": depEndDate
            }
          }, {
            "$or": [{
              "endDate": {
                "$gte": depStartDate
              }
            }, {
              "endDate": null
            }]
          }]
        };
      } else if (startDepDatePresent) { // Only Start date is given, no End date is given in filter criteria
        // Show all the campaigns that have start date greater than equal to given start date
        deployDate = {
          "deploymentDates.0": {
            "$gte": depStartDate
          }
        };

        maDate = {
          "ma.mailHistory.startDate": {
            "$gte": depStartDate
          }
        };
      } else if (endDepDatePresent) { // Only End date is given, no Start date is given in filter criteria
        // Show all the campaigns that have end date less than equal to given end date
        deployDate = maDate = {
          "endDate": {
            "$lte": depEndDate
          }
        };
      }

      datesObj.$or = [deployDate, maDate];

      if (req.body.requestedStartDate && req.body.requestedStartDate.trim().length > 0) {
        var requestStartDate = utils.formatDate(req.body.requestedStartDate);
        filterObj['createdOn'] = {
          "$gte": requestStartDate
        };
      }
      if (req.body.requestedEndDate && req.body.requestedEndDate.trim().length > 0) {
        var requestedEndDate = utils.formatDate(req.body.requestedEndDate);
        filterObj['createdOn'] = filterObj['createdOn'] || {};
        filterObj['createdOn'].$lte = requestedEndDate;
      }
      filterObj.$and = [datesObj, mhidObj];
    }

    /**
     * params - this will decide the values to be fetched from database for each campaign.
     * as of now we are fetching all the details on searching campaign - this has to be changed for faster performance.
     */
    var params = {};
    /**
     * if this api was hit for exporting campaigns
     * @param  {[type]} req.body.action  - Decides if the api was called for
     *                                     search or export
     * if 'export' - then params are coustomised based on the request.
     */
    if (req.body.action === 'export') {
      params = req.body.columns.join(',').split(',').join(' ');
      var isExport = true;
    }

    Campaign.find(filterObj, params, {
        sort: {
          'requestID': -1
        }
      },
      function(err, campaigns) {
        if (err) {
          return errUtils.handleError(res, err);
        }
        var filteredArr = [],
          isIDPresent = false;
        if (req.body.requestID && req.body.requestID.trim().length < 5) {
          isIDPresent = true;
          for (var cnt = 0; cnt < campaigns.length; cnt++) {
            var campaingObj = campaigns[cnt],
              value = campaingObj.requestID + "";
            if (value.lastIndexOf(req.body.requestID, 0) !== -1) {
              filteredArr.push(campaingObj);
            }
          }
        }
        /**
         * filtered array is sent back as response if requestId of campaign is requested
         */
        if (isIDPresent) {
          return res.status(200).jsonp(filteredArr);
        }

        /**
         * If the api was for export block below gets exicuted
         */
        if (isExport) {
          var fieldsDetails = [];
          req.body.heading.forEach(function(heading, index) {
            fieldsDetails.push({
              key: heading,
              reference: req.body.columns[index]
            });
          });
          /**
           * Extracted Campaigns are formated and then sent back as response.
           */
          var options = {
            startDate: req.body.deploymentStartDate || '',
            endDate: req.body.deploymentEndDate || ''
          }
          return res.status(200).jsonp(formatForExport.campaigns(campaigns, fieldsDetails, options));
        }
        return res.status(200).jsonp(campaigns);
      });
    logger.info('Exiting method api.campaign.index');
  },

  /*
   * Name: create
   * Description: This action method adds / create one campaign in DB. It perfomr validations of different campaign fields bfore adding to DB.
   * @param {Object} req Request object received from client
   * @param {Object} res Response object send back to client
   */
  create: function(req, res) {
    logger.info('api.campaign.create :: method entry');
    // Attach the validator method to request object. Will be used later to validate the campaign / request object.
    utils.setupValidator(req, res);
    var Campaign = db.campaignClass(),
      campaign = new Campaign(),
      sequenceGenerator = db.sequenceGeneratorClass(),
      CampaignStatus = db.campaignStateClass(),
      loggedInUserName = req.session.loggedInUser.name,
      isValid = false;

    // Above we created empty campaign object. Now get the campaign object filled with info that we received from client.
    // This is initial prepration campaign object without any validations.
    campaign = campaignLibrary.getCampaignObject(campaign, req);
    var dt = new Date();
    var requestedUTCDate = new Date(Date.UTC(dt.getFullYear(), dt.getMonth(), dt.getDate()));
    requestedUTCDate.setUTCHours(12);
    campaign.createdOn = requestedUTCDate;
    campaign.updatedOn = requestedUTCDate;
    // Two initial states for fresh campaign can be draft (when user saved, without submitting) OR submi to DCE for 1st level approval
    if (!(campaign.state.codeName === 'draft' || campaign.state.codeName === 'submitted4approval')) {
      return errUtils.handleCustomError(res, 412, 'Invalid Campaign Request');
    }
    // We need to skip any validation on campaign in case we are just saving it (draft) and not submitting it. We should validate only in case of submittion.
    if (campaign.state.codeName !== 'draft') {
      isValid = campaignLibrary.isValidCampaign(req);
      if (!(isValid.status)) {
        return errUtils.handleCustomError(res, 412, {
          status: 'failure',
          code: 'VALIDATION_FAILED',
          reason: 'Validation Error(s): ' + isValid.reason
        });
      }
    }
    var query = {
        name: 'campaign'
      },
      update = {
        $inc: {
          sequence: 1
        }
      },
      options = {
        new: true,
        upsert: true
      };
    // For requested state, get mongo document from 'campaignstatus' DB collection. This will be embedded in the campaign document.
    CampaignStatus.findOne({
      'codeName': req.body.state.codeName
    }, function(err, campaignState) {
      if (err) {
        return errUtils.handleCustomError(res, 412, 'Invalid Campaign State');
      }
      // Add log entry in campaign for state change
      campaign = campaignLibrary.addLog(loggedInUserName, campaign, campaignState.logDisplayName);
      campaign.state = campaignState;

      // Generate the unique seq no as Request ID of campaign. This is unique identifier for business to refer.
      // This is not primary key, although it can server as primary key also.
      sequenceGenerator.findOneAndUpdate(query, update, options, function(error, result) {
        if (error) {
          return errUtils.handleCustomError(res, 412, 'Request ID Generation Failed');
        }
        logger.info('api.campaign.create :: RequestID generated: ' + result.sequence);
        campaign.requestID = result.sequence;

        // Finally save the campaign in DB under campaign collection.
        campaign.save(function(err) {
          if (err) {
            return errUtils.handleError(res, err);
          }
          logger.info('api.campaign.create :: Campaign (RequestID - ' + campaign.requestID + ') saved successfully');
          res.status(200).jsonp(campaign);
        });
      });
    });
  },

  /*
   * Name: show
   * Description: This action method returns a single campaign as JSON, based on the requested ID
   * @param {Object} req Request object received from client
   * @param {Object} res Response object send back to client
   */
  show: function(req, res) {
    logger.info('api.campaign.show :: method entry');
    var Campaign = db.campaignClass();

    // Query DB to get the campaign based on requested ID
    Campaign.findById(req.params.campaign_id, function(err, campaign) {
      if (err) {
        return errUtils.handleError(res, err);
      }
      if (!campaign) {
        return errUtils.handleCustomError(res, 412, {
          status: 'failure',
          reason: 'Requested campaign does not exists.'
        });
      }
      // If the campaign is Rolledback, get the status of campaign from ET.
      // If the campaign has been deployed or cancelled, client may want to handle it diferently.
      if (campaign.state.codeName === 'rollBack2Manager') {
        esp.getCampaignDeploymentDetails(campaign, function(err, camp) {
          if (err) {
            return errUtils.handleError(res, err);
          } else {
            return res.status(200).json(camp);
          }
        });
      } else {
        return res.json(campaign);
      }
    });
  },

  /*
   * Name: lock
   * Description: This action method is called to acquire the edit-lock for given campaign. Edit lock must be acquired before going to.
   * @param {Object} req Request object received from client
   * @param {Object} res Response object send back to client
   */
  lock: function(req, res) {
    logger.info('api.campaign.lock :: method entry');
    // Locking may be immediately after unlocking (Save As case).
    // To avoid race condition, we delay the locking by few milli-sec by default.
    setTimeout(function() {
      logger.info('api.campaign.lock.timer :: method entry');
      var Campaign = db.campaignClass();
      // Get the requested campaign from DB
      Campaign.findById(req.params.campaignId, function(err, campaign) {
        var isRequestor = false,
          isPMM = false,
          isSMM = false,
          isAdmin = false,
          response = {
            status: 'failure',
            reason: '',
            isLocked: false,
            lockKey: '',
            lockOwner: null,
            expiresAt: null
          },
          currDate;
        if (err) {
          return errUtils.handleError(res, err);
        }

        if (!campaign) {
          response.reason = 'Can not acquire an edit lock as the related campaign does not exist.';
          // return res.status(200).jsonp(response);
          return errUtils.handleCustomError(res, 200, response);
        }
        response.isLocked = campaign.lock.isLocked;
        response.lockKey = campaign.lock.key;
        response.lockOwner = campaign.lock.owner;
        response.expiresAt = campaign.lock.expiresAt;
        // Check if the lock is already acquired or not ?
        if (!(campaign.lock.isLocked)) {
          // Caution -- From here on, till we dont save the campaign back in DB, race condition can occur between multiple client requests.
          // In case of race condition, the request that saves the campaign later, will win in acquire the lock.
          isRequestor = utils.isCampaignRequestor(req.session.loggedInUser, campaign);
          isPMM = utils.isPMM(req.session.loggedInUser, campaign);
          isSMM = utils.isSMM(req.session.loggedInUser, campaign);
          isAdmin = utils.isAdminUser(req.session.loggedInUser);
          // Only allow requestor, pmm, smm and admins to acquire lock and edit the campaign - this is how business need it.
          if (isRequestor || isPMM || isSMM || isAdmin) {
            response.isLocked = campaign.lock.isLocked = true;
            response.lockKey = campaign.lock.key = req.params.tabId;
            response.lockOwner = campaign.lock.owner = req.session.loggedInUser;
            currDate = new Date();
            currDate.setMilliseconds(currDate.getMilliseconds() + campaignLockMaxTimeout); // lock auto-expires after 30 mins
            response.expiresAt = campaign.lock.expiresAt = currDate;
            // Clear previous timer, if any
            utils.clearCampaignUnlockTimer(campaign);
            // Set 30 mins timer to auto-release the lock in case its not released manually in 30 minutes
            campaign.lock.timer = utils.setCampaignUnlockTimer(req.params.campaignId, req.params.tabId, campaignLockMaxTimeout);
            // We are good to go and acquire the lock, so save the campaign to DB.
            campaign.save(function(err) {
              if (err) {
                return errUtils.handleError(res, err);
              }
              logger.info('api.campaign.lock.timer :: User (' + req.session.loggedInUser.name + ') successfully acquired the campaign lock for campaign ID:' + campaign.requestID);
              response.status = 'success';
              response.reason = 'User (' + req.session.loggedInUser.name + ') successfully acquired the campaign lock for campaign ID: ' + campaign.requestID;
              return res.status(200).jsonp(response);
            });
          } else { // User that requested the lock is not requestor, PMM, SMM or Admin so lock can not be acquired.
            response.reason = 'You can not acquire the lock, as only campaign requestor, primary or secondary marketing manager of the campaign and admin users can acquire the campaign lock.';
            return res.status(200).json(response);
          }
        } else { // Some one already have acquired the lock.
          if (campaign.lock.key === req.params.tabId) {
            // Requestor of lock is himself the lock owner, so he/she need not to re-acquire it.
            response.reason = 'You already have the lock, you need not to re-acquire it.';
          } else {
            // Someone else, other than the requestor have the lock. Wait for lock to be released and then try again.
            response.reason = 'Could not acquire a lock as it has been already acquired by someone.';
          }
          return res.status(200).json(response);
        }
      });
    }, 100);
  },

  /*
   * Name: unlock
   * Description: This action method is called to release the edit-lock for given campaign. Edit lock must be released once the campaign is edited and saved.
   * @param {Object} req Request object received from client
   * @param {Object} res Response object send back to client
   */
  unlock: function(req, res) {
    logger.info('api.campaign.unlock :: method entry');
    var Campaign = db.campaignClass();
    // Get the requested campaign from DB
    Campaign.findById(req.params.campaignId, function(err, campaign) {
      var response = {
        status: 'failure',
        reason: '',
        isLocked: false,
        lockKey: '',
        lockOwner: null
      };

      if (err) {
        return errUtils.handleError(res, err);
      }

      if (!campaign) {
        response.reason = 'Can not unlock an edit lock as the related campaign does not exist.';
        return errUtils.handleCustomError(res, 200, response);
      }

      response.isLocked = campaign.lock.isLocked;
      response.lockKey = campaign.lock.key;
      response.lockOwner = campaign.lock.owner;
      // Check if the campaign is already locked or not ?
      if (campaign.lock.isLocked) {
        // Unlock only if request to unlock is from Admin or the current owner of lock.
        if ((utils.isAdminUser(req.session.loggedInUser)) || (req.session.loggedInUser.uid === campaign.lock.owner.uid)) {
          // Release the lock
          response.isLocked = campaign.lock.isLocked = false;
          response.lockKey = campaign.lock.key = '';
          response.lockOwner = campaign.lock.owner = null;
          // As we are unlocking, we need to cancel the earlier registered timer that is supposed to auto-release of lock. That is not required any more.
          // If we dont do this, it will fire at later time and may unlock the lock that is acquired by some other user at that particular time -- that is dangerous situation to be in.
          if (campaign.lock.timer) {
            clearTimeout(campaign.lock.timer);
            campaign.lock.timer = null;
          }
          response.status = 'success';
          response.reason = 'User (' + req.session.loggedInUser.name + ') successfully released the campaign lock for campaign ID: ' + campaign.requestID;
          // Save the campaign to make the unlock effective.
          campaign.save(function(err) {
            if (err) {
              return errUtils.handleError(res, err);
            }
            logger.info('api.campaign.unlock :: User (' + req.session.loggedInUser.name + ') successfully released the campaign lock for campaign ID: ' + campaign.requestID);
            return res.status(200).jsonp(response);
          });
        } else { // Requestor is not an Admin or the current owner of lock, so he/she do not have right to unlock it.
          response.reason = 'You are not an Admin or the owner of this campaign lock, so you can not release it.';
          return res.status(200).json(response);
        }
      } else { // Lock is already unlocked; no one hase acquired it, so no need to release it.
        response.reason = 'The campaign is not locked so there is no lock to release.';
        return res.status(200).json(response);
      }
    });
  },

  /*
   * Name: extendLockTimer
   * Description: This action method is called to extend the edit-lock for given campaign.
   * By default the campaign is locked for max 30 mins. User need to extend the lock if he/she wants to keep the 
   * lock for more than 30mins, this will reset the lock window to next 30 mins. 
   * @param {Object} req Request object received from client
   * @param {Object} res Response object send back to client
   */
  extendLockTimer: function(req, res) {
    logger.info('api.campaign.extendLockTimer :: method entry');
    var Campaign = db.campaignClass();
    Campaign.findById(req.params.campaignId, function(err, campaign) {
      var response = {
          status: 'failure',
          reason: ''
        },
        currDate;

      if (err) {
        return errUtils.handleError(res, err);
      }

      if (!campaign) {
        response.reason = 'Can not extend an edit lock as the related campaign does not exist.';
        return errUtils.handleCustomError(res, 200, response);
      }

      // Check if the reuqestor is the current owner of lock or not ?
      if (campaign.lock.isLocked) {
        if (campaign.lock.key === req.params.tabId) {
          if (campaign.lock.expiresAt >= new Date()) { // Still there is a time for lock to expire automatically, that means we are requesting to extend the lock with in 30 mins of acquiring the lock, so honour the request
            // Cancel the earlier registered timer that was scheduled to auto-release the lock after 30 mins.
            utils.clearCampaignUnlockTimer(campaign);
            // Set the new expiry time of 30 min starting from now. This is the actual extension of lock.
            currDate = new Date();
            currDate.setMilliseconds(currDate.getMilliseconds() + campaignLockMaxTimeout); // lock auto-expires after 30 mins
            campaign.lock.expiresAt = currDate;
            // Setup new timer to be triggered after 30 mins, that will uto-release the lock, if not release within 30 min.
            // We surely dont want to be in a situation where campaign remains locked forever. It should auto-release after 30 mins.
            campaign.lock.timer = utils.setCampaignUnlockTimer(req.params.campaignId, req.params.tabId, campaignLockMaxTimeout);
            // Finally make unlock effective by saving campaign to DB
            campaign.save(function(err) {
              if (err) {
                return errUtils.handleError(res, err);
              }
              logger.info('api.campaign.extendLockTimer :: User (' + req.session.loggedInUser.name + ') successfully reset the campaign lock timer for campaign ID: ' + campaign.requestID);
              response.status = 'success';
              response.reason = 'User (' + req.session.loggedInUser.name + ') successfully reset the campaign lock timer for campaign ID: ' + campaign.requestID;
              return res.status(200).jsonp(response);
            });
          } else { // This siatuation is rare to occur, will only occur is extend lock request and earlier registered unlock timer fires at same time - race condition.
            response.reason = 'Could not extend the lock as campaign lock has timed out. Taking you out of campaign edit mode.';
            return res.status(200).jsonp(response);
          }
        } else { // Requestor of extend-lock request is not the current owner of lock, so he/she can not request to extend the lock. Wrong request done.
          response.reason = 'You are not the current owner of lock, so you can not extend the lock.';
          return res.status(200).jsonp(response);
        }
      } else { // No one has acquired the lock, so there should be any question to extend the lock. Wrong request done.
        response.reason = 'Campaign lock has been auto-released due to timeout and you are not the editor of campaign anymore. Taking you out of campaign edit mode.';
        return res.status(200).jsonp(response);
      }
    });
  },
  /*
   * Name: update
   * Description: This action method is called to update an existing campaign.
   * @param {Object} req Request object received from client
   * @param {Object} res Response object send back to client
   */
  update: function(req, res) {
    logger.info('api.campaign.update :: method entry');
    // Setup the validator on request object. This will be used to validate the campaign against business rules.
    utils.setupValidator(req, res);
    /**
     * Campaign - Campaign class, used to make CRUD operations over campaign
     * @type {Object}
     */
    var Campaign = db.campaignClass(),
      response,
      /**
       * CampaignStatus - Campaign Status class, used to make CRUD operations over campaign status
       * @type {[type]}
       */
      CampaignStatus = db.campaignStateClass(),
      /**
       * ewt2Save - Boolean to check if the state transition is abstract.
       *            i.e., saving the campaign.
       * @type {Boolean}
       */
      ewt2Save = false,
      campaignRequest,
      loggedInUserName,
      isValid = false;
    loggedInUserName = req.session.loggedInUser.name;

    /**
     * Fetching the campaign from the data base that has to be updated
     */
    Campaign.findById(req.params.campaign_id, function(err, campaign) {
      /**
       * if error occurs while retrieving the campaign then throwing back an error
       */
      if (err) {
        return errUtils.handleError(res, err);
      }

      /**
       * Campaign to be updated not found, so return an error.
       */
      if (!campaign) {
        return errUtils.handleCustomError(res, 404, {
          'status': 'failure',
          'reason': 'Campaign with ID ' + req.params.campaign_id + ', not found'
        });
      }

      // STO Change
      campaign.sto = {};
      if (req.body.sto) {
        campaign.sto = req.body.sto;
        campaign.sto.isSTO = req.body.sto.isSTO;
        campaign.sto.isThrottled = req.body.sto.isThrottled;
        campaign.sto.isSpecificTime = req.body.sto.isSpecificTime;
        campaign.sto.isSpecialTestingReq = req.body.sto.isSpecialTestingReq;
        campaign.sto.stoEmailTrackingType = req.body.sto.stoEmailTrackingType;
        campaign.sto.stoEventToTrack = req.body.sto.stoEventToTrack;
      }
      campaign.commCode = req.body.commCode || campaign.commCode || {};

      // If the user that wants to update the campaign is not an owner of edit lock, do not update / save campaign.
      // It will be disaster to update campaign, specially when the lock is acquired by someone else - as that user may be updating the campaign
      if (!(campaign.lock.isLocked) || (campaign.lock.owner.uid !== req.session.loggedInUser.uid)) {
        return errUtils.handleCustomError(res, 412, {
          status: 'failure',
          code: 'NO_OWNER',
          showOnUI: true,
          reason: 'Could not update the campaign, as currently you do not own an edit lock for this campaign (' + campaign.requestID + ').'
        });
      }

      // If campaign is in 'declined' state, it should not be updated as it is one of the end states.
      if (campaign.state.codeName === 'declined') {
        return errUtils.handleCustomError(res, 412, {
          status: 'failure',
          showOnUI: true,
          reason: 'Declined Campaign cannot be modified.'
        });
      }

      // Check if the campaign current state is approved and client sends the same code in request, then its a Save as Draft operation after EWT1 stage.
      if (campaign.state.codeName === 'approved' && campaign.state.codeName === req.body.state.codeName) {
        // Change the state in request to identify it differently in validate function, called later in flow.
        req.body.state.codeName = 'ewt2Save';
        ewt2Save = true;
      }

      // Check if state trasition is possible or not. This is going to cross check against state-machine.
      var status = stateValidator.validateState(campaign, req.body.state.codeName);
      if (!status) {
        return errUtils.handleCustomError(res, 412, {
          status: 'failure',
          reason: 'Transition to "' + req.body.state.name + '" state is not allowed from current state "' + campaign.state.name + '".'
        });
      }

      /**
       * Cheking if validation should happen over the requested campaign.
       */
      switch (req.body.state.codeName) {
        case 'draft':
        case 'declined':
        case 'revisionRequired':
        case 'rollBack2Manager':
        case 'ewt2Save':
          /**
           * We need not to validate if the campaign is in one of the above states.
           */
          break;
        case 'cancelled':
          campaignLibrary.cancelCampaign(campaign);
          break;
        default:
          if (req.body.state.codeName === campaign.state.codeName) {
            // If requested state is same as current state of campaign, its a Save As operation, skip validation in this case.
            break;
          }
          isValid = campaignLibrary.isValidCampaign(req);
          // In all other cases validate the campaign and ensure that it passes against all business rules.
          if (!(isValid.status) && !ewt2Save) {
            return errUtils.handleCustomError(res, 412, {
              status: 'failure',
              code: 'VALIDATION_FAILED',
              showOnUI: true,
              reason: 'Validation Errors:' + isValid.reason
            });
          }
          break;
      }

      // Send notification email. This will send notification email to interested parties, if there is state transition
      email.sendEmail(req, campaign);

      // Get the campaignstatus document for requested state. We will embed that document in Campaign document to register the new state.
      CampaignStatus.findOne({
        'codeName': req.body.state.codeName
      }, function(err, campaignState) {
        // Add log entry to campaign, if there is state transition.
        if (campaign.state.codeName !== campaignState.codeName) {
          campaign = campaignLibrary.addLog(loggedInUserName, campaign, campaignState.logDisplayName);
        } else {
          // For Save as Draft - Although this is not state transition, still register this in campaign log for reference.
          campaign = campaignLibrary.addLog(loggedInUserName, campaign, 'Saved');
        }
        // Update the campaign document with data recevied in request.
        campaignRequest = campaignLibrary.getCampaignObject(campaign, req);

        if (campaignRequest.emailType.codeName === 'ET_MA') {
          campaignRequest = campaignLibrary.processMAAttachments(req, campaignRequest);
        }

        // Assign the new state to campaign
        campaignRequest.state = campaignState;

        var dt = new Date();
        var requestedUTCDate = new Date(Date.UTC(dt.getFullYear(), dt.getMonth(), dt.getDate()));
        requestedUTCDate.setUTCHours(12);
        campaign.updatedOn = requestedUTCDate;

        // Finally, save the campaign to DB
        campaignRequest.save(function(err) {
          if (err) {
            return errUtils.handleError(res, err);
          } else {
            if (req.body.state.codeName === 'queued2esp') { // This is submit to ESP case
              /**
               * As submit to ESP may take some time (API calls to ESP, sending emails etc), we dont want to hold the user.
               * The approach taken is to just schedule the campaign in queue for submission to ET, change the campaign status to queued2esp and return back.
               * Once the submission is done, we will fire the event, which will make change in campaign staus accordingly.
               *
               * Register the event handler for event that will be fire the submission process in background.
               * 
               * NOTE: we used .once() method. It will get fired only once and then this handler will get de-registered automatically.
               * If we do not use .once() method, there can be multiple submissions to ESP for each campaign.
               */
              ee.once('queuedForEsp', function(campaign) {
                esp.submitToET(campaign, function(err) {
                  if (err) {
                    logger.error('api.campaign.update :: Campaign (RequestID - ' + campaign.requestID + ') could not be submitted to ESP.');
                  } else {
                    logger.info('api.campaign.update :: Campaign (RequestID - ' + campaign.requestID + ') successfully submitted to ESP.');
                  }
                });
              });
              logger.info('api.campaign.update :: Event emitter, emitted queued2esp event for Campaign (RequestID - ' + campaign.requestID + ')');
              // Fire the event (for whcih we registered the handler above) to start the submission process in backgorund. We are just going to start the process and return back.
              ee.emit('queuedForEsp', campaign);
            }

            // If we decline the capaign after submission to ESP, we need to cancel the campaign at ESP end
            if (req.body.state.codeName === 'declined' && campaign.isSubmittedToESP) {
              // The approach is same as submission to ESP. We start the process of cancelling campaign at ESP in backend and return back.
              // Register the event handler that will start the cancellation process.
              ee.once('cancelAtESP', function(campaign) {
                esp.cancelRolledBackCampaign(campaign, function(err) {
                  if (err) {
                    logger.error('api.campaign.update :: Campaign (RequestID - ' + campaign.requestID + ') could not be cancelled at ESP end.');
                  } else {
                    logger.info('api.campaign.update :: Campaign (RequestID - ' + campaign.requestID + ') successfully cancelled at ESP end.');
                  }
                });
              });
              logger.info('api.campaign.update :: Event emitter, emitted cancelAtESP event for Campaign (RequestID - ' + campaign.requestID + ')');
              // Fire an event to cancel the campaign at ESP end. On firing this event, above registered handler will get invoked.
              ee.emit('cancelAtESP', campaign);
            }
            // Although the request is not yet complete, but we started the needed process to complete the request, so we need not to wait. Return back to client.
            return res.status(200).jsonp(campaignRequest);
          }
        });
      });
    });
  }
};
