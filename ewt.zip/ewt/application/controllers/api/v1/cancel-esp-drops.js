/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and 
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 (ERA) - This file exposes required API to UI that aid in cancelling select campaign
 * drops at ET.
 */
'use strict';

var db = require('../../../lib/db'),
  intgUtils = require('../../../lib/esp-intg-utils'),
  errUtils = require('../../../lib/err-utils'),
  _ = require('lodash');

module.exports = {

  /**
   * Name: showByEmailTypeCode
   * Description: This action method is responsible read request body for the array of cancelled drops and cancel them at ET.
   * @param  {Object} req Request object received from client
   * @param  {Object} res Response data returned to client
   * @return {Void}     This function returns JSON data to client
   */

  cancelCampaignDrops: function(req, res) {
    var requestID = req.body.requestID;
    var Campaign = db.campaignClass();
    Campaign.findOne({
      'requestID': requestID
    }, function(err, campaign) {
      if (err) {
        logger.error('inside cancel campaign drops error');
        return errUtils.handleError(res, err);
      } else {
        logger.info('cancelled campaign is found in cancelCampaignDrops function');
        intgUtils.markCellAsCancelled(campaign, req.body.canceledDrops, function(err) {
          campaign.markModified('versions');
          campaign.markModified('ma.mailHistory');
          campaign.markModified('ma.maCells');
          campaign.save(function(err) {
            if (!err) {
              return res.status(200).json(req.body.canceledDrops);
            } else {
              return errUtils.handleError(res, err);
            }
          });
        });
      }
    });
  }
};
