/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-POC - <DESC_HERE>
 */

'use strict';

function sendErrorResponse(res, mhid) {
  var errorResponse = {
    'mhid': mhid,
    'errorMessage': 'MHID is already used. Please cross-check.'
  };
  logger.error(errorResponse);
  res.status(200).jsonp(errorResponse);
}

function handleCustomError(res, errCode, errMessage) {
  logger.error(errMessage);
  return res.status(errCode).send(errMessage);
}

function handleError(res, err) {
  logger.error(err);
  return res.status(500).send(err);
}

function handleErroneusRequest(res) {
  var errorResponse = {
    'errorMessage': 'Invalid mhid in the request'
  };
  res.status(500).jsonp(errorResponse);
}
var db = require('../../../lib/db.js'),
  _ = require('lodash'),
  utils = require('../../../lib/utils.js');

module.exports = {
  validate: function(req, res) {
    var Campaign = db.campaignClass();
    var mhid = req.params.mhid || req.body.mailHistory[0].mhid;
    if (mhid.length !== 8) {
      return handleErroneusRequest(res);
    }
    Campaign.count({
      'mailHistory.mhid': mhid,
      'state.codeName': {
        $ne: 'cancelled'
      }
    }, function(err, count) {
      Campaign.count({
        'ma.mailHistory.mhid': mhid,
        'state.codeName': {
          $ne: 'cancelled'
        }
      }, function(err, macount) {
        if (count === 0 && macount === 0) {
          var status = {
            status: 'ok'
          };
          res.status(200).jsonp(status);
        } else {
          return sendErrorResponse(res, mhid);
        }
      });
    });
  },
  create: function(req, res) {
    var Campaign = db.campaignClass(),
      isMHIDChanged = false;
    Campaign.findOne({
      'requestID': req.body.requestID
    }, function(err, campaign) {
      if (err) {
        return res.status(500).jsonp({
          'error': 'failure'
        });
      }
      if (campaign.emailType.codeName === 'ET_MA') {
        //ma mhid changes
        var MAILHISTORY = db.maMailHistoryClass(),
          newMhid;
        //to check if MHID Add or update operation
        //oldMHID will present for update operation
        if (req.body.cell && Array.isArray(req.body.cell) && req.body.cell.length > 0) {
          req.body.cell.forEach(function(cell, index) {
            req.body.cell[index].srcCode = req.body.cell[index].srcCode.toUpperCase();
          });
        }
        if (req.body.newMHID && req.body.oldMHID) {
          //validate if new and old mhid's are different
          if (req.body.newMHID.mhid !== req.body.oldMHID.mhid) {
            var oldMHID = req.body.oldMHID.mhid;
            var oldMHIDIndex = -1,
              oldMhidCellIndex = -1,
              newMHIDIndex = -1;
            //find old mhid and get cell object
            oldMHIDIndex = _.findIndex(campaign.ma.mailHistory, {
              'mhid': req.body.oldMHID.mhid
            });
            if (oldMHIDIndex !== -1) {
              oldMhidCellIndex = _.findIndex(campaign.ma.mailHistory[oldMHIDIndex].cells, {
                'srcCode': req.body.oldMHID.cell.srcCode
              });
              campaign.ma.mailHistory[oldMHIDIndex].cells.splice(oldMhidCellIndex, 1);
              if (campaign.ma.mailHistory[oldMHIDIndex].cells.length === 0) {
                campaign.ma.mailHistory.splice(oldMHIDIndex, 1);
              }
            }
            newMHIDIndex = _.findIndex(campaign.ma.mailHistory, {
              'mhid': req.body.newMHID.mhid
            });
            //mhid not exsists need to create and push the cell
            if (newMHIDIndex === -1) {
              var obj = {};
              obj.mhid = req.body.newMHID.mhid;
              obj.startDate = req.body.newMHID.startDate;
              obj.cell = req.body.newMHID.cell;
              req.body = obj;
            } else {
              //mhid exsists need to push the cell to mhid
              isMHIDChanged = true;
              req.body.oldMHID.mhid = req.body.newMHID.mhid;
            }
          }
        }
        if (!req.body.oldMHID) {
          //validate mhid exsists 
          var mhidAtIndex = -1;
          //find the mhid index
          mhidAtIndex = _.findIndex(campaign.ma.mailHistory, {
            'mhid': req.body.mhid
          });
          if (mhidAtIndex !== -1) {
            campaign.ma.mailHistory[mhidAtIndex].startDate = utils.formatDate(req.body.startDate);
            var isCellMHIDIndex = -1;
            isCellMHIDIndex = _.findIndex(campaign.ma.mailHistory[mhidAtIndex].cells, {
              'srcCode': req.body.cell.srcCode
            });
            if (isCellMHIDIndex !== -1) {
              return handleCustomError(res, 412, {
                'status': 'failure',
                'reason': 'cellid and mhid combination should be unique'
              });
            }
            campaign.ma.mailHistory[mhidAtIndex].cells.push.apply(campaign.ma.mailHistory[mhidAtIndex].cells, req.body.cell);
          } else {
            //If mhid is not present
            MAILHISTORY = db.maMailHistoryClass();
            newMhid = new MAILHISTORY();
            newMhid.mhid = req.body.mhid.toUpperCase();
            newMhid.startDate = utils.formatDate(req.body.startDate);
            newMhid.cells = req.body.cell;
            campaign.ma.mailHistory = campaign.ma.mailHistory || [];
            campaign.ma.mailHistory.push(newMhid);
          }
        } else {
          req.body.newMHID.cell.srcCode = req.body.newMHID.cell.srcCode.toUpperCase();
          var mhidIndex = -1;
          mhidIndex = _.findIndex(campaign.ma.mailHistory, {
            'mhid': req.body.oldMHID.mhid
          });
          if (mhidIndex === -1) {
            return handleCustomError(res, 412, {
              'status': 'failure',
              'reason': 'MHID not found'
            });
          }
          campaign.ma.mailHistory[mhidIndex].mhid = req.body.oldMHID.mhid.toUpperCase();
          campaign.ma.mailHistory[mhidIndex].startDate = utils.formatDate(req.body.newMHID.startDate);
          var oldCellIndex = _.findIndex(campaign.ma.mailHistory[mhidIndex].cells, {
            'srcCode': req.body.oldMHID.cell.srcCode
          });
          if (oldCellIndex === -1 && !isMHIDChanged) {
            return handleCustomError(res, 412, {
              'status': 'failure',
              'reason': 'cellId not found'
            });
          }
          var isCellMHIDExsists = -1;
          isCellMHIDExsists = _.findIndex(campaign.ma.mailHistory[mhidIndex].cells, {
            'srcCode': req.body.newMHID.cell.srcCode
          });
          if (isCellMHIDExsists !== -1 && req.body.newMHID.cell.srcCode !== req.body.oldMHID.cell.srcCode) {
            return handleCustomError(res, 412, {
              'status': 'failure',
              'reason': 'cellid and mhid combination should be unique'
            });
          }
          if (isMHIDChanged) {
            campaign.ma.mailHistory[mhidIndex].cells.push(req.body.newMHID.cell);
          } else {
            campaign.ma.mailHistory[mhidIndex].cells[oldCellIndex] = req.body.newMHID.cell;
          }
        }
      }
      if (campaign.ma.mailHistory && campaign.ma.mailHistory.length > 0 && campaign.durationInWeeks) {
        campaign = utils.calculateMAEndDate(campaign);
      }
      campaign.markModified('ma.mailHistory');
      campaign.save(function(err) {
        logger.info('mhid add success');
        if (err) {
          return handleError(res, err);
        }
        res.status(200).jsonp({
          'newMhid': req.body,
          'message': 'success'
        });
      });
    });
  },
  destroy: function(req, res) {
    //mhid destroy for MA campaigns
    var Campaign = db.campaignClass();
    Campaign.findById(req.body.id, function(err, campaign) {
      if (err) {
        return handleError(res, err);
      } else if (campaign) {
        var removeMHIDIndex = -1;
        removeMHIDIndex = _.findIndex(campaign.ma.mailHistory, {
          'mhid': req.body.mhid
        });
        if (removeMHIDIndex === -1) {
          return handleCustomError(res, 412, {
            'status': 'failure',
            'reason': 'MHID not found'
          });
        }
        var cellIndex = -1;
        cellIndex = _.findIndex(campaign.ma.mailHistory[removeMHIDIndex].cells, {
          'srcCode': req.body.cell.srcCode
        });
        if (cellIndex === -1) {
          return handleCustomError(res, 412, {
            'status': 'failure',
            'reason': 'CellID not found'
          });
        }
        campaign.ma.mailHistory[removeMHIDIndex].cells.splice(cellIndex, 1);
        if (campaign.ma.mailHistory[removeMHIDIndex].cells.length === 0) {
          campaign.ma.mailHistory.splice(removeMHIDIndex, 1);
        }
        if (campaign.ma.mailHistory && campaign.ma.mailHistory.length > 0) {
          campaign = utils.calculateMAEndDate(campaign);
        } else {
          //If all mhid's are deleted set the date to null;
          campaign.endDate = null;
        }
        campaign.markModified('ma.mailHistory');
        campaign.save(function(err, data) {
          if (err) {
            logger.error('campaign not updated' + err);
            return handleError(res, err);
          }
          logger.info('mhid deleted success');
          res.status(200).jsonp({
            'message': 'success'
          });

        });
      }
    });
  }
};
