/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-POC - <DESC_HERE>
 */

'use strict';

var db = require('../../../lib/db.js');

function handleError(res, err) {
  return res.status(500).send(err);
}

module.exports = {
  index: function(req, res) {
    var pznVariable = db.pznVariableClass();
    pznVariable.find(null, null, {
      sort: {
        codeName: 1
      }
    }, function(err, pznVariables) {
      if (err) {
        return handleError(res, err);
      }
      return res.status(200).json(pznVariables);
    });
  }
};