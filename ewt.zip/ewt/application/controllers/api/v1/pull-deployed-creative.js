/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md 
 *
 *
 * Description: EWT-2.0 (ERA) - This file defined the service controller to pull the deployed creatives from ET
 */

'use strict';

var timeToPullTimer = null,
  etUtils = require('../../../lib/et-utils.js'),
  config = require('config'),
  os = require('os');

var deployedCreative = {
  getFromET: function(req, res) {
    logger.info('api.pull-deployed-creative.getFromET :: method entry');

    // Check if its a call from service or is it a scheduled call.
    if (req) {
      // Call to service from HTTP client
      deployedCreative.schedulePull(true, req.query.whatToGet, function(msg) {
        res.json(msg);
      });
    } else {
      // Its a call from within app. Most probably the call may come from app startup time.
      deployedCreative.schedulePull(false);
    }
  },
  schedulePull: function(performPullNow, whatToGet, cb) {
    logger.info('api.pull-deployed-creative.schedulePull :: method entry');

    var now = new Date(),
      tomorrow, timeToPull;

    cb = cb || function() {};
    // We should pull from ET by default, unless explicitly denied
    performPullNow = (performPullNow === undefined) ? true : performPullNow;

    // If timer is scheduled, we are in invoked timer, so clear this timer and process the timer.
    if (timeToPullTimer) {
      clearTimeout(timeToPullTimer);
    }

    if (performPullNow) {
      // Start the batch of pulling deployed creatives from ET
      etUtils.retrieveDeployedCreatives(whatToGet, function(err, message) {
        var msg;
        if (err) {
          msg = 'Error while pulling deployed creatives from ET at time ' + now + '. Error Message: ' + err;
        } else {
          msg = 'Successfully pulled deployed creatives from ET at time ' + now + '. Success Message: ' + message;
        }
        logger.error(msg);
        return cb(msg);
      });
    }

    // Schedule the pull for next mid night. Schedule on configured server, not all app servers.
    if (os.hostname().toUpperCase() === config.application.esp.deployedCreatives.scheduleOn.toUpperCase()) {
      tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
      timeToPull = (tomorrow - now);
      // Schedule only if we are scheduling in future.
      if (timeToPull >= 0) {
        logger.info('Scheduled next batch for tomorrow: ' + tomorrow);
        logger.info('Time in hours for next scheduled batch to run:' + timeToPull / 3600000);
        timeToPullTimer = setTimeout(deployedCreative.schedulePull, timeToPull);
      }
    }
  },
  cancelScheduledPull: function(cb) {
    if (timeToPullTimer) {
      clearTimeout(timeToPullTimer);
    }
    return cb();
  }
};

module.exports = deployedCreative;
