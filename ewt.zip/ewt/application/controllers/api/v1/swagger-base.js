'use strict';

var ip = require('ip');
var config = require('config');

module.exports = {
  'swagger': '2.0',
  'info': {
    'title': 'Amex EWT API',
    'description': 'Amex EWT API',
    'version': '1.0.0'
  },
  'produces': ['application/json'],
  'host': ip.address() + ':' + config.http.port,
  'basePath': '/api/v1',

  'definitions': {
    'StandardReponse': {
      'properties' : {
        'code' : {
          'type' : 'integer',
          'format' : 'int32'
        },
        'message' : {
          'type' : 'string'
        },
        'fields' : {
          'type' : 'string'
        }
      }
    },

    'GeneralError': {
      'properties' : {
        'code' : {
          'type' : 'integer',
          'format' : 'int32'
        },
        'message' : {
          'type' : 'string'
        },
        'fields' : {
          'type' : 'string'
        }
      }
    },

    'Error': {
      'properties' : {
        'code' : {
          'type' : 'integer',
          'format' : 'int32'
        },
        'message' : {
          'type' : 'string'
        },
        'fields' : {
          'type' : 'string'
        }
      }
    }

  },

  'responses': {

    'NotFound': {
      'description': 'Entity not found.'
    },
    'IllegalInput': {
      'description': 'Illegal input for operation.'
    },
    'GeneralError': {
      'description': 'General Error',
      'schema': {
          '$ref': '#/definitions/GeneralError'
      }
    }
  }
};