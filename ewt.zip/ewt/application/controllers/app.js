/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-POC - <DESC_HERE>
 */

'use strict';

/*
 *  Controller which handles api requests coming from the router.
 */
var db = require('../lib/db.js'),
  ldap = require('../lib/ldap.js'),
  config = require('config'),
  appUtils = require('../lib/app.js');

module.exports = {
  get: function(req, res) {
    logger.info('controller.app :: method entry');
    // check user details in request header
    var User = db.userClass(),
      host = req.get('host'),
      user = {
        guid: req.get('GUID'),
        firstName: req.get('firstname'),
        lastName: req.get('lastname'),
        empId: req.get('employeeid'),
        email: req.get('email')
      },
      userDetailsObj;

    if (host.search('localhost') < 0 && (host.search('10.20.154.175') < 0)) { // Non development (E0) env
      if (user.guid) {
        // get user's leader from LDAP for non-dev envs
        logger.info('LDAP Object' + JSON.stringify(user));
        ldap.getUserAndLeaderDetails(user, function(err, ldapUser) {
          if (err) {
            logger.error('Failed to load getUserAndLeaderDetails...');
            return handleError(res, err);
          } else {
            return appUtils.renderApp(ldapUser, req, res);
          }
        });
      } else {
        userDetailsObj = {
          firstName: user.firstName,
          lastName: user.lastName,
          showLink: false
        };
        // could not identify user - unauthorized access 
        res.render('common/error/403', {
          user: userDetailsObj,
          userDetails: JSON.stringify(userDetailsObj)
        });
      }
    } else {
      // development env - bypass SSO, LDAP and get leader details from DB
      // validate dummy user against EWT DB
      user = {
        leader: {
          name: 'Dummy Leader',
          firstName: 'Dummy',
          lastName: 'leader',
          email: 'leader@aexp.com'
        }
      };
      /*
       If you switch between below dummy users, you also need to make change in 'application/middlewares/auth.js'
       There you accordinly need to set the loggedInUser object in session, as sessions are currently disabled in local env as we do not have redis in local.
       */
    //  user.sAMAccountName = 'smurugad';
      user.sAMAccountName = 'knapoli';
     // user.sAMAccountName = 'avarghes';
      return appUtils.renderApp(user, req, res);
    }
  }
};
