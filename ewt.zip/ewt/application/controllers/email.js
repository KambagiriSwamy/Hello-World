/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-POC - mailer
 */

'use strict';

var db = require('../lib/db.js');
var dateFormat = require('dateformat');
var nodemailer = require('nodemailer'),
  smtpTransport = require('nodemailer-smtp-transport'),
  config = require('config'),
  path = require('path'),
  EmailTemplate = require('email-templates').EmailTemplate;
 var  dustHelpers = require('dustjs-helpers');


var emailConfig = config.application.email;
/*
 *  transporter
 *
 *  TODO: this is a transport workaround in order to get this working you must comment out line 863-865 - smtp-connection.js inside smtp-transport mod 'node_modules/nodemailer-smtp-transport/node_modules/smtp-connection/src'
 *
 */
var transporter = nodemailer.createTransport(smtpTransport({
  host: emailConfig.endpoint.host,
  debug: false,
  secureConnection: 'false',
  tls: {
    ciphers: 'SSLv3',
    rejectUnauthorized: false
  }
}));

/*
 *  Controller to handle email send
 *
 */
var email = {
  getTemplate: function(action) {
    /*
     * Creates email templates depending on action passed.
     */
    var directory = path.join(path.normalize(__dirname + '/..'), 'public', 'views', 'common', 'email', action);
    return new EmailTemplate(directory);
  },
  sendEmail: function(req, campaign) {
    /*
     * Takes corresponding email action based on request.
     * Set defaults based on the condition(state.codeName).
     */
    logger.info('sendEmail::method entry');
    if (req.body.state.codeName !== campaign.state.codeName) {
      var emailAction,
        currentUser = {},
        toList = [],
        ccList = [],
        bccList = [];

      if (req.body.state.codeName === 'approved') {
        emailAction = email.notifyApproval;
        toList = [req.body.requestor.email];
      } else if (req.body.state.codeName === 'declined') {
        emailAction = email.notifyDecline;
        toList = req.body.declineReason.email.split(',');
      } else if (req.body.state.codeName === 'revisionRequired') {
        emailAction = email.notifyRevisions;
        toList = req.body.revisionRequired.email.split(',');
      } else if (req.body.state.codeName === 'rollBack2Manager' && req.body.rollBack.email !== 'none') {
        emailAction = email.notifyRollBack;
        toList = req.body.rollBack.email.split(',');
      }
      if (emailAction) {
        emailAction(currentUser, campaign, toList, ccList, bccList, function(error, results) {
          if (error) {
            logger.info('Email corresponding to codeName ' + req.body.state.codeName + ' is not sent.');
          } else {
            logger.info('Email corresponding to codeName ' + req.body.state.codeName + ' is sent to : ' + JSON.stringify(toList));
          }
        });
      }
    }
  },
  notifyApproval: function(currentUser, campaign, toList, ccList, bccList, callback) {
    var startDate = dateFormat(campaign.deploymentDates[0], 'mm/dd/yyyy');
    campaign.startDate = startDate;
    email.getTemplate('approval').render(campaign).then(function(results) {

      var recievers = ((process.env.NODE_ENV !== 'production') && (emailConfig.recievers.overwriteDefaults)) ? emailConfig.recievers.mmEmail : toList.toString();
      logger.info('Campaign email successfully generated from template, attempting to send email to :' + recievers);
      var mailOptions = {
        from: emailConfig.authorizedSenders.approval, // sender address
        to: recievers, // list of receivers
        cc: ccList.toString(),
        bcc: bccList.toString(),
        subject: 'Email Campaign Request ' + campaign.requestID + ' is approved.', // Subject line
        html: results.html,
        attachments: [{
            'filename': campaign.name + '_' + campaign.requestID + '.txt',
            'content': results.text
          }] // html body
      };
      logger.debug('mail options  : ' + JSON.stringify(mailOptions));
      // send mail with defined transport object
      transporter.sendMail(mailOptions, function(error, info) {
        if (error) {
          logger.error('Approval email for campaign send failed ' + JSON.stringify(campaign) + ' Error: ' + error);
          return callback(error, null);
        }
        logger.info('Campaign email approval successfully sent.' + info.response);
        return callback(null, info.response);
      });
    });
  },
  notifyDecline: function(currentUser, campaign, toList, ccList, bccList, callback) {
    campaign.today = dateFormat(new Date(), 'mm/dd/yyyy');
    var startDate = dateFormat(campaign.deploymentDates[0], 'mm/dd/yyyy');
    campaign.startDate = startDate;
    email.getTemplate('rejection').render(campaign, function(error, results) {
      if (error) {
        logger.error('Campaign email UN-successfully generated from template');
        return callback(error, null);
      }
      var recievers = ((process.env.NODE_ENV !== 'production') && (emailConfig.recievers.overwriteDefaults)) ? emailConfig.recievers.mmEmail : toList.toString();
      logger.info('Campaign email successfully generated from Rejectiontemplate, attempting to send email to :' + recievers);
      var mailOptions = {
        from: emailConfig.authorizedSenders.rejection, // sender address
        to: recievers,
        cc: ccList.toString(),
        bcc: bccList.toString(), // list of receivers
        subject: 'CANCELLED: Email Campaign Name: ' + campaign.name + ' (Initiator: AXPi)', // Subject line
        html: results.html
      };

      // send mail with defined transport object
      transporter.sendMail(mailOptions, function(error, info) {
        if (error) {
          logger.error('Rejection email for campaign send failed ' + JSON.stringify(campaign) + ' Error: ' + error);
          return callback(error, null);
        }
        logger.info('Campaign email Rejection successfully sent.' + info.response);
        return callback(null, info.response);
      });
    });
  },
  notifyRevisions: function(currentUser, campaign, toList, ccList, bccList, callback) {
    var startDate = dateFormat(campaign.deploymentDates[0], 'mm/dd/yyyy');
    campaign.startDate = startDate;
    email.getTemplate('review').render(campaign, function(error, results) {
      if (error) {
        logger.error('Campaign email UN-successfully generated from template');
        return callback(error, null);
      }
      var recievers = ((process.env.NODE_ENV !== 'production') && (emailConfig.recievers.overwriteDefaults)) ? emailConfig.recievers.mmEmail : toList.toString();
      logger.info('Campaign email successfully generated from reviewTemplate, attempting to send email to :' + recievers);
      var mailOptions = {
        from: emailConfig.authorizedSenders.review, // sender address
        to: recievers,
        cc: ccList.toString(),
        bcc: bccList.toString(), // list of receivers
        subject: 'ACTION REQUIRED- Revisions must be made to your Email campaign (Initiator: AXPi)', // Subject line
        html: results.html
      };
      // send mail with defined transport object
      transporter.sendMail(mailOptions, function(error, info) {
        if (error) {
          logger.error('Revisions email for campaign send failed ' + JSON.stringify(campaign) + ' Error: ' + error);
          return callback(error, null);
        }
        logger.info('Campaign email Revisions successfully sent.' + info.response);
        return callback(null, info.response);
      });
    });
  },
  notifyRollBack: function(currentUser, campaign, toList, ccList, bccList, callback) {
    var startDate = dateFormat(campaign.deploymentDates[0], 'mm/dd/yyyy');
    campaign.startDate = startDate;
    email.getTemplate('rollBack').render(campaign, function(error, results) {
      if (error) {
        logger.error('Campaign email UN-successfully generated from template');
        return callback(error, null);
      }
      var recievers = ((process.env.NODE_ENV !== 'production') && (emailConfig.recievers.overwriteDefaults)) ? emailConfig.recievers.mmEmail : toList.toString();
      logger.info('Campaign email successfully generated from rollBackTemplate, attempting to send email to :' + recievers);
      var mailOptions = {
        from: emailConfig.authorizedSenders.review, // sender address
        to: recievers,
        cc: ccList.toString(),
        bcc: bccList.toString(), // list of receivers
        subject: 'Campaign (' + campaign.requestID + ') has been rolled back for editing', // Subject line
        html: results.html
      };
      // send mail with defined transport object
      transporter.sendMail(mailOptions, function(error, info) {
        if (error) {
          logger.error('Roll Back email for campaign send failed ' + JSON.stringify(campaign) + ' Error: ' + error);
          return callback(error, null);
        }
        logger.info('Campaign email Roll Back successfully sent.' + info.response);
        return callback(null, info.response);
      });
    });
  },
  send2et: function(templateType, campaign, toList, ccList, bccList, subject, attachments, callback) {
    //var campaign = JSON.parse(JSON.stringify(cmp));
    var attachmentArr = [],
      emailTemplateDir;

    campaign.startDate = dateFormat(campaign.deploymentDates[0], 'mm/dd/yyyy');

    switch (templateType) {
      case 'submit':
        emailTemplateDir = 'et-submit';
        break;
      case 'cancel':
        emailTemplateDir = 'et-cancel';
        campaign.cancelDate = dateFormat(new Date().toISOString(), 'mm/dd/yyyy');
        campaign.activeMailHistory.startDate = dateFormat(campaign.activeMailHistory.startDate, 'mm/dd/yyyy');
        campaign.allCells = [];
        campaign.versions.forEach(function(version) {
          version.cells.forEach(function(cell) {
            campaign.allCells.push(cell.srcCode);
          });
        });
        attachments = [];
        break;
      case 'ma-submit':
        emailTemplateDir = 'et-ma-submit';
        break;
      case 'ma-summary':
        emailTemplateDir = 'et-ma-summary';
        logger.info('cell mappings in email.js : ' + JSON.stringify(campaign.cellMappings));
        attachments = [];
        break;
      case 'ma-cancel':
        emailTemplateDir = 'et-ma-cancel';
        campaign.cancelDate = dateFormat(new Date().toISOString(), 'mm/dd/yyyy');
        campaign.activeMailHistory.startDate = dateFormat(campaign.activeMailHistory.startDate, 'mm/dd/yyyy');
        campaign.allVersions = [];
        campaign.ma.maVersions.forEach(function(version) {
          campaign.allVersions.push(version.versionId);
        });
        attachments = [];
        break;
      case 'cancel-drop':
        emailTemplateDir = 'et-cancel-drop';
        campaign.cancelDate = dateFormat(new Date().toISOString(), 'mm/dd/yyyy');
        attachments = [];
        break;
      default:
        logger.error('Not a valid ET email template type. It should be either submit or cancel.');
        return callback(new Error('Not a valid ET email template type. It should be either submit or cancel.'), null);
    }

    email.getTemplate(emailTemplateDir).render(campaign, function(error, results) {
      if (error) {
        logger.error('Campaign email UN-successfully generated from template' + JSON.stringify(error));
        return callback(error, null);
      }
      logger.info('Campaign email successfully generated from rollBackTemplate, attempting to send email to :' + toList.toString());
      var mailOptions = {
        from: emailConfig.authorizedSenders.review, // sender address
        to: toList.toString(),
        cc: ccList.toString(),
        bcc: bccList.toString(), // list of receivers
        subject: subject.toString(),
        html: results.html
      };

      attachments.forEach(function(attachment) {
        if (attachment) {
          var attachmentObj = {};
          attachmentObj.path = attachment;
          attachmentArr.push(attachmentObj);
        }
      });
      mailOptions.attachments = attachmentArr;

      // send mail with defined transport object
      transporter.sendMail(mailOptions, function(error, info) {
        if (error) {
          logger.error('Could not send email to ExactTarget for campaign: ' + JSON.stringify(campaign) + ' Error: ' + error);
          return callback(error, null);
        } else {
          logger.info('Successfully sent an email to ExactTarget.' + info.response);
          return callback(null, info.response);
        }
      });
    });
  },
  notifyRequestAccess: function(userDetails, toList, ccList, bccList, callback) {
    logger.info('controller.email.notifyRequestAccess :: method entry');
    userDetails.link = config.application.email.addUserUrl;
    email.getTemplate('request-access').render(userDetails).then(function(results, error) {
      if (error) {
        logger.error('Failed to generate email body for Request Access from email template.');
        return callback(error, null);
      }
      logger.info('Attempting to send Request Access Email to :' + toList);
      var recievers = ((process.env.NODE_ENV !== 'production') && (emailConfig.recievers.overwriteDefaults)) ? emailConfig.recievers.mmEmail : toList.toString();
      var mailOptions = {
        from: emailConfig.authorizedSenders.approval, // sender address
        to: recievers, // list of receivers
        cc: ccList.toString(),
        subject: 'New User Requesting Access to ERA', // Subject line
        html: results.html,
      };

      logger.info('Details of email that to be send: ' + JSON.stringify(mailOptions));

      transporter.sendMail(mailOptions, function(error, info) {
        if (error) {
          logger.error('Failed to send Request Access Email to admins for user: with email-id: ' + userDetails.email + ' Error: ' + error);
          return callback(error, null);
        }
        logger.info('Request Access Email sent successfully.');
        return callback(null, info.response);
      });
    });
  }
};

module.exports = email;
