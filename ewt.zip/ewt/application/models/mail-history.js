/**
 *  * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Created by smurugad on 8/20/2015.
 *  Business Unit:  Valid values are:
 *  Global Merchant Services (GMS), GCC,OPEN,CCSG,Publishing,GMPI,Global Prepaid,Consumer Travel,
 * AXPi,MR,Card Services,Direct Deposits,Enterprise Growth Group (EGG), Digital Partnerships & Development (DPD)
 */

'use strict';

var mongoose = require('mongoose');

var MailHistory = new mongoose.Schema({
    mhid: {type: String, index: true},
    startDate: Date,
}, {collection: 'mailHistory', strict: false });

module.exports = MailHistory;
