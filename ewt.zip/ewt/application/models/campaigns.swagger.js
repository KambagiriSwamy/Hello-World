module.exports = {
  paths: {
    '/campaigns': {
      'get': {
        'description': 'Returns all campaigns from the system that the campaign has access to',
        'tags': ['Campaigns'],
        'produces': [
          'application/json'
        ],
        'responses': {
          '200': {
            'description': 'A list of campaigns.',
            'schema': {
              'type': 'array',
              'items': {
                '$ref': '#/definitions/Campaign'
              }
            }
          }
        }
      },

      'post': {
        'summary': 'Create a new campaign',
        'description': 'Api endpoint to create a new campaign',
        'tags': ['Campaigns'],
        'produces': [
          'application/json'
        ],
        'parameters': [

          {
            'name': 'campaign',
            'in': 'body',
            'description': 'Campaign to add to the system',
            'required': true,
            'schema': {
              'type': 'object',
              '$ref': '#/definitions/Campaign'
            }
          }

        ],

        'responses': {
          '201': {
            'description': 'A successful creation of a campaign.'
          },
          '400': {
            'description': 'Malformed structure'
          },
          '500': {
            'description': 'Application error.'
          }
        }
      }
    },

    '/campaigns/{campaign_id}': {
      'get': {
        'x-swagger-router-controller': 'Campaigns',
        'tags': ['Campaigns'],
        'operationId': 'campaignGet',
        'parameters': [

          {
            'name' : 'id',
            'in' : 'path',
            'type' : 'string',
            'format' : 'uuid',
            'description' : 'Campaign ID.',
            'required' : true
          }

        ],
        'responses': {
          '200': {
            'description' : 'A campaign object',
            'schema' : {
              'type' : 'object',
              '$ref' : '#/definitions/Campaign'
            }
          },

          'default': {
            'description' : 'Unexpected error',
            'schema' : {
              '$ref' : '#/definitions/Error'
            }
          }
        }
      },

      'patch': {
        'x-swagger-router-controller': 'Campaigns',
        'tags': ['Campaigns'],
        'operationId': 'campaignUpdate',
        'consumes' : [
          'application/json'
        ],
        'parameters': [

          {
            'name' : 'id',
            'in' : 'path',
            'type' : 'string',
            'format' : 'uuid',
            'description' : 'Campaign ID.',
            'required' : true
          },
          {
            'name' : 'campaign',
            'in' : 'body',
            'description' : 'Campaign details to update',
            'dataType': 'string',
            'required' : true
          }

        ],
        'responses': {
          '200': {
            'description' : 'A campaign object',
            'schema' : {
              'type' : 'object',
              '$ref' : '#/definitions/Campaign'
            }
          },

          'default': {
            'description' : 'Unexpected error',
            'schema' : {
              '$ref' : '#/definitions/Error'
            }
          }
        }
      },

      'put': {
        'x-swagger-router-controller': 'Campaigns',
        'tags': ['Campaigns'],
        'operationId': 'campaignUpdate',
        'consumes' : [
          'application/json'
        ],
        'parameters': [

          {
            'name' : 'id',
            'in' : 'path',
            'type' : 'string',
            'format' : 'uuid',
            'description' : 'Campaign ID.',
            'required' : true
          },
          {
            'name' : 'campaign',
            'in' : 'body',
            'description' : 'Campaign details to update',
            'dataType': 'string',
            'required' : true
          }

        ],
        'responses': {
          '200': {
            'description' : 'A campaign object',
            'schema' : {
              'type' : 'object',
              '$ref' : '#/definitions/Campaign'
            }
          },

          'default': {
            'description' : 'Unexpected error',
            'schema' : {
              '$ref' : '#/definitions/Error'
            }
          }
        }
      },

      'delete': {
        'x-swagger-router-controller': 'Campaigns',
        'tags': ['Campaigns'],
        'operationId': 'campaignDelete',
        'parameters': [

          {
            'name' : 'id',
            'in' : 'path',
            'type' : 'string',
            'format' : 'uuid',
            'description' : 'Campaign ID.',
            'required' : true
          }

        ],
        'responses': {
          '200': {
            'description' : 'Successfully',
            'schema' : {
              'type' : 'object',
              '$ref' : '#/definitions/StandardReponse'
            }
          },

          'default': {
            'description' : 'Unexpected error',
            'schema' : {
              '$ref' : '#/definitions/Error'
            }
          }
        }
      }
    }
  },

  definitions: {
    'Campaign': {
      'type': 'object',
      'properties': {
        'id': {
          'type': 'string',
          'format': 'uuid'
        },
        'name': {
          'type': 'string'
        },
        'description': {
          'type': 'string'
        },
        'status': {
          'type': 'string'
        },
        'start_date': {
          'type': 'string',
          'format': 'date-time'
        },
        'end_date': {
          'type': 'string',
          'format': 'date-time'
        },
        'control_group': {
          'type': 'string'
        },
        'max_impressions_per_visitor': {
          'type': 'integer'
        },
        'max_impressions_per_session': {
          'type': 'integer'
        },
        'weight_vs_other_campaigns': {
          'type': 'integer'
        }
      }
    }
  },

  responses: {

  }
}