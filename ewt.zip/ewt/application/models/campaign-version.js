/**
 *  * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 * Campaign-Version
 *
 *
 */

'use strict';

var mongoose = require('mongoose'),
  Cell = require('./cell'),
  EmailSubject = require('./email-subject');


var CampaignVersion = new mongoose.Schema({
  number: Number,
  description: String,
  poid: String,
  complianceCode: String,
  cells: [typeof Cell],
  subjects: [typeof EmailSubject]
}, {
  collection: 'campaignVersion',
  strict: false
});

module.exports = CampaignVersion;
