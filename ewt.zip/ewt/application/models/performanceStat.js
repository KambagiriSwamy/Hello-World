/**
 * Created by smurugad on 3/7/16.
 */
'use strict';

var mongoose = require('mongoose');
var PerformanceStat  = new mongoose.Schema({
  "totalRequests": Number,
  "totalErrors": Number,
  "totalTimeSeconds": Number,
  "rps": Number,
  "meanLatencyMs": Number,
  "maxLatencyMs": Number,
  "percentiles": [{"percent": String,"response":Number}],
  "errorCodes": String
}, {
  collection: 'performanceStat',
  strict: false
});
module.exports = PerformanceStat;