/**
 *  * Module: ERA
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 * Products -- Collection maintains list of Products and their frequencey.
 *
 *
 */

'use strict';
var mongoose = require('mongoose');
var Products = new mongoose.Schema({
  businessUnitCode:String,
  commCode:String,
  Code:String,
  codeName:String,
  name:String,
  description:String
}, {
  collection: 'product',
  strict: false
});

module.exports = Products;
