/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *

 */
'use strict';

var mongoose = require('mongoose');

/**
 * Description: Define different EEmail Types . Valid values are:
 * U S STANDARD,
 * U S HOURLY TRIGGER
 * U S BATCH TRIGGER
 * BROADCAST
 * Marketing Automation
 */
var EmailType = new mongoose.Schema({
    code: {type: String, required: true, unique: true},
    codeName: String,
    name: String
}, {collection: 'emailType', strict: false });

module.exports = EmailType;
