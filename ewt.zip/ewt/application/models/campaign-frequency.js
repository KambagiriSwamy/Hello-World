/**
 *  * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Created by smurugad on 8/20/2015.
 *   Campaign Frequency : Valid Values are:
 *   Hourly, Daily, Weekly, Bi-Weekly, Monthly
 */
 'use strict';

var mongoose = require('mongoose');

var CampaignFrequency = new mongoose.Schema({
    code: {type: String, required: true, unique: true},
    codeName: String,
    name: String
}, {collection: 'campaignFrequency', strict: false });

module.exports = CampaignFrequency;

