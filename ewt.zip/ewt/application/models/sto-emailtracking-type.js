/**
 * Module: ERA
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *

 */
'use strict';

var mongoose = require('mongoose');

/**
 * Description: Define STO Email Tracking Types . Valid values are:
 *
 * a. Value 1 represents STO enabled for best send DAY & TIME
 * b. Value 2 represents STO enabled for best send DAY
 * c. Value 3 represents STO enabled for best send TIME
*  Default Best Send Time (3) will be used
 */
var EmailTrackingTypes = new mongoose.Schema({
  code: {type: String, required: true, unique: true},
  codeName: String,
  name: String
}, {collection: 'emailTrackingTypes', strict: false });

module.exports = EmailTrackingTypes;
