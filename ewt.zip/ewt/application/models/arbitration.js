/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
  * Campaign Orbitration
 *
 * Possible Values are: Arbitrated, Non Arbitrated
 */
 'use strict';
 
var mongoose = require('mongoose');

var Arbitration = new mongoose.Schema({
  code: {type: String, required: true, unique: true},
  codeName: String,
  name: String
	}, {collection:'arbitration', strict:false}
);
module.exports = Arbitration;
