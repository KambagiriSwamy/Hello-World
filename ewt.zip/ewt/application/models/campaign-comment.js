/**
 *  * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Created by smurugad on 8/20/2015.
 * Description: Define different Campaign Sub-Types . Valid values are
 * TBD
 */
 'use strict';

var mongoose = require('mongoose');

var CampaignComment = new mongoose.Schema({
    timestamp: Date,
    userName: String,
    content: String
}, {collection: 'campaignComment', strict: false });

module.exports = CampaignComment;
