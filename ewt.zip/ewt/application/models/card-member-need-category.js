/**
 *  * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * CardMember opt out captures the CM's opt-outs.
 * Possible Values:
 * Card & Credit,Protection & Insurance,Benefits and Rewards - Travel,Benefits and Rewards - Shopping & Retail,
 * Benefits and Rewards - Dining & Entertainment,Benefits and Rewards - Other Spend,Benefits and Rewards - Benefit awareness,
 * Publications,Prepaid,Other banking products,Account Management,Corporate Offers ,Market Research Surveys
 */
'use strict';

var mongoose = require('mongoose');

var CardMemberNeedCategory = new mongoose.Schema ({
    code: {type: String, required: true},
    codeName: String,
    name: String,
    granularOptOutCode: {type: String, required: true},
    secondaryGranNeedCatCd:String,
    businessUnitCode: {type: String, required: true},
    oneoffDeploymentWeek: Number,
    oneoffDeploymentDay: Number
}, {collection: 'cardMemberNeedCategory', strict: false});

module.exports = CardMemberNeedCategory;
