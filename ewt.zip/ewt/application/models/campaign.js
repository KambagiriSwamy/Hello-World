/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *

 */
'use strict';

var mongoose = require ('mongoose'),
  User = require ('./user.js'),
  EmailType = require ('./email-type.js'),
  CampaignFreq = require ('./campaign-frequency'),
  BusinessUnit = require ('./business-unit.js'),
  CMNeedCategory = require ('./card-member-need-category'),
  DynamicCampaign = require ('./dynamic-campaign'),
  CampaignType = require ('./campaign-type'),
  CampaignSubType = require ('./campaign-sub-type'),
  CardProduct = require ('./card-product'),
  EmailVendor = require ('./email-vendor'),
  Arbitration = require ('./arbitration'),
  CampaignStatus = require ('./campaign-status'),
  CampaignLog = require ('./campaign-log.js'),
  CampaignComments = require ('./campaign-comment'),
  MAVersion = require ('./ma-version'),
  MailHistory = require ('./mail-history'),
  Version = require ('./campaign-version'),
  Attachment = require ('./attachment'),
  PZNField = require ('./personalization-field'),
  MarketingAutomation = require ('./marketing-automation'),
  Duration = require ('./campaign-duration.js'),
  STOemailTrackingType = require ('./sto-emailtracking-type'),
  STOeventsToTrack = require ('./sto-eventstotrack'),
  DeployedCreative = require ('./deployed-creative'),
  CommCode = require ('./comm-code');

var Campaign = new mongoose.Schema ({
  requestID: {
    type: Number,
    index: {
      unique: true
    }
  },
  name: String,
  state: typeof CampaignStatus,
  requestor: typeof User,
  primaryMarketingManager: typeof User,
  secondaryMarketingManager: typeof User,
  emailType: typeof EmailType,
  freq: typeof CampaignFreq,
  businessUnit: typeof BusinessUnit,
  isMultiCMNeedCategory: Boolean,
  lock: {
    isLocked: {
      type: Boolean,
      default: false
    },
    key: String, // TAB ID
    owner: typeof User, // User who locked it
    expiresAt: Date // timestamp when lock was last aquired
  },
  primaryCmNeedCategory: typeof CMNeedCategory,
  cmNeedCategories: [typeof CMNeedCategory],
  isDynamicCampaign: Boolean,
  dynamicCampaigns: [typeof DynamicCampaign],
  type: typeof CampaignType,
  subType: typeof CampaignSubType,
  budgetLine: String,
  responsbilityCenter: String,
  description: String,
  conversionData: String,
  cardProducts: [typeof CardProduct],
  volumeCap: {
    type: Number
  },
  triggerRest: {
    type: Number
  },
  esp: typeof EmailVendor,
  arbitration: typeof Arbitration,
  log: [typeof CampaignLog],
  startWeek: Date,
  durationInWeeks: Number,
  deploymentDates: [Date],
  endDate: Date,
  comments: [typeof CampaignComments],
  espInstructions: String,
  ma: typeof MarketingAutomation,
  mailHistory: [typeof MailHistory],
  previewEmailList: [String],
  deployEmailList: [String],
  approversEmailList: [String],
  pznFields: [typeof PZNField],
  versions: [typeof Version],
  subjectLines: [typeof SubjectLine],
  creativeMockup: typeof Attachment,
  attachments: [typeof Attachment],
  sizeOfAllAttachmentsInMB: Number,
  declineComments: String,
  revisionReasonComments: String,
  rollBackComments: String,
  espLoadDetails: [typeof Object],
  criticalDataSubmitted: [typeof Object],
  cancelledDrops: [typeof Object],
  deployedCreatives: [typeof DeployedCreative],
  commCode: typeof CommCode,
  isSubmittedToESP: {
    type: Boolean,
    default: false
  },
  createdOn: Date,
  updatedOn: Date,
  criticalDataUpdates: {
    MHID: {
      type: Boolean,
      default: false
    },
    VERSIONS: {
      type: Boolean,
      default: false
    },
    CELLS: {
      type: Boolean,
      default: false
    },
    DEPLOYMENTDATES: {
      type: Boolean,
      default: false
    }
  },
  sto: {
    isThrottled: {
      type: Boolean,
      default: false
    },
    isSpecificTime: {
      type: Boolean,
      default: false
    },
    isSpecialTestingReq: {
      type: Boolean,
      default: false
    },
    isSTO: {
      type: Boolean,
      default: false
    },
    stoEmailTrackingType: typeof STOemailTrackingType,
    stoEventToTrack: typeof STOeventsToTrack
  },
  buDeployment: Date
}, {
  collection: 'campaign',
  strict: false
});
module.exports = Campaign;
