 /**
  * Module: EWT-POC
  *
  * --------------------------------------------------------------------------
  *
  * (C) Copyright 2014 American Express, Inc. All rights reserved.
  * The contents of this file represent American Express trade secrets and
  * are confidential. Use outside of American Express is prohibited and in
  * violation of copyright law.  Licence information of all dependent modules
  * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
  *
  *
  * Description: Marketing Automation Fields
  *
  *
  *
  */
 'use strict';

 var mongoose = require('mongoose'),
   maVersion = require('./ma-version.js'),
   Attachment = require('./attachment.js'),
   MaMailHistory = require('./ma-mail-history.js'),
   Cell = require('./cell');

 var MarketingAutomation = mongoose.Schema({
   instructionDocuments: [typeof Attachment],
   approvalDocuments: [typeof Attachment],
   disengagementValue: Number,
   maCells: [typeof Cell],
   maVersions: [typeof maVersion],
   mailHistory: [typeof MaMailHistory],
   filesSentToET: [typeof Object]
 }, {
   collection: 'marketingAutomation',
   strict: false
 });
 module.exports = MarketingAutomation;
