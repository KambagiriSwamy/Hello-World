/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: Marketing Automation Fields
 *
 *
 *
 */

'use strict';

var mongoose = require('mongoose'),
  TriggerEvent = require('./trigger-event.js'),
  Attachment = require('./attachment.js');



var MarketingAutomationVersions = mongoose.Schema({
  versionId: Number,
  versionName: String,
  subjectLine: String,
  poid: String,
  complianceCode: String,
  triggerEvent: Object,
  creativeDocument: [typeof Attachment]
}, {
  collection: 'marketingAutomationVersion',
  strict: false
});

module.exports = MarketingAutomationVersions;
