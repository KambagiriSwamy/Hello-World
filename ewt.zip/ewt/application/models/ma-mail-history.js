'use strict';

var mongoose = require('mongoose'),
  Cell = require('./cell');

var MaMailHistory = new mongoose.Schema({
  mhid: {
    type: String,
    index: true
  },
  startDate: Date,
  cells: [typeof Cell]
}, {
  collection: 'maMailHistory',
  strict: false
});

module.exports = MaMailHistory;
