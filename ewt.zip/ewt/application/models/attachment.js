/**
 *  * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 * FileContents:
 * Text Version, HTML Version, Creative Governance, Images, Initial Draft, Final Creative Preview, Other
 *
 *
 */

'use strict';

var mongoose = require('mongoose'),
    AttachmentType = require('./attachment-type');

var Attachment = new mongoose.Schema({
  gfsID: String,
  type: typeof AttachmentType,
  creativeVersion: Number,
  fileName: String,
  extension: String,
  size: String
}, {collection: 'attachment', strict: false});

module.exports = Attachment;
