/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-POC - <DESC_HERE>
 */

'use strict';

var mongoose = require('mongoose');

var UserRole = mongoose.Schema({
  code: {
    type: String,
    required: true,
    unique: true
  },
  codeName: String,
  name: String
}, {
  collection: 'userRole',
  strict: false
});

module.exports = UserRole;
