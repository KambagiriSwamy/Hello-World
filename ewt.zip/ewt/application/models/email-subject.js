/**
 *  * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 * Mail-Plan
 *
 *
 */

'use strict';

var mongoose = require('mongoose');
var EmailSubject = new mongoose.Schema({
  subjectLine: String,
  espInstructions: String
}, {
  collection: 'emailSubject',
  strict: false
});

module.exports = EmailSubject;
