/**
 * Module: EWT-POC
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 * EWT-POC has been created by jumpstart-generator and powered by jumpstart-engine
 * Description: EWT-2.0 (ERA) - Application entry point. It starts the server.
 */

'use strict';

var config = require('config'),
  jumpstart = require('jumpstart-engine')(config),
  db = require('./application/lib/db'),
  deployedCreatives = require('./application/controllers/api/v1/pull-deployed-creative'),
  crypto = require('crypto'),
  algorithm = 'aes256',
  key = 'emailworkflowtoolversiontwo',
  config = require('config'),
  dbConfig = config.application.mongo,
  decipherUser = crypto.createDecipher(algorithm, key),
  decipherPass = crypto.createDecipher(algorithm, key),
  dbUser, dbPass;

jumpstart.serve(function() {
  var mongoAuth = '',
    mongoURL = '',
    hostString = '';

  if (dbConfig.auth.user && dbConfig.auth.pass) {
    dbUser = decipherUser.update(dbConfig.auth.user, 'hex', 'utf8') + decipherUser.final('utf8');
    dbPass = decipherPass.update(dbConfig.auth.pass, 'hex', 'utf8') + decipherPass.final('utf8');
    mongoAuth = dbUser + ':' + dbPass + '@';
  }
  for (var indx = 0; indx < dbConfig.instances.length; indx++) {
    hostString = indx ? hostString + ',' : hostString;
    hostString += dbConfig.instances[indx].host + ':' + dbConfig.instances[indx].port;
  }
  mongoURL = 'mongodb://' + mongoAuth + hostString + '/' + dbConfig.db;
  db.connect(mongoURL, dbConfig.options, function() {
    console.log('The Server started at port: ' + config.http.port);
    deployedCreatives.getFromET();
  });

  process.on('SIGINT', function() {
    deployedCreatives.cancelScheduledPull(function() {
      db.closeConnections(function() {
        process.exit(0);
      });
    });
  });
});
