/**
 * Module: EWT-2.0 (ERA)
 *
 * --------------------------------------------------------------------------
 *
 * (C) Copyright 2014 American Express, Inc. All rights reserved.
 * The contents of this file represent American Express trade secrets and
 * are confidential. Use outside of American Express is prohibited and in
 * violation of copyright law.  Licence information of all dependent modules
 * can be found https://stash.mps.intra.aexp.com/projects/WF/repos/jumpstart-engine/browse/README.md
 *
 *
 * Description: EWT-2.0 (ERA) - This file is the top level file for release 2.0 DB patch.
 */

'use strict';

var config = require('config');
var jumpstart = require('jumpstart-engine')(config);
var db = require('./application/lib/db');
var crypto = require('crypto');
var algorithm = 'aes256';
var key = 'emailworkflowtoolversiontwo';
var config = require('config');
var dbConfig = config.application.mongo;
var asyncEach = require('async-each');

var decipherUser = crypto.createDecipher(algorithm, key);
var decipherPass = crypto.createDecipher(algorithm, key);
var dbUser, dbPass;

var masterCollectionsPatch = require('./db/Release_2_1/patch-add-records-to-master-collections.js')

if (dbConfig.auth.user !== '') {
  dbUser = decipherUser.update(dbConfig.auth.user, 'hex', 'utf8') + decipherUser.final('utf8');
}
if (dbConfig.auth.pass !== '') {
  dbPass = decipherPass.update(dbConfig.auth.pass, 'hex', 'utf8') + decipherPass.final('utf8');
}

var mongoAuth = '',
  mongoURL = '',
  dbConfig = config.application.mongo,
  hostString = '';

if (dbConfig.auth.user && dbConfig.auth.pass) {
  mongoAuth = dbUser + ':' + dbPass + '@';
}
for (var indx = 0; indx < dbConfig.instances.length; indx++) {
  if (indx > 0) {
    hostString += ',';
  }
  hostString += dbConfig.instances[indx].host + ':' + dbConfig.instances[indx].port;
}

mongoURL = 'mongodb://' + mongoAuth + hostString + '/' + config.application.mongo.db;
console.log('Mongo URL: ' + mongoURL);
console.log('Mongo Options: ' + JSON.stringify(config.application.mongo.options));

db.connect(mongoURL, config.application.mongo.options, function() {
  masterCollectionsPatch.runPatch(function(err) {
    if (err) {
      console.log('FAIL: Master collection patch failed. ERROR:' + err);
    } else {
      console.log('SUCCESS: Master collection patch executed successfully');
    }
    db.closeConnections(function() {
      process.exit(0);
    });
  });
});

process.on('SIGINT', function() {
  db.closeConnections(function() {
    process.exit(0);
  });
});
