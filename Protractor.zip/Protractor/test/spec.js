describe('Protractor Demo App', function() {
	beforeEach(function(){
		browser.get('http://localhost:3000/index');
	});
  it('should have a title', function() {
    
    expect(browser.getTitle()).toEqual('Protractor Example');
  });

  it('should enter text and trigger click event', function(){
    element(by.model('username')).sendKeys('Kambagiri Swamy');
    element(by.id('b1')).click();

	var EC = protractor.ExpectedConditions;
	// Waits for an alert pops up.
	browser.wait(EC.alertIsPresent(), 5000);
  });
});