exports.config = {
  framework: 'jasmine',
  //seleniumAddress: 'http://localhost:4444/wd/hub',
   directConnect: true,

  specs: ['test/spec.js'],
  

  multiCapabilities: [{
    browserName: 'firefox'
  }, {
    browserName: 'chrome'
  }],

   jasmineNodeOpts: {
    showColors: true, // Use colors in the command line report.
  }

  // // Starting the Server from a Test Script
  // seleniumServerJar :'',
  // seleniumPort : '',
  // seleniumArgs : ''
  // //Remote Selenium Server
  // //Using BrowserStack as remote Selenium Server
  // browserstackUser :'',
  // browserstackKey :''
  // //Using Sauce Labs as remote Selenium Server
  // sauceUser :'',
  // sauceKey :''

  // //Connecting Directly to Browser Drivers
  // directConnect: true


}


// Setting up PhantomJS
// capabilities: {
//   'browserName': 'phantomjs',

//   /* 
//    * Can be used to specify the phantomjs binary path.
//    * This can generally be ommitted if you installed phantomjs globally.
//    */
//   'phantomjs.binary.path': require('phantomjs').path,

//   /*
//    * Command line args to pass to ghostdriver, phantomjs's browser driver.
//    * See https://github.com/detro/ghostdriver#faq
//    */
//   'phantomjs.ghostdriver.cli.args': ['--loglevel=DEBUG']
// }