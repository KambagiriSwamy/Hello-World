// grab the things we need
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

// create a schema
var exceptionsSchema = new Schema({
 
  code:Number,
  message: String,
  created_at: Date,
  updated_at: Date
});

// the schema is useless so far
// we need to create a model using it
var Exception = mongoose.model('Exception', exceptionsSchema);

// make this available to our users in our Node applications
module.exports = Exception;