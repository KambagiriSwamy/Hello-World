var Exception = require('../models/exception.js');
module.exports = function (req, res) {
    var newException = new Exception({
        code: req.body.code, created_at:new Date(), updated_at: new Date(),
        message: req.body.message,
    });
    newException.save((err) => { if (err) { console.log(err); console.log('saved successffully!') } })
};