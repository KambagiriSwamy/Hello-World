import { NodeAPIPage } from './app.po';

describe('node-api App', function() {
  let page: NodeAPIPage;

  beforeEach(() => {
    page = new NodeAPIPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
