var Homepage = function() {

  var username = element(by.model('username'));

  this.setName = function(name) {
    username.sendKeys(name);
  };

  this.inputButtonClick = function(){
    element(by.id('b1')).click();
  };

  this.get = function() {
    browser.get('http://localhost:3000/index');
  };

  this.getTitle = function(){
    return browser.getTitle();
  };

};



describe('Protractor Demo App', function() {

  var AppHomePage;

	beforeEach(function(){
		AppHomePage = new Homepage();
    AppHomePage.get();
	});

  it('should have a title', function() {
    
    expect(AppHomePage.getTitle()).toEqual('Protractor Example');

  });

  it('should enter text and trigger click event', function(){

    AppHomePage.setName('Kambagiri Swamy');
    AppHomePage.inputButtonClick();

  	var EC = protractor.ExpectedConditions;
  	// Waits for an alert pops up.
  	browser.wait(EC.alertIsPresent(), 5000);
  });
});